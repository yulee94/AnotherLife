using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace AnotherLife.StoryCombat.V2
{
    public static class CombatCodec
    {
        public const int MaximumBytes = 65536;
        static readonly Encoding Utf8 = new UTF8Encoding(false, true);
        static void Text(BinaryWriter w, string text)
        { var bytes = Utf8.GetBytes(text); Check.Require(bytes.Length <= 128); w.Write((ushort)bytes.Length); w.Write(bytes); }
        static string Text(BinaryReader r)
        { int n = r.ReadUInt16(); Check.Require(n <= 128); var bytes = r.ReadBytes(n); Check.Require(bytes.Length == n); return Utf8.GetString(bytes); }
        static bool Bool(BinaryReader r) { byte b = r.ReadByte(); Check.Require(b <= 1); return b == 1; }
        public static byte[] Encode(CombatInput input)
        {
            Check.Require(input != null);
            using (var stream = new MemoryStream()) using (var w = new BinaryWriter(stream, Utf8, true))
            {
                Text(w, "anotherlife-combat-input-v2-d3-candidate"); Text(w, CombatInput.EngineVersion); Text(w, input.ContentId); Text(w, input.ContentRevision);
                var rules = input.Rules; w.Write(rules.Scale); w.Write(rules.DefenseK); w.Write(rules.MaximumEffects); w.Write(rules.MaximumEvents); w.Write(rules.MaximumCommands); w.Write(rules.ReadinessThreshold);
                w.Write((byte)input.Units.Count);
                foreach (var u in input.Units)
                {
                    Text(w, u.Id); w.Write((byte)u.Side); w.Write(u.MaximumHp); w.Write(u.Offense); w.Write(u.Armor); w.Write(u.Resistance); w.Write(u.Speed); w.Write((byte)u.Skills.Count);
                    foreach (var s in u.Skills)
                    {
                        Text(w, s.Id); w.Write((byte)s.Selection); w.Write(s.MaximumTargets); w.Write(s.SecondaryScale); w.Write(s.Penetration); w.Write(s.Area); w.Write(s.BypassCover); w.Write(s.PrimaryInterceptable); w.Write(s.HpCostCoefficient); w.Write(s.IsUltimate); w.Write(s.LifestealCoefficient); w.Write(s.LifestealCap); w.Write(s.UseAimForPrimaryCoverBypass); w.Write((byte)s.Classification); w.Write(s.AllowConcealedPrimaryReveal); w.Write((byte)s.Followup); w.Write(s.KillConcealTurns); w.Write(s.SurvivorDefenseDelta); w.Write(s.SurvivorDefenseTurns); w.Write((byte)s.SurvivorDefenseKind); w.Write((byte)s.Effects.Count);
                        foreach (var e in s.Effects) { w.Write((byte)e.Kind); w.Write((byte)e.Targets); w.Write(e.Value); w.Write(e.Turns); w.Write((byte)e.DamageKind); w.Write(e.Beneficial); w.Write(e.Removable); w.Write(e.BarrierOnly); w.Write((byte)e.Predicate); w.Write(e.Threshold); w.Write(e.Charges); w.Write(e.StackCap); w.Write(e.LifestealCap); w.Write(e.RequiredEmpoweredTargetLimit); w.Write(e.EmpoweredSecondaryDamage); w.Write(e.EmpoweredSecondaryScale); w.Write(e.PostEmpowerDamageTakenIncrease); w.Write(e.PostEmpowerTurns); }
                    }
                }
                w.Flush(); Check.Require(stream.Length <= MaximumBytes); return stream.ToArray();
            }
        }
        public static CombatInput Decode(byte[] bytes)
        {
            Check.Require(bytes != null && bytes.Length <= MaximumBytes);
            try
            {
                using (var stream = new MemoryStream(bytes, false)) using (var r = new BinaryReader(stream, Utf8, true))
                {
                    Check.Require(Text(r) == "anotherlife-combat-input-v2-d3-candidate" && Text(r) == CombatInput.EngineVersion);
                    string content = Text(r), revision = Text(r);
                    var rules = new CombatRules(r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32());
                    int count = r.ReadByte(); Check.Require(count >= 6 && count <= 10); var units = new CombatantInput[count];
                    for (int i = 0; i < count; i++)
                    {
                        string id = Text(r); var side = (Side)r.ReadByte(); int hp = r.ReadInt32(), offense = r.ReadInt32(), armor = r.ReadInt32(), resistance = r.ReadInt32(), speed = r.ReadInt32();
                        int skillCount = r.ReadByte(); Check.Require(skillCount >= 1 && skillCount <= 6); var skills = new CombatSkill[skillCount];
                        for (int j = 0; j < skillCount; j++)
                        {
                            string skillId = Text(r); var selection = (Selection)r.ReadByte(); int max = r.ReadInt32(), secondary = r.ReadInt32(), penetration = r.ReadInt32(); bool area = Bool(r), bypass = Bool(r), interceptable = Bool(r); int hpCost = r.ReadInt32(); bool ultimate = Bool(r); int lifesteal = r.ReadInt32(), lifestealCap = r.ReadInt32(); bool aim = Bool(r); var classification = (ActionClass)r.ReadByte(); bool revealPrimary = Bool(r); var followup = (OutcomeFollowup)r.ReadByte(); int concealTurns = r.ReadInt32(), defenseDelta = r.ReadInt32(), defenseTurns = r.ReadInt32(); var defenseKind = (DamageKind)r.ReadByte();
                            int effectCount = r.ReadByte(); Check.Require(effectCount >= 1 && effectCount <= 16); var effects = new CombatEffect[effectCount];
                            for (int k = 0; k < effectCount; k++) effects[k] = new CombatEffect((EffectKind)r.ReadByte(), (EffectTargets)r.ReadByte(), r.ReadInt32(), r.ReadInt32(), (DamageKind)r.ReadByte(), Bool(r), Bool(r), Bool(r), (EffectPredicate)r.ReadByte(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), r.ReadInt32(), Bool(r), r.ReadInt32(), r.ReadInt32(), r.ReadInt32());
                            skills[j] = new CombatSkill(skillId, selection, max, effects, secondary, penetration, area, bypass, interceptable, hpCost, ultimate, lifesteal, lifestealCap, aim, classification, revealPrimary, followup, concealTurns, defenseDelta, defenseTurns, defenseKind);
                        }
                        units[i] = new CombatantInput(id, side, hp, offense, armor, resistance, speed, skills);
                    }
                    Check.Require(stream.Position == stream.Length); return new CombatInput(content, revision, rules, units);
                }
            }
            catch (Exception e) when (e is EndOfStreamException || e is DecoderFallbackException || e is ArgumentException)
            { throw new InvalidDataException("COMBAT-V2-INVALID", e); }
        }
        public static string Digest(byte[] bytes)
        { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        internal static string StateHash(Frame f, IEnumerable<CombatReceipt> receipts, string inputHash)
        {
            using (var stream = new MemoryStream()) using (var w = new BinaryWriter(stream, Utf8, true))
            {
                Text(w, "anotherlife-combat-state-v2-d3-candidate"); Text(w, inputHash); w.Write(f.Version); w.Write(f.Turn); w.Write(f.Sequence); w.Write((byte)f.Outcome);
                w.Write(f.Position); w.Write(f.Queue.Length); foreach (int slot in f.Queue) w.Write(slot);
                w.Write(f.CompletedOwnerTurns.Length); foreach (long completed in f.CompletedOwnerTurns) w.Write(completed);
                w.Write(f.Readiness.Length); foreach (int ready in f.Readiness) w.Write(ready); w.Write(f.Hp.Length); foreach (int hp in f.Hp) w.Write(hp);
                w.Write(f.Statuses.Count);
                foreach (var s in f.Statuses.OrderBy(s => s.Sequence))
                { w.Write((byte)s.Kind); w.Write((byte)s.DamageKind); w.Write(s.Source); w.Write(s.Target); Text(w, s.Skill); w.Write(s.Amount); w.Write(s.Turns); w.Write(s.Sequence); w.Write(s.AppliedTurn); w.Write(s.FirstEligibleOwnerTurn); w.Write(s.Charges); w.Write(s.LifestealCap); w.Write(s.RequiredEmpoweredTargetLimit); w.Write(s.EmpoweredSecondaryScale); w.Write(s.PostEmpowerDamageTakenIncrease); w.Write(s.PostEmpowerTurns); w.Write(s.Beneficial); w.Write(s.Removable); }
                var rows = receipts.Where(r => r.Recorded && !r.Replayed).ToArray(); w.Write(rows.Length);
                foreach (var row in rows)
                {
                    var c = row.Command; Text(w, c.Nonce); w.Write(c.ExpectedVersion); Text(w, c.Actor); Text(w, c.Skill); w.Write(c.Primary); w.Write((byte)c.Mode); w.Write(c.ExpectedWindowSequence);
                    w.Write(c.Secondary.Count); foreach (int target in c.Secondary) w.Write(target); Text(w, row.Diagnostic);
                    w.Write(row.DamageResults.Count);
                    foreach (var p in row.DamageResults) { w.Write(p.ActualRecipient); w.Write(p.IntendedTarget); w.Write(p.IsPrimary); w.Write(p.CoverBypassed); w.Write((byte)p.Origin); w.Write(p.PostMitigationAmount); w.Write(p.BarrierAbsorbed); w.Write(p.HpRemoved); }
                }
                w.Flush(); return Digest(stream.ToArray());
            }
        }
    }
}

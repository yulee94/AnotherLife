using System;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    internal sealed class ChargedEffects
    {
        readonly Status[] modifiers, marks;
        readonly bool[] eligible;
        internal ChargedEffects(CombatInput input, Frame frame, CombatSkill skill, int[] selected, ActionContext context, ActionProjection projection, int primary)
        {
            int actor = frame.Actor; eligible = new bool[frame.Hp.Length];
            foreach (var effect in skill.Effects.Where(e => e.Kind == EffectKind.Damage))
            {
                var targets = effect.Targets == EffectTargets.Self ? new[] { actor } : effect.Targets == EffectTargets.Team ?
                    Enumerable.Range(0, frame.Hp.Length).Where(i => input.Units[i].Side == input.Units[actor].Side).ToArray() : selected;
                foreach (int target in targets)
                    if (projection.Routes(skill, effect, target, primary) && frame.Hp[target] > 0 && input.Units[target].Side != input.Units[actor].Side && context.Matches(input, effect, actor, target)) eligible[target] = true;
            }
            modifiers = frame.Statuses.Where(s => s.Kind == EffectKind.NextOffenseModifier && s.Target == actor && eligible.Any(x => x)).Select(s => s.Copy()).ToArray();
            marks = frame.Statuses.Where(s => s.Kind == EffectKind.SourceMark && s.Source == actor && eligible[s.Target]).Select(s => s.Copy()).ToArray();
        }
        internal long Adjust(CombatInput input, int intendedTarget, long raw)
        {
            if (!eligible[intendedTarget]) return raw;
            long adjustment = 0;
            foreach (var s in modifiers.Concat(marks.Where(s => s.Target == intendedTarget))) adjustment = checked(adjustment + s.Amount);
            adjustment = Math.Max(-input.Rules.Scale, Math.Min(input.Rules.Scale, adjustment));
            return adjustment == 0 ? raw : checked(raw * (input.Rules.Scale + adjustment)) / input.Rules.Scale;
        }
        internal void Consume(Frame frame, ActionBudget budget)
        {
            foreach (var snapshot in modifiers.Concat(marks).OrderBy(s => s.Sequence))
            {
                var live = frame.Statuses.SingleOrDefault(s => s.Sequence == snapshot.Sequence);
                if (live == null) continue;
                budget.Spend(); live.Charges--;
                if (live.Charges == 0) frame.Statuses.Remove(live);
            }
        }
        internal static void PayCost(Frame frame, CombatSkill skill, int scale, ActionBudget budget)
        {
            if (skill.HpCostCoefficient == 0) return;
            int actor = frame.Actor, hp = frame.Hp[actor];
            if (hp <= 1) throw new PlanRefused("HP-COST-UNAVAILABLE");
            long cost = Math.Min(hp - 1L, Math.Max(1L, checked((long)hp * skill.HpCostCoefficient) / scale));
            budget.Spend(); frame.Hp[actor] = checked(hp - (int)cost);
        }
        internal static void Store(CombatInput input, Frame frame, int actor, int target, CombatSkill skill, CombatEffect effect, long amount)
        {
            if (effect.Kind == EffectKind.Poison)
            {
                var owned = frame.Statuses.Where(s => s.Kind == EffectKind.Poison && s.Source == actor && s.Target == target).OrderBy(s => s.Sequence).ToArray();
                if (owned.Length >= effect.StackCap) frame.Statuses.Remove(owned[0]);
            }
            else if (effect.Kind == EffectKind.SourceMark)
                frame.Statuses.RemoveAll(s => s.Kind == EffectKind.SourceMark && s.Source == actor && s.Target == target);
            else if (effect.Kind == EffectKind.NextOffenseModifier || effect.Kind == EffectKind.Barrier || effect.Kind == EffectKind.NextLifestealWindow || effect.Kind == EffectKind.Aim || effect.Kind == EffectKind.DamageTakenIncrease)
                frame.Statuses.RemoveAll(s => s.Kind == effect.Kind && s.Source == actor && s.Target == target && s.Skill == skill.Id);
            else
                frame.Statuses.RemoveAll(s => s.Source == actor && s.Target == target && s.Skill == skill.Id && s.Kind == effect.Kind && s.DamageKind == effect.DamageKind);
            if (frame.Statuses.Count(s => s.Target == target) >= input.Rules.MaximumEffects) throw new PlanRefused("EFFECT-CAPACITY");
            frame.Statuses.Add(new Status { Source = actor, Target = target, Skill = skill.Id, Kind = effect.Kind, DamageKind = effect.DamageKind,
                RequiredEmpoweredTargetLimit = effect.RequiredEmpoweredTargetLimit, EmpoweredSecondaryScale = effect.EmpoweredSecondaryScale, PostEmpowerDamageTakenIncrease = effect.PostEmpowerDamageTakenIncrease, PostEmpowerTurns = effect.PostEmpowerTurns, LifestealCap = effect.LifestealCap, Amount = amount, Turns = effect.Turns, Charges = effect.Charges, AppliedTurn = frame.Turn,
                FirstEligibleOwnerTurn = checked(frame.CompletedOwnerTurns[target] + (target == actor ? 2L : 1L)),
                Sequence = checked(++frame.Sequence), Beneficial = effect.Beneficial, Removable = effect.Removable });
        }
    }
}
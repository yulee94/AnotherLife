using System;
using System.Collections.Generic;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    internal sealed class Status
    {
        internal EffectKind Kind; internal DamageKind DamageKind; internal int Source, Target, Turns;
        internal string Skill = ""; internal long Amount, Sequence, AppliedTurn;
        internal int RequiredEmpoweredTargetLimit, EmpoweredSecondaryScale, PostEmpowerDamageTakenIncrease, PostEmpowerTurns, LifestealCap, Charges; internal long FirstEligibleOwnerTurn; internal bool Beneficial, Removable;
        internal Status Copy() => (Status)MemberwiseClone();
    }
    internal sealed class Frame
    {
        internal long[] CompletedOwnerTurns = Array.Empty<long>(); internal int[] Readiness = Array.Empty<int>(), Hp = Array.Empty<int>(), Queue = Array.Empty<int>(); internal int Position;
        internal long Version = 1, Turn = 1, Sequence; internal BattleOutcome Outcome;
        internal List<Status> Statuses = new List<Status>();
        internal int Actor => Outcome == BattleOutcome.Active ? Queue[Position] : -1;
        internal Frame Copy() => new Frame { Readiness = (int[])Readiness.Clone(), CompletedOwnerTurns = (long[])CompletedOwnerTurns.Clone(), Hp = (int[])Hp.Clone(), Queue = (int[])Queue.Clone(), Position = Position,
            Version = Version, Turn = Turn, Sequence = Sequence, Outcome = Outcome, Statuses = Statuses.Select(s => s.Copy()).ToList() };
    }
    internal sealed class ActionBudget
    {
        int left; internal bool CoverUsed;
        internal ActionBudget(int limit) { left = limit; }
        internal void Spend() { if (--left < 0) throw new PlanRefused("EVENT-CAPACITY"); }
    }
    internal sealed class PlanRefused : Exception { internal PlanRefused(string code) : base(code) { } }

    public static class CombatReplay
    {
        internal static int[] Queue(CombatInput input, Frame frame) => Enumerable.Range(0, input.Units.Count)
            .Where(i => frame.Hp[i] > 0).OrderByDescending(i => ActionContext.EffectiveSpeed(input, frame, i)).ThenBy(i => input.Units[i].Side).ThenBy(i => i).ToArray();
        public static CombatResult Replay(CombatInput input, IEnumerable<CombatCommand> commands) => ReplayCore(input, commands, out _);
        internal static CombatResult ReplayCore(CombatInput input, IEnumerable<CombatCommand> commands, out Frame frame)
        {
            Check.Require(input != null && commands != null);
            frame = new Frame { Readiness = new int[input.Units.Count], CompletedOwnerTurns = new long[input.Units.Count], Hp = input.Units.Select(x => x.MaximumHp).ToArray() }; frame.Queue = Queue(input, frame);
            var receipts = new List<CombatReceipt>(); var seen = new Dictionary<string, CombatReceipt>(StringComparer.Ordinal); int count = 0;
            foreach (var command in commands)
            {
                Check.Require(++count <= input.Rules.MaximumCommands + 1 && command != null);
                bool structural = Check.Defined(command.Mode) && (command.Mode == ActionMode.Normal ? command.ExpectedWindowSequence == 0 : command.ExpectedWindowSequence > 0) && Check.Nonce(command.Nonce) && Check.Id(command.Actor) && Check.Id(command.Skill) && command.ExpectedVersion > 0 &&
                    command.Primary >= 0 && command.Primary < input.Units.Count && command.Secondary.Count <= 4 &&
                    command.Secondary.All(i => i >= 0 && i < input.Units.Count) && command.Secondary.Distinct().Count() == command.Secondary.Count && !command.Secondary.Contains(command.Primary);
                if (!structural) { receipts.Add(new CombatReceipt(command, "COMMAND-INVALID", false, false)); continue; }
                if (seen.TryGetValue(command.Nonce, out var previous))
                {
                    receipts.Add(command.Same(previous.Command) ? new CombatReceipt(previous.Command, previous.Diagnostic, true, true, previous.DamageResults) : new CombatReceipt(command, "REQUEST-CONFLICT", false, false));
                    continue;
                }
                if (seen.Count >= input.Rules.MaximumCommands) { receipts.Add(new CombatReceipt(command, "CAPACITY", false, false)); continue; }
                string diagnostic = ""; IEnumerable<PacketDamageResult>? damageResults = null;
                if (frame.Outcome != BattleOutcome.Active) diagnostic = "FINISHED";
                else if (command.ExpectedVersion != frame.Version || frame.Version == long.MaxValue) diagnostic = "VERSION-CONFLICT";
                else if (command.Actor != input.Units[frame.Actor].Id) diagnostic = "NOT-YOUR-TURN";
                else
                {
                    var skill = input.Units[frame.Actor].Skills.SingleOrDefault(x => x.Id == command.Skill);
                    if (skill == null) diagnostic = "SKILL-UNAVAILABLE";
                    else
                    {
                        var projection = ActionProjection.Build(input, frame, skill, command.Primary, false);
                        var targets = projection.Diagnostic.Length == 0 ? TargetRules.Resolve(input, frame, frame.Actor, skill, command, projection.Empowered) : null;
                        if (projection.Diagnostic.Length != 0) diagnostic = projection.Diagnostic;
                        else if (targets == null) diagnostic = "TARGET-INVALID";
                        else if (skill.IsUltimate && frame.Readiness[frame.Actor] < input.Rules.ReadinessThreshold) diagnostic = "ULTIMATE-NOT-READY";
                        else if (projection.Validate(command).Length != 0) diagnostic = projection.Validate(command);
                        else
                        {
                            var candidate = frame.Copy();
                            try
                            {
                                var budget = new ActionBudget(input.Rules.MaximumEvents);
                                var context = new ActionContext(frame);
                                var charges = new ChargedEffects(input, frame, skill, targets, context, projection, command.Primary);
                                var results = new RootActionResults(input, frame, skill, command.Primary, targets, context, projection);
                                results.Begin(candidate, budget);
                                ChargedEffects.PayCost(candidate, skill, input.Rules.Scale, budget);
                                EffectResolver.Apply(input, candidate, skill, command.Primary, targets, budget, context, charges, results, projection);
                                charges.Consume(candidate, budget);
                                ActionContext.BreakConcealment(candidate, skill, budget);
                                results.Finish(candidate, budget); OutcomeFollowups.Resolve(input, candidate, skill, command.Primary, results, budget); TurnScheduler.Finish(input, candidate, budget); candidate.Version++; frame = candidate; damageResults = results.Packets;
                            }
                            catch (PlanRefused e) { diagnostic = e.Message; }
                            catch (OverflowException) { diagnostic = "ARITHMETIC-CAPACITY"; }
                        }
                    }
                }
                var receipt = new CombatReceipt(command, diagnostic, false, true, damageResults); seen.Add(command.Nonce, receipt); receipts.Add(receipt);
            }
            string inputHash = CombatCodec.Digest(CombatCodec.Encode(input));
            return new CombatResult(frame, receipts.AsReadOnly(), inputHash, CombatCodec.StateHash(frame, receipts, inputHash));
        }
    }
    internal static class TargetRules
    {
        internal static int[]? Resolve(CombatInput input, Frame frame, int actor, CombatSkill skill, CombatCommand command, bool empowered = false)
        {
            bool Enemy(int i) => input.Units[i].Side != input.Units[actor].Side;
            bool Living(int i) => frame.Hp[i] > 0;
            bool hostile = skill.Selection == Selection.Enemy || skill.Selection == Selection.UpToEnemies || skill.Selection == Selection.AllEnemies;
            if (!Living(command.Primary)) return null;
            if (skill.Selection == Selection.Self && command.Primary != actor) return null;
            if (skill.Selection != Selection.Self && hostile != Enemy(command.Primary)) return null;
            if (!empowered && skill.Selection != Selection.UpToEnemies && command.Secondary.Count != 0) return null;
            if (hostile && skill.Selection != Selection.AllEnemies)
            {
                var taunt = frame.Statuses.Where(s => s.Kind == EffectKind.Taunt && s.Target == actor && Living(s.Source) && Enemy(s.Source) && !ActionContext.Hidden(frame, s.Source)).OrderByDescending(s => s.Sequence).FirstOrDefault();
                if (taunt != null && command.Primary != taunt.Source) return null;
            }
            if (skill.Selection == Selection.AllEnemies || skill.Selection == Selection.AllAllies)
                return Enumerable.Range(0, input.Units.Count).Where(i => Living(i) && Enemy(i) == hostile).ToArray();
            var selected = new[] { command.Primary }.Concat(command.Secondary).ToArray();
            if (selected.Length > (empowered ? 2 : skill.MaximumTargets) || selected.Any(i => !Living(i) || (hostile && ActionContext.Hidden(frame, i) && !(skill.AllowConcealedPrimaryReveal && i == command.Primary)) || (skill.Selection != Selection.Self && Enemy(i) != hostile))) return null;
            return selected.OrderBy(i => i).ToArray();
        }
    }
    internal static class TurnScheduler
    {
        internal static void Finish(CombatInput input, Frame f, ActionBudget budget)
        {
            int actor = f.Actor;
            TimedEffects.FinishOwnerTurn(input, f, actor, budget);
            f.Statuses.RemoveAll(s => s.Turns <= 0 || f.Hp[s.Target] == 0);
            bool party = Enumerable.Range(0, f.Hp.Length).Any(i => input.Units[i].Side == Side.Party && f.Hp[i] > 0);
            bool enemy = Enumerable.Range(0, f.Hp.Length).Any(i => input.Units[i].Side == Side.Enemy && f.Hp[i] > 0);
            if (!party) f.Outcome = BattleOutcome.Defeat; else if (!enemy) f.Outcome = BattleOutcome.Victory;
            if (f.Outcome != BattleOutcome.Active) return;
            do { f.Position++; } while (f.Position < f.Queue.Length && f.Hp[f.Queue[f.Position]] == 0);
            if (f.Position == f.Queue.Length) { f.Queue = CombatReplay.Queue(input, f); f.Position = 0; }
            f.Turn = checked(f.Turn + 1);
        }
    }
    internal static class EffectResolver
    {
        internal static void Apply(CombatInput input, Frame frame, CombatSkill skill, int primary, int[] selected, ActionBudget budget, ActionContext context, ChargedEffects charges, RootActionResults results, ActionProjection projection)
        {
            int actor = frame.Actor;
            foreach (var effect in skill.Effects)
            {
                int[] targets = effect.Targets == EffectTargets.Self ? new[] { actor } : effect.Targets == EffectTargets.Team ?
                    Enumerable.Range(0, frame.Hp.Length).Where(i => input.Units[i].Side == input.Units[actor].Side && frame.Hp[i] > 0).ToArray() : selected;
                foreach (int target in targets)
                {
                    if (!projection.Routes(skill, effect, target, primary)) continue;
                    budget.Spend(); if (frame.Hp[target] <= 0 || !context.Matches(input, effect, actor, target)) continue;
                    bool ally = input.Units[target].Side == input.Units[actor].Side;
                    if ((effect.Kind == EffectKind.Damage || effect.Kind == EffectKind.Taunt || effect.Kind == EffectKind.HealingReduction || effect.Kind == EffectKind.Reveal || effect.Kind == EffectKind.SourceMark || effect.Kind == EffectKind.Poison || effect.Kind == EffectKind.Dispel || effect.Kind == EffectKind.DamageTakenIncrease && effect.Targets != EffectTargets.Self) && ally ||
                        (effect.Kind == EffectKind.Heal || effect.Kind == EffectKind.DelayedHeal || effect.Kind == EffectKind.Barrier || effect.Kind == EffectKind.Cover || effect.Kind == EffectKind.Conceal || effect.Kind == EffectKind.AreaReduction || effect.Kind == EffectKind.Cleanse || effect.Kind == EffectKind.NextLifestealWindow || effect.Kind == EffectKind.Aim) && !ally ||
                        (effect.Kind == EffectKind.Defense || effect.Kind == EffectKind.SpeedModifier || effect.Kind == EffectKind.NextOffenseModifier) && effect.Beneficial != ally) throw new PlanRefused("EFFECT-TARGET-INVALID");
                    long amount = effect.Value;
                    if (effect.Kind == EffectKind.Damage || effect.Kind == EffectKind.Heal || effect.Kind == EffectKind.DelayedHeal || effect.Kind == EffectKind.Poison || effect.Kind == EffectKind.Barrier)
                    {
                        amount = checked((long)input.Units[actor].Offense * effect.Value) / input.Rules.Scale;
                        if (effect.Targets == EffectTargets.Selected && target != primary && (skill.Selection == Selection.UpToEnemies || projection.Empowered))
                        {
                            int secondaryScale = projection.Empowered && effect.Kind == EffectKind.Damage && effect.EmpoweredSecondaryDamage ? projection.SecondaryScale : skill.SecondaryScale;
                            amount = checked(amount * secondaryScale) / input.Rules.Scale;
                        }
                    }
                    if (effect.Kind == EffectKind.Damage) Damage(input, frame, actor, target, charges.Adjust(input, target, amount), effect.DamageKind, skill, primary, selected.Length, budget, results, projection);
                    else if (effect.Kind == EffectKind.Heal) results.Heal(target, TimedEffects.Heal(input, frame, target, amount));
                    else if (effect.Kind == EffectKind.Dispel || effect.Kind == EffectKind.Cleanse)
                    {
                        bool beneficial = effect.Kind == EffectKind.Dispel;
                        var found = frame.Statuses.Where(s => s.Target == target && s.Removable && s.Beneficial == beneficial && (!effect.BarrierOnly || s.Kind == EffectKind.Barrier)).OrderBy(s => s.Sequence).FirstOrDefault();
                        if (found != null) { results.Removed(found); frame.Statuses.Remove(found); }
                    }
                    else
                    {
                        if (effect.Kind == EffectKind.Cover && target == actor) throw new PlanRefused("COVER-SELF");
                        if (!(effect.Kind == EffectKind.DamageTakenIncrease && target == actor)) results.Touch(actor, target, skill.Id, effect); ChargedEffects.Store(input, frame, actor, target, skill, effect, amount);
                    }
                }
            }
        }
        static void Damage(CombatInput input, Frame f, int actor, int target, long amount, DamageKind kind, CombatSkill skill, int primary, int selectedCount, ActionBudget budget, RootActionResults results, ActionProjection projection)
        {
            // A catalog may mark a multi-shot PRIMARY as a direct interceptable packet; ordinary cleave/area is not Cover-eligible.
            int intended = target; bool bypass = target == primary && (skill.BypassCover || results.AimActive);
            bool single = !projection.Empowered && (skill.Selection == Selection.Enemy || skill.PrimaryInterceptable && target == primary);
            if (single && !skill.Area && !bypass && !budget.CoverUsed)
            {
                var cover = f.Statuses.Where(s => s.Kind == EffectKind.Cover && s.Target == target && f.Hp[s.Source] > 0 && s.Source != target).OrderBy(s => s.Sequence).FirstOrDefault();
                if (cover != null) { target = cover.Source; budget.CoverUsed = true; budget.Spend(); }
            }
            results.Damage(Mitigate(input, f, target, amount, kind, skill.Penetration, skill.Area, budget, DamageOrigin.Root, intended, intended == primary, bypass));
        }
        internal static PacketDamageResult Mitigate(CombatInput input, Frame f, int target, long amount, DamageKind kind, int penetration, bool area, ActionBudget budget, DamageOrigin origin = DamageOrigin.Poison, int intended = -1, bool primary = false, bool bypass = false)
        {
            long defense = kind == DamageKind.Physical ? input.Units[target].Armor : input.Units[target].Resistance;
            foreach (var status in f.Statuses.Where(s => s.Target == target && s.Kind == EffectKind.Defense && s.DamageKind == kind)) defense = checked(defense + status.Amount);
            defense = Math.Max(0, Math.Min(Check.MaxStat, defense));
            defense = checked(defense * (input.Rules.Scale - penetration)) / input.Rules.Scale;
            amount = checked(amount * input.Rules.DefenseK) / checked(input.Rules.DefenseK + defense);
            long increase = f.Statuses.Where(s => s.Target == target && s.Kind == EffectKind.DamageTakenIncrease).Select(s => s.Amount).DefaultIfEmpty(0).Max();
            if (increase > 0) amount = checked(amount * (input.Rules.Scale + increase)) / input.Rules.Scale;
            if (area)
            {
                long reduction = Math.Min(input.Rules.Scale, f.Statuses.Where(s => s.Target == target && s.Kind == EffectKind.AreaReduction).Sum(s => s.Amount));
                amount = checked(amount * (input.Rules.Scale - reduction)) / input.Rules.Scale;
            }
            long mitigated = amount, absorbedTotal = 0; int hpBefore = f.Hp[target];
            foreach (var shield in f.Statuses.Where(s => s.Target == target && s.Kind == EffectKind.Barrier).OrderBy(s => s.Sequence).ToArray())
            { budget.Spend(); long absorbed = Math.Min(amount, shield.Amount); absorbedTotal = checked(absorbedTotal + absorbed); shield.Amount -= absorbed; amount -= absorbed; if (shield.Amount == 0) f.Statuses.Remove(shield); if (amount == 0) break; }
            f.Hp[target] = (int)Math.Max(0L, f.Hp[target] - amount);
            return new PacketDamageResult(target, intended < 0 ? target : intended, primary, bypass, origin, mitigated, absorbedTotal, hpBefore - f.Hp[target]);
        }
    }
}

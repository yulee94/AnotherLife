using System;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    internal static class TimedEffects
    {
        internal static int Heal(CombatInput input, Frame frame, int target, long amount)
        {
            if (frame.Hp[target] <= 0) return 0; int before = frame.Hp[target];
            long reduction = 0;
            foreach (var status in frame.Statuses.Where(s => s.Target == target && s.Kind == EffectKind.HealingReduction))
                reduction = checked(reduction + status.Amount);
            reduction = Math.Min(input.Rules.Scale, reduction);
            if (reduction != 0) amount = checked(amount * (input.Rules.Scale - reduction)) / input.Rules.Scale;
            frame.Hp[target] = (int)Math.Min(input.Units[target].MaximumHp, checked(frame.Hp[target] + amount));
            return frame.Hp[target] - before;
        }
        internal static void FinishOwnerTurn(CombatInput input, Frame frame, int actor, ActionBudget budget)
        {
            if (frame.Hp[actor] <= 0) return;
            long completing = checked(frame.CompletedOwnerTurns[actor] + 1);
            // Snapshot eligibility; all due events resolve before expiry removes modifiers.
            var due = frame.Statuses.Where(s => s.Target == actor && s.FirstEligibleOwnerTurn <= completing)
                .OrderBy(s => s.Sequence).ToArray();
            foreach (var status in due)
            {
                if (frame.Hp[actor] <= 0) break;
                if (!frame.Statuses.Contains(status)) continue; // A previous poison tick may have consumed this barrier.
                budget.Spend();
                if (status.Kind == EffectKind.DelayedHeal && status.Turns == 1)
                    Heal(input, frame, actor, status.Amount);
                if (status.Kind == EffectKind.Poison)
                    EffectResolver.Mitigate(input, frame, actor, status.Amount, DamageKind.Magic, 0, false, budget);
                status.Turns--;
            }
            frame.CompletedOwnerTurns[actor] = completing;
            // Scheduler removes expired and dead-target records after this entire phase.
        }
    }
}
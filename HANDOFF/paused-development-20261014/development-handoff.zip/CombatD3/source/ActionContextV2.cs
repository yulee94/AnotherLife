using System;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    // Private action-start copies. Never persisted or reused across root actions.
    internal sealed class ActionContext
    {
        readonly int[] hp;
        readonly bool[] harmful, hidden; readonly bool[,] ownPoison;
        internal ActionContext(Frame frame)
        {
            hp = (int[])frame.Hp.Clone(); ownPoison = new bool[hp.Length, hp.Length];
            foreach (var s in frame.Statuses.Where(s => s.Kind == EffectKind.Poison)) ownPoison[s.Source, s.Target] = true;
            harmful = new bool[hp.Length]; hidden = new bool[hp.Length];
            for (int i = 0; i < hp.Length; i++)
            {
                harmful[i] = frame.Statuses.Any(s => s.Target == i && !s.Beneficial);
                hidden[i] = Hidden(frame, i);
            }
        }
        internal bool Matches(CombatInput input, CombatEffect effect, int actor, int target)
        {
            switch (effect.Predicate)
            {
                case EffectPredicate.Always: return true;
                case EffectPredicate.TargetInjured:
                    return checked((long)hp[target] * input.Rules.Scale) <= checked((long)input.Units[target].MaximumHp * effect.Threshold);
                case EffectPredicate.TargetHarmfulStatus: return harmful[target];
                case EffectPredicate.ActorConcealed: return hidden[actor];
                case EffectPredicate.TargetOwnPoison: return ownPoison[actor, target];
                default: throw new PlanRefused("PREDICATE-INVALID");
            }
        }
        internal static bool Hidden(Frame frame, int target) => frame.Statuses.Any(s => s.Target == target && s.Kind == EffectKind.Conceal) &&
            !frame.Statuses.Any(s => s.Target == target && s.Kind == EffectKind.Reveal);
        internal static long EffectiveSpeed(CombatInput input, Frame frame, int actor)
        {
            long speed = input.Units[actor].Speed;
            foreach (var s in frame.Statuses.Where(s => s.Target == actor && s.Kind == EffectKind.SpeedModifier)) speed = checked(speed + s.Amount);
            return Math.Max(0, Math.Min(Check.MaxStat, speed));
        }
        internal static void BreakConcealment(Frame frame, CombatSkill skill, ActionBudget budget)
        {
            if (skill.Selection != Selection.Enemy && skill.Selection != Selection.UpToEnemies && skill.Selection != Selection.AllEnemies) return;
            foreach (var status in frame.Statuses.Where(s => s.Target == frame.Actor && s.Kind == EffectKind.Conceal).ToArray())
            { budget.Spend(); frame.Statuses.Remove(status); }
        }
    }
}
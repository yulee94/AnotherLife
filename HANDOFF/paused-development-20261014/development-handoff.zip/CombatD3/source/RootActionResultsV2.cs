using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    public enum DamageOrigin { Root, Poison }
    // Derived audit evidence only: no caller can submit these records as combat input.
    public sealed class PacketDamageResult
    {
        public int ActualRecipient { get; } public int IntendedTarget { get; }
        public bool IsPrimary { get; } public bool CoverBypassed { get; } public DamageOrigin Origin { get; }
        public long PostMitigationAmount { get; } public long BarrierAbsorbed { get; } public int HpRemoved { get; }
        internal PacketDamageResult(int recipient, int intended, bool primary, bool bypass, DamageOrigin origin, long mitigated, long absorbed, int removed)
        { ActualRecipient = recipient; IntendedTarget = intended; IsPrimary = primary; CoverBypassed = bypass; Origin = origin; PostMitigationAmount = mitigated; BarrierAbsorbed = absorbed; HpRemoved = removed; }
    }
    internal sealed class RootActionResults
    {
        readonly CombatInput input; readonly CombatSkill skill; readonly int actor, selectedPrimary, selectedStartingHp;
        readonly Status[] before; readonly long[] ownerTurns; readonly int[] healCredit;
        readonly HashSet<string> touched = new HashSet<string>(StringComparer.Ordinal);
        readonly HashSet<string> removedKeys = new HashSet<string>(StringComparer.Ordinal);
        readonly List<PacketDamageResult> packets = new List<PacketDamageResult>();
        readonly Status? window, aim; bool effective; long rootHpRemoved;
        internal IEnumerable<PacketDamageResult> Packets => packets;
        internal bool SelectedKilledByRoot(Frame frame) => selectedStartingHp > 0 && frame.Hp[selectedPrimary] == 0 && packets.Any(p => p.Origin == DamageOrigin.Root && p.ActualRecipient == selectedPrimary && p.HpRemoved == selectedStartingHp);
        internal bool AimActive => aim != null;
        internal RootActionResults(CombatInput input, Frame start, CombatSkill skill, int primary, int[] selected, ActionContext context, ActionProjection projection)
        {
            this.input = input; this.skill = skill; actor = start.Actor; selectedPrimary = primary; selectedStartingHp = start.Hp[primary];
            before = start.Statuses.Select(s => s.Copy()).ToArray(); ownerTurns = (long[])start.CompletedOwnerTurns.Clone();
            healCredit = start.Hp.Select((hp, i) => input.Units[i].MaximumHp - hp).ToArray();
            bool eligible = skill.Effects.Any(e => e.Kind == EffectKind.Damage && e.Value > 0 && e.Targets == EffectTargets.Selected &&
                selected.Any(t => projection.Routes(skill, e, t, primary) && (t == primary || skill.Selection != Selection.UpToEnemies && !projection.Empowered || projection.SecondaryScale > 0) && start.Hp[t] > 0 && input.Units[t].Side != input.Units[actor].Side && context.Matches(input, e, actor, t)));
            window = eligible ? before.Where(s => s.Target == actor && s.Kind == EffectKind.NextLifestealWindow && (s.RequiredEmpoweredTargetLimit == 0 || projection.Empowered && s.Sequence == projection.WindowSequence)).OrderBy(s => s.Sequence).FirstOrDefault() : null;
            bool primaryEligible = skill.Effects.Any(e => e.Kind == EffectKind.Damage && e.Value > 0 && e.Targets == EffectTargets.Selected && context.Matches(input, e, actor, primary));
            aim = skill.UseAimForPrimaryCoverBypass && primaryEligible ? before.Where(s => s.Target == actor && s.Kind == EffectKind.Aim).OrderBy(s => s.Sequence).FirstOrDefault() : null;
        }
        internal static ActionClass Classify(Selection selection, IEnumerable<CombatEffect> effects)
        {
            bool selectedEnemy = selection == Selection.Enemy || selection == Selection.UpToEnemies || selection == Selection.AllEnemies;
            ActionClass result = ActionClass.None;
            foreach (var e in effects)
            {
                bool hostile = e.Kind == EffectKind.Damage || e.Kind == EffectKind.Dispel || e.Kind == EffectKind.Taunt || e.Kind == EffectKind.HealingReduction || e.Kind == EffectKind.Reveal || e.Kind == EffectKind.SourceMark || e.Kind == EffectKind.Poison ||
                    (e.Kind == EffectKind.Defense || e.Kind == EffectKind.SpeedModifier || e.Kind == EffectKind.NextOffenseModifier) && !e.Beneficial;
                hostile |= e.Kind == EffectKind.DamageTakenIncrease && e.Targets != EffectTargets.Self;
                Check.Require(hostile == (e.Targets == EffectTargets.Selected && selectedEnemy));
                bool zero = (e.Kind == EffectKind.Damage || e.Kind == EffectKind.Heal || e.Kind == EffectKind.Barrier || e.Kind == EffectKind.DelayedHeal || e.Kind == EffectKind.Poison || e.Kind == EffectKind.AreaReduction || e.Kind == EffectKind.HealingReduction || e.Kind == EffectKind.SourceMark) && e.Value == 0;
                if (!zero && !(e.Kind == EffectKind.DamageTakenIncrease && e.Targets == EffectTargets.Self)) result |= hostile ? ActionClass.Offense : ActionClass.Support;
            }
            return result;
        }
        internal void Begin(Frame frame, ActionBudget budget)
        {
            if (!skill.IsUltimate) return;
            if (frame.Readiness[actor] < input.Rules.ReadinessThreshold) throw new PlanRefused("ULTIMATE-NOT-READY");
            frame.Readiness[actor] = 0;
        }
        internal void Damage(PacketDamageResult packet)
        {
            packets.Add(packet);
            if (packet.Origin != DamageOrigin.Root) return;
            rootHpRemoved = checked(rootHpRemoved + packet.HpRemoved);
            effective |= packet.PostMitigationAmount > 0;
        }
        internal void Heal(int target, int restored)
        {
            int credit = Math.Min(healCredit[target], restored); healCredit[target] -= credit; effective |= credit > 0;
        }
        static string Key(Status s) => ((int)s.Kind).ToString(CultureInfo.InvariantCulture) + ":" + s.Source + ":" + s.Target + ":" +
            (s.Kind == EffectKind.SourceMark || s.Kind == EffectKind.Poison ? "" : s.Skill) + ":" + (s.Kind == EffectKind.Defense ? (int)s.DamageKind : 0);
        internal void Touch(Status status) { touched.Add(Key(status)); }
        internal void Removed(Status status) { Touch(status); removedKeys.Add(Key(status)); }
        internal void Touch(int source, int target, string id, CombatEffect effect) => Touch(new Status { Source = source, Target = target, Skill = id, Kind = effect.Kind, DamageKind = effect.DamageKind });
        string Signature(Status s)
        {
            long expiry = checked(Math.Max(ownerTurns[s.Target] + 1, s.FirstEligibleOwnerTurn) + s.Turns - 1);
            return string.Join("/", s.Amount.ToString(CultureInfo.InvariantCulture), s.Charges.ToString(CultureInfo.InvariantCulture), expiry.ToString(CultureInfo.InvariantCulture), s.Beneficial ? "1" : "0", s.Removable ? "1" : "0", s.LifestealCap.ToString(CultureInfo.InvariantCulture), s.RequiredEmpoweredTargetLimit.ToString(CultureInfo.InvariantCulture), s.EmpoweredSecondaryScale.ToString(CultureInfo.InvariantCulture), s.PostEmpowerDamageTakenIncrease.ToString(CultureInfo.InvariantCulture), s.PostEmpowerTurns.ToString(CultureInfo.InvariantCulture));
        }
        static bool Meaningful(Status s) => s.Amount != 0 || s.Kind == EffectKind.Cover || s.Kind == EffectKind.Taunt || s.Kind == EffectKind.Conceal || s.Kind == EffectKind.Reveal || s.Kind == EffectKind.Aim;
        internal void Finish(Frame frame, ActionBudget budget)
        {
            foreach (string key in touched)
            {
                var old = before.Where(s => Key(s) == key && (Meaningful(s) || removedKeys.Contains(key))).ToArray();
                var now = frame.Statuses.Where(s => Key(s) == key && (Meaningful(s) || removedKeys.Contains(key))).ToArray();
                // Legacy generic keys can retain multiple irrelevant-DamageKind records. Do not invent a profile migration here.
                bool stackable = old.Concat(now).All(s => s.Kind == EffectKind.Poison);
                if (!removedKeys.Contains(key) && (!stackable && (old.Length > 1 || now.Length > 1) || now.Length == 0)) continue;
                if (!old.Select(Signature).OrderBy(x => x, StringComparer.Ordinal).SequenceEqual(now.Select(Signature).OrderBy(x => x, StringComparer.Ordinal))) effective = true;
            }
            foreach (var snapshot in new[] { window, aim }.Where(s => s != null).OrderBy(s => s!.Sequence))
            {
                var live = frame.Statuses.SingleOrDefault(s => s.Sequence == snapshot!.Sequence);
                if (live != null) { budget.Spend(); frame.Statuses.Remove(live); }
            }
            long coefficient = window?.Amount ?? skill.LifestealCoefficient;
            int cap = window?.LifestealCap ?? skill.LifestealCap;
            long heal = Math.Min(cap, checked(rootHpRemoved * coefficient) / input.Rules.Scale);
            if (heal > 0) { budget.Spend(); TimedEffects.Heal(input, frame, actor, heal); }
            if (window != null && window.RequiredEmpoweredTargetLimit == 2)
            {
                budget.Spend();
                frame.Statuses.RemoveAll(s => s.Kind == EffectKind.DamageTakenIncrease && s.Source == window.Source && s.Target == actor && s.Skill == window.Skill);
                if (frame.Statuses.Count(s => s.Target == actor) >= input.Rules.MaximumEffects) throw new PlanRefused("EFFECT-CAPACITY");
                frame.Statuses.Add(new Status { Kind = EffectKind.DamageTakenIncrease, DamageKind = DamageKind.Physical, Source = window.Source, Target = actor, Skill = window.Skill,
                    Amount = window.PostEmpowerDamageTakenIncrease, Turns = window.PostEmpowerTurns, Beneficial = false, Removable = true, Sequence = checked(++frame.Sequence), AppliedTurn = frame.Turn,
                    FirstEligibleOwnerTurn = checked(frame.CompletedOwnerTurns[actor] + 2) });
            }
            if (!skill.IsUltimate && effective) frame.Readiness[actor] = Math.Min(input.Rules.ReadinessThreshold, frame.Readiness[actor] + 1);
        }
    }
}
namespace AnotherLife.StoryCombat.V2
{
    // One bounded post-root branch, not an event subscription or recursive action mechanism.
    internal static class OutcomeFollowups
    {
        internal static void Resolve(CombatInput input, Frame frame, CombatSkill skill, int primary, RootActionResults results, ActionBudget budget)
        {
            if (skill.Followup == OutcomeFollowup.None || frame.Hp[frame.Actor] <= 0) return;
            CombatEffect effect; int target;
            if (results.SelectedKilledByRoot(frame))
            {
                target = frame.Actor;
                effect = new CombatEffect(EffectKind.Conceal, EffectTargets.Self, 0, skill.KillConcealTurns);
            }
            else if (frame.Hp[primary] > 0)
            {
                target = primary;
                effect = new CombatEffect(EffectKind.Defense, EffectTargets.Selected, skill.SurvivorDefenseDelta, skill.SurvivorDefenseTurns, skill.SurvivorDefenseKind, false);
            }
            else return; // A future non-root death is not a selected root kill.
            budget.Spend();
            ChargedEffects.Store(input, frame, frame.Actor, target, skill, effect, effect.Value);
            // No readiness touch, damage callback, lifesteal, charge consumption, or second branch.
        }
    }
}
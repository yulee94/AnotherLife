using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    [Flags] public enum ActionClass { None = 0, Offense = 1, Support = 2, Mixed = 3 }
    public enum OutcomeFollowup { None, SelectedKillConcealElseDefense }
    public enum ActionMode { Normal, Empowered }
    public enum Side { Party, Enemy }
    public enum Selection { Self, Ally, Enemy, UpToEnemies, AllEnemies, AllAllies }
    public enum EffectKind { Damage, Heal, Barrier, Defense, Taunt, Cover, AreaReduction, Dispel, Cleanse, DelayedHeal, HealingReduction, SpeedModifier, Conceal, Reveal, NextOffenseModifier, SourceMark, Poison, NextLifestealWindow, Aim, DamageTakenIncrease }
    public enum EffectPredicate { Always, TargetInjured, TargetHarmfulStatus, ActorConcealed, TargetOwnPoison }
    public enum DamageKind { Physical, Magic }
    public enum EffectTargets { Selected, Self, Team }
    public enum BattleOutcome { Active, Victory, Defeat }

    // Safety bounds are format limits, not balance or hero data. All combat coefficients are input data.
    internal static class Check
    {
        internal const int MaxStat = 10000000;
        internal static void Require(bool ok) { if (!ok) throw new InvalidDataException("COMBAT-V2-INVALID"); }
        internal static bool Id(string value) => value != null && value.Length > 0 && value.Length <= 128 &&
            value.All(c => Character.IsAsciiLetterOrDigitCompat(c) || c == '_' || c == '-' || c == '.');
        internal static bool Nonce(string value) => value != null && value.Length == 32 && value.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f');
        internal static bool Defined<T>(T value) where T : struct => Enum.IsDefined(typeof(T), value);
    }
    internal static class Character
    {
        internal static bool IsAsciiLetterOrDigitCompat(char c) => c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9';
    }
    public sealed class CombatRules
    {
        public int Scale { get; } public int DefenseK { get; } public int MaximumEffects { get; }
        public int ReadinessThreshold { get; } public int MaximumEvents { get; } public int MaximumCommands { get; }
        public CombatRules(int scale, int defenseK, int effects, int events, int commands, int readinessThreshold = 3)
        {
            Check.Require(readinessThreshold >= 1 && readinessThreshold <= 1000); ReadinessThreshold = readinessThreshold;
            Check.Require(scale >= 1 && scale <= 1000000 && defenseK >= 1 && defenseK <= Check.MaxStat &&
                effects >= 1 && effects <= 128 && events >= 1 && events <= 4096 && commands >= 1 && commands <= 10000);
            Scale = scale; DefenseK = defenseK; MaximumEffects = effects; MaximumEvents = events; MaximumCommands = commands;
        }
    }
    public sealed class CombatEffect
    {
        public EffectKind Kind { get; } public EffectTargets Targets { get; } public DamageKind DamageKind { get; }
        public int Value { get; } public int Turns { get; } public bool Beneficial { get; } public bool Removable { get; }
        public bool EmpoweredSecondaryDamage { get; } public int EmpoweredSecondaryScale { get; } public int PostEmpowerDamageTakenIncrease { get; } public int PostEmpowerTurns { get; }
        public int LifestealCap { get; } public int RequiredEmpoweredTargetLimit { get; } public int Charges { get; } public int StackCap { get; } public bool BarrierOnly { get; } public EffectPredicate Predicate { get; } public int Threshold { get; }
        // Damage/heal/barrier Value is a coefficient in Rules.Scale units; defense is a signed flat modifier.
        public CombatEffect(EffectKind kind, EffectTargets targets, int value, int turns = 0,
            DamageKind damageKind = DamageKind.Physical, bool beneficial = true, bool removable = true, bool barrierOnly = false, EffectPredicate predicate = EffectPredicate.Always, int threshold = 0, int charges = 0, int stackCap = 0, int lifestealCap = 0, int requiredEmpoweredTargetLimit = 0, bool empoweredSecondaryDamage = false, int empoweredSecondaryScale = 0, int postEmpowerDamageTakenIncrease = 0, int postEmpowerTurns = 0)
        {
            Check.Require(Check.Defined(kind) && Check.Defined(targets) && Check.Defined(damageKind) && Check.Defined(predicate) && threshold >= 0 && threshold <= 1000000 &&
                value >= -Check.MaxStat && value <= Check.MaxStat && turns >= 0 && turns <= 100);
            bool status = kind == EffectKind.Barrier || kind == EffectKind.Defense || kind == EffectKind.Taunt || kind == EffectKind.Cover || kind == EffectKind.AreaReduction || kind == EffectKind.DelayedHeal || kind == EffectKind.HealingReduction || kind == EffectKind.SpeedModifier || kind == EffectKind.Conceal || kind == EffectKind.Reveal || kind == EffectKind.NextOffenseModifier || kind == EffectKind.SourceMark || kind == EffectKind.Poison || kind == EffectKind.NextLifestealWindow || kind == EffectKind.Aim || kind == EffectKind.DamageTakenIncrease;
            Check.Require(status ? turns > 0 : turns == 0);
            Check.Require(kind == EffectKind.Defense || kind == EffectKind.SpeedModifier || kind == EffectKind.NextOffenseModifier || value >= 0);
            Check.Require(!(kind == EffectKind.Defense || kind == EffectKind.SpeedModifier || kind == EffectKind.NextOffenseModifier) || value != 0);
            Check.Require(!barrierOnly || kind == EffectKind.Dispel);
            Check.Require(!(kind == EffectKind.Taunt || kind == EffectKind.HealingReduction || kind == EffectKind.Reveal || kind == EffectKind.SourceMark || kind == EffectKind.Poison) || !beneficial);
            Check.Require(!(kind == EffectKind.Defense || kind == EffectKind.SpeedModifier || kind == EffectKind.NextOffenseModifier) || beneficial == (value > 0));
            Check.Require(!(kind == EffectKind.Barrier || kind == EffectKind.Cover || kind == EffectKind.AreaReduction || kind == EffectKind.DelayedHeal || kind == EffectKind.Conceal || kind == EffectKind.NextLifestealWindow || kind == EffectKind.Aim) || beneficial);
            Check.Require(!(kind == EffectKind.Conceal || kind == EffectKind.Reveal || kind == EffectKind.Aim) || value == 0);
            Check.Require(predicate == EffectPredicate.TargetInjured ? threshold > 0 : threshold == 0);
            Check.Require(kind == EffectKind.NextOffenseModifier || kind == EffectKind.SourceMark ? charges >= 1 && charges <= 128 : kind == EffectKind.NextLifestealWindow || kind == EffectKind.Aim ? charges == 1 : charges == 0);
            Check.Require(kind == EffectKind.Poison ? stackCap >= 1 && stackCap <= 128 && damageKind == DamageKind.Magic : stackCap == 0);
            Check.Require(requiredEmpoweredTargetLimit == 0 || requiredEmpoweredTargetLimit == 2);
            Check.Require(!empoweredSecondaryDamage || kind == EffectKind.Damage && targets == EffectTargets.Selected);
            Check.Require(requiredEmpoweredTargetLimit == 2 ? kind == EffectKind.NextLifestealWindow && targets == EffectTargets.Self && removable && empoweredSecondaryScale > 0 && empoweredSecondaryScale <= 1000000 && postEmpowerDamageTakenIncrease > 0 && postEmpowerDamageTakenIncrease <= 1000000 && postEmpowerTurns > 0 && postEmpowerTurns <= 100 : empoweredSecondaryScale == 0 && postEmpowerDamageTakenIncrease == 0 && postEmpowerTurns == 0);
            Check.Require(kind != EffectKind.DamageTakenIncrease || !beneficial && removable && value > 0);
            EmpoweredSecondaryDamage = empoweredSecondaryDamage; EmpoweredSecondaryScale = empoweredSecondaryScale; PostEmpowerDamageTakenIncrease = postEmpowerDamageTakenIncrease; PostEmpowerTurns = postEmpowerTurns;
            Check.Require(kind == EffectKind.NextLifestealWindow ? value > 0 && lifestealCap > 0 && lifestealCap <= Check.MaxStat : lifestealCap == 0);
            LifestealCap = lifestealCap; RequiredEmpoweredTargetLimit = requiredEmpoweredTargetLimit; Charges = charges; StackCap = stackCap; Predicate = predicate; Threshold = threshold; Kind = kind; Targets = targets; Value = value; Turns = turns; DamageKind = damageKind;
            Beneficial = beneficial; Removable = removable; BarrierOnly = barrierOnly;
        }
    }
    public sealed class CombatSkill
    {
        public string Id { get; } public Selection Selection { get; } public int MaximumTargets { get; }
        public bool Area { get; } public bool BypassCover { get; } public bool PrimaryInterceptable { get; } public int Penetration { get; }
        public bool AllowConcealedPrimaryReveal { get; } public OutcomeFollowup Followup { get; } public int KillConcealTurns { get; } public int SurvivorDefenseDelta { get; } public int SurvivorDefenseTurns { get; } public DamageKind SurvivorDefenseKind { get; }
        public bool IsUltimate { get; } public bool UseAimForPrimaryCoverBypass { get; } public int LifestealCoefficient { get; } public int LifestealCap { get; } public ActionClass Classification { get; }
        public int HpCostCoefficient { get; } public int SecondaryScale { get; } public IReadOnlyList<CombatEffect> Effects { get; }
        public CombatSkill(string id, Selection selection, int maximumTargets, IEnumerable<CombatEffect> effects,
            int secondaryScale, int penetration = 0, bool area = false, bool bypassCover = false, bool primaryInterceptable = false, int hpCostCoefficient = 0, bool isUltimate = false, int lifestealCoefficient = 0, int lifestealCap = 0, bool useAimForPrimaryCoverBypass = false, ActionClass? classification = null, bool allowConcealedPrimaryReveal = false, OutcomeFollowup followup = OutcomeFollowup.None, int killConcealTurns = 0, int survivorDefenseDelta = 0, int survivorDefenseTurns = 0, DamageKind survivorDefenseKind = DamageKind.Physical)
        {
            Check.Require(hpCostCoefficient >= 0 && hpCostCoefficient <= 1000000); HpCostCoefficient = hpCostCoefficient;
            var rows = effects?.Take(17).ToArray();
            Check.Require(Check.Id(id) && Check.Defined(selection) && maximumTargets >= 1 && maximumTargets <= 5 &&
                rows != null && rows.Length >= 1 && rows.Length <= 16 && rows.All(x => x != null) &&
                secondaryScale >= 0 && secondaryScale <= 1000000 && penetration >= 0 && penetration <= 1000000);
            Check.Require(!(selection == Selection.Self || selection == Selection.Ally || selection == Selection.Enemy) || maximumTargets == 1);
            Check.Require(!(selection == Selection.AllEnemies || selection == Selection.AllAllies) || maximumTargets == 5);
            Id = id; Selection = selection; MaximumTargets = maximumTargets; Effects = Array.AsReadOnly(rows!);
            Check.Require(!primaryInterceptable || selection == Selection.UpToEnemies);
            Check.Require(lifestealCoefficient >= 0 && lifestealCoefficient <= 1000000 && lifestealCap >= 0 && lifestealCap <= Check.MaxStat);
            Check.Require(lifestealCoefficient == 0 ? lifestealCap == 0 : lifestealCap > 0 && rows!.Any(e => e.Kind == EffectKind.Damage && e.Value > 0));
            Check.Require(!useAimForPrimaryCoverBypass || isUltimate && selection == Selection.UpToEnemies && maximumTargets <= 3 && primaryInterceptable && !bypassCover && rows!.Any(e => e.Kind == EffectKind.Damage && e.Targets == EffectTargets.Selected && e.Value > 0));
            Check.Require(Check.Defined(followup) && Check.Defined(survivorDefenseKind));
            if (followup == OutcomeFollowup.None)
                Check.Require(killConcealTurns == 0 && survivorDefenseDelta == 0 && survivorDefenseTurns == 0 && survivorDefenseKind == DamageKind.Physical);
            else
            {
                Check.Require(isUltimate && selection == Selection.Enemy && maximumTargets == 1 && !area && !primaryInterceptable && !bypassCover && !useAimForPrimaryCoverBypass && !allowConcealedPrimaryReveal);
                Check.Require(rows!.Length == 1 && rows[0].Kind == EffectKind.Damage && rows[0].Targets == EffectTargets.Selected && rows[0].Value > 0 && rows[0].Predicate == EffectPredicate.Always && !rows[0].EmpoweredSecondaryDamage);
                Check.Require(killConcealTurns > 0 && killConcealTurns <= 100 && survivorDefenseDelta < 0 && survivorDefenseDelta >= -Check.MaxStat && survivorDefenseTurns > 0 && survivorDefenseTurns <= 100);
            }
            if (allowConcealedPrimaryReveal)
            {
                Check.Require(!isUltimate && selection == Selection.Enemy && maximumTargets == 1 && !area && !primaryInterceptable && !bypassCover && !useAimForPrimaryCoverBypass && penetration == 0 && hpCostCoefficient == 0 && lifestealCoefficient == 0 && followup == OutcomeFollowup.None);
                Check.Require(rows!.Length == 2 && rows[0].Kind == EffectKind.Reveal && rows[0].Targets == EffectTargets.Selected && rows[1].Kind == EffectKind.Aim && rows[1].Targets == EffectTargets.Self && rows.All(e => e.Predicate == EffectPredicate.Always && e.Removable && e.Value == 0 && !e.EmpoweredSecondaryDamage));
            }
            AllowConcealedPrimaryReveal = allowConcealedPrimaryReveal; Followup = followup; KillConcealTurns = killConcealTurns; SurvivorDefenseDelta = survivorDefenseDelta; SurvivorDefenseTurns = survivorDefenseTurns; SurvivorDefenseKind = survivorDefenseKind;
            IsUltimate = isUltimate; LifestealCoefficient = lifestealCoefficient; LifestealCap = lifestealCap; UseAimForPrimaryCoverBypass = useAimForPrimaryCoverBypass;
            Check.Require(rows!.All(e => e.RequiredEmpoweredTargetLimit == 0 || isUltimate && selection == Selection.Self));
            Classification = RootActionResults.Classify(selection, rows!); Check.Require(!classification.HasValue || classification.Value == Classification);
            SecondaryScale = secondaryScale; Penetration = penetration; Area = area; BypassCover = bypassCover; PrimaryInterceptable = primaryInterceptable;
        }
    }
    public sealed class CombatantInput
    {
        public string Id { get; } public Side Side { get; } public int MaximumHp { get; }
        public int Offense { get; } public int Armor { get; } public int Resistance { get; } public int Speed { get; }
        public IReadOnlyList<CombatSkill> Skills { get; }
        public CombatantInput(string id, Side side, int hp, int offense, int armor, int resistance, int speed, IEnumerable<CombatSkill> skills)
        {
            var rows = skills?.Take(7).ToArray();
            Check.Require(Check.Id(id) && Check.Defined(side) && hp >= 1 && hp <= Check.MaxStat && offense >= 1 && offense <= Check.MaxStat &&
                armor >= 0 && armor <= Check.MaxStat && resistance >= 0 && resistance <= Check.MaxStat && speed >= 0 && speed <= Check.MaxStat &&
                rows != null && rows.Length >= 1 && rows.Length <= 6 && rows.All(x => x != null) && rows.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() == rows.Length);
            Id = id; Side = side; MaximumHp = hp; Offense = offense; Armor = armor; Resistance = resistance; Speed = speed; Skills = Array.AsReadOnly(rows!);
        }
    }
    public sealed class CombatInput
    {
        public const string EngineVersion = "five-hero-effects-v2-d3-candidate";
        public string ContentId { get; } public string ContentRevision { get; } public CombatRules Rules { get; }
        public IReadOnlyList<CombatantInput> Units { get; }
        public CombatInput(string contentId, string revision, CombatRules rules, IEnumerable<CombatantInput> units)
        {
            var rows = units?.Take(11).ToArray();
            Check.Require(Check.Id(contentId) && Check.Id(revision) && rules != null && rows != null && rows.Length >= 6 && rows.Length <= 10 && rows.All(x => x != null));
            Check.Require(rows!.Count(x => x.Side == Side.Party) == 5 && rows.Count(x => x.Side == Side.Enemy) >= 1 && rows.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() == rows.Length);
            foreach (var skill in rows.SelectMany(x => x.Skills))
            {
                Check.Require(skill.SecondaryScale <= rules!.Scale && skill.Penetration <= rules.Scale && skill.HpCostCoefficient <= rules.Scale && skill.LifestealCoefficient <= rules.Scale);
                foreach (var effect in skill.Effects) { Check.Require(!(effect.Kind == EffectKind.AreaReduction || effect.Kind == EffectKind.HealingReduction) || effect.Value <= rules.Scale); Check.Require(effect.Threshold <= rules.Scale); Check.Require(!(effect.Kind == EffectKind.NextOffenseModifier || effect.Kind == EffectKind.SourceMark || effect.Kind == EffectKind.NextLifestealWindow) || Math.Abs((long)effect.Value) <= rules.Scale); Check.Require(effect.StackCap <= rules.MaximumEffects); Check.Require(effect.EmpoweredSecondaryScale <= rules.Scale && effect.PostEmpowerDamageTakenIncrease <= rules.Scale); Check.Require(effect.Kind != EffectKind.DamageTakenIncrease || effect.Value <= rules.Scale); }
            }
            foreach (var unit in rows) Check.Require(unit.Skills.SelectMany(s => s.Effects).Where(e => e.Kind == EffectKind.Poison).Select(e => e.StackCap).Distinct().Count() <= 1);
            foreach (var unit in rows.Where(u => u.Skills.Any(s => s.Effects.Any(e => e.RequiredEmpoweredTargetLimit == 2))))
                foreach (var skill in unit.Skills.Where(s => s.Effects.Any(e => e.Kind == EffectKind.Damage && e.Value > 0))) Check.Require(ActionProjection.Supports(skill));
            ContentId = contentId; ContentRevision = revision; Rules = rules!; Units = Array.AsReadOnly(rows);
        }
    }
    public sealed class CombatCommand
    {
        public ActionMode Mode { get; } public long ExpectedWindowSequence { get; }
        public string Nonce { get; } public long ExpectedVersion { get; } public string Actor { get; } public string Skill { get; }
        public int Primary { get; } public IReadOnlyList<int> Secondary { get; }
        public CombatCommand(string nonce, long version, string actor, string skill, int primary, IEnumerable<int>? secondary = null, ActionMode mode = ActionMode.Normal, long expectedWindowSequence = 0)
        { Mode = mode; ExpectedWindowSequence = expectedWindowSequence; Nonce = nonce; ExpectedVersion = version; Actor = actor; Skill = skill; Primary = primary; Secondary = Array.AsReadOnly((secondary ?? Array.Empty<int>()).Take(6).OrderBy(x => x).ToArray()); }
        internal bool Same(CombatCommand other) => Mode == other.Mode && ExpectedWindowSequence == other.ExpectedWindowSequence && ExpectedVersion == other.ExpectedVersion && Actor == other.Actor && Skill == other.Skill && Primary == other.Primary && Secondary.SequenceEqual(other.Secondary);
    }
    public sealed class CombatReceipt
    {
        public CombatCommand Command { get; } public string Diagnostic { get; } public bool Replayed { get; } public bool Recorded { get; }
        public IReadOnlyList<PacketDamageResult> DamageResults { get; }
        internal CombatReceipt(CombatCommand c, string diagnostic, bool replayed, bool recorded, IEnumerable<PacketDamageResult>? damage = null) { DamageResults = Array.AsReadOnly((damage ?? Array.Empty<PacketDamageResult>()).ToArray()); Command = c; Diagnostic = diagnostic; Replayed = replayed; Recorded = recorded; }
    }
    public sealed class StatusView
    {
        public EffectKind Kind { get; } public int Source { get; } public int Target { get; } public string Skill { get; }
        public int RequiredEmpoweredTargetLimit { get; } public int EmpoweredSecondaryScale { get; } public int PostEmpowerDamageTakenIncrease { get; } public int PostEmpowerTurns { get; }
        public int LifestealCap { get; } public int Charges { get; } public long FirstEligibleOwnerTurn { get; } public long Amount { get; } public int RemainingTurns { get; } public long Sequence { get; }
        internal StatusView(Status s) { RequiredEmpoweredTargetLimit = s.RequiredEmpoweredTargetLimit; EmpoweredSecondaryScale = s.EmpoweredSecondaryScale; PostEmpowerDamageTakenIncrease = s.PostEmpowerDamageTakenIncrease; PostEmpowerTurns = s.PostEmpowerTurns; LifestealCap = s.LifestealCap; Charges = s.Charges; FirstEligibleOwnerTurn = s.FirstEligibleOwnerTurn; Kind = s.Kind; Source = s.Source; Target = s.Target; Skill = s.Skill; Amount = s.Amount; RemainingTurns = s.Turns; Sequence = s.Sequence; }
    }
    public sealed class CombatResult
    {
        public IReadOnlyList<int> Readiness { get; } public IReadOnlyList<long> CompletedOwnerTurns { get; } public IReadOnlyList<int> Hp { get; } public IReadOnlyList<StatusView> Statuses { get; }
        public IReadOnlyList<CombatReceipt> Receipts { get; } public int Actor { get; } public long Version { get; }
        public BattleOutcome Outcome { get; } public string InputHash { get; } public string StateHash { get; }
        internal CombatResult(Frame f, IReadOnlyList<CombatReceipt> receipts, string inputHash, string stateHash)
        { Readiness = Array.AsReadOnly((int[])f.Readiness.Clone()); CompletedOwnerTurns = Array.AsReadOnly((long[])f.CompletedOwnerTurns.Clone()); Hp = Array.AsReadOnly((int[])f.Hp.Clone()); Statuses = Array.AsReadOnly(f.Statuses.Select(s => new StatusView(s)).ToArray()); Receipts = receipts; Actor = f.Actor; Version = f.Version; Outcome = f.Outcome; InputHash = inputHash; StateHash = stateHash; }
    }
}

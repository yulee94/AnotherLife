using System;
using System.Collections.Generic;
using System.Linq;

namespace AnotherLife.StoryCombat.V2
{
    // Pure derived legal-action data. The query replays trusted input/history and never accepts live client status values.
    public sealed class ActionProjection
    {
        public string Diagnostic { get; } public long Version { get; } public bool Empowered { get; }
        public long WindowSequence { get; } public int MaximumTargets { get; } public int SecondaryScale { get; }
        public IReadOnlyList<int> LegalSecondary { get; }
        internal ActionProjection(string diagnostic, long version, bool empowered, long sequence, int maximum, int scale, IEnumerable<int> secondary)
        { Diagnostic = diagnostic; Version = version; Empowered = empowered; WindowSequence = sequence; MaximumTargets = maximum; SecondaryScale = scale; LegalSecondary = Array.AsReadOnly(secondary.ToArray()); }
        internal static bool Supports(CombatSkill skill) => skill.Followup == OutcomeFollowup.None && !skill.AllowConcealedPrimaryReveal && !skill.Area && !skill.PrimaryInterceptable && !skill.BypassCover && !skill.UseAimForPrimaryCoverBypass &&
            (skill.Selection == Selection.Enemy || skill.Selection == Selection.UpToEnemies && skill.MaximumTargets <= 2) &&
            skill.Effects.Any(e => e.Kind == EffectKind.Damage && e.Value > 0 && e.EmpoweredSecondaryDamage) &&
            skill.Effects.Where(e => e.Kind == EffectKind.Damage && e.Value > 0).All(e => e.EmpoweredSecondaryDamage && (skill.Selection != Selection.UpToEnemies || e.Predicate == EffectPredicate.Always || e.Predicate == EffectPredicate.ActorConcealed));
        internal bool Routes(CombatSkill skill, CombatEffect effect, int target, int primary)
        {
            if (!Empowered || effect.Targets != EffectTargets.Selected || target == primary) return true;
            if (effect.Kind == EffectKind.Damage) return effect.EmpoweredSecondaryDamage;
            return skill.Selection == Selection.UpToEnemies; // Preserve existing routing, never expand single-target debuffs.
        }
        internal static ActionProjection Build(CombatInput input, Frame frame, CombatSkill skill, int primary, bool checkReadiness = true)
        {
            ActionProjection Refuse(string code) => new ActionProjection(code, frame.Version, false, 0, skill.MaximumTargets, skill.SecondaryScale, Array.Empty<int>());
            if (primary < 0 || primary >= input.Units.Count) return Refuse("TARGET-INVALID");
            var command = new CombatCommand(new string('0', 32), frame.Version, input.Units[frame.Actor].Id, skill.Id, primary);
            if (TargetRules.Resolve(input, frame, frame.Actor, skill, command) == null) return Refuse("TARGET-INVALID");
            if (checkReadiness && skill.IsUltimate && frame.Readiness[frame.Actor] < input.Rules.ReadinessThreshold) return Refuse("ULTIMATE-NOT-READY");
            var context = new ActionContext(frame);
            bool positivePrimary = skill.Effects.Any(e => e.Kind == EffectKind.Damage && e.Value > 0 && e.Targets == EffectTargets.Selected && context.Matches(input, e, frame.Actor, primary));
            var window = positivePrimary ? frame.Statuses.Where(s => s.Target == frame.Actor && s.Kind == EffectKind.NextLifestealWindow).OrderBy(s => s.Sequence).FirstOrDefault() : null;
            bool empowered = window != null && window.RequiredEmpoweredTargetLimit == 2;
            if (empowered && !Supports(skill)) return Refuse("EMPOWERED-SKILL-UNSUPPORTED");
            int maximum = empowered ? 2 : skill.MaximumTargets;
            var secondaries = new List<int>();
            if (empowered || skill.Selection == Selection.UpToEnemies)
                for (int i = 0; i < input.Units.Count; i++)
                {
                    if (i == primary) continue;
                    var probe = new CombatCommand(command.Nonce, frame.Version, command.Actor, skill.Id, primary, new[] { i });
                    if (TargetRules.Resolve(input, frame, frame.Actor, skill, probe, empowered) != null) secondaries.Add(i);
                }
            return new ActionProjection("", frame.Version, empowered, empowered ? window!.Sequence : 0, maximum, empowered ? window!.EmpoweredSecondaryScale : skill.SecondaryScale, secondaries);
        }
        internal string Validate(CombatCommand command)
        {
            if (Diagnostic.Length != 0) return Diagnostic;
            if (command.Mode == ActionMode.Empowered && (!Empowered || command.ExpectedWindowSequence != WindowSequence)) return "WINDOW-CONFLICT";
            if (Empowered && command.Mode != ActionMode.Empowered) return "EMPOWERED-SELECTION-REQUIRED";
            return "";
        }
        public static ActionProjection Query(CombatInput input, IEnumerable<CombatCommand> history, string actor, string skill, int primary)
        {
            var replay = CombatReplay.ReplayCore(input, history, out var frame);
            ActionProjection Refuse(string code) => new ActionProjection(code, frame.Version, false, 0, 0, 0, Array.Empty<int>());
            if (replay.Receipts.Count(r => r.Recorded && !r.Replayed) >= input.Rules.MaximumCommands) return Refuse("CAPACITY");
            if (frame.Outcome != BattleOutcome.Active) return Refuse("FINISHED");
            if (actor != input.Units[frame.Actor].Id) return Refuse("NOT-YOUR-TURN");
            var selected = input.Units[frame.Actor].Skills.SingleOrDefault(s => s.Id == skill);
            return selected == null ? Refuse("SKILL-UNAVAILABLE") : Build(input, frame, selected, primary);
        }
    }
}
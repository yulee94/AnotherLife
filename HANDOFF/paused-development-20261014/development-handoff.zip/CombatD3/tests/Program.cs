using AnotherLife.StoryCombat.V2;
using System.Text.Json;
using V1 = AnotherLife.StoryCombat;

static partial class Tests
{
    static int failed, passed;
    static string N(int value) => value.ToString("x32");
    static void Eq<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
    static void Assert(bool value) { if (!value) throw new Exception("Assertion failed"); }
    static void Throws(Action action) { try { action(); } catch (InvalidDataException) { return; } throw new Exception("Expected invalid data"); }
    static void Test(string name, Action action) { try { action(); passed++; Console.WriteLine("PASS " + name); } catch (Exception e) { failed++; Console.WriteLine("FAIL " + name + ": " + e); } }
    static CombatEffect E(EffectKind kind, int value, int turns = 0, bool good = true, EffectTargets targets = EffectTargets.Selected, DamageKind damage = DamageKind.Physical, bool barrierOnly = false)
        => new(kind, targets, value, turns, damage, good, true, barrierOnly);
    static CombatSkill S(string id, Selection selection, params CombatEffect[] effects) => new(id, selection, selection == Selection.AllEnemies || selection == Selection.AllAllies ? 5 : 1, effects, 1000);
    static CombatSkill Hit => S("hit", Selection.Enemy, E(EffectKind.Damage, 1000));
    static CombatSkill Rest => S("rest", Selection.Self, E(EffectKind.Heal, 0)); // Test-only explicit action, not a shipped fallback.
    static CombatInput Input(CombatSkill[]? first = null, CombatSkill[]? enemy = null, int armor = 0, int resistance = 0, int events = 100, int effects = 16, int? guardArmor = null)
    {
        var units = Enumerable.Range(0, 10).Select(i => new CombatantInput("u" + i, i < 5 ? Side.Party : Side.Enemy, 1000, 100,
            i == 0 ? guardArmor ?? armor : armor, resistance, i == 0 ? 100 : i == 5 ? 90 : 80 - i,
            i == 0 ? first ?? new[] { Hit, Rest } : i == 5 ? enemy ?? new[] { Hit, Rest } : new[] { Hit, Rest }));
        return new CombatInput("synthetic", "dev1", new CombatRules(1000, 100, effects, events, 100), units);
    }
    static CombatCommand C(int nonce, int actor, string skill, int target, params int[] secondary) => new(N(nonce), nonce, "u" + actor, skill, target, secondary);
    static CombatResult Run(CombatInput input, params CombatCommand[] commands) => CombatReplay.Replay(input, commands);
    static void Main()
    {
        Test("finite barrier absorbs and overflow reaches HP", () => {
            var b = Input(new[] { S("shield", Selection.Self, E(EffectKind.Barrier, 500, 2)) });
            var r = Run(b, C(1, 0, "shield", 0), C(2, 5, "hit", 0)); Eq(950, r.Hp[0]); Eq(0, r.Statuses.Count); Eq(3L, r.Version);
        });
        Test("Cover redirects before recipient armor", () => {
            var b = Input(new[] { S("cover", Selection.Ally, E(EffectKind.Cover, 0, 2)) }, armor: 0, guardArmor: 300);
            var r = Run(b, C(1, 0, "cover", 1), C(2, 5, "hit", 1)); Eq(975, r.Hp[0]); Eq(1000, r.Hp[1]);
        });
        Test("Cover per-root limit does not recursively redirect packets", () => {
            var two = S("two", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000));
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 2));
            var units = Input(new[] { cover }, new[] { two }).Units.Select((u, i) => i == 1 ?
                new CombatantInput(u.Id, u.Side, u.MaximumHp, u.Offense, u.Armor, u.Resistance, 95, new[] { cover }) : u).ToArray();
            var b = new CombatInput("synthetic", "dev1", new CombatRules(1000, 100, 16, 100, 100), units);
            // u0 covers u1; u1 covers u2. First packet redirects u2 -> u1, never u1 -> u0.
            // Second packet remains on u2 because this root action already spent its one redirect.
            var r = Run(b, C(1, 0, "cover", 1), C(2, 1, "cover", 2), C(3, 5, "two", 2));
            Eq(1000, r.Hp[0]); Eq(900, r.Hp[1]); Eq(900, r.Hp[2]);
        });
        Test("area bypasses Cover but not mitigation", () => {
            var area = new CombatSkill("area", Selection.AllEnemies, 5, new[] { E(EffectKind.Damage, 1000) }, 1000, area: true);
            var r = Run(Input(new[] { S("cover", Selection.Ally, E(EffectKind.Cover, 0, 2)) }, new[] { area }), C(1, 0, "cover", 1), C(2, 5, "area", 0));
            for (int i = 0; i < 5; i++) Eq(900, r.Hp[i]);
        });
        Test("explicit primary Cover bypass retains armor", () => {
            var shot = new CombatSkill("shot", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1000) }, 1000, bypassCover: true);
            var r = Run(Input(new[] { S("cover", Selection.Ally, E(EffectKind.Cover, 0, 2)) }, new[] { shot }, armor: 100), C(1, 0, "cover", 1), C(2, 5, "shot", 1)); Eq(1000, r.Hp[0]); Eq(950, r.Hp[1]);
        });
        Test("taunt rejects another primary without consuming turn", () => {
            var b = Input(new[] { S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 2, false)) });
            var first = C(1, 0, "taunt", 5); var r = Run(b, first, C(2, 5, "hit", 1));
            Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic); Eq(2L, r.Version); Eq(5, r.Actor); Eq(1000, r.Hp[1]);
            r = Run(b, first, C(2, 5, "hit", 1), new CombatCommand(N(3), 2, "u5", "hit", 0)); Eq(900, r.Hp[0]);
        });
        Test("taunt allows ally support", () => {
            var r = Run(Input(new[] { S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 2, false)) }), C(1, 0, "taunt", 5), C(2, 5, "rest", 5)); Eq("", r.Receipts.Last().Diagnostic);
        });
        Test("physical magic and partial penetration differ", () => {
            var physical = Run(Input(armor: 100, resistance: 300), C(1, 0, "hit", 5)); Eq(950, physical.Hp[5]);
            var magic = S("magic", Selection.Enemy, E(EffectKind.Damage, 1000, damage: DamageKind.Magic));
            Eq(975, Run(Input(new[] { magic }, armor: 100, resistance: 300), C(1, 0, "magic", 5)).Hp[5]);
            var pierce = new CombatSkill("pierce", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1000) }, 1000, penetration: 500);
            Eq(934, Run(Input(new[] { pierce }, armor: 100), C(1, 0, "pierce", 5)).Hp[5]);
        });
        Test("defense buff and area reduction each apply once", () => {
            var ward = S("ward", Selection.AllAllies, E(EffectKind.Defense, 100, 2), E(EffectKind.AreaReduction, 500, 2));
            var area = new CombatSkill("area", Selection.AllEnemies, 5, new[] { E(EffectKind.Damage, 1000) }, 1000, area: true);
            var r = Run(Input(new[] { ward }, new[] { area }), C(1, 0, "ward", 0), C(2, 5, "area", 0)); for (int i = 0; i < 5; i++) Eq(975, r.Hp[i]);
        });
        Test("ranger primary heavy and two distinct secondary hits", () => {
            var split = new CombatSkill("split", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500);
            var r = Run(Input(new[] { split }), C(1, 0, "split", 7, 5, 6)); Eq(900, r.Hp[7]); Eq(950, r.Hp[5]); Eq(950, r.Hp[6]); Eq(1000, r.Hp[8]);
            Eq("TARGET-INVALID", Run(Input(new[] { split }), C(1, 0, "split", 5, 6, 7, 8)).Receipts.Single().Diagnostic);
        });
        Test("duplicate target rejects atomically", () => {
            var split = new CombatSkill("split", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500);
            var r = Run(Input(new[] { split }), C(1, 0, "split", 5, 6, 6)); Eq(false, r.Receipts.Single().Recorded); Assert(r.Hp.All(x => x == 1000));
        });
        Test("secondary permutation replay and primary conflict", () => {
            var split = new CombatSkill("split", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500); var b = Input(new[] { split });
            var r = Run(b, C(1, 0, "split", 5, 6, 7), C(1, 0, "split", 5, 7, 6), C(1, 0, "split", 6, 5, 7));
            Eq(true, r.Receipts[1].Replayed); Eq("REQUEST-CONFLICT", r.Receipts[2].Diagnostic); Eq(900, r.Hp[5]); Eq(2L, r.Version);
        });
        Test("barrier-only dispel occurs before own hit and leaves armor", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Defense, 100, 2), E(EffectKind.Barrier, 2000, 2));
            var unmake = new CombatSkill("unmake", Selection.AllEnemies, 5, new[] { E(EffectKind.Dispel, 0, barrierOnly: true), E(EffectKind.Damage, 1000) }, 1000, area: true);
            var r = Run(Input(new[] { ward }, new[] { unmake }), C(1, 0, "ward", 0), C(2, 5, "unmake", 0)); Eq(950, r.Hp[0]); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Defense)); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Barrier));
        });
        Test("cleanse removes taunt not beneficial shield", () => {
            var taunt = S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 2, false));
            var clean = S("clean", Selection.Self, E(EffectKind.Barrier, 1000, 2), E(EffectKind.Cleanse, 0));
            var r = Run(Input(new[] { taunt }, new[] { clean }), C(1, 0, "taunt", 5), C(2, 5, "clean", 5)); Eq(1, r.Statuses.Count); Eq(EffectKind.Barrier, r.Statuses[0].Kind);
        });
        Test("effect budget failure rolls back earlier damage", () => {
            var two = S("two", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000));
            var r = Run(Input(new[] { two }, events: 1), C(1, 0, "two", 5)); Eq("EVENT-CAPACITY", r.Receipts[0].Diagnostic); Eq(1000, r.Hp[5]); Eq(1L, r.Version);
        });
        Test("status capacity rolls back entire root action", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Barrier, 1000, 2), E(EffectKind.Defense, 100, 2));
            var r = Run(Input(new[] { ward }, effects: 1), C(1, 0, "ward", 0)); Eq("EFFECT-CAPACITY", r.Receipts[0].Diagnostic); Eq(0, r.Statuses.Count);
        });
        Test("same-source shield refresh replaces instead of stacking", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 1000, 2), E(EffectKind.Barrier, 500, 2));
            var r = Run(Input(new[] { shield }), C(1, 0, "shield", 0)); Eq(1, r.Statuses.Count); Eq(50L, r.Statuses[0].Amount);
        });
        Test("owner-turn expiry and stable full round scheduling", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 1000, 1)); var b = Input(new[] { shield, Rest }); var commands = new List<CombatCommand> { C(1, 0, "shield", 0) };
            var actors = new List<int> { 0 }; var r = CombatReplay.Replay(b, commands);
            for (int n = 2; n <= 11; n++) { actors.Add(r.Actor); commands.Add(new CombatCommand(N(n), r.Version, b.Units[r.Actor].Id, "rest", r.Actor)); r = CombatReplay.Replay(b, commands); }
            Eq("0,5,1,2,3,4,6,7,8,9,0", string.Join(",", actors)); Eq(0, r.Statuses.Count);
        });
        Test("death skips queued actor and terminal replay grants no second hit", () => {
            var kill = new CombatSkill("kill", Selection.AllEnemies, 5, new[] { E(EffectKind.Damage, 10000) }, 1000, area: true); var b = Input(new[] { kill });
            var r = Run(b, C(1, 0, "kill", 5), C(1, 0, "kill", 5)); Eq(BattleOutcome.Victory, r.Outcome); Eq(-1, r.Actor); Eq(true, r.Receipts[1].Replayed);
        });
        Test("codec exact roundtrip and replay of active barriers", () => {
            var b = Input(new[] { S("shield", Selection.Self, E(EffectKind.Barrier, 2000, 2)) }); var bytes = CombatCodec.Encode(b); var copy = CombatCodec.Decode(bytes);
            Eq(Convert.ToHexString(bytes), Convert.ToHexString(CombatCodec.Encode(copy))); Eq(Run(b, C(1, 0, "shield", 0)).StateHash, Run(copy, C(1, 0, "shield", 0)).StateHash);
        });
        Test("codec every truncation and trailing byte rejects", () => {
            var bytes = CombatCodec.Encode(Input()); for (int n = 0; n < bytes.Length; n++) { int length = n; Throws(() => CombatCodec.Decode(bytes.Take(length).ToArray())); }
            Throws(() => CombatCodec.Decode(bytes.Concat(new byte[] { 0 }).ToArray())); var bad = (byte[])bytes.Clone(); bad[2] = (byte)'z'; Throws(() => CombatCodec.Decode(bad));
        });
        Test("input mutation cannot alter immutable snapshot", () => {
            var effects = new[] { E(EffectKind.Damage, 1000) }; var skill = S("hit", Selection.Enemy, effects); var b = Input(new[] { skill }); effects[0] = E(EffectKind.Damage, 9000); Eq(900, Run(b, C(1, 0, "hit", 5)).Hp[5]);
        });
        Test("two-target cleave cap and all-enemy five-target outcome", () => {
            var cleave = new CombatSkill("cleave", Selection.UpToEnemies, 2, new[] { E(EffectKind.Damage, 1000) }, 1000);
            var r = Run(Input(new[] { cleave }), C(1, 0, "cleave", 5, 6)); Eq(900, r.Hp[5]); Eq(900, r.Hp[6]); Eq(1000, r.Hp[7]);
            Eq("TARGET-INVALID", Run(Input(new[] { cleave }), C(1, 0, "cleave", 5, 6, 7)).Receipts[0].Diagnostic);
            var area = new CombatSkill("area", Selection.AllEnemies, 5, new[] { E(EffectKind.Damage, 1000) }, 1000, area: true);
            r = Run(Input(new[] { area }), C(1, 0, "area", 5)); for (int i = 5; i < 10; i++) Eq(900, r.Hp[i]);
        });
        Test("defense debuff clamps at zero rather than amplifying damage", () => {
            var breakHit = S("break", Selection.Enemy, E(EffectKind.Defense, -200, 2, false), E(EffectKind.Damage, 1000));
            Eq(900, Run(Input(new[] { breakHit }, armor: 100), C(1, 0, "break", 5)).Hp[5]);
        });
        Test("healing is capped at maximum HP", () => {
            var heal = S("heal", Selection.Self, E(EffectKind.Heal, 10000));
            var r = Run(Input(enemy: new[] { heal }), C(1, 0, "hit", 5), C(2, 5, "heal", 5)); Eq(1000, r.Hp[5]);
        });
        Test("dispel removes one eligible benefit in application order", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Defense, 100, 2), E(EffectKind.Barrier, 1000, 2));
            var dispel = S("dispel", Selection.Enemy, E(EffectKind.Dispel, 0));
            var r = Run(Input(new[] { ward }, new[] { dispel }), C(1, 0, "ward", 0), C(2, 5, "dispel", 0)); Eq(1, r.Statuses.Count); Eq(EffectKind.Barrier, r.Statuses[0].Kind);
        });
        Test("dead enemy queue entry is skipped", () => {
            var kill = S("kill", Selection.Enemy, E(EffectKind.Damage, 10000));
            var r = Run(Input(new[] { kill }), C(1, 0, "kill", 5)); Eq(BattleOutcome.Active, r.Outcome); Eq(1, r.Actor);
        });
        Test("capacity retains original nonce recovery", () => {
            var original = Input(); var b = new CombatInput("synthetic", "dev1", new CombatRules(1000, 100, 16, 100, 1), original.Units);
            var r = Run(b, C(1, 0, "hit", 5), C(1, 0, "hit", 5)); Eq(true, r.Receipts[1].Replayed); Eq(900, r.Hp[5]);
            r = Run(b, C(1, 0, "hit", 5), C(2, 5, "hit", 0)); Eq("CAPACITY", r.Receipts[1].Diagnostic); Eq(1000, r.Hp[0]);
        });
        Test("multishot primary interception is explicit and bypass is primary-only", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 2));
            var shot = new CombatSkill("shot", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true);
            var r = Run(Input(new[] { cover }, new[] { shot }), C(1, 0, "cover", 1), C(2, 5, "shot", 1, 2)); Eq(900, r.Hp[0]); Eq(1000, r.Hp[1]); Eq(950, r.Hp[2]);
            shot = new CombatSkill("shot", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500, bypassCover: true, primaryInterceptable: true);
            r = Run(Input(new[] { cover }, new[] { shot }), C(1, 0, "cover", 1), C(2, 5, "shot", 1, 2)); Eq(1000, r.Hp[0]); Eq(900, r.Hp[1]); Eq(950, r.Hp[2]);
        });
        Test("mitigation overflow rolls back an earlier shield application", () => {
            var skill = new CombatSkill("overflow", Selection.Enemy, 1, new[] {
                E(EffectKind.Barrier, 1, 2, targets: EffectTargets.Self), E(EffectKind.Damage, 10000000) }, 1);
            var units = Input().Units.Select((u, i) => i == 0 ? new CombatantInput(u.Id, u.Side, u.MaximumHp, 10000000, 0, 0, 100, new[] { skill }) : u);
            var b = new CombatInput("synthetic", "overflow", new CombatRules(1, 10000000, 16, 100, 100),
                units.Select(u => u.Id == "u0" ? u : new CombatantInput(u.Id, u.Side, u.MaximumHp, u.Offense, u.Armor, u.Resistance, u.Speed,
                    new[] { new CombatSkill("hit", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1) }, 1) })));
            var r = Run(b, C(1, 0, "overflow", 5)); Eq("ARITHMETIC-CAPACITY", r.Receipts[0].Diagnostic);
            Eq(0, r.Statuses.Count); Eq(1L, r.Version); Assert(r.Hp.All(h => h == 1000));
        });
        Test("v1 canonical snapshot and terminal golden unchanged", V1Golden);
        C1Tests();
        C2Tests();
        C3Tests();
        D1Tests();
        D2Tests();
        D3Tests();
        Console.WriteLine($"RESULT passed={passed} failed={failed}"); Environment.ExitCode = failed == 0 ? 0 : 1;
    }
    static void V1Golden()
    {
        const string path = "F:/AnotherLife/backend/StoryCombat.Tests/Fixtures/test-story-1-1.json";
        using var doc = JsonDocument.Parse(File.ReadAllBytes(path)); var x = doc.RootElement;
        string S(JsonElement e, string k) => e.GetProperty(k).GetString()!; int I(JsonElement e, string k) => e.GetProperty(k).GetInt32();
        var b = new V1.BattleInput(S(x, "engineVersion"), S(x, "contentId"), S(x, "contentVersion"), true, x.GetProperty("startedAt").GetInt64(), S(x, "turnOrder"), S(x, "enemyTarget"),
            x.GetProperty("heroes").EnumerateArray().Select(h => new V1.Hero(S(h, "instanceId"), S(h, "definitionId"), S(h, "definitionVersion"), I(h, "maxHp"), I(h, "damage"), h.GetProperty("skills").EnumerateArray().Select(s => new V1.Skill(S(s, "id"), Enum.Parse<V1.Target>(S(s, "target")), Enum.Parse<V1.Effect>(S(s, "effect")), I(s, "multiplier"))))),
            x.GetProperty("enemies").EnumerateArray().Select(e => new V1.Enemy(S(e, "definitionId"), I(e, "maxHp"), I(e, "attack"))));
        var commands = new List<V1.ActionCommand>(); var r = V1.TurnReplay.Replay(b, commands); Eq("35f1ffdeec667c24c07f780646f9a9114b1e18e89fe25aa6c9889f4387002afd", r.InputHash);
        var bytes = V1.SnapshotCodec.Encode(b); Eq(Convert.ToHexString(bytes), Convert.ToHexString(V1.SnapshotCodec.Encode(V1.SnapshotCodec.Decode(bytes))));
        for (int n = 1; r.Outcome == V1.Outcome.Active && n < 100; n++) { commands.Add(new V1.ActionCommand(N(n), r.Version, b.Heroes[r.Cursor].InstanceId, b.Heroes[r.Cursor].Skills[0].Id, Enumerable.Range(5, b.Enemies.Count).First(i => r.Hp[i] > 0), 1000 + n)); r = V1.TurnReplay.Replay(b, commands); }
        Eq(V1.Outcome.Victory, r.Outcome); Eq(13L, r.Version); Eq("56,80,80,80,80,0,0,0", string.Join(",", r.Hp)); Eq("baa6ed05122f36528215d5e10c4360da80a85cd0b89a5b2a7ad01b8c38e2cad0", r.StateHash);
    }
}

using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatSkill Finisher(int damage = 10000, int concealTurns = 2, int defenseDelta = -100, int defenseTurns = 2, DamageKind defenseKind = DamageKind.Physical, int cost = 0, int steal = 0, int cap = 0) =>
        new("finish", Selection.Enemy, 1, new[] { E(EffectKind.Damage, damage) }, 1000, hpCostCoefficient: cost, isUltimate: true, lifestealCoefficient: steal, lifestealCap: cap, followup: OutcomeFollowup.SelectedKillConcealElseDefense, killConcealTurns: concealTurns, survivorDefenseDelta: defenseDelta, survivorDefenseTurns: defenseTurns, survivorDefenseKind: defenseKind);
    static CombatSkill Hawk(bool capability = true, int revealTurns = 2) => new("hawk", Selection.Enemy, 1, new[] { E(EffectKind.Reveal, 0, revealTurns, false), Aim(targets: EffectTargets.Self) }, 1000, allowConcealedPrimaryReveal: capability);
    static List<CombatCommand> FinisherReady(CombatInput b, int target = 5) { var log = new List<CombatCommand>(); Step(b, log, "hit", target); UntilActor(b, log, 0); return log; }
    static void D3Tests()
    {
        Test("D3 selected root kill grants one fresh conceal without extra turn", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest } }), 1); var log = FinisherReady(b); var before = Run(b, log.ToArray()); var r = Step(b, log, "finish", 5); Eq(0, r.Hp[5]); Eq(before.Version + 1, r.Version); Eq(1, r.Actor); Eq(0, r.Readiness[0]); var s = r.Statuses.Single(); Eq(EffectKind.Conceal, s.Kind); Eq(0, s.Target); Eq("finish", s.Skill); Eq(2, s.RemainingTurns); Eq(900, r.Receipts.Last().DamageResults.Single().HpRemoved);
        });
        Test("D3 fresh kill conceal survives ordinary old conceal break", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hide, Finisher(), Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hide", 0); UntilActor(b, log, 0); var old = Run(b, log.ToArray()).Statuses.Single().Sequence; var r = Step(b, log, "finish", 5); var s = r.Statuses.Single(); Assert(s.Sequence > old); Eq("finish", s.Skill); Eq(2, s.RemainingTurns); Eq(0, r.Hp[5]);
        });
        Test("D3 selected survivor receives typed defense after strike", () => {
            var b = Threshold(Input(new[] { Hit, Finisher(1000), Rest }, armor: 100), 1); var log = FinisherReady(b); var r = Step(b, log, "finish", 5); Eq(900, r.Hp[5]); Eq(EffectKind.Defense, r.Statuses.Single().Kind); Eq(-100L, r.Statuses.Single().Amount); Eq(5, r.Statuses.Single().Target); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
            UntilActor(b, log, 0); Eq(800, Step(b, log, "hit", 5).Hp[5]);
        });
        Test("D3 magical survivor defense reduction leaves physical armor intact", () => {
            var magic = S("magic", Selection.Enemy, E(EffectKind.Damage, 1000, damage: DamageKind.Magic)); var b = Threshold(Input(new[] { Hit, Finisher(1000, defenseKind: DamageKind.Magic), magic, Rest }, armor: 100, resistance: 100), 1); var log = FinisherReady(b); Step(b, log, "finish", 5); UntilActor(b, log, 0); Eq(800, Step(b, log, "magic", 5).Hp[5]);
        });
        Test("D3 Cover protector death is selected survivor not kill credit", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 6); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Step(b, log, "finish", 6); Eq(0, r.Hp[5]); Eq(900, r.Hp[6]); Eq(5, r.Receipts.Last().DamageResults.Single().ActualRecipient); Eq(6, r.Statuses.Single(s => s.Kind == EffectKind.Defense).Target); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("D3 surviving protector also leaves defense branch on selected enemy", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(1000), Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 6); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Step(b, log, "finish", 6); Eq(900, r.Hp[5]); Eq(900, r.Hp[6]); Eq(6, r.Statuses.Single(s => s.Kind == EffectKind.Defense).Target);
        });
        Test("D3 shielded and floored strikes take survivor branch", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 5000, 5)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(1000), Rest }, [5] = new[] { shield, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); Step(b, log, "shield", 5); UntilActor(b, log, 0); var r = Step(b, log, "finish", 5); Eq(900, r.Hp[5]); Eq(0, r.Receipts.Last().DamageResults.Single().HpRemoved); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Defense));
            b = Threshold(Kits(new() { [0] = new[] { Hide, Finisher(1), Rest } }), 1); log = new List<CombatCommand>(); Step(b, log, "hide", 0); UntilActor(b, log, 0); r = Step(b, log, "finish", 5); Eq(1000, r.Hp[5]); Eq(0L, r.Receipts.Last().DamageResults.Single().PostMitigationAmount); Eq(EffectKind.Defense, r.Statuses.Single().Kind);
        });
        Test("D3 kill conceal finite expiry uses subsequent owner turns", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(concealTurns: 1), Rest } }), 1); var log = FinisherReady(b); Step(b, log, "finish", 5); UntilActor(b, log, 0); Assert(!Step(b, log, "rest", 0).Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("D3 survivor can cleanse defense branch", () => {
            var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(1000), Rest }, [5] = new[] { clean, Rest } }), 1); var log = FinisherReady(b); Step(b, log, "finish", 5); Assert(!Step(b, log, "clean", 5).Statuses.Any());
        });
        Test("D3 last enemy kill commits conceal then terminal without reopening", () => {
            var original = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest } }), 1); var b = new CombatInput(original.ContentId, original.ContentRevision, original.Rules, original.Units.Take(6)); var log = FinisherReady(b); var r = Step(b, log, "finish", 5); Eq(BattleOutcome.Victory, r.Outcome); Eq(-1, r.Actor); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Conceal)); log.Add(log.Last()); Eq(r.StateHash, Run(b, log.ToArray()).StateHash);
        });
        Test("D3 branch budget failure rolls back paid root and lifesteal", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(cost: 500, steal: 500, cap: 100), Rest } }, events: 3), 1); var log = FinisherReady(b); var before = Run(b, log.ToArray()); var r = Step(b, log, "finish", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[0]); Eq(900, r.Hp[5]); Eq(before.Version, r.Version); Eq(1, r.Readiness[0]); Eq(0, r.Receipts.Last().DamageResults.Count); Assert(!r.Statuses.Any());
        });
        Test("D3 kill branch capacity failure restores lethal strike", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Barrier, 1000, 5)); var b = Threshold(Input(new[] { ward, Finisher(), Rest }, effects: 1), 1); var log = new List<CombatCommand>(); Step(b, log, "ward", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "finish", 5); Eq("EFFECT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[5]); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence); Eq(1, r.Readiness[0]);
        });
        Test("D3 survivor branch capacity failure restores shield absorption", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Barrier, 5000, 5)); var b = Threshold(Input(new[] { Hit, Finisher(1000), Rest }, new[] { ward, Rest }, effects: 1), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); Step(b, log, "ward", 5); UntilActor(b, log, 0); var r = Step(b, log, "finish", 5); Eq("EFFECT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(500L, r.Statuses.Single().Amount); Eq(900, r.Hp[5]); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D3 owner-end poison can kill newly concealed actor after lifesteal", () => {
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 9000), Poison(2500, 2)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(steal: 500, cap: 100), Rest }, [5] = new[] { wound, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); Step(b, log, "wound", 0); UntilActor(b, log, 0); var r = Step(b, log, "finish", 5); Eq(0, r.Hp[0]); Eq(0, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal)); Eq(1, r.Receipts.Last().DamageResults.Count); Eq(DamageOrigin.Root, r.Receipts.Last().DamageResults.Single().Origin);
        });
        Test("D3 late poison failure restores branch and old state", () => {
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 9000), Poison(2000, 2)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest }, [5] = new[] { wound, Rest } }, events: 2), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); Step(b, log, "wound", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "finish", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(100, r.Hp[0]); Eq(900, r.Hp[5]); Eq(1, r.Readiness[0]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal)); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D3 finisher duplicate preserves branch sequence", () => { var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest } }), 1); var log = FinisherReady(b); var r = Step(b, log, "finish", 5); log.Add(log.Last()); var again = Run(b, log.ToArray()); Eq(r.StateHash, again.StateHash); Eq(r.Statuses.Single().Sequence, again.Statuses.Single().Sequence); });
        Test("D3 finisher invalid target and unavailable readiness cannot branch", () => { var b = Input(new[] { Finisher() }); Eq("ULTIMATE-NOT-READY", Run(b, C(1, 0, "finish", 5)).Receipts.Single().Diagnostic); Eq("TARGET-INVALID", Run(b, C(1, 0, "finish", 0)).Receipts.Single().Diagnostic); });
        Test("D3 finisher strict profile rejects conditional extra or projected damage", () => {
            foreach (var effects in new[] { new[] { Conditional(EffectPredicate.ActorConcealed, 1000) }, new[] { E(EffectKind.Damage, 1000), Aim(targets: EffectTargets.Self) }, new[] { CleaveDamage() } }) Throws(() => new CombatSkill("bad", Selection.Enemy, 1, effects, 1000, isUltimate: true, followup: OutcomeFollowup.SelectedKillConcealElseDefense, killConcealTurns: 2, survivorDefenseDelta: -100, survivorDefenseTurns: 2));
            Throws(() => Input(new[] { Ascend, Finisher() }));
        });
        Test("D3 finisher payload rejects missing harmful or finite fields", () => { Throws(() => Finisher(concealTurns: 0)); Throws(() => Finisher(defenseDelta: 0)); Throws(() => Finisher(defenseTurns: 0)); Throws(() => Finisher(defenseKind: (DamageKind)9)); Throws(() => new CombatSkill("bad", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1000) }, 1000, killConcealTurns: 2)); });
        Test("D3 HawkEye query and command admit hidden enemy with no secondary", () => {
            var b = Kits(new() { [0] = new[] { Hawk(), Hit, Rest }, [5] = new[] { Hide, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var p = ActionProjection.Query(b, log, "u0", "hawk", 5); Eq("", p.Diagnostic); Eq(false, p.Empowered); Eq(0, p.LegalSecondary.Count); Eq(before.StateHash, Run(b, log.ToArray()).StateHash); var r = Step(b, log, "hawk", 5); Eq("", r.Receipts.Last().Diagnostic); Eq(1, r.Readiness[0]); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Reveal)); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Aim)); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Conceal)); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D3 ordinary reveal without capability still refuses hidden target", () => { var b = Kits(new() { [0] = new[] { Hawk(false), Hit, Rest }, [5] = new[] { Hide, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); Eq("TARGET-INVALID", Step(b, log, "hawk", 5).Receipts.Last().Diagnostic); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "hit", 5).Diagnostic); });
        Test("D3 HawkEye permits visible enemy but not ally or secondary", () => { var b = Input(new[] { Hawk() }); Eq("", Run(b, C(1, 0, "hawk", 5)).Receipts.Single().Diagnostic); Eq("TARGET-INVALID", Run(b, C(1, 0, "hawk", 0)).Receipts.Single().Diagnostic); Eq("TARGET-INVALID", Run(b, C(1, 0, "hawk", 5, 6)).Receipts.Single().Diagnostic); });
        Test("D3 HawkEye preserves visible taunt primary restriction", () => {
            var taunt = S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 3, false)); var b = Kits(new() { [0] = new[] { Hawk(), Rest }, [5] = new[] { Hide, Rest }, [6] = new[] { taunt, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 6); Step(b, log, "taunt", 0); UntilActor(b, log, 0); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "hawk", 5).Diagnostic); Eq("", Step(b, log, "hawk", 6).Receipts.Last().Diagnostic);
        });
        Test("D3 Reveal expiry preserves remaining Conceal", () => {
            var b = Kits(new() { [0] = new[] { Hawk(revealTurns: 1), Hit, Rest }, [5] = new[] { Hide, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); Step(b, log, "hawk", 5); Step(b, log, "rest", 5); UntilActor(b, log, 0); var r = Run(b, log.ToArray()); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Conceal && s.Target == 5)); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Reveal)); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "hit", 5).Diagnostic); Eq("", ActionProjection.Query(b, log, "u0", "hawk", 5).Diagnostic);
        });
        Test("D3 Reveal cleanse restores hiding without deleting Conceal", () => {
            var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0)); var b = Kits(new() { [0] = new[] { Hawk(), Hit, Rest }, [5] = new[] { Hide, clean, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); Step(b, log, "hawk", 5); Step(b, log, "clean", 5); UntilActor(b, log, 0); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "hit", 5).Diagnostic);
        });
        Test("D3 HawkEye preserves lifesteal window and only grants Aim", () => {
            var grant = S("grant", Selection.Self, Window()); var b = Kits(new() { [0] = new[] { grant, Hawk(), Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var old = Run(b, log.ToArray()).Statuses.Single().Sequence; var r = Step(b, log, "hawk", 5); Eq(old, r.Statuses.Single(s => s.Kind == EffectKind.NextLifestealWindow).Sequence); Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.NextLifestealWindow).Charges); Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.Aim).Charges);
        });
        Test("D3 HawkEye retains ordinary hostile actor conceal break", () => { var b = Kits(new() { [0] = new[] { Hide, Hawk(), Rest } }); var log = new List<CombatCommand>(); Step(b, log, "hide", 0); UntilActor(b, log, 0); var r = Step(b, log, "hawk", 5); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal && s.Target == 0)); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Aim)); });
        Test("D3 late Aim capacity failure restores target Reveal", () => {
            var grant = S("grant", Selection.Self, Window()); var b = Input(new[] { grant, Hawk(), Rest }, effects: 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "hawk", 5); Eq("EFFECT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(before.Readiness[0], r.Readiness[0]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Reveal || s.Kind == EffectKind.Aim)); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence);
        });
        Test("D3 late Aim event failure restores hidden target state", () => { var b = Kits(new() { [0] = new[] { Hawk(), Rest }, [5] = new[] { Hide, Rest } }, events: 1); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "hawk", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(0, r.Readiness[0]); Eq(EffectKind.Conceal, r.Statuses.Single().Kind); });
        Test("D3 HawkEye duplicate is stable and conflict cannot regrant", () => { var b = Input(new[] { Hawk() }); var c = C(1, 0, "hawk", 5); var r = Run(b, c); Eq(r.StateHash, Run(b, c, c).StateHash); var conflict = new CombatCommand(c.Nonce, c.ExpectedVersion, c.Actor, c.Skill, 6); Eq("REQUEST-CONFLICT", Run(b, c, conflict).Receipts.Last().Diagnostic); });
        Test("D3 HawkEye rejects hostile payload expansion and conditional effects", () => {
            foreach (var extra in new[] { E(EffectKind.Damage, 1000), Mark(), Poison(), E(EffectKind.Dispel, 0), E(EffectKind.Defense, -100, 2, false) }) Throws(() => new CombatSkill("bad", Selection.Enemy, 1, new[] { E(EffectKind.Reveal, 0, 2, false), Aim(targets: EffectTargets.Self), extra }, 1000, allowConcealedPrimaryReveal: true));
            var conditional = new CombatEffect(EffectKind.Reveal, EffectTargets.Selected, 0, 2, beneficial: false, predicate: EffectPredicate.ActorConcealed); Throws(() => new CombatSkill("bad", Selection.Enemy, 1, new[] { conditional, Aim(targets: EffectTargets.Self) }, 1000, allowConcealedPrimaryReveal: true));
        });
        Test("D3 HawkEye rejects wrong shape cost and ultimate flags", () => {
            var effects = new[] { E(EffectKind.Reveal, 0, 2, false), Aim(targets: EffectTargets.Self) }; Throws(() => new CombatSkill("bad", Selection.UpToEnemies, 2, effects, 1000, allowConcealedPrimaryReveal: true)); Throws(() => new CombatSkill("bad", Selection.Enemy, 1, effects, 1000, hpCostCoefficient: 1, allowConcealedPrimaryReveal: true)); Throws(() => new CombatSkill("bad", Selection.Enemy, 1, effects, 1000, isUltimate: true, allowConcealedPrimaryReveal: true)); Throws(() => new CombatSkill("bad", Selection.Enemy, 1, effects.Reverse(), 1000, allowConcealedPrimaryReveal: true));
        });
        Test("D3 codec preserves descriptor and reveal capability", () => {
            var b = Input(new[] { Finisher(defenseKind: DamageKind.Magic), Hawk(), Rest }); var copy = CombatCodec.Decode(CombatCodec.Encode(b)); Eq(CombatCodec.Digest(CombatCodec.Encode(b)), CombatCodec.Digest(CombatCodec.Encode(copy))); Eq(OutcomeFollowup.SelectedKillConcealElseDefense, copy.Units[0].Skills[0].Followup); Eq(-100, copy.Units[0].Skills[0].SurvivorDefenseDelta); Eq(DamageKind.Magic, copy.Units[0].Skills[0].SurvivorDefenseKind); Eq(true, copy.Units[0].Skills[1].AllowConcealedPrimaryReveal); Assert(Run(Input(new[] { Hawk() })).InputHash != Run(Input(new[] { Hawk(false) })).InputHash);
        });
        Test("D3 rejects D2r002 format and unknown descriptor", () => {
            var bytes = CombatCodec.Encode(Input()); using var stream = new MemoryStream(); using (var w = new BinaryWriter(stream, System.Text.Encoding.UTF8, true)) { var domain = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-d2r002-candidate"); w.Write((ushort)domain.Length); w.Write(domain); int old = BitConverter.ToUInt16(bytes, 0); w.Write(bytes, old + 2, bytes.Length - old - 2); } Throws(() => CombatCodec.Decode(stream.ToArray())); Throws(() => new CombatSkill("bad", Selection.Self, 1, new[] { E(EffectKind.Heal, 0) }, 1000, followup: (OutcomeFollowup)9));
        });
        Test("D3 late branch refusal restores old conceal broken by offense", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hide, Finisher(), Rest } }, events: 2), 1); var log = new List<CombatCommand>(); Step(b, log, "hide", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "finish", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[5]); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence); Eq("hide", r.Statuses.Single().Skill); Eq(1, r.Readiness[0]);
        });
        Test("D3 kill conceal remains removable by ordinary area dispel", () => {
            var strip = S("strip", Selection.AllEnemies, E(EffectKind.Dispel, 0)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Finisher(), Rest }, [6] = new[] { strip, Rest } }), 1); var log = FinisherReady(b); Step(b, log, "finish", 5); UntilActor(b, log, 6); var r = Step(b, log, "strip", 0); Eq("", r.Receipts.Last().Diagnostic); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("D3 HawkEye does not change hidden taunt-source eligibility", () => {
            var taunt = S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 3, false)); var hideAlly = S("hideAlly", Selection.Ally, E(EffectKind.Conceal, 0, 3)); var b = Kits(new() { [0] = new[] { Hawk(), Rest }, [5] = new[] { Hide, Rest }, [6] = new[] { taunt, Rest }, [7] = new[] { hideAlly, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "rest", 0); Step(b, log, "hide", 5); UntilActor(b, log, 6); Step(b, log, "taunt", 0); Step(b, log, "hideAlly", 6); UntilActor(b, log, 0); Eq("", ActionProjection.Query(b, log, "u0", "hawk", 5).Diagnostic); Eq("", Step(b, log, "hawk", 5).Receipts.Last().Diagnostic);
        });
        Test("D3 HawkEye dead primary and stale command retain rejection", () => {
            var kill = S("kill", Selection.Enemy, E(EffectKind.Damage, 10000)); var b = Kits(new() { [0] = new[] { kill, Hawk(), Rest } }); var log = new List<CombatCommand>(); Step(b, log, "kill", 5); UntilActor(b, log, 0); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "hawk", 5).Diagnostic); var before = Run(b, log.ToArray()); log.Add(new CombatCommand(N(log.Count + 1), 1, "u0", "hawk", 6)); var r = Run(b, log.ToArray()); Eq("VERSION-CONFLICT", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Aim || s.Kind == EffectKind.Reveal));
        });
    }
}
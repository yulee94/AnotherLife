using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatEffect CleaveDamage(int value = 1000, EffectPredicate predicate = EffectPredicate.Always, int threshold = 0) => new(EffectKind.Damage, EffectTargets.Selected, value, predicate: predicate, threshold: threshold, empoweredSecondaryDamage: true);
    static CombatEffect FullWindow(int scale = 500, int increase = 500, int turns = 2, int windowTurns = 5) => new(EffectKind.NextLifestealWindow, EffectTargets.Self, 500, windowTurns, charges: 1, lifestealCap: 100, requiredEmpoweredTargetLimit: 2, empoweredSecondaryScale: scale, postEmpowerDamageTakenIncrease: increase, postEmpowerTurns: turns);
    static CombatSkill Ascend => new("ascend", Selection.Self, 1, new[] { FullWindow() }, 1000, isUltimate: true);
    static CombatSkill Strike => S("strike", Selection.Enemy, CleaveDamage());
    static CombatSkill Riven => new("riven", Selection.UpToEnemies, 2, new[] { CleaveDamage() }, 800);
    static CombatSkill Price => new("price", Selection.Enemy, 1, new[] { CleaveDamage(), E(EffectKind.Defense, -10, 3, false) }, 1000, hpCostCoefficient: 500);
    static CombatSkill Roar => S("roar", Selection.Enemy, E(EffectKind.Defense, -10, 3, false));
    static CombatInput FullInput(int events = 100) => Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Riven, Price, Roar, Rest } }, events), 1);
    static List<CombatCommand> FullReady(CombatInput b, bool wound = false)
    {
        var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); Step(b, log, "ascend", 0);
        if (wound) Step(b, log, "hit", 0);
        UntilActor(b, log, 0); return log;
    }
    static CombatResult Empower(CombatInput b, List<CombatCommand> log, string skill = "strike", int primary = 5, params int[] secondary)
    {
        var r = Run(b, log.ToArray()); var p = ActionProjection.Query(b, log, b.Units[r.Actor].Id, skill, primary);
        log.Add(new CombatCommand(N(log.Count + 1), r.Version, b.Units[r.Actor].Id, skill, primary, secondary, ActionMode.Empowered, p.WindowSequence)); return Run(b, log.ToArray());
    }
    static CombatEffect Vulnerable(int amount = 500, int turns = 3, DamageKind kind = DamageKind.Physical) => new(EffectKind.DamageTakenIncrease, EffectTargets.Selected, amount, turns, kind, false);
    static void D2Tests()
    {
        Test("D2 full package codec and copied payload", () => {
            var b = FullInput(); var copy = CombatCodec.Decode(CombatCodec.Encode(b)); Eq(CombatCodec.Digest(CombatCodec.Encode(b)), CombatCodec.Digest(CombatCodec.Encode(copy)));
            var log = FullReady(copy); var s = Run(copy, log.ToArray()).Statuses.Single(); Eq(2, s.RequiredEmpoweredTargetLimit); Eq(500, s.EmpoweredSecondaryScale); Eq(500, s.PostEmpowerDamageTakenIncrease); Eq(2, s.PostEmpowerTurns);
        });
        Test("D2 projection is pure immutable and agrees with admitted command", () => {
            var b = FullInput(); var log = FullReady(b); var before = Run(b, log.ToArray()); var p = ActionProjection.Query(b, log, "u0", "strike", 5); Eq("", p.Diagnostic); Eq(true, p.Empowered); Eq(2, p.MaximumTargets); Eq("6,7,8,9", string.Join(",", p.LegalSecondary)); Eq(before.StateHash, Run(b, log.ToArray()).StateHash); Assert(p.LegalSecondary is not int[]);
            Eq("", Empower(b, log, secondary: new[] { 6 }).Receipts.Last().Diagnostic);
        });
        Test("D2 wrong actor and unknown skill projection reject", () => { var b = FullInput(); Eq("NOT-YOUR-TURN", ActionProjection.Query(b, Array.Empty<CombatCommand>(), "u5", "strike", 5).Diagnostic); Eq("SKILL-UNAVAILABLE", ActionProjection.Query(b, Array.Empty<CombatCommand>(), "u0", "absent", 5).Diagnostic); Eq("ULTIMATE-NOT-READY", ActionProjection.Query(b, Array.Empty<CombatCommand>(), "u0", "ascend", 0).Diagnostic); });
        Test("D2 explicit secondary adds one scaled packet and no extra turn", () => {
            var b = FullInput(); var log = FullReady(b); var before = Run(b, log.ToArray()); var r = Empower(b, log, secondary: new[] { 6 }); Eq(800, r.Hp[5]); Eq(950, r.Hp[6]); Eq(2, r.Receipts.Last().DamageResults.Count); Eq(before.Version + 1, r.Version); Eq(5, r.Actor); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.DamageTakenIncrease));
        });
        Test("D2 primary-only empowered selection legal", () => { var b = FullInput(); var log = FullReady(b); var r = Empower(b, log); Eq("", r.Receipts.Last().Diagnostic); Eq(1, r.Receipts.Last().DamageResults.Count); Eq(1000, r.Hp[6]); });
        Test("D2 full package normal mode cannot evade consumption", () => {
            var b = FullInput(); var log = FullReady(b); var before = Run(b, log.ToArray()); var r = Step(b, log, "strike", 5); Eq("EMPOWERED-SELECTION-REQUIRED", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence);
        });
        Test("D2 sequence mismatch rejects without fallback", () => {
            var b = FullInput(); var log = FullReady(b); var r = Run(b, log.ToArray()); log.Add(new CombatCommand(N(log.Count + 1), r.Version, "u0", "strike", 5, new[] { 6 }, ActionMode.Empowered, r.Statuses.Single().Sequence + 1)); var after = Run(b, log.ToArray()); Eq("WINDOW-CONFLICT", after.Receipts.Last().Diagnostic); Eq(r.Version, after.Version); Eq(1000, after.Hp[6]);
        });
        Test("D2 malformed mode and missing sequence reject structurally", () => {
            var b = FullInput(); foreach (var c in new[] { new CombatCommand(N(1), 1, "u0", "strike", 5, mode: ActionMode.Empowered), new CombatCommand(N(1), 1, "u0", "strike", 5, mode: (ActionMode)9), new CombatCommand(N(1), 1, "u0", "strike", 5, expectedWindowSequence: 1) }) Eq("COMMAND-INVALID", Run(b, c).Receipts.Single().Diagnostic);
        });
        Test("D2 duplicate empowered request preserves state and evidence", () => { var b = FullInput(); var log = FullReady(b); var r = Empower(b, log, secondary: new[] { 6 }); log.Add(log.Last()); var again = Run(b, log.ToArray()); Eq(r.StateHash, again.StateHash); Eq(true, again.Receipts.Last().Replayed); Eq(2, again.Receipts.Last().DamageResults.Count); });
        Test("D2 nonce mode and sequence changes conflict", () => {
            var b = FullInput(); var log = FullReady(b); Empower(b, log); var c = log.Last(); log.Add(new CombatCommand(c.Nonce, c.ExpectedVersion, c.Actor, c.Skill, c.Primary)); Eq("REQUEST-CONFLICT", Run(b, log.ToArray()).Receipts.Last().Diagnostic); log.RemoveAt(log.Count - 1); log.Add(new CombatCommand(c.Nonce, c.ExpectedVersion, c.Actor, c.Skill, c.Primary, mode: ActionMode.Empowered, expectedWindowSequence: c.ExpectedWindowSequence + 1)); Eq("REQUEST-CONFLICT", Run(b, log.ToArray()).Receipts.Last().Diagnostic);
        });
        Test("D2 overlimit ally and duplicate secondaries preserve package", () => {
            var b = FullInput(); var seed = FullReady(b); foreach (var secondary in new[] { new[] { 6, 7 }, new[] { 1 }, new[] { 5 }, new[] { 6, 6 } }) { var log = new List<CombatCommand>(seed); var r = Empower(b, log, secondary: secondary); Assert(r.Receipts.Last().Diagnostic.Length > 0); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow)); Eq(0, r.Statuses.Count(s => s.Kind == EffectKind.DamageTakenIncrease)); }
        });
        Test("D2 static two target skill uses overridden scale once", () => { var b = FullInput(); var log = FullReady(b); var r = Empower(b, log, "riven", 5, 6); Eq(800, r.Hp[5]); Eq(950, r.Hp[6]); Eq(2, r.Receipts.Last().DamageResults.Count); });
        Test("D2 Blood Price pays once and does not expand target defense debuff", () => { var b = FullInput(); var log = FullReady(b); var r = Empower(b, log, "price", 5, 6); Eq(575, r.Hp[0]); Eq(800, r.Hp[5]); Eq(950, r.Hp[6]); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Defense)); Eq(5, r.Statuses.Single(s => s.Kind == EffectKind.Defense).Target); });
        Test("D2 support and Roar preserve full package without penalty", () => { var b = FullInput(); var log = FullReady(b); var r = Step(b, log, "roar", 5); Eq("", r.Receipts.Last().Diagnostic); Assert(r.Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow)); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.DamageTakenIncrease)); });
        Test("D2 setup ultimate creates no vulnerability", () => { var b = FullInput(); var log = FullReady(b); Eq(0, Run(b, log.ToArray()).Statuses.Count(s => s.Kind == EffectKind.DamageTakenIncrease)); });
        Test("D2 penalty begins after lifesteal and retains setup identity", () => { var b = FullInput(); var log = FullReady(b, true); var r = Empower(b, log); Eq(950, r.Hp[0]); var s = r.Statuses.Single(); Eq(EffectKind.DamageTakenIncrease, s.Kind); Eq("ascend", s.Skill); Eq(2, s.RemainingTurns); Eq(0, s.Source); Eq(0, s.Target); });
        Test("D2 incoming vulnerability affects physical and magical packets", () => {
            var two = S("two", Selection.Enemy, Vulnerable(), E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000, damage: DamageKind.Magic)); var result = Run(Input(new[] { two }), C(1, 0, "two", 5)); Eq(700, result.Hp[5]);
        });
        Test("D2 vulnerability applies postdefense prearea barrier", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.AreaReduction, 500, 3), E(EffectKind.Barrier, 100, 3)); var attack = new CombatSkill("attack", Selection.Enemy, 1, new[] { Vulnerable(), E(EffectKind.Damage, 1000) }, 1000, area: true); var r = Run(Input(new[] { ward }, new[] { attack }, armor: 100), C(1, 0, "ward", 0), C(2, 5, "attack", 0)); var p = r.Receipts.Last().DamageResults.Single(); Eq(37L, p.PostMitigationAmount); Eq(10L, p.BarrierAbsorbed); Eq(27, p.HpRemoved);
        });
        Test("D2 vulnerability uses highest increase rather than sum", () => {
            var low = S("low", Selection.Enemy, Vulnerable(200)); var high = S("high", Selection.Enemy, Vulnerable(500)); var b = Kits(new() { [0] = new[] { low, Rest }, [1] = new[] { high, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "low", 5); Step(b, log, "rest", 5); Step(b, log, "high", 5); var r = Step(b, log, "hit", 5); Eq(850, r.Hp[5]); Eq(2, r.Statuses.Count);
        });
        Test("D2 vulnerability refresh ignores irrelevant DamageKind", () => { var attack = S("attack", Selection.Enemy, Vulnerable(700), Vulnerable(200, kind: DamageKind.Magic), E(EffectKind.Damage, 1000)); var r = Run(Input(new[] { attack }), C(1, 0, "attack", 5)); Eq(880, r.Hp[5]); Eq(1, r.Statuses.Count); });
        Test("D2 vulnerability is cleanseable and not dispellable", () => {
            var apply = S("apply", Selection.Enemy, Vulnerable()); var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0)); var r = Run(Input(new[] { apply }, new[] { clean }), C(1, 0, "apply", 5), C(2, 5, "clean", 5)); Assert(!r.Statuses.Any());
            var strip = S("strip", Selection.Enemy, Vulnerable(), E(EffectKind.Dispel, 0)); Eq(1, Run(Input(new[] { strip }), C(1, 0, "strip", 5)).Statuses.Count);
        });
        Test("D2 penalty expires after exact subsequent owner turns", () => { var b = FullInput(); var log = FullReady(b); Empower(b, log); UntilActor(b, log, 0); Eq(1, Step(b, log, "rest", 0).Statuses.Single().RemainingTurns); UntilActor(b, log, 0); Assert(!Step(b, log, "rest", 0).Statuses.Any()); });
        Test("D2 late event failure rolls back cost lifesteal window penalty and trace", () => {
            var b = FullInput(events: 6); var log = FullReady(b); var before = Run(b, log.ToArray()); var r = Empower(b, log, "price", 5, 6); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(before.Hp[0], r.Hp[0]); Eq(before.Readiness[0], r.Readiness[0]); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D2 invalid payload and nonself setup reject", () => {
            Throws(() => new CombatEffect(EffectKind.NextLifestealWindow, EffectTargets.Self, 500, 3, charges: 1, lifestealCap: 100, requiredEmpoweredTargetLimit: 2)); Throws(() => S("bad", Selection.Self, FullWindow())); Throws(() => new CombatSkill("bad", Selection.Ally, 1, new[] { FullWindow() }, 1000, isUltimate: true));
        });
        Test("D2 full kit rejects unsupported damaging actions and unmarked damage", () => {
            Throws(() => Input(new[] { Ascend, Hit })); var area = new CombatSkill("area", Selection.AllEnemies, 5, new[] { CleaveDamage() }, 1000, area: true); Throws(() => Input(new[] { Ascend, area })); var three = new CombatSkill("three", Selection.UpToEnemies, 3, new[] { CleaveDamage() }, 500); Throws(() => Input(new[] { Ascend, three }));
        });
        Test("D2 six-slot Berserker fixture admits all positive offense", () => { var vow = S("vow", Selection.Self, Mod(targets: EffectTargets.Self), new CombatEffect(EffectKind.DamageTakenIncrease, EffectTargets.Self, 200, 2, beneficial: false)); var b = Input(new[] { Strike, Riven, vow, Price, Roar, Ascend }); Eq(6, b.Units[0].Skills.Count); });
        Test("D2 coefficient bounds and damage-only projection flag fail closed", () => { Throws(() => new CombatEffect(EffectKind.Heal, EffectTargets.Self, 1000, empoweredSecondaryDamage: true)); Throws(() => Input(new[] { new CombatSkill("ascend", Selection.Self, 1, new[] { FullWindow(scale: 1001) }, 1000, isUltimate: true), Strike })); Throws(() => Vulnerable(0)); });
        Test("D2 D1 domain rejected without reinterpretation", () => {
            var bytes = CombatCodec.Encode(FullInput()); using var stream = new MemoryStream(); using (var w = new BinaryWriter(stream, System.Text.Encoding.UTF8, true)) { var domain = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-d1-candidate"); w.Write((ushort)domain.Length); w.Write(domain); int old = BitConverter.ToUInt16(bytes, 0); w.Write(bytes, old + 2, bytes.Length - old - 2); } Throws(() => CombatCodec.Decode(stream.ToArray()));
        });
        Test("D2 D1 regression oldest multiple Aim consumes only one", () => {
            var own = S("own", Selection.Self, Aim()); var other = S("other", Selection.Ally, Aim()); var b = Threshold(Kits(new() { [0] = new[] { own, Ultimate(true), Rest }, [1] = new[] { other, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "own", 0); Step(b, log, "rest", 5); Step(b, log, "other", 0); UntilActor(b, log, 0); var r = Shot(b, log, 5); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.Aim)); Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.Aim).Source);
        });
        Test("D2 D1 regression same-root window refresh preserves new sequence", () => {
            var action = S("action", Selection.Enemy, Window(500, 100, targets: EffectTargets.Self), E(EffectKind.Damage, 1000)); var b = Kits(new() { [0] = new[] { action, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "action", 5); Step(b, log, "hit", 0); UntilActor(b, log, 0); var old = Run(b, log.ToArray()).Statuses.Single().Sequence; var r = Step(b, log, "action", 5); Eq(950, r.Hp[0]); Eq(1, r.Statuses.Single().Charges); Assert(r.Statuses.Single().Sequence > old);
        });
        Test("D2 D1 regression same-root Aim refresh uses old bypass preserves new", () => {
            var ult = new CombatSkill("ultimate", Selection.UpToEnemies, 3, new[] { Aim(targets: EffectTargets.Self), E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, isUltimate: true, useAimForPrimaryCoverBypass: true); var grant = S("grant", Selection.Self, Aim()); var b = Threshold(Kits(new() { [0] = new[] { grant, ult, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var old = Run(b, log.ToArray()).Statuses.Single().Sequence; var r = Shot(b, log, 5); Eq(true, r.Receipts.Last().DamageResults.Single().CoverBypassed); Assert(r.Statuses.Single().Sequence > old);
        });
        Test("D2 D1 regression zero secondary-only eligibility preserves window", () => {
            foreach (int scale in new[] { 0, 500 }) { var grant = S("grant", Selection.Self, Window()); var conditional = new CombatSkill("conditional", Selection.UpToEnemies, 2, new[] { Conditional(EffectPredicate.TargetInjured, 1000, 999) }, scale); var b = Kits(new() { [0] = new[] { grant, conditional, Rest }, [1] = new[] { Hit, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "rest", 5); Step(b, log, "hit", 6); UntilActor(b, log, 0); var r = Run(b, log.ToArray()); log.Add(new CombatCommand(N(log.Count + 1), r.Version, "u0", "conditional", 5, new[] { 6 })); r = Run(b, log.ToArray()); Eq(scale == 0 ? 1 : 0, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow)); }
        });
        Test("D2 D1 regression lifesteal precedes surviving and lethal poison", () => {
            foreach (int tick in new[] { 1250, 2000 }) { var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 9000), Poison(tick, 2)); var grant = S("grant", Selection.Self, Window()); var b = Kits(new() { [0] = new[] { grant, Drain(), Rest }, [5] = new[] { wound, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "wound", 0); UntilActor(b, log, 0); var r = Step(b, log, "drain", 5); Eq(tick == 1250 ? 25 : 0, r.Hp[0]); Eq(100, r.Receipts.Last().DamageResults.Single().HpRemoved); Eq(2, r.Readiness[0]); }
        });
        Test("D2 D1 regression late poison failure rolls back lifesteal and window", () => {
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 9000), Poison(2000, 2)); var grant = S("grant", Selection.Self, Window()); var b = Kits(new() { [0] = new[] { grant, Drain(), Rest }, [5] = new[] { wound, Rest } }, events: 3); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "wound", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "drain", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(100, r.Hp[0]); Eq(1000, r.Hp[5]); Eq(before.Version, r.Version); Eq(before.Readiness[0], r.Readiness[0]); Eq(string.Join(",", before.Statuses.Select(s => s.Sequence)), string.Join(",", r.Statuses.Select(s => s.Sequence))); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D2 new penalty applies to same owner-end poison after lifesteal", () => {
            var hit = S("hit", Selection.Enemy, E(EffectKind.Damage, 1000), Poison(1000, 3)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { hit, Rest } }), 1); var log = FullReady(b, true); var r = Empower(b, log); Eq(800, r.Hp[0]); Eq(100, r.Receipts.Last().DamageResults.Single().HpRemoved); Eq(2, r.Statuses.Single(s => s.Kind == EffectKind.DamageTakenIncrease).RemainingTurns);
        });
        Test("D2 hidden primary and secondary never gain broad visibility bypass", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { Hide, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); Step(b, log, "ascend", 0); Step(b, log, "hide", 5); UntilActor(b, log, 0); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "strike", 5).Diagnostic); var p = ActionProjection.Query(b, log, "u0", "strike", 6); Assert(!p.LegalSecondary.Contains(5)); Eq("TARGET-INVALID", Empower(b, log, "strike", 6, 5).Receipts.Last().Diagnostic);
        });
        Test("D2 taunt still restricts projected primary", () => {
            var taunt = S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 3, false)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { taunt, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); Step(b, log, "ascend", 0); Step(b, log, "taunt", 0); UntilActor(b, log, 0); Eq("TARGET-INVALID", ActionProjection.Query(b, log, "u0", "strike", 6).Diagnostic); Eq("", Empower(b, log, "strike", 5, 6).Receipts.Last().Diagnostic);
        });
        Test("D2 single selected empowered cleave follows ordinary cleave Cover behavior", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 6); UntilActor(b, log, 0); Step(b, log, "ascend", 0); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Empower(b, log, "strike", 6); Eq(1000, r.Hp[5]); Eq(800, r.Hp[6]); Eq(6, r.Receipts.Last().DamageResults.Single().ActualRecipient); Eq(false, r.Receipts.Last().DamageResults.Single().CoverBypassed);
        });
        Test("D2 dispelled unused package has no penalty and stale assertion rejects", () => {
            var dispel = S("dispel", Selection.Enemy, E(EffectKind.Dispel, 0)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { dispel, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); var setup = Step(b, log, "ascend", 0); long sequence = setup.Statuses.Single().Sequence; Step(b, log, "dispel", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); Assert(!before.Statuses.Any()); log.Add(new CombatCommand(N(log.Count + 1), before.Version, "u0", "strike", 5, mode: ActionMode.Empowered, expectedWindowSequence: sequence)); Eq("WINDOW-CONFLICT", Run(b, log.ToArray()).Receipts.Last().Diagnostic);
        });
        Test("D2 expired unused package creates no penalty", () => {
            var setup = new CombatSkill("ascend", Selection.Self, 1, new[] { FullWindow(windowTurns: 1) }, 1000, isUltimate: true); var b = Threshold(Kits(new() { [0] = new[] { Strike, setup, Rest } }), 1); var log = FullReady(b); Step(b, log, "rest", 0); Assert(!Run(b, log.ToArray()).Statuses.Any());
        });
        Test("D2 old standalone window precedes newer full package", () => {
            var grant = S("grant", Selection.Self, Window(turns: 5)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, grant, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Step(b, log, "ascend", 0); UntilActor(b, log, 0); Eq(false, ActionProjection.Query(b, log, "u0", "strike", 5).Empowered); var r = Step(b, log, "strike", 5); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow)); Eq(2, r.Statuses.Single().RequiredEmpoweredTargetLimit); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.DamageTakenIncrease));
        });
        Test("D2 full package all-false primary preserves window", () => {
            var conditional = S("conditional", Selection.Enemy, CleaveDamage(predicate: EffectPredicate.ActorConcealed)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, conditional, Rest } }), 1); var log = FullReady(b); var r = Step(b, log, "conditional", 5); Eq("", r.Receipts.Last().Diagnostic); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow)); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D2 fully shielded empowered attack still consumes and penalizes", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 5000, 5)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { shield, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); Step(b, log, "ascend", 0); Step(b, log, "shield", 5); UntilActor(b, log, 0); var r = Empower(b, log); Eq(0, r.Receipts.Last().DamageResults.Single().HpRemoved); Assert(r.Statuses.Any(s => s.Kind == EffectKind.DamageTakenIncrease)); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D2 full kit rejects target-dependent native cleave evasion", () => {
            var conditional = new CombatSkill("conditional", Selection.UpToEnemies, 2, new[] { CleaveDamage(predicate: EffectPredicate.TargetInjured, threshold: 999) }, 500); Throws(() => Input(new[] { Ascend, conditional }));
        });
        Test("D2 weakened to zero still consumes package and penalizes", () => {
            var weaken = S("weaken", Selection.Enemy, Mod(-1000, 1)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { weaken, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "strike", 5); UntilActor(b, log, 0); Step(b, log, "ascend", 0); Step(b, log, "weaken", 0); UntilActor(b, log, 0); var r = Empower(b, log); Eq(0L, r.Receipts.Last().DamageResults.Single().PostMitigationAmount); Eq(0, r.Readiness[0]); Assert(r.Statuses.Any(s => s.Kind == EffectKind.DamageTakenIncrease)); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D2 projection reports command capacity consistently", () => {
            var original = Input(); var b = new CombatInput(original.ContentId, original.ContentRevision, new CombatRules(1000, 100, 16, 100, 1), original.Units); var log = new[] { C(1, 0, "hit", 5) }; Eq("CAPACITY", ActionProjection.Query(b, log, "u5", "hit", 0).Diagnostic);
        });
        Test("D2 last living enemy permits primary-only projected action", () => {
            var original = FullInput(); var b = new CombatInput(original.ContentId, original.ContentRevision, original.Rules, original.Units.Take(6)); var log = FullReady(b); var p = ActionProjection.Query(b, log, "u0", "strike", 5); Eq(0, p.LegalSecondary.Count); Eq("", Empower(b, log).Receipts.Last().Diagnostic);
        });
        Test("D2 late poison failure rolls back newly inserted penalty", () => {
            var hit = S("hit", Selection.Enemy, E(EffectKind.Damage, 1000), Poison(1000, 3)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, Rest }, [5] = new[] { hit, Rest } }, events: 4), 1); var log = FullReady(b, true); var before = Run(b, log.ToArray()); var r = Empower(b, log); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Hp[0], r.Hp[0]); Eq(before.Hp[5], r.Hp[5]); Eq(before.Version, r.Version); Eq(before.Readiness[0], r.Readiness[0]); Eq(before.CompletedOwnerTurns[0], r.CompletedOwnerTurns[0]); Eq(string.Join(",", before.Statuses.Select(s => s.Sequence)), string.Join(",", r.Statuses.Select(s => s.Sequence))); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.DamageTakenIncrease)); Eq(0, r.Receipts.Last().DamageResults.Count);
        });
        Test("D2 r002 native cleave Poison retains original scale while Damage changes", () => {
            var venom = new CombatSkill("venom", Selection.UpToEnemies, 2, new[] { CleaveDamage(), Poison(1000, 2) }, 800); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, venom, Rest } }), 1);
            foreach (bool powered in new[] { false, true }) {
                var log = powered ? FullReady(b) : new List<CombatCommand>(); CombatResult r;
                if (powered) r = Empower(b, log, "venom", 5, 6);
                else { log.Add(C(1, 0, "venom", 5, 6)); r = Run(b, log.ToArray()); }
                Eq("", r.Receipts.Last().Diagnostic); Eq(powered ? 950 : 920, r.Hp[6]); Eq(80L, r.Statuses.Single(s => s.Kind == EffectKind.Poison && s.Target == 6).Amount);
                Eq(powered ? 50L : 80L, r.Receipts.Last().DamageResults.Single(p => p.IntendedTarget == 6).PostMitigationAmount);
                UntilActor(b, log, 6); r = Step(b, log, "rest", 6); Eq(powered ? 870 : 840, r.Hp[6]);
            }
        });
        Test("D2 r002 newly expanded single target still excludes secondary Poison", () => {
            var venom = S("venom", Selection.Enemy, CleaveDamage(), Poison(1000, 2)); var b = Threshold(Kits(new() { [0] = new[] { Strike, Ascend, venom, Rest } }), 1); var log = FullReady(b); var r = Empower(b, log, "venom", 5, 6);
            Eq(950, r.Hp[6]); Eq(100L, r.Statuses.Single(s => s.Kind == EffectKind.Poison).Amount); Eq(5, r.Statuses.Single(s => s.Kind == EffectKind.Poison).Target); UntilActor(b, log, 6); Eq(950, Step(b, log, "rest", 6).Hp[6]);
        });
        Test("D2 r002 same ultimate truly refreshes its own captured Aim identity", () => {
            var ult = new CombatSkill("ultimate", Selection.UpToEnemies, 3, new[] { Aim(targets: EffectTargets.Self), E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, isUltimate: true, useAimForPrimaryCoverBypass: true);
            var b = Threshold(Kits(new() { [0] = new[] { Hit, ult, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); UntilActor(b, log, 0); var first = Shot(b, log, 5); Eq(false, first.Receipts.Last().DamageResults.Single().CoverBypassed);
            long oldSequence = first.Statuses.Single(s => s.Kind == EffectKind.Aim).Sequence; UntilActor(b, log, 0); Step(b, log, "hit", 5); UntilActor(b, log, 0);
            var before = Run(b, log.ToArray()); var oldAim = before.Statuses.Single(s => s.Kind == EffectKind.Aim); Eq(oldSequence, oldAim.Sequence); Eq("ultimate", oldAim.Skill); Assert(oldAim.RemainingTurns > 0); Eq(1, before.Readiness[0]);
            var r = Shot(b, log, 5); Eq(true, r.Receipts.Last().DamageResults.Single().CoverBypassed); var fresh = r.Statuses.Single(s => s.Kind == EffectKind.Aim); Eq(oldAim.Source, fresh.Source); Eq(oldAim.Target, fresh.Target); Eq(oldAim.Skill, fresh.Skill); Assert(fresh.Sequence > oldSequence); Eq(1, fresh.Charges); Eq(5, fresh.RemainingTurns);
            log.Add(log.Last()); var replayed = Run(b, log.ToArray()); Eq(r.StateHash, replayed.StateHash); Eq(true, replayed.Receipts.Last().Replayed); Eq(fresh.Sequence, replayed.Statuses.Single(s => s.Kind == EffectKind.Aim).Sequence);
        });
        Test("D2 r002 rejects sealed r001 domain", () => {
            var bytes = CombatCodec.Encode(FullInput()); using var stream = new MemoryStream(); using (var w = new BinaryWriter(stream, System.Text.Encoding.UTF8, true)) { var domain = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-d2-candidate"); w.Write((ushort)domain.Length); w.Write(domain); int old = BitConverter.ToUInt16(bytes, 0); w.Write(bytes, old + 2, bytes.Length - old - 2); } Throws(() => CombatCodec.Decode(stream.ToArray())); Eq("five-hero-effects-v2-d3-candidate", CombatInput.EngineVersion);
        });
    }
}
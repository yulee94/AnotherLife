using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatEffect Window(int coefficient = 500, int cap = 100, int turns = 5, EffectTargets targets = EffectTargets.Selected) => new(EffectKind.NextLifestealWindow, targets, coefficient, turns, charges: 1, lifestealCap: cap);
    static CombatEffect Aim(int turns = 5, EffectTargets targets = EffectTargets.Selected) => new(EffectKind.Aim, targets, 0, turns, charges: 1);
    static CombatSkill Drain(int coefficient = 500, int cap = 100, int damage = 1000) => new("drain", Selection.Enemy, 1, new[] { E(EffectKind.Damage, damage) }, 1000, lifestealCoefficient: coefficient, lifestealCap: cap);
    static CombatSkill Ultimate(bool aim = false) => new("ultimate", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, isUltimate: true, useAimForPrimaryCoverBypass: aim);
    static CombatInput Threshold(CombatInput b, int n) => new(b.ContentId, b.ContentRevision, new CombatRules(b.Rules.Scale, b.Rules.DefenseK, b.Rules.MaximumEffects, b.Rules.MaximumEvents, b.Rules.MaximumCommands, n), b.Units);
    static CombatResult Shot(CombatInput b, List<CombatCommand> log, int primary, params int[] secondary)
    { var r = Run(b, log.ToArray()); log.Add(new CombatCommand(N(log.Count + 1), r.Version, b.Units[r.Actor].Id, "ultimate", primary, secondary)); return Run(b, log.ToArray()); }
    static void D1Tests()
    {
        Test("D1 readiness begins at zero and result is immutable", () => {
            var r = Run(Input()); Assert(r.Readiness.All(x => x == 0)); Assert(r.Readiness is not int[]);
            try { ((IList<int>)r.Readiness)[0] = 20; throw new Exception("mutable"); } catch (NotSupportedException) { }
        });
        Test("D1 configured zero and floor zero damage earn no readiness", () => {
            foreach (int value in new[] { 0, 1 }) { var r = Run(Input(new[] { S("zero", Selection.Enemy, E(EffectKind.Damage, value)) }), C(1, 0, "zero", 5)); Eq(0, r.Readiness[0]); Eq(0L, r.Receipts[0].DamageResults[0].PostMitigationAmount); }
        });
        Test("D1 all false root predicates earn no readiness", () => {
            var b = Input(new[] { S("miss", Selection.Enemy, Conditional(EffectPredicate.ActorConcealed, 1000)) }); var r = Run(b, C(1, 0, "miss", 5)); Eq(0, r.Readiness[0]); Eq(0, r.Receipts[0].DamageResults.Count);
            var breaking = S("breaking", Selection.Enemy, E(EffectKind.Conceal, 0, 3, targets: EffectTargets.Self), E(EffectKind.Damage, 0));
            b = Kits(new() { [0] = new[] { breaking, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "breaking", 5); Eq(0, Run(b, log.ToArray()).Readiness[0]);
        });
        Test("D1 positive damage grants exactly one capped readiness", () => {
            var twice = S("twice", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000)); var b = Threshold(Kits(new() { [0] = new[] { twice, Rest } }), 1); var log = new List<CombatCommand>();
            Eq(1, Step(b, log, "twice", 5).Readiness[0]); UntilActor(b, log, 0); Eq(1, Step(b, log, "twice", 5).Readiness[0]);
        });
        Test("D1 full barrier still qualifies positive mitigation damage", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 2000, 3)); var r = Run(Input(new[] { shield }), C(1, 0, "shield", 0), C(2, 5, "hit", 0)); var p = r.Receipts[1].DamageResults.Single();
            Eq(1, r.Readiness[5]); Eq(100L, p.PostMitigationAmount); Eq(100L, p.BarrierAbsorbed); Eq(0, p.HpRemoved);
        });
        Test("D1 fully mitigated positive coefficient does not qualify", () => {
            var r = Run(Input(new[] { S("tiny", Selection.Enemy, E(EffectKind.Damage, 10)) }, armor: 10000000), C(1, 0, "tiny", 5)); Eq(0, r.Readiness[0]); Eq(0L, r.Receipts[0].DamageResults[0].PostMitigationAmount);
        });
        Test("D1 direct heal credits actual starting deficit", () => {
            var heal = S("heal", Selection.Self, E(EffectKind.Heal, 1000)); var r = Run(Input(enemy: new[] { heal }), C(1, 0, "hit", 5), C(2, 5, "heal", 5)); Eq(1, r.Readiness[5]); Eq(1000, r.Hp[5]);
            r = Run(Input(new[] { heal }), C(1, 0, "heal", 0)); Eq(0, r.Readiness[0]);
        });
        Test("D1 cost-created deficit earns no healing readiness", () => {
            var paid = Paid(500, E(EffectKind.Heal, 1000, targets: EffectTargets.Self)); var r = Run(Input(new[] { paid }), C(1, 0, "paid", 5)); Eq(600, r.Hp[0]); Eq(0, r.Readiness[0]);
        });
        Test("D1 paid heal retains preexisting deficit credit", () => {
            var paid = Paid(500, E(EffectKind.Heal, 1000, targets: EffectTargets.Self)); var r = Run(Input(enemy: new[] { paid }), C(1, 0, "hit", 5), C(2, 5, "paid", 0)); Eq(550, r.Hp[5]); Eq(1, r.Readiness[5]);
        });
        Test("D1 full healing reduction removes direct heal credit", () => {
            var cut = S("cut", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.HealingReduction, 1000, 3, false)); var heal = S("heal", Selection.Self, E(EffectKind.Heal, 1000)); var r = Run(Input(new[] { cut }, new[] { heal }), C(1, 0, "cut", 5), C(2, 5, "heal", 5)); Eq(900, r.Hp[5]); Eq(0, r.Readiness[5]);
        });
        Test("D1 effective support qualifies and empty cleanse does not", () => {
            Eq(1, Run(Input(new[] { Hide }), C(1, 0, "hide", 0)).Readiness[0]); var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0)); Eq(0, Run(Input(new[] { clean }), C(1, 0, "clean", 0)).Readiness[0]);
        });
        Test("D1 zero barrier and zero delayed heal do not qualify", () => {
            foreach (var kind in new[] { EffectKind.Barrier, EffectKind.DelayedHeal }) { var s = S("zero", Selection.Self, E(kind, 0, 3)); Eq(0, Run(Input(new[] { s }), C(1, 0, "zero", 0)).Readiness[0]); }
        });
        Test("D1 actual cleanse earns readiness and poison tick alone does not", () => {
            var poison = S("poison", Selection.Enemy, Poison()); var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0));
            var r = Run(Input(new[] { poison }, new[] { clean }), C(1, 0, "poison", 5), C(2, 5, "clean", 5)); Eq(1, r.Readiness[5]); Eq(1000, r.Hp[5]);
            r = Run(Input(new[] { poison }), C(1, 0, "poison", 5), C(2, 5, "rest", 5)); Eq(0, r.Readiness[5]); Eq(900, r.Hp[5]); Eq(0, r.Receipts[1].DamageResults.Count);
        });
        Test("D1 intrinsic lifesteal uses actual HP and shared heal", () => {
            var r = Run(Input(enemy: new[] { Drain() }), C(1, 0, "hit", 5), C(2, 5, "drain", 0)); Eq(950, r.Hp[5]); Eq(900, r.Hp[0]); Eq(DamageOrigin.Root, r.Receipts[1].DamageResults.Single().Origin);
        });
        Test("D1 lifesteal cap limits aggregate healing", () => {
            var r = Run(Input(enemy: new[] { Drain(1000, 20) }), C(1, 0, "hit", 5), C(2, 5, "drain", 0)); Eq(920, r.Hp[5]);
        });
        Test("D1 lifesteal excludes overkill", () => {
            var b = Hp0(Input(enemy: new[] { Drain(1000, 1000, 10000) }), 10); var r = Run(b, C(1, 0, "hit", 5), C(2, 5, "drain", 0)); Eq(910, r.Hp[5]); Eq(10, r.Receipts[1].DamageResults.Single().HpRemoved);
        });
        Test("D1 lifesteal excludes absorbed barrier damage", () => {
            CombatSkill shield;
            // Use an enemy-selected mixed skill so the barrier remains a valid self-target effect.
            shield = S("shield", Selection.Enemy, E(EffectKind.Barrier, 2000, 3, targets: EffectTargets.Self), E(EffectKind.Damage, 1000));
            var r = Run(Input(new[] { shield }, new[] { Drain() }), C(1, 0, "shield", 5), C(2, 5, "drain", 0)); Eq(900, r.Hp[5]); Eq(0, r.Receipts[1].DamageResults.Single().HpRemoved);
        });
        Test("D1 lifesteal credits actual Cover recipient", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 3), E(EffectKind.Heal, 0)); var r = Run(Input(new[] { cover }, new[] { Drain() }, guardArmor: 100), C(1, 0, "cover", 1), C(2, 5, "drain", 1)); var p = r.Receipts[1].DamageResults.Single(); Eq(0, p.ActualRecipient); Eq(1, p.IntendedTarget); Eq(50, p.HpRemoved); Eq(1000, r.Hp[1]);
        });
        Test("D1 lifesteal applies healing reduction once", () => {
            var cut = S("cut", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.HealingReduction, 500, 3, false)); var r = Run(Input(new[] { cut }, new[] { Drain() }), C(1, 0, "cut", 5), C(2, 5, "drain", 0)); Eq(925, r.Hp[5]);
        });
        Test("D1 lifesteal at maximum HP remains capped", () => { var r = Run(Input(new[] { Drain() }), C(1, 0, "drain", 5)); Eq(1000, r.Hp[0]); Eq(1, r.Readiness[0]); });
        Test("D1 window overrides intrinsic pair and consumes once", () => {
            var grant = S("grant", Selection.Self, Window(1000, 15)); var b = Kits(new() { [0] = new[] { grant, Drain(), Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "hit", 0); UntilActor(b, log, 0); var r = Step(b, log, "drain", 5); Eq(915, r.Hp[0]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 pure debuff preserves lifesteal window", () => {
            var grant = S("grant", Selection.Self, Window()); var debuff = S("debuff", Selection.Enemy, E(EffectKind.Defense, -10, 2, false)); var b = Kits(new() { [0] = new[] { grant, debuff, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var r = Step(b, log, "debuff", 5); Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.NextLifestealWindow).Charges);
        });
        Test("D1 zero configured damage preserves window", () => {
            var grant = S("grant", Selection.Self, Window()); var zero = S("zero", Selection.Enemy, E(EffectKind.Damage, 0)); var b = Kits(new() { [0] = new[] { grant, zero, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Eq(1, Step(b, log, "zero", 5).Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 false damage predicate preserves window", () => {
            var grant = S("grant", Selection.Self, Window()); var miss = S("miss", Selection.Enemy, Conditional(EffectPredicate.ActorConcealed, 1000)); var b = Kits(new() { [0] = new[] { grant, miss, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Eq(1, Step(b, log, "miss", 5).Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 new window cannot fund same root action", () => {
            var mixed = S("mixed", Selection.Enemy, Window(1000, 100, targets: EffectTargets.Self), E(EffectKind.Damage, 1000)); var r = Run(Input(enemy: new[] { mixed }), C(1, 0, "hit", 5), C(2, 5, "mixed", 0)); Eq(900, r.Hp[5]); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 window expires on its finite owner turns", () => {
            var grant = S("grant", Selection.Self, Window(turns: 1)); var b = Kits(new() { [0] = new[] { grant, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Assert(!Step(b, log, "rest", 0).Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 dispel removes window before later root", () => {
            var grant = S("grant", Selection.Self, Window()); var dispel = S("dispel", Selection.Enemy, E(EffectKind.Dispel, 0)); var r = Run(Input(new[] { grant }, new[] { dispel }), C(1, 0, "grant", 0), C(2, 5, "dispel", 0)); Assert(!r.Statuses.Any()); Eq(1, r.Readiness[5]);
        });
        Test("D1 unavailable ultimate preserves all combat state", () => {
            var b = Input(new[] { Ultimate() }); var r = Run(b, C(1, 0, "ultimate", 5)); Eq("ULTIMATE-NOT-READY", r.Receipts.Single().Diagnostic); Eq(1L, r.Version); Assert(r.Hp.All(x => x == 1000)); Eq(0, r.Readiness[0]);
        });
        Test("D1 ready ultimate consumes all and earns none", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hit, Ultimate(), Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); UntilActor(b, log, 0); var r = Shot(b, log, 5, 6, 7); Eq("", r.Receipts.Last().Diagnostic); Eq(0, r.Readiness[0]); Eq(800, r.Hp[5]); Eq(950, r.Hp[6]); Eq(950, r.Hp[7]);
        });
        Test("D1 duplicate ultimate recovers receipt without another consume", () => {
            var b = Threshold(Kits(new() { [0] = new[] { Hit, Ultimate(), Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); UntilActor(b, log, 0); var before = Shot(b, log, 5); log.Add(log.Last()); var r = Run(b, log.ToArray()); Eq(before.StateHash, r.StateHash); Eq(true, r.Receipts.Last().Replayed); Eq(1, r.Receipts.Last().DamageResults.Count);
        });
        Test("D1 Aim bypasses primary Cover and preserves secondary scale", () => {
            var grant = S("grant", Selection.Self, Aim()); var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { grant, Ultimate(true), Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Shot(b, log, 6, 7); Eq(1000, r.Hp[5]); Eq(900, r.Hp[6]); Eq(950, r.Hp[7]); var p = r.Receipts.Last().DamageResults; Eq(true, p[0].CoverBypassed); Eq(false, p[1].CoverBypassed); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
        Test("D1 absent Aim keeps primary interception", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { Hit, Ultimate(true), Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 6); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Shot(b, log, 6); Eq(900, r.Hp[5]); Eq(900, r.Hp[6]); Eq(false, r.Receipts.Last().DamageResults[0].CoverBypassed);
        });
        Test("D1 ordinary offense preserves Aim", () => {
            var grant = S("grant", Selection.Self, Aim()); var b = Kits(new() { [0] = new[] { grant, Hit, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Assert(Step(b, log, "hit", 5).Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
        Test("D1 Aim cannot bypass armor or barrier", () => {
            var grant = S("grant", Selection.Self, Aim()); var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 1000, 5)); var b = Threshold(Input(new[] { grant, Ultimate(true), Rest }, new[] { shield, Rest }, armor: 100), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "shield", 5); UntilActor(b, log, 0); var r = Shot(b, log, 5); var p = r.Receipts.Last().DamageResults.Single(); Eq(50L, p.PostMitigationAmount); Eq(50L, p.BarrierAbsorbed); Eq(0, p.HpRemoved);
        });
        Test("D1 Aim expiry removes capability", () => {
            var grant = S("grant", Selection.Self, Aim(1)); var b = Kits(new() { [0] = new[] { grant, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); Assert(!Step(b, log, "rest", 0).Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
        Test("D1 Aim dispel removes capability", () => {
            var grant = S("grant", Selection.Self, Aim()); var dispel = S("dispel", Selection.Enemy, E(EffectKind.Dispel, 0)); Assert(!Run(Input(new[] { grant }, new[] { dispel }), C(1, 0, "grant", 0), C(2, 5, "dispel", 0)).Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
        Test("D1 invalid target does not consume ready or Aim", () => {
            var grant = S("grant", Selection.Self, Aim()); var b = Threshold(Kits(new() { [0] = new[] { grant, Ultimate(true), Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var r = Shot(b, log, 0); Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic); Eq(1, r.Readiness[0]); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
        Test("D1 late event refusal rolls back readiness damage Aim and receipt trace", () => {
            var grant = S("grant", Selection.Self, Aim()); var b = Threshold(Kits(new() { [0] = new[] { grant, Ultimate(true), Rest } }, events: 1), 1); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Shot(b, log, 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(1000, r.Hp[5]); Eq(1, r.Readiness[0]); Eq(0, r.Receipts.Last().DamageResults.Count); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence);
        });
        Test("D1 codec roundtrip covers all D1 fields", () => {
            var grant = S("grant", Selection.Self, Window(), Aim()); var b = Threshold(Input(new[] { grant, Ultimate(true), Drain() }), 7); var copy = CombatCodec.Decode(CombatCodec.Encode(b)); Eq(7, copy.Rules.ReadinessThreshold); Eq(true, copy.Units[0].Skills[1].IsUltimate); Eq(true, copy.Units[0].Skills[1].UseAimForPrimaryCoverBypass); Eq(500, copy.Units[0].Skills[2].LifestealCoefficient); Eq(100, copy.Units[0].Skills[0].Effects[0].LifestealCap); Eq(CombatCodec.Digest(CombatCodec.Encode(b)), CombatCodec.Digest(CombatCodec.Encode(copy)));
        });
        Test("D1 threshold changes input hash", () => { var b = Input(); Assert(Run(Threshold(b, 1)).InputHash != Run(Threshold(b, 2)).InputHash); });
        Test("D1 action classes derive from effect roles", () => {
            Eq(ActionClass.None, Rest.Classification); Eq(ActionClass.Offense, Hit.Classification); Eq(ActionClass.Support, Hide.Classification); Eq(ActionClass.Mixed, S("mix", Selection.Enemy, E(EffectKind.Damage, 1000), Aim(targets: EffectTargets.Self)).Classification);
            Throws(() => new CombatSkill("lie", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1000) }, 1000, classification: ActionClass.Support));
        });
        Test("D1 invalid effect target role fails closed", () => { Throws(() => S("bad", Selection.Self, E(EffectKind.Damage, 1000))); Throws(() => S("bad", Selection.Enemy, Aim())); });
        Test("D1 unsupported empowered target projection fails closed", () => { Throws(() => new CombatEffect(EffectKind.NextLifestealWindow, EffectTargets.Self, 500, 3, charges: 1, lifestealCap: 100, requiredEmpoweredTargetLimit: 2)); });
        Test("D1 finite window and Aim contracts reject invalid counts", () => {
            Throws(() => new CombatEffect(EffectKind.Aim, EffectTargets.Self, 0, 3)); Throws(() => new CombatEffect(EffectKind.Aim, EffectTargets.Self, 0, 0, charges: 1)); Throws(() => new CombatEffect(EffectKind.NextLifestealWindow, EffectTargets.Self, 500, 3, charges: 2, lifestealCap: 10)); Throws(() => Window(cap: 0));
        });
        Test("D1 Aim capability rejects nonultimate or unrestricted shapes", () => {
            Throws(() => new CombatSkill("bad", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, useAimForPrimaryCoverBypass: true));
            Throws(() => new CombatSkill("bad", Selection.UpToEnemies, 4, new[] { E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, isUltimate: true, useAimForPrimaryCoverBypass: true));
        });
        Test("D1 intrinsic lifesteal rejects invalid cap and missing offense", () => { Throws(() => Drain(cap: 0)); Throws(() => new CombatSkill("bad", Selection.Self, 1, new[] { E(EffectKind.Heal, 1000) }, 1000, lifestealCoefficient: 500, lifestealCap: 10)); });
        Test("D1 readiness threshold bounds reject unsafe snapshots", () => { Throws(() => Threshold(Input(), 0)); Throws(() => Threshold(Input(), 1001)); });
        Test("D1 rejects C3r002 domain", () => {
            var b = CombatCodec.Encode(Input()); using var stream = new MemoryStream(); using (var w = new BinaryWriter(stream, System.Text.Encoding.UTF8, true)) { var domain = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-c3r002-candidate"); w.Write((ushort)domain.Length); w.Write(domain); int old = BitConverter.ToUInt16(b, 0); w.Write(b, old + 2, b.Length - old - 2); } Throws(() => CombatCodec.Decode(stream.ToArray()));
        });
        Test("D1 duplicate refresh in one root grants only one readiness", () => {
            var grant = S("grant", Selection.Self, Aim(), Aim()); var r = Run(Input(new[] { grant }), C(1, 0, "grant", 0)); Eq(1, r.Readiness[0]); Eq(1, r.Statuses.Count); Eq(2L, r.Statuses[0].Sequence);
        });
        Test("D1 identical effective expiry refresh grants no readiness", () => {
            var shorterWhenInjured = new CombatEffect(EffectKind.Defense, EffectTargets.Selected, 100, 2, predicate: EffectPredicate.TargetInjured, threshold: 999);
            var grant = S("grant", Selection.Self, E(EffectKind.Defense, 100, 3), shorterWhenInjured); var b = Kits(new() { [0] = new[] { grant, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "grant", 0); Step(b, log, "hit", 0); UntilActor(b, log, 0); var r = Step(b, log, "grant", 0); Eq(1, r.Readiness[0]); Eq(1, r.Statuses.Count); Eq(100L, r.Statuses[0].Amount);
        });
        Test("D1 oldest window chosen without consuming a second source", () => {
            var own = S("own", Selection.Self, Window(500, 100)); var ally = S("ally", Selection.Ally, Window(1000, 100)); var b = Kits(new() { [0] = new[] { own, Hit, Rest }, [1] = new[] { ally, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "own", 0); Step(b, log, "hit", 0); Step(b, log, "ally", 0); UntilActor(b, log, 0); var r = Step(b, log, "hit", 5); Eq(950, r.Hp[0]); Eq(1, r.Statuses.Count(s => s.Kind == EffectKind.NextLifestealWindow)); Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.NextLifestealWindow).Source);
        });
        Test("D1 eligible shielded root consumes window without healing", () => {
            var grant = S("grant", Selection.Self, Window()); var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 2000, 5)); var b = Kits(new() { [0] = new[] { grant, Hit, Rest }, [5] = new[] { shield, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); Step(b, log, "shield", 5); UntilActor(b, log, 0); var r = Step(b, log, "hit", 5); Eq(0, r.Receipts.Last().DamageResults.Single().HpRemoved); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.NextLifestealWindow));
        });
        Test("D1 lifesteal aggregates actual root packets before one floor", () => {
            var drain = new CombatSkill("drain", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 10), E(EffectKind.Damage, 10) }, 1000, lifestealCoefficient: 500, lifestealCap: 100); var r = Run(Input(enemy: new[] { drain }), C(1, 0, "hit", 5), C(2, 5, "drain", 0)); Eq(901, r.Hp[5]); Eq(2, r.Receipts[1].DamageResults.Count);
        });
        Test("D1 event failure after window selection rolls back HP cost and window", () => {
            var grant = S("grant", Selection.Self, Window()); var paid = Paid(500, E(EffectKind.Damage, 1000)); var b = Kits(new() { [0] = new[] { grant, paid, Rest } }, events: 2); var log = new List<CombatCommand>(); Step(b, log, "grant", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "paid", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[0]); Eq(1000, r.Hp[5]); Eq(before.Readiness[0], r.Readiness[0]); Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence);
        });
        Test("D1 accepted no-op ultimate still consumes readiness", () => {
            var ult = new CombatSkill("ultimate", Selection.Self, 1, new[] { E(EffectKind.Heal, 0) }, 1000, isUltimate: true); var b = Threshold(Kits(new() { [0] = new[] { Hit, ult, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 5); UntilActor(b, log, 0); var r = Step(b, log, "ultimate", 0); Eq("", r.Receipts.Last().Diagnostic); Eq(0, r.Readiness[0]);
        });
        Test("D1 self-granted Aim cannot enable that same ultimate", () => {
            var ult = new CombatSkill("ultimate", Selection.UpToEnemies, 3, new[] { Aim(targets: EffectTargets.Self), E(EffectKind.Damage, 1000) }, 500, primaryInterceptable: true, isUltimate: true, useAimForPrimaryCoverBypass: true); var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 5)); var b = Threshold(Kits(new() { [0] = new[] { Hit, ult, Rest }, [5] = new[] { cover, Rest } }), 1); var log = new List<CombatCommand>(); Step(b, log, "hit", 6); Step(b, log, "cover", 6); UntilActor(b, log, 0); var r = Shot(b, log, 6); Eq(5, r.Receipts.Last().DamageResults.Single().ActualRecipient); Eq(false, r.Receipts.Last().DamageResults.Single().CoverBypassed); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Aim));
        });
    }
}
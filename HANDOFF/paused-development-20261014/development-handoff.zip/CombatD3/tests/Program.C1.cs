using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatResult Step(CombatInput b, List<CombatCommand> log, string skill, int target)
    {
        var before = CombatReplay.Replay(b, log);
        log.Add(new CombatCommand(N(log.Count + 1), before.Version, b.Units[before.Actor].Id, skill, target));
        return CombatReplay.Replay(b, log);
    }
    static void UntilActor(CombatInput b, List<CombatCommand> log, int actor)
    {
        for (int i = 0; i < 10; i++)
        {
            var r = CombatReplay.Replay(b, log); if (r.Actor == actor) return;
            var next = Step(b, log, "rest", r.Actor); Eq("", next.Receipts.Last().Diagnostic);
        }
        throw new Exception("Expected actor not scheduled");
    }
    static void C1Tests()
    {
        Test("C1 self delayed heal begins after current owner turn and fires once", () => {
            var delayed = S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 1000, 1));
            var b = Input(new[] { delayed, Rest }); var log = new List<CombatCommand>();
            var r = Step(b, log, "delayed", 0); Eq(1, r.Statuses[0].RemainingTurns); Eq(2L, r.Statuses[0].FirstEligibleOwnerTurn); Eq(1L, r.CompletedOwnerTurns[0]);
            r = Step(b, log, "hit", 0); Eq(900, r.Hp[0]); UntilActor(b, log, 0);
            r = Step(b, log, "rest", 0); Eq(1000, r.Hp[0]); Eq(0, r.Statuses.Count); Eq(2L, r.CompletedOwnerTurns[0]);
            r = Step(b, log, "hit", 0); UntilActor(b, log, 0); r = Step(b, log, "rest", 0); Eq(900, r.Hp[0]);
        });
        Test("C1 ally delayed heal ticks at first eligible owner end", () => {
            var delayed = S("delayed", Selection.Ally, E(EffectKind.DelayedHeal, 500, 1));
            var b = Input(new[] { delayed, Rest }); var log = new List<CombatCommand>();
            Step(b, log, "delayed", 1); Step(b, log, "hit", 1); var r = Step(b, log, "rest", 1);
            Eq(950, r.Hp[1]); Eq(0, r.Statuses.Count); Eq(1L, r.CompletedOwnerTurns[1]);
        });
        Test("C1 delayed heal duration counts eligible owner turns", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 500, 2)), Rest }); var log = new List<CombatCommand>();
            Step(b, log, "delayed", 0); Step(b, log, "hit", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "rest", 0); Eq(900, r.Hp[0]); Eq(1, r.Statuses.Single().RemainingTurns);
            UntilActor(b, log, 0); r = Step(b, log, "rest", 0); Eq(950, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C1 dispel removes delayed heal before due event", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 1000, 1)), Rest },
                new[] { S("strip", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.Dispel, 0)), Rest });
            var log = new List<CombatCommand>(); Step(b, log, "delayed", 0); Step(b, log, "strip", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "rest", 0); Eq(900, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C1 dead delayed target has no healing or completed turn catch-up", () => {
            var b = Input(new[] { S("delayed", Selection.Ally, E(EffectKind.DelayedHeal, 1000, 1)), Rest },
                new[] { S("kill", Selection.Enemy, E(EffectKind.Damage, 10000)), Rest });
            var log = new List<CombatCommand>(); Step(b, log, "delayed", 1); var r = Step(b, log, "kill", 1);
            Eq(0, r.Hp[1]); Eq(0, r.Statuses.Count); Eq(0L, r.CompletedOwnerTurns[1]); UntilActor(b, log, 0);
            r = Step(b, log, "rest", 0); Eq(0, r.Hp[1]); Eq(0L, r.CompletedOwnerTurns[1]);
        });
        Test("C1 direct healing reduction applies once before maximum HP cap", () => {
            var b = Input(new[] { S("wound", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.HealingReduction, 500, 1, false)) },
                new[] { S("heal", Selection.Self, E(EffectKind.Heal, 3000)) });
            var r = Run(b, C(1, 0, "wound", 5), C(2, 5, "heal", 5)); Eq(1000, r.Hp[5]); Eq(0, r.Statuses.Count);
            b = Input(new[] { S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 500, 1, false)) },
                new[] { S("heal", Selection.Self, E(EffectKind.Heal, 2000)) });
            Eq(800, Run(b, C(1, 0, "wound", 5), C(2, 5, "heal", 5)).Hp[5]);
        });
        Test("C1 delayed healing shares reduction and expiry follows due healing", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 2000, 1)), Rest },
                new[] { S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 500, 1, false)), Rest });
            var log = new List<CombatCommand>(); Step(b, log, "delayed", 0); Step(b, log, "wound", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "rest", 0); Eq(800, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C1 cleanse removes reduction before delayed healing", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 2000, 1)), S("cleanse", Selection.Self, E(EffectKind.Cleanse, 0)), Rest },
                new[] { S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 500, 1, false)), Rest });
            var log = new List<CombatCommand>(); Step(b, log, "delayed", 0); Step(b, log, "wound", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "cleanse", 0); Eq(900, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C1 full healing reduction prevents all healing", () => {
            var b = Input(new[] { S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 1000, 1, false)) },
                new[] { S("heal", Selection.Self, E(EffectKind.Heal, 2000)) });
            Eq(700, Run(b, C(1, 0, "wound", 5), C(2, 5, "heal", 5)).Hp[5]);
        });
        Test("C1 end-turn event capacity rolls back healing status expiry and owner count", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 500, 1), E(EffectKind.DelayedHeal, 500, 1, damage: DamageKind.Magic)), Rest }, events: 2);
            var log = new List<CombatCommand>(); Step(b, log, "delayed", 0); Step(b, log, "hit", 0); UntilActor(b, log, 0);
            var before = Run(b, log.ToArray()); var r = Step(b, log, "rest", 0);
            Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Version, r.Version); Eq(900, r.Hp[0]);
            Eq(1L, r.CompletedOwnerTurns[0]); Eq(2, r.Statuses.Count); Assert(r.Statuses.All(s => s.RemainingTurns == 1 && s.FirstEligibleOwnerTurn == 2));
        });
        Test("C1 codec round-trip and duplicate preserve timed state", () => {
            var b = Input(new[] { S("delayed", Selection.Self, E(EffectKind.DelayedHeal, 1000, 1)), Rest });
            var command = C(1, 0, "delayed", 0); var original = Run(b, command);
            var decoded = CombatCodec.Decode(CombatCodec.Encode(b)); var replay = Run(decoded, command, command);
            Eq(original.StateHash, replay.StateHash); Eq(1L, replay.CompletedOwnerTurns[0]); Eq(2L, replay.Statuses.Single().FirstEligibleOwnerTurn);
            Eq("five-hero-effects-v2-d3-candidate", CombatInput.EngineVersion);
        });
        Test("C1 arithmetic overflow rolls back newly allocated delayed timing", () => {
            var action = new CombatSkill("overflow", Selection.Enemy, 1, new[] {
                E(EffectKind.DelayedHeal, 1, 1, targets: EffectTargets.Self), E(EffectKind.Damage, 10000000) }, 1);
            var other = new CombatSkill("hit", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1) }, 1);
            var units = Input().Units.Select((u, i) => new CombatantInput(u.Id, u.Side, u.MaximumHp,
                i == 0 ? 10000000 : u.Offense, 0, 0, u.Speed, new[] { i == 0 ? action : other }));
            var b = new CombatInput("synthetic", "overflow", new CombatRules(1, 10000000, 16, 100, 100), units);
            var r = Run(b, C(1, 0, "overflow", 5)); Eq("ARITHMETIC-CAPACITY", r.Receipts.Single().Diagnostic);
            Eq(0, r.Statuses.Count); Assert(r.CompletedOwnerTurns.All(t => t == 0)); Eq(1L, r.Version); Assert(r.Hp.All(h => h == 1000));
        });
        Test("C1 rejects invalid polarity duration and reduction coefficient", () => {
            Throws(() => E(EffectKind.DelayedHeal, 1000, 0)); Throws(() => E(EffectKind.DelayedHeal, 1000, 1, false));
            Throws(() => E(EffectKind.HealingReduction, 500, 1, true));
            Throws(() => Input(new[] { S("invalid", Selection.Enemy, E(EffectKind.HealingReduction, 1001, 1, false)) }));
        });
    }
}
using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatInput Kits(Dictionary<int, CombatSkill[]> kits, int events = 100)
    {
        var b = Input(events: events);
        return new CombatInput("synthetic", "c2", b.Rules, b.Units.Select((u, i) =>
            new CombatantInput(u.Id, u.Side, u.MaximumHp, u.Offense, u.Armor, u.Resistance, u.Speed, kits.TryGetValue(i, out var skills) ? skills : u.Skills)));
    }
    static CombatEffect Conditional(EffectPredicate predicate, int coefficient, int threshold = 0) =>
        new(EffectKind.Damage, EffectTargets.Selected, coefficient, predicate: predicate, threshold: threshold);
    static CombatSkill Hide => S("hide", Selection.Self, E(EffectKind.Conceal, 0, 3));
    static void C2Tests()
    {
        Test("C1 regression multiple source reductions above Scale clamp once", () => {
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 700, 3, false));
            var reduce = S("reduce", Selection.Enemy, E(EffectKind.HealingReduction, 700, 3, false));
            var heal = S("heal", Selection.Self, E(EffectKind.Heal, 5000));
            var b = Kits(new() { [0] = new[] { wound, Rest }, [1] = new[] { reduce, Rest }, [5] = new[] { heal, Rest } });
            var log = new List<CombatCommand>(); Step(b, log, "wound", 5); Step(b, log, "rest", 5); Step(b, log, "reduce", 5);
            UntilActor(b, log, 5); var r = Step(b, log, "heal", 5); Eq(700, r.Hp[5]);
        });
        Test("C1 regression reduction expires before later-sequenced delayed heal removal", () => {
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 500, 1, false));
            var delayed = S("delayed", Selection.Ally, E(EffectKind.DelayedHeal, 2000, 1));
            var b = Kits(new() { [1] = new[] { delayed, Rest }, [5] = new[] { wound, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "rest", 0); Step(b, log, "wound", 0); Step(b, log, "delayed", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "rest", 0); Eq(800, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C2 speed changes only next round and gives every actor one turn", () => {
            var slow = S("slow", Selection.Enemy, E(EffectKind.SpeedModifier, -1000, 3, false));
            var b = Kits(new() { [0] = new[] { slow, Rest } }); var log = new List<CombatCommand>();
            var r = Step(b, log, "slow", 5); Eq(5, r.Actor);
            var first = new List<int> { 0 }; for (int i = 0; i < 9; i++) { first.Add(r.Actor); r = Step(b, log, "rest", r.Actor); }
            Eq("0,5,1,2,3,4,6,7,8,9", string.Join(",", first)); Eq(0, r.Actor);
            var next = new List<int>(); for (int i = 0; i < 10; i++) { next.Add(r.Actor); r = Step(b, log, "rest", r.Actor); }
            Eq("0,1,2,3,4,6,7,8,9,5", string.Join(",", next)); Assert(r.CompletedOwnerTurns.All(t => t == 2));
        });
        Test("C2 equal effective speeds use side then stable slot", () => {
            var boost = S("boost", Selection.Ally, E(EffectKind.SpeedModifier, 21, 3));
            var b = Kits(new() { [0] = new[] { boost, Rest } });
            b = new CombatInput(b.ContentId, b.ContentRevision, b.Rules, b.Units.Select((u, i) => new CombatantInput(u.Id, u.Side, u.MaximumHp, u.Offense, u.Armor, u.Resistance, i == 5 ? 100 : u.Speed, u.Skills)));
            var log = new List<CombatCommand>(); Step(b, log, "boost", 1);
            UntilActor(b, log, 0); var r = Step(b, log, "rest", 0); Eq(1, r.Actor); r = Step(b, log, "rest", 1); Eq(5, r.Actor);
        });
        Test("C2 hidden hostile primary is rejected without state advancement", () => {
            var b = Kits(new() { [0] = new[] { Hide, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "hide", 0);
            var r = Step(b, log, "hit", 0); Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic); Eq(2L, r.Version);
            Eq(1000, r.Hp[0]); Eq(0L, r.CompletedOwnerTurns[5]); Eq(3, r.Statuses.Single().RemainingTurns);
        });
        Test("C2 hidden hostile secondary rejects whole multi-target action", () => {
            var shot = new CombatSkill("shot", Selection.UpToEnemies, 3, new[] { E(EffectKind.Damage, 1000) }, 1000);
            var b = Kits(new() { [0] = new[] { Hide, Rest }, [5] = new[] { shot, Rest } });
            var r = Run(b, C(1, 0, "hide", 0), C(2, 5, "shot", 1, 0)); Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic); Assert(r.Hp.All(h => h == 1000));
        });
        Test("C2 derived all-enemy area includes hidden primary anchor", () => {
            var area = new CombatSkill("area", Selection.AllEnemies, 5, new[] { E(EffectKind.Damage, 1000) }, 1000, area: true);
            var b = Kits(new() { [0] = new[] { Hide, Rest }, [5] = new[] { area, Rest } });
            var r = Run(b, C(1, 0, "hide", 0), C(2, 5, "area", 0)); Eq("", r.Receipts.Last().Diagnostic); for (int i = 0; i < 5; i++) Eq(900, r.Hp[i]);
        });
        Test("C2 Reveal overrides conceal then expiry restores hidden selection", () => {
            var reveal = new CombatSkill("reveal", Selection.AllEnemies, 5, new[] { E(EffectKind.Reveal, 0, 1, false) }, 1000, area: true);
            var b = Kits(new() { [0] = new[] { Hide, Rest }, [5] = new[] { reveal, Hit, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "hide", 0); Step(b, log, "reveal", 0); UntilActor(b, log, 6); var r = Step(b, log, "hit", 0); Eq(900, r.Hp[0]);
            UntilActor(b, log, 0); Step(b, log, "rest", 0); r = Step(b, log, "hit", 0); Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic);
        });
        Test("C2 cleanse of Reveal restores hidden selection immediately", () => {
            var reveal = new CombatSkill("reveal", Selection.AllEnemies, 5, new[] { E(EffectKind.Reveal, 0, 3, false) }, 1000, area: true);
            var clean = S("clean", Selection.Ally, E(EffectKind.Cleanse, 0));
            var b = Kits(new() { [0] = new[] { Hide, Rest }, [1] = new[] { clean, Rest }, [5] = new[] { reveal, Rest } });
            var log = new List<CombatCommand>(); Step(b, log, "hide", 0); Step(b, log, "reveal", 0); Step(b, log, "clean", 0); UntilActor(b, log, 6);
            Eq("TARGET-INVALID", Step(b, log, "hit", 0).Receipts.Last().Diagnostic);
        });
        Test("C2 concealed taunt source lapses without retargeting", () => {
            var taunt = S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 3, false));
            var hideAlly = S("hideAlly", Selection.Ally, E(EffectKind.Conceal, 0, 3));
            var b = Kits(new() { [0] = new[] { taunt, Rest }, [1] = new[] { hideAlly, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "taunt", 5); Step(b, log, "rest", 5); Step(b, log, "hideAlly", 0); UntilActor(b, log, 5);
            var r = Step(b, log, "hit", 2); Eq("", r.Receipts.Last().Diagnostic); Eq(900, r.Hp[2]); Eq(1000, r.Hp[0]);
        });
        Test("C2 Cover bypass cannot bypass conceal or visible taunt", () => {
            var bypass = new CombatSkill("bypass", Selection.Enemy, 1, new[] { E(EffectKind.Damage, 1000) }, 1000, bypassCover: true);
            var b = Kits(new() { [0] = new[] { Hide, Rest }, [5] = new[] { bypass, Rest } });
            Eq("TARGET-INVALID", Run(b, C(1, 0, "hide", 0), C(2, 5, "bypass", 0)).Receipts.Last().Diagnostic);
            b = Kits(new() { [0] = new[] { S("taunt", Selection.Enemy, E(EffectKind.Taunt, 0, 2, false)), Rest }, [5] = new[] { bypass, Rest } });
            Eq("TARGET-INVALID", Run(b, C(1, 0, "taunt", 5), C(2, 5, "bypass", 1)).Receipts.Last().Diagnostic);
        });
        Test("C2 injury predicate inclusive equality uses action-start HP", () => {
            var action = S("conditional", Selection.Enemy, E(EffectKind.Damage, 1000), Conditional(EffectPredicate.TargetInjured, 2000, 900));
            var b = Kits(new() { [0] = new[] { action, Hit, Rest } });
            Eq(900, Run(b, C(1, 0, "conditional", 5)).Hp[5]);
            var log = new List<CombatCommand>(); Step(b, log, "hit", 5); UntilActor(b, log, 0);
            Eq(600, Step(b, log, "conditional", 5).Hp[5]);
        });
        Test("C2 new harmful status cannot enable same-action conditional damage", () => {
            var action = S("conditional", Selection.Enemy, E(EffectKind.SpeedModifier, -1, 3, false), Conditional(EffectPredicate.TargetHarmfulStatus, 2000));
            var b = Kits(new() { [0] = new[] { action, Rest } }); var log = new List<CombatCommand>();
            Eq(1000, Step(b, log, "conditional", 5).Hp[5]); UntilActor(b, log, 0); Eq(800, Step(b, log, "conditional", 5).Hp[5]);
        });
        Test("C2 self conceal cannot enable same-action conceal predicate", () => {
            var action = S("conditional", Selection.Enemy, E(EffectKind.Conceal, 0, 3, targets: EffectTargets.Self), Conditional(EffectPredicate.ActorConcealed, 2000));
            var b = Kits(new() { [0] = new[] { action, Hide, Rest } });
            var r = Run(b, C(1, 0, "conditional", 5)); Eq(1000, r.Hp[5]); Eq(0, r.Statuses.Count);
            var log = new List<CombatCommand>(); Step(b, log, "hide", 0); UntilActor(b, log, 0); r = Step(b, log, "conditional", 5); Eq(800, r.Hp[5]); Eq(0, r.Statuses.Count);
        });
        Test("C2 offensive barrier-absorbed hit breaks conceal", () => {
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 2000, 3));
            var b = Kits(new() { [0] = new[] { Hide, Hit, Rest }, [5] = new[] { shield, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "hide", 0); Step(b, log, "shield", 5); UntilActor(b, log, 0);
            var r = Step(b, log, "hit", 5); Eq(1000, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("C2 late conceal-break budget failure rolls back damage and new statuses", () => {
            var action = S("action", Selection.Enemy, E(EffectKind.Conceal, 0, 3, targets: EffectTargets.Self), E(EffectKind.Damage, 1000));
            var b = Kits(new() { [0] = new[] { action, Rest } }, events: 2); var r = Run(b, C(1, 0, "action", 5));
            Eq("EVENT-CAPACITY", r.Receipts.Single().Diagnostic); Eq(1000, r.Hp[5]); Eq(0, r.Statuses.Count); Eq(1L, r.Version); Assert(r.CompletedOwnerTurns.All(t => t == 0));
        });
        Test("C2 predicate and status codec round-trip with duplicate replay", () => {
            var action = S("action", Selection.Enemy, E(EffectKind.SpeedModifier, -5, 3, false), Conditional(EffectPredicate.TargetInjured, 2000, 500));
            var b = Kits(new() { [0] = new[] { action, Hide, Rest } }); var bytes = CombatCodec.Encode(b); var copy = CombatCodec.Decode(bytes);
            Eq(Convert.ToHexString(bytes), Convert.ToHexString(CombatCodec.Encode(copy))); var c = C(1, 0, "action", 5);
            Eq(Run(b, c).StateHash, Run(copy, c, c).StateHash); Eq("five-hero-effects-v2-d3-candidate", CombatInput.EngineVersion);
        });
        Test("C2 speed upper cap makes oversized boosts tie by slot", () => {
            var boost = S("boost", Selection.AllAllies, E(EffectKind.SpeedModifier, 10000000, 3));
            var b = Kits(new() { [1] = new[] { boost, Rest } });
            b = new CombatInput(b.ContentId, b.ContentRevision, b.Rules, b.Units.Select((u, i) => new CombatantInput(u.Id, u.Side, u.MaximumHp, u.Offense, u.Armor, u.Resistance, i == 1 ? 200 : u.Speed, u.Skills)));
            var log = new List<CombatCommand>(); Eq(1, Run(b).Actor); var r = Step(b, log, "boost", 1);
            for (int i = 0; i < 9; i++) r = Step(b, log, "rest", r.Actor);
            Eq(0, r.Actor); r = Step(b, log, "rest", 0); Eq(1, r.Actor);
        });
        Test("C2 Reveal prevents action-start conceal advantage", () => {
            var reveal = new CombatSkill("reveal", Selection.AllEnemies, 5, new[] { E(EffectKind.Reveal, 0, 3, false) }, 1000, area: true);
            var attack = S("attack", Selection.Enemy, Conditional(EffectPredicate.ActorConcealed, 2000));
            var b = Kits(new() { [0] = new[] { Hide, attack, Rest }, [5] = new[] { reveal, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "hide", 0); Step(b, log, "reveal", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "attack", 5); Eq(1000, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("C2 cleansing a harmful status cannot disable action-start predicate", () => {
            var cleanHeal = S("cleanHeal", Selection.Self, E(EffectKind.Cleanse, 0),
                new CombatEffect(EffectKind.Heal, EffectTargets.Selected, 2000, predicate: EffectPredicate.TargetHarmfulStatus));
            var wound = S("wound", Selection.Enemy, E(EffectKind.Damage, 3000), E(EffectKind.HealingReduction, 500, 3, false));
            var b = Kits(new() { [0] = new[] { cleanHeal, Rest }, [5] = new[] { wound, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "rest", 0); Step(b, log, "wound", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "cleanHeal", 0); Eq(900, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C2 reader rejects prior C1 input domain", () => {
            var bytes = CombatCodec.Encode(Input()); var oldHeader = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-c1-candidate");
            Array.Copy(oldHeader, 0, bytes, 2, oldHeader.Length); Throws(() => CombatCodec.Decode(bytes));
            Throws(() => Conditional((EffectPredicate)255, 1000));
        });
        Test("C2 invalid status polarity magnitude and predicate thresholds reject", () => {
            Throws(() => E(EffectKind.Conceal, 1, 1)); Throws(() => E(EffectKind.Reveal, 0, 1)); Throws(() => E(EffectKind.SpeedModifier, -1, 1));
            Throws(() => Conditional(EffectPredicate.TargetInjured, 1000)); Throws(() => Conditional(EffectPredicate.ActorConcealed, 1000, 1));
            Throws(() => Kits(new() { [0] = new[] { S("invalid", Selection.Enemy, Conditional(EffectPredicate.TargetInjured, 1000, 1001)) } }));
        });
    }
}
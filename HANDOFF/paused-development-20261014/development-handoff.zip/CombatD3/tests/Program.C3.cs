using AnotherLife.StoryCombat.V2;

static partial class Tests
{
    static CombatEffect Mod(int value = 500, int charges = 2, int turns = 5, EffectTargets targets = EffectTargets.Selected) =>
        new(EffectKind.NextOffenseModifier, targets, value, turns, beneficial: value > 0, charges: charges);
    static CombatEffect Mark(int value = 500, int charges = 1) => new(EffectKind.SourceMark, EffectTargets.Selected, value, 5, beneficial: false, charges: charges);
    static CombatEffect Poison(int value = 1000, int turns = 3, int cap = 2) => new(EffectKind.Poison, EffectTargets.Selected, value, turns, DamageKind.Magic, false, stackCap: cap);
    static CombatSkill Paid(int cost, params CombatEffect[] effects) => new("paid", Selection.Enemy, 1, effects, 1000, hpCostCoefficient: cost);
    static CombatInput Hp0(CombatInput b, int hp) => new(b.ContentId, b.ContentRevision, b.Rules,
        b.Units.Select((u, i) => new CombatantInput(u.Id, u.Side, i == 0 ? hp : u.MaximumHp, u.Offense, u.Armor, u.Resistance, u.Speed, u.Skills)));
    static void C3Tests()
    {
        Test("C2 regression injury predicate refers to intended target before Cover", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 3));
            var attack = S("attack", Selection.Enemy, Conditional(EffectPredicate.TargetInjured, 2000, 900));
            var b = Kits(new() { [0] = new[] { cover, Rest }, [5] = new[] { attack, Hit, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "rest", 0); Step(b, log, "hit", 1); UntilActor(b, log, 0); Step(b, log, "cover", 1);
            var r = Step(b, log, "attack", 1); Eq(800, r.Hp[0]); Eq(900, r.Hp[1]);
        });
        Test("C2 regression partial removal of existing Conceal records rolls back", () => {
            var allyHide = S("allyHide", Selection.Ally, E(EffectKind.Conceal, 0, 3));
            var b = Kits(new() { [0] = new[] { Hide, Hit, Rest }, [1] = new[] { allyHide, Rest } }, events: 2); var log = new List<CombatCommand>();
            Step(b, log, "hide", 0); Step(b, log, "rest", 5); Step(b, log, "allyHide", 0); UntilActor(b, log, 0);
            var before = Run(b, log.ToArray()); var r = Step(b, log, "hit", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic);
            Eq(1000, r.Hp[5]); Eq(2, r.Statuses.Count); Eq(before.Version, r.Version); Eq(before.CompletedOwnerTurns[0], r.CompletedOwnerTurns[0]);
            Eq(string.Join(",", before.Statuses.Select(s => s.Sequence)), string.Join(",", r.Statuses.Select(s => s.Sequence)));
        });
        Test("C3 positive cost refuses HP1 and rounds minimum cost at HP2", () => {
            var paid = Paid(1, E(EffectKind.Damage, 1000)); var b = Kits(new() { [0] = new[] { paid, Rest } });
            var r = Run(Hp0(b, 1), C(1, 0, "paid", 5)); Eq("HP-COST-UNAVAILABLE", r.Receipts.Single().Diagnostic); Eq(1, r.Hp[0]); Eq(1000, r.Hp[5]); Eq(1L, r.Version);
            r = Run(Hp0(b, 2), C(1, 0, "paid", 5)); Eq(1, r.Hp[0]); Eq(900, r.Hp[5]);
            r = Run(b, C(1, 0, "paid", 5)); Eq(999, r.Hp[0]);
        });
        Test("C3 full and zero cost coefficients leave one or charge nothing", () => {
            var b = Kits(new() { [0] = new[] { Paid(1000, E(EffectKind.Damage, 1000)), Rest } }); Eq(1, Run(b, C(1, 0, "paid", 5)).Hp[0]);
            b = Kits(new() { [0] = new[] { Paid(0, E(EffectKind.Damage, 1000)), Rest } }); Eq(1000, Run(b, C(1, 0, "paid", 5)).Hp[0]);
        });
        Test("C3 cost cannot self-enable injury predicate", () => {
            var heal = new CombatEffect(EffectKind.Heal, EffectTargets.Self, 1000, predicate: EffectPredicate.TargetInjured, threshold: 500);
            var b = Kits(new() { [0] = new[] { Paid(500, heal), Rest } }); Eq(500, Run(b, C(1, 0, "paid", 5)).Hp[0]);
        });
        Test("C3 invalid target and duplicate recovery never pay twice", () => {
            var b = Kits(new() { [0] = new[] { Paid(100, E(EffectKind.Damage, 1000)), Rest } });
            var r = Run(b, C(1, 0, "paid", 1)); Eq("TARGET-INVALID", r.Receipts.Single().Diagnostic); Eq(1000, r.Hp[0]);
            var c = C(1, 0, "paid", 5); r = Run(b, c, c); Eq(900, r.Hp[0]); Eq(900, r.Hp[5]); Eq(true, r.Receipts.Last().Replayed);
        });
        Test("C3 late event failure rolls back cost and prior damage", () => {
            var b = Kits(new() { [0] = new[] { Paid(500, E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000)), Rest } }, events: 2);
            var r = Run(b, C(1, 0, "paid", 5)); Eq("EVENT-CAPACITY", r.Receipts.Single().Diagnostic); Assert(r.Hp.All(h => h == 1000)); Eq(1L, r.Version);
        });
        Test("C3 next offense consumes once per root and replay preserves charges", () => {
            var buff = S("buff", Selection.Self, Mod()); var two = S("two", Selection.Enemy, E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000));
            var b = Kits(new() { [0] = new[] { buff, two, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "buff", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "two", 5); Eq(700, r.Hp[5]); Eq(1, r.Statuses.Single().Charges);
            var replay = Run(b, log.Concat(new[] { log.Last() }).ToArray()); Eq(r.StateHash, replay.StateHash); Eq(1, replay.Statuses.Single().Charges);
        });
        Test("C3 blocked damage still consumes but false predicate does not", () => {
            var buff = S("buff", Selection.Self, Mod(charges: 1)); var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 5000, 4));
            var conditional = S("conditional", Selection.Enemy, Conditional(EffectPredicate.TargetInjured, 1000, 500));
            var b = Kits(new() { [0] = new[] { buff, conditional, Hit, Rest }, [5] = new[] { shield, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "buff", 0); Step(b, log, "shield", 5); UntilActor(b, log, 0); var r = Step(b, log, "conditional", 5);
            Eq(1, r.Statuses.Single(s => s.Kind == EffectKind.NextOffenseModifier).Charges); UntilActor(b, log, 0); r = Step(b, log, "hit", 5);
            Eq(1000, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.NextOffenseModifier));
        });
        Test("C3 new modifier does not self-enable or self-consume", () => {
            var action = S("action", Selection.Enemy, Mod(charges: 1, targets: EffectTargets.Self), E(EffectKind.Damage, 1000));
            var b = Kits(new() { [0] = new[] { action, Rest } }); var r = Run(b, C(1, 0, "action", 5)); Eq(900, r.Hp[5]); Eq(1, r.Statuses.Single().Charges);
        });
        Test("C3 refreshed modifier uses old bonus and preserves new sequence charges", () => {
            var action = S("action", Selection.Enemy, Mod(charges: 2, targets: EffectTargets.Self), E(EffectKind.Damage, 1000));
            var b = Kits(new() { [0] = new[] { action, Rest } }); var log = new List<CombatCommand>(); var first = Step(b, log, "action", 5); UntilActor(b, log, 0);
            var r = Step(b, log, "action", 5); Eq(750, r.Hp[5]); Eq(2, r.Statuses.Single().Charges); Assert(r.Statuses.Single().Sequence > first.Statuses.Single().Sequence);
        });
        Test("C3 own marks and modifier combine with upper clamp", () => {
            var setup = S("setup", Selection.Enemy, Mod(800, 2, targets: EffectTargets.Self), Mark(800));
            var b = Kits(new() { [0] = new[] { setup, Hit, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "setup", 5); UntilActor(b, log, 0);
            var r = Step(b, log, "hit", 5); Eq(800, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.SourceMark)); Eq(1, r.Statuses.Single().Charges);
        });
        Test("C3 harmful next-offense modifier can reduce eligible damage to zero", () => {
            var weaken = S("weaken", Selection.Enemy, Mod(-1000, 1)); var b = Kits(new() { [0] = new[] { weaken, Rest } });
            var r = Run(b, C(1, 0, "weaken", 5), C(2, 5, "hit", 0)); Eq(1000, r.Hp[0]); Eq(0, r.Statuses.Count);
        });
        Test("C3 other source mark neither boosts nor consumes", () => {
            var mark = S("mark", Selection.Enemy, Mark()); var b = Kits(new() { [0] = new[] { mark, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "mark", 5); Step(b, log, "rest", 5); var r = Step(b, log, "hit", 5); Eq(900, r.Hp[5]); Eq(1, r.Statuses.Single().Charges); Eq(0, r.Statuses.Single().Source);
        });
        Test("C3 same source mark via another skill replaces finite record", () => {
            var b = Kits(new() { [0] = new[] { S("first", Selection.Enemy, Mark(200)), S("second", Selection.Enemy, Mark(700, 2)), Rest } });
            var log = new List<CombatCommand>(); var first = Step(b, log, "first", 5); UntilActor(b, log, 0); var r = Step(b, log, "second", 5);
            Eq(1, r.Statuses.Count); Eq(700L, r.Statuses.Single().Amount); Eq(2, r.Statuses.Single().Charges); Assert(r.Statuses.Single().Sequence > first.Statuses.Single().Sequence);
        });
        Test("C3 poison first owner tick and finite expiration", () => {
            var b = Kits(new() { [0] = new[] { S("poison", Selection.Enemy, Poison(turns: 2)), Rest } }); var log = new List<CombatCommand>();
            var r = Step(b, log, "poison", 5); Eq(1000, r.Hp[5]); Eq(1L, r.Statuses.Single().FirstEligibleOwnerTurn);
            r = Step(b, log, "rest", 5); Eq(900, r.Hp[5]); Eq(1, r.Statuses.Single().RemainingTurns); UntilActor(b, log, 5);
            r = Step(b, log, "rest", 5); Eq(800, r.Hp[5]); Eq(0, r.Statuses.Count); UntilActor(b, log, 5); Eq(800, Step(b, log, "rest", 5).Hp[5]);
        });
        Test("C3 poison ignores Cover and skill penetration but uses magic and barriers", () => {
            var ward = S("ward", Selection.Ally, E(EffectKind.Cover, 0, 3));
            var poison = new CombatSkill("poison", Selection.Enemy, 1, new[] { Poison(turns: 1) }, 1000, penetration: 1000, area: true);
            var shield = S("shield", Selection.Self, E(EffectKind.Barrier, 200, 1), E(EffectKind.AreaReduction, 1000, 1), E(EffectKind.Defense, 100, 1, damage: DamageKind.Magic));
            var b = Kits(new() { [0] = new[] { ward, Rest }, [1] = new[] { shield, Rest }, [5] = new[] { poison, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "ward", 1); Step(b, log, "poison", 1); var r = Step(b, log, "shield", 1); Eq(970, r.Hp[1]); Eq(1000, r.Hp[0]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Poison));
        });
        Test("C3 poison amount is unaffected by root offensive modifier", () => {
            var b = Kits(new() { [0] = new[] { S("buff", Selection.Self, Mod(1000)), S("poison", Selection.Enemy, Poison()), Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "buff", 0); UntilActor(b, log, 0); var r = Step(b, log, "poison", 5); Eq(100L, r.Statuses.Single(s => s.Kind == EffectKind.Poison).Amount);
            Eq(2, r.Statuses.Single(s => s.Kind == EffectKind.NextOffenseModifier).Charges); r = Step(b, log, "rest", 5); Eq(900, r.Hp[5]);
        });
        Test("C3 poison cap replaces oldest own stack without evicting another source", () => {
            var p1 = S("p1", Selection.Enemy, Poison(100, 5, 1)); var p2 = S("p2", Selection.Enemy, Poison(200, 5, 1));
            var b = Kits(new() { [0] = new[] { p1, p2, Rest }, [1] = new[] { p1, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "p1", 5); Step(b, log, "rest", 5); var before = Step(b, log, "p1", 5); var otherSequence = before.Statuses.Single(s => s.Source == 1).Sequence;
            UntilActor(b, log, 0); var r = Step(b, log, "p2", 5); Eq(2, r.Statuses.Count); Eq(20L, r.Statuses.Single(s => s.Source == 0).Amount); Eq(otherSequence, r.Statuses.Single(s => s.Source == 1).Sequence);
        });
        Test("C3 deterministic cleanse removes oldest poison before ticking", () => {
            var poison = S("poison", Selection.Enemy, Poison(1000), Poison(500)); var clean = S("clean", Selection.Self, E(EffectKind.Cleanse, 0));
            var b = Kits(new() { [0] = new[] { poison, Rest }, [5] = new[] { clean, Rest } });
            var r = Run(b, C(1, 0, "poison", 5), C(2, 5, "clean", 5)); Eq(950, r.Hp[5]); Eq(1, r.Statuses.Count); Eq(50L, r.Statuses.Single().Amount);
        });
        Test("C3 poison persists after source death and ignores target conceal", () => {
            var poison = S("poison", Selection.Enemy, Poison(turns: 2)); var kill = S("kill", Selection.Enemy, E(EffectKind.Damage, 10000));
            var b = Kits(new() { [0] = new[] { poison, Rest }, [5] = new[] { kill, Hide, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "poison", 5); var r = Step(b, log, "kill", 0); Eq(0, r.Hp[0]); Eq(900, r.Hp[5]); UntilActor(b, log, 5);
            r = Step(b, log, "hide", 5); Eq(800, r.Hp[5]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.Poison)); Assert(r.Statuses.Any(s => s.Kind == EffectKind.Conceal));
        });
        Test("C3 lethal poison stops later delayed heal and completes accepted owner turn", () => {
            var poison = S("poison", Selection.Enemy, Poison(10000, 1)); var delayed = S("delayed", Selection.Ally, E(EffectKind.DelayedHeal, 10000, 1));
            var b = Kits(new() { [5] = new[] { poison, Rest }, [1] = new[] { delayed, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "rest", 0); Step(b, log, "poison", 0); Step(b, log, "delayed", 0); UntilActor(b, log, 0);
            var r = Step(b, log, "rest", 0); Eq(0, r.Hp[0]); Eq(2L, r.CompletedOwnerTurns[0]); Eq(0, r.Statuses.Count); Eq(5, r.Actor);
        });
        Test("C3 late poison budget failure rolls back earlier tick and timing", () => {
            var poison = S("poison", Selection.Enemy, Poison(1000), Poison(1000)); var b = Kits(new() { [0] = new[] { poison, Rest } }, events: 2);
            var log = new List<CombatCommand>(); Step(b, log, "poison", 5); var r = Step(b, log, "rest", 5);
            Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[5]); Eq(0L, r.CompletedOwnerTurns[5]); Assert(r.Statuses.All(s => s.RemainingTurns == 3)); Eq(2L, r.Version);
        });
        Test("C3 own poison predicate isolates source and cannot self-enable", () => {
            var action = S("action", Selection.Enemy, Poison(100, 5), Conditional(EffectPredicate.TargetOwnPoison, 2000));
            var b = Kits(new() { [0] = new[] { action, Rest }, [1] = new[] { S("conditional", Selection.Enemy, Conditional(EffectPredicate.TargetOwnPoison, 2000)), Rest } }); var log = new List<CombatCommand>();
            Eq(1000, Step(b, log, "action", 5).Hp[5]); Step(b, log, "rest", 5); Eq(990, Step(b, log, "conditional", 5).Hp[5]);
            UntilActor(b, log, 0); Eq(790, Step(b, log, "action", 5).Hp[5]);
        });
        Test("C3 codec and replay preserve charges poison and cost contracts", () => {
            var action = Paid(100, Mod(targets: EffectTargets.Self), Mark(), Poison()); var b = Kits(new() { [0] = new[] { action, Rest } });
            var bytes = CombatCodec.Encode(b); var copy = CombatCodec.Decode(bytes); Eq(Convert.ToHexString(bytes), Convert.ToHexString(CombatCodec.Encode(copy)));
            var c = C(1, 0, "paid", 5); Eq(Run(b, c).StateHash, Run(copy, c, c).StateHash); Eq("five-hero-effects-v2-d3-candidate", CombatInput.EngineVersion);
        });
        Test("C3 own mark applies before Cover recipient mitigation", () => {
            var cover = S("cover", Selection.Ally, E(EffectKind.Cover, 0, 3)); var mark = S("mark", Selection.Enemy, Mark());
            var b = Kits(new() { [0] = new[] { cover, Rest }, [5] = new[] { mark, Hit, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "cover", 1); Step(b, log, "mark", 1); UntilActor(b, log, 5); var r = Step(b, log, "hit", 1);
            Eq(850, r.Hp[0]); Eq(1000, r.Hp[1]); Assert(!r.Statuses.Any(s => s.Kind == EffectKind.SourceMark));
        });
        Test("C3 multi-target root consumes only intended own marks", () => {
            var mark = S("mark", Selection.AllEnemies, Mark());
            var shot = new CombatSkill("shot", Selection.UpToEnemies, 2, new[] { E(EffectKind.Damage, 1000) }, 1000);
            var b = Kits(new() { [0] = new[] { mark, shot, Rest } }); var log = new List<CombatCommand>(); Step(b, log, "mark", 5); UntilActor(b, log, 0);
            var before = Run(b, log.ToArray()); log.Add(new CombatCommand(N(log.Count + 1), before.Version, "u0", "shot", 5, new[] { 6 })); var r = Run(b, log.ToArray());
            Eq(850, r.Hp[5]); Eq(850, r.Hp[6]); Eq(3, r.Statuses.Count); Assert(r.Statuses.All(s => s.Target >= 7 && s.Charges == 1));
        });
        Test("C3 invalid paid target preserves preexisting charge", () => {
            var b = Kits(new() { [0] = new[] { S("buff", Selection.Self, Mod()), Paid(500, E(EffectKind.Damage, 1000)), Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "buff", 0); UntilActor(b, log, 0); var r = Step(b, log, "paid", 1);
            Eq("TARGET-INVALID", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[0]); Eq(2, r.Statuses.Single().Charges);
        });
        Test("C3 poison replacement and earlier damage roll back on later failure", () => {
            var first = S("first", Selection.Enemy, Poison(100, 5, 1));
            var fail = S("fail", Selection.Enemy, Poison(200, 5, 1), E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000), E(EffectKind.Damage, 1000));
            var b = Kits(new() { [0] = new[] { first, fail, Rest } }, events: 3); var log = new List<CombatCommand>(); Step(b, log, "first", 5); UntilActor(b, log, 0);
            var before = Run(b, log.ToArray()); var r = Step(b, log, "fail", 5); Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(before.Hp[5], r.Hp[5]);
            Eq(before.Statuses.Single().Sequence, r.Statuses.Single().Sequence); Eq(before.Statuses.Single().RemainingTurns, r.Statuses.Single().RemainingTurns); Eq(10L, r.Statuses.Single().Amount);
        });
        Test("C3 total effect capacity never evicts another source poison", () => {
            var poison = S("poison", Selection.Enemy, Poison(100, 5, 1)); var b = Kits(new() { [0] = new[] { poison, Rest }, [1] = new[] { poison, Rest } });
            b = new CombatInput(b.ContentId, b.ContentRevision, new CombatRules(1000, 100, 1, 100, 100), b.Units);
            var log = new List<CombatCommand>(); Step(b, log, "poison", 5); Step(b, log, "rest", 5); var r = Step(b, log, "poison", 5);
            Eq("EFFECT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1, r.Statuses.Count); Eq(0, r.Statuses.Single().Source); Eq(990, r.Hp[5]);
        });
        Test("C3 modifier expiry and dispel prevent future bonus", () => {
            var buff = S("buff", Selection.Self, Mod(charges: 2, turns: 1)); var strip = S("strip", Selection.Enemy, E(EffectKind.Dispel, 0));
            var b = Kits(new() { [0] = new[] { buff, Hit, Rest }, [5] = new[] { strip, Rest } }); var log = new List<CombatCommand>();
            Step(b, log, "buff", 0); Step(b, log, "strip", 0); UntilActor(b, log, 0); Eq(900, Step(b, log, "hit", 5).Hp[5]);
            log.Clear(); Step(b, log, "buff", 0); UntilActor(b, log, 0); var r = Step(b, log, "rest", 0); Eq(0, r.Statuses.Count);
        });
        Test("C3 reader rejects C2 domain and preserves charge result immutability", () => {
            var b = Kits(new() { [0] = new[] { S("buff", Selection.Self, Mod()), Hit, Rest } }); var bytes = CombatCodec.Encode(b);
            var prior = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-c2-candidate"); Array.Copy(prior, 0, bytes, 2, prior.Length); Throws(() => CombatCodec.Decode(bytes));
            var log = new List<CombatCommand>(); var before = Step(b, log, "buff", 0); UntilActor(b, log, 0); var after = Step(b, log, "hit", 5);
            Eq(2, before.Statuses.Single().Charges); Eq(1, after.Statuses.Single().Charges);
        });
        Test("C3 new mark cannot boost itself and refresh preserves new charge", () => {
            var action = S("action", Selection.Enemy, Mark(), E(EffectKind.Damage, 1000)); var b = Kits(new() { [0] = new[] { action, Rest } }); var log = new List<CombatCommand>();
            var first = Step(b, log, "action", 5); Eq(900, first.Hp[5]); Eq(1, first.Statuses.Single().Charges); UntilActor(b, log, 0);
            var r = Step(b, log, "action", 5); Eq(750, r.Hp[5]); Eq(1, r.Statuses.Single().Charges); Assert(r.Statuses.Single().Sequence > first.Statuses.Single().Sequence);
        });
        Test("C3 poison arithmetic overflow rolls back paid root and due timing", () => {
            var poison = new CombatSkill("poison", Selection.Enemy, 1, new[] { Poison(10000000, 2, 1) }, 1);
            var paid = new CombatSkill("paid", Selection.Self, 1, new[] { E(EffectKind.Heal, 0) }, 1, hpCostCoefficient: 1);
            var rest = new CombatSkill("rest", Selection.Self, 1, new[] { E(EffectKind.Heal, 0) }, 1);
            var units = Input().Units.Select((u, i) => new CombatantInput(u.Id, u.Side, u.MaximumHp, i == 0 ? 10000000 : u.Offense, 0, 0, u.Speed, new[] { i == 0 ? poison : i == 5 ? paid : rest }));
            var b = new CombatInput("synthetic", "overflow", new CombatRules(1, 10000000, 16, 100, 100), units);
            var r = Run(b, C(1, 0, "poison", 5), C(2, 5, "paid", 5)); Eq("ARITHMETIC-CAPACITY", r.Receipts.Last().Diagnostic);
            Eq(1000, r.Hp[5]); Eq(0L, r.CompletedOwnerTurns[5]); Eq(2, r.Statuses.Single().RemainingTurns); Eq(2L, r.Version);
        });
        Test("C3 r002 mixed-kind modifier refresh retains one last record and one charge consumption", () => {
            var buff = S("buff", Selection.Self,
                new CombatEffect(EffectKind.NextOffenseModifier, EffectTargets.Selected, 250, 2, DamageKind.Physical, charges: 1),
                new CombatEffect(EffectKind.NextOffenseModifier, EffectTargets.Selected, 250, 4, DamageKind.Magic, charges: 2));
            var b = Kits(new() { [0] = new[] { buff, Hit, Rest } }, events: 3); var log = new List<CombatCommand>();
            var applied = Step(b, log, "buff", 0); Eq(1, applied.Statuses.Count); Eq(250L, applied.Statuses.Single().Amount);
            Eq(2, applied.Statuses.Single().Charges); Eq(4, applied.Statuses.Single().RemainingTurns); Eq(2L, applied.Statuses.Single().Sequence);
            UntilActor(b, log, 0); var r = Step(b, log, "hit", 5); Eq(875, r.Hp[5]); Eq(1, r.Statuses.Count); Eq(1, r.Statuses.Single().Charges); Eq(3, r.Statuses.Single().RemainingTurns);
            var replay = Run(b, log.Concat(new[] { log.Last() }).ToArray()); Eq(r.StateHash, replay.StateHash); Eq(875, replay.Hp[5]); Eq(1, replay.Statuses.Single().Charges);
        });
        Test("C3 r002 mixed-kind modifier rollback restores consumed charge and timing", () => {
            var buff = S("buff", Selection.Self,
                new CombatEffect(EffectKind.NextOffenseModifier, EffectTargets.Selected, 250, 2, DamageKind.Physical, charges: 1),
                new CombatEffect(EffectKind.NextOffenseModifier, EffectTargets.Selected, 250, 4, DamageKind.Magic, charges: 2));
            var b = Kits(new() { [0] = new[] { buff, Hit, Rest } }, events: 2); var log = new List<CombatCommand>();
            Step(b, log, "buff", 0); UntilActor(b, log, 0); var before = Run(b, log.ToArray()); var r = Step(b, log, "hit", 5);
            Eq("EVENT-CAPACITY", r.Receipts.Last().Diagnostic); Eq(1000, r.Hp[5]); Eq(before.Version, r.Version); Eq(1, r.Statuses.Count);
            Eq(2, r.Statuses.Single().Charges); Eq(4, r.Statuses.Single().RemainingTurns); Eq(2L, r.Statuses.Single().Sequence); Eq(1L, r.CompletedOwnerTurns[0]);
            var replay = Run(b, log.Concat(new[] { log.Last() }).ToArray()); Eq(r.StateHash, replay.StateHash); Eq(true, replay.Receipts.Last().Replayed);
        });
        Test("C3 r002 mixed-kind barrier replaces finite amount and absorbs either damage kind", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Barrier, 2000, 5, damage: DamageKind.Physical), E(EffectKind.Barrier, 500, 2, damage: DamageKind.Magic));
            foreach (var kind in new[] { DamageKind.Physical, DamageKind.Magic }) {
                var hit = S("hit", Selection.Enemy, E(EffectKind.Damage, 1000, damage: kind)); var b = Kits(new() { [0] = new[] { ward, Rest }, [5] = new[] { hit, Rest } });
                var applied = Run(b, C(1, 0, "ward", 0)); Eq(1, applied.Statuses.Count); Eq(50L, applied.Statuses.Single().Amount); Eq(2, applied.Statuses.Single().RemainingTurns); Eq(2L, applied.Statuses.Single().Sequence);
                var r = Run(b, C(1, 0, "ward", 0), C(2, 5, "hit", 0)); Eq(950, r.Hp[0]); Eq(0, r.Statuses.Count);
            }
        });
        Test("C3 r002 Defense retains independent physical and magic records", () => {
            var ward = S("ward", Selection.Self, E(EffectKind.Defense, 100, 3, damage: DamageKind.Physical), E(EffectKind.Defense, 300, 3, damage: DamageKind.Magic));
            var two = S("two", Selection.Enemy, E(EffectKind.Damage, 1000, damage: DamageKind.Physical), E(EffectKind.Damage, 1000, damage: DamageKind.Magic));
            var b = Kits(new() { [0] = new[] { ward, Rest }, [5] = new[] { two, Rest } }); var r = Run(b, C(1, 0, "ward", 0), C(2, 5, "two", 0));
            Eq(2, r.Statuses.Count); Eq(925, r.Hp[0]); Assert(r.Statuses.Any(s => s.Amount == 100)); Assert(r.Statuses.Any(s => s.Amount == 300));
        });
        Test("C3 r002 decoder rejects sealed r001 input domain", () => {
            var bytes = CombatCodec.Encode(Input()); var prior = System.Text.Encoding.UTF8.GetBytes("anotherlife-combat-input-v2-c3-candidate");
            int currentLength = BitConverter.ToUInt16(bytes, 0); using var stream = new MemoryStream(); using var writer = new BinaryWriter(stream);
            writer.Write((ushort)prior.Length); writer.Write(prior); writer.Write(bytes, 2 + currentLength, bytes.Length - 2 - currentLength); writer.Flush();
            Throws(() => CombatCodec.Decode(stream.ToArray())); Eq("five-hero-effects-v2-d3-candidate", CombatInput.EngineVersion);
        });
        Test("C3 invalid charge cap and cost contracts fail closed", () => {
            Throws(() => Mod(charges: 0)); Throws(() => new CombatEffect(EffectKind.Heal, EffectTargets.Self, 1000, charges: 1));
            Throws(() => new CombatEffect(EffectKind.Poison, EffectTargets.Selected, 1000, 1, beneficial: false, stackCap: 1));
            Throws(() => Kits(new() { [0] = new[] { S("one", Selection.Enemy, Poison(cap: 1)), S("two", Selection.Enemy, Poison(cap: 2)) } }));
            Throws(() => Kits(new() { [0] = new[] { Paid(1001, E(EffectKind.Damage, 1000)) } }));
        });
    }
}
using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using AL.Core.Accounts;
using AnotherLife.StoryCombat;

namespace AnotherLife.AccountService;

// Detached catalog prerequisite only. The caller must supply the authenticated,
// lease-held roster and enforce enrollment, unlocks, building and storage admission.
public sealed class KingdomStoryCatalog
{
    public sealed class Stage
    {
        public string Id { get; }
        public string DefinitionRevision { get; }
        public string RequiredBuilding { get; }
        public bool RuntimeEnabled { get; }
        public StorySettlementTerms Settlement { get; }
        internal IReadOnlyList<Enemy> Enemies { get; }
        internal Stage(string id, string revision, string building, bool enabled,
            StorySettlementTerms terms, Enemy[] enemies)
        { Id=id; DefinitionRevision=revision; RequiredBuilding=building; RuntimeEnabled=enabled;
          Settlement=terms; Enemies=Array.AsReadOnly(enemies); }
    }
    sealed record HeroDefinition(string Id, string Revision, int Hp, int Damage, Skill[] Skills);
    readonly IReadOnlyDictionary<string, HeroDefinition> heroes;
    public string Revision { get; }
    public string Digest { get; }
    public bool RuntimeEnabled { get; }
    public IReadOnlyList<Stage> Stages { get; }
    KingdomStoryCatalog(string revision, string digest, bool enabled, Stage[] stages, Dictionary<string,HeroDefinition> heroes)
    { Revision=revision; Digest=digest; RuntimeEnabled=enabled; Stages=Array.AsReadOnly(stages);
      this.heroes=new System.Collections.ObjectModel.ReadOnlyDictionary<string,HeroDefinition>(heroes); }
    static InvalidDataException Bad()=>new("AL-STORY-RUNTIME-CATALOG-INVALID");
    static void Need(bool value) { if(!value) throw Bad(); }
    static void Fields(JsonElement e, params string[] names)
    {
        Need(e.ValueKind==JsonValueKind.Object);
        var found=e.EnumerateObject().Select(p=>p.Name).ToArray();
        Need(found.Length==names.Length && found.Distinct(StringComparer.Ordinal).Count()==found.Length &&
            found.All(n=>names.Contains(n,StringComparer.Ordinal)));
    }
    static string Text(JsonElement e,string name)
    { var x=e.GetProperty(name); Need(x.ValueKind==JsonValueKind.String); return x.GetString()!; }
    static string Id(JsonElement e,string name)
    {
        string s=Text(e,name); Need(s.Length is >=1 and <=128 &&
            s.All(c=>char.IsAsciiLetterOrDigit(c)||c is '_' or '-' or '.')); return s;
    }
    static long Number(JsonElement e,string name,long min,long max)
    {
        var x=e.GetProperty(name); Need(x.ValueKind==JsonValueKind.Number);
        Need(x.TryGetInt64(out long n) && n>=min && n<=max && x.GetRawText()==n.ToString(CultureInfo.InvariantCulture)); return n;
    }
    static bool Flag(JsonElement e,string name)
    { var x=e.GetProperty(name); Need(x.ValueKind is JsonValueKind.True or JsonValueKind.False); return x.GetBoolean(); }
    static JsonElement[] Rows(JsonElement e,string name,int min,int max)
    {
        var x=e.GetProperty(name); Need(x.ValueKind==JsonValueKind.Array && x.GetArrayLength()>=min && x.GetArrayLength()<=max);
        return x.EnumerateArray().ToArray();
    }
    public static KingdomStoryCatalog Parse(byte[] utf8)
    {
        Need(utf8!=null && utf8.Length is >0 and <=4194304);
        byte[] owned=(byte[])utf8.Clone();
        try
        {
            using var doc=JsonDocument.Parse(owned,new JsonDocumentOptions { MaxDepth=12, AllowTrailingCommas=false, CommentHandling=JsonCommentHandling.Disallow });
            var root=doc.RootElement; Fields(root,"version","catalogId","revision","runtimeEnabled","heroes","records");
            Need(Number(root,"version",1,1)==1 && Text(root,"catalogId")=="kingdom_story_runtime");
            string revision=Id(root,"revision"); bool enabled=Flag(root,"runtimeEnabled");
            var heroes=new Dictionary<string,HeroDefinition>(StringComparer.Ordinal);
            foreach(var h in Rows(root,"heroes",0,120))
            {
                Fields(h,"id","revision","maximumHp","damage","skills");
                var skills=Rows(h,"skills",1,6).Select(s=> {
                    Fields(s,"id","target","effect","multiplier");
                    // Exact supported semantics, never a fallback for an unknown hero mechanic.
                    string effect=Text(s,"effect"),target=Text(s,"target");
                    Need((effect=="damage" && target=="enemy") || (effect=="heal" && target=="ally"));
                    return new Skill(Id(s,"id"),target=="enemy"?Target.Enemy:Target.Ally,
                        effect=="damage"?Effect.Damage:Effect.Heal,(int)Number(s,"multiplier",1,10));
                }).ToArray();
                Need(skills.Select(s=>s.Id).Distinct(StringComparer.Ordinal).Count()==skills.Length);
                string id=Id(h,"id"); Need(heroes.TryAdd(id,new(id,Id(h,"revision"),
                    (int)Number(h,"maximumHp",1,5400000),(int)Number(h,"damage",1,5400000),skills)));
            }
            var stages=new List<Stage>(); var ids=new HashSet<string>(StringComparer.Ordinal);
            foreach(var row in Rows(root,"records",0,600))
            {
                Fields(row,"stageId","definitionRevision","requiredBuilding","runtimeEnabled","engineVersion","enemies","repeat","firstClear","unlocks");
                Need(Text(row,"engineVersion")==FiniteAttemptPolicy.Engine);
                string id=Id(row,"stageId"); Need(ids.Add(id));
                var enemies=Rows(row,"enemies",1,5).Select(e=> {
                    Fields(e,"id","maximumHp","attack"); return new Enemy(Id(e,"id"),
                        (int)Number(e,"maximumHp",1,10000000),(int)Number(e,"attack",1,1000000));
                }).ToArray();
                StoryResourceTerm[] Rewards(string name)=>Rows(row,name,0,128).Select(r=> {
                    Fields(r,"definitionId","resourceId","quantity");
                    return new StoryResourceTerm(Id(r,"definitionId"),Id(r,"resourceId"),Number(r,"quantity",1,1000000000000));
                }).ToArray();
                var unlocks=Rows(row,"unlocks",0,600).Select(u=> {
                    Fields(u,"stageId"); return Id(u,"stageId");
                }).ToArray();
                stages.Add(new Stage(id,Id(row,"definitionRevision"),Id(row,"requiredBuilding"),Flag(row,"runtimeEnabled"),
                    new StorySettlementTerms(revision,Rewards("repeat"),Rewards("firstClear"),unlocks),enemies));
            }
            Need(stages.All(s=>s.Settlement.Unlocks.All(ids.Contains)));
            Need(!enabled || (heroes.Count>=5 && stages.Any(s=>s.RuntimeEnabled)));
            return new(revision,Convert.ToHexString(SHA256.HashData(owned)).ToLowerInvariant(),enabled,stages.ToArray(),heroes);
        }
        catch(Exception e) when(e is JsonException or ArgumentException or InvalidOperationException or OverflowException or KeyNotFoundException) { throw Bad(); }
    }
    public Stage Resolve(string catalogRevision,string stageId,string definitionRevision)
    {
        var stage=Stages.SingleOrDefault(s=>s.Id==stageId);
        if(!RuntimeEnabled || Revision!=catalogRevision || stage==null || !stage.RuntimeEnabled || stage.DefinitionRevision!=definitionRevision)
            throw new InvalidOperationException("AL-STORY-CONTENT-UNAVAILABLE");
        return stage;
    }
    // Internal to the server assembly: not a public arbitrary preparation delegate or ownership proof.
    internal BattleInput BuildInput(string catalogRevision,string stageId,string definitionRevision,
        AccountHeroCollectionSnapshot roster,IEnumerable<string> selectedAcquisitions,long now,FiniteAttemptCatalog policies)
    {
        var stage=Resolve(catalogRevision,stageId,definitionRevision);
        if(roster==null || selectedAcquisitions==null || policies==null) throw Bad();
        var ids=selectedAcquisitions.Take(6).ToArray();
        Need(ids.Length==5 && ids.Distinct(StringComparer.Ordinal).Count()==5);
        var party=ids.Select(id=> {
            var owned=roster.Acquisitions.SingleOrDefault(a=>a.AcquisitionId==id);
            if(owned==null || !heroes.TryGetValue(owned.DesignId,out var h)) throw new InvalidOperationException("AL-STORY-ROSTER-UNAVAILABLE");
            return new Hero(owned.AcquisitionId,h.Id,h.Revision,h.Hp,h.Damage,h.Skills);
        }).ToArray();
        return new BattleInput(FiniteAttemptPolicy.Engine,stage.Id,stage.DefinitionRevision,false,now,
            "party-then-enemies","first-living-party",party,stage.Enemies,policies.Resolve("story",stage.Id,0));
    }
}

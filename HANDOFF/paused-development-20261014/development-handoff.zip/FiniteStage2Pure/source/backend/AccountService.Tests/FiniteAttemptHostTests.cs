using System.Text;
using System.Text.Json.Nodes;
using AnotherLife.AccountService;
using AnotherLife.StoryCombat;

// Detached catalog tests, not host/security/store qualification. Registration is deferred.
internal static class FiniteAttemptHostTests
{
    static void Need(bool value) { if(!value) throw new Exception("Catalog assertion failed"); }
    static void Bad(Action action)
    { try { action(); } catch(Exception e) when(e is InvalidDataException or InvalidOperationException) { return; } throw new Exception("Expected refusal"); }
    static JsonObject Fixture()
    {
        var heroes=new JsonArray();
        for(int i=0;i<5;i++) heroes.Add(new JsonObject { ["id"]="fixture-hero-"+i,["revision"]="fixture-v1",
            ["maximumHp"]=100,["damage"]=2,["skills"]=new JsonArray(new JsonObject {
                ["id"]="hit",["target"]="enemy",["effect"]="damage",["multiplier"]=1 }) });
        return new JsonObject { ["version"]=1,["catalogId"]="kingdom_story_runtime",["revision"]="fixture-v1",["runtimeEnabled"]=true,
            ["heroes"]=heroes,["records"]=new JsonArray(new JsonObject { ["stageId"]="fixture-stage",["definitionRevision"]="fixture-def-v1",
                ["requiredBuilding"]="fixture-building",["runtimeEnabled"]=true,["engineVersion"]=FiniteAttemptPolicy.Engine,
                ["enemies"]=new JsonArray(new JsonObject { ["id"]="fixture-enemy",["maximumHp"]=100,["attack"]=1 }),
                ["repeat"]=new JsonArray(new JsonObject { ["definitionId"]="fixture-reward",["resourceId"]="food",["quantity"]=1 }),
                ["firstClear"]=new JsonArray(),["unlocks"]=new JsonArray() }) };
    }
    static KingdomStoryCatalog Parse(JsonObject x)=>KingdomStoryCatalog.Parse(Encoding.UTF8.GetBytes(x.ToJsonString()));
    static JsonObject Row(JsonObject x)=>(JsonObject)x["records"]![0]!;
    public static void Register(Action<string,Func<Task>> add)
    {
        void Case(string name,Action action)=>add("Finite Stage2 catalog: "+name,()=> { action(); return Task.CompletedTask; });
        Case("exact stage revisions and frozen resource terms",()=> {
            var c=Parse(Fixture());var s=c.Resolve("fixture-v1","fixture-stage","fixture-def-v1");
            Need(s.Settlement.Repeat.Single().Quantity==1 && c.Digest.Length==64);
            Bad(()=>c.Resolve("other","fixture-stage","fixture-def-v1"));Bad(()=>c.Resolve("fixture-v1","fixture-stage","other"));
        });
        Case("disabled root and disabled stage unavailable",()=> {
            var x=Fixture();x["runtimeEnabled"]=false;Bad(()=>Parse(x).Resolve("fixture-v1","fixture-stage","fixture-def-v1"));
            x=Fixture();Row(x)["runtimeEnabled"]=false;Bad(()=>Parse(x));
        });
        Case("disabled empty scaffold valid but not playable",()=> {
            var x=Fixture();x["runtimeEnabled"]=false;x["heroes"]=new JsonArray();x["records"]=new JsonArray();
            var c=Parse(x);Need(c.Stages.Count==0);Bad(()=>c.Resolve("fixture-v1","fixture-stage","fixture-def-v1"));
        });
        Case("caller bytes and JSON mutations cannot change admitted image",()=> {
            var x=Fixture();var bytes=Encoding.UTF8.GetBytes(x.ToJsonString());var c=KingdomStoryCatalog.Parse(bytes);string digest=c.Digest;
            Array.Fill(bytes,(byte)0);Row(x)["definitionRevision"]="changed";
            Need(c.Digest==digest && c.Resolve("fixture-v1","fixture-stage","fixture-def-v1").DefinitionRevision=="fixture-def-v1");
        });
        Case("duplicate decoded names unknown fields and missing fields refused",()=> {
            var x=Fixture();x["extra"]=0;Bad(()=>Parse(x));x=Fixture();x.Remove("heroes");Bad(()=>Parse(x));
            string raw=Fixture().ToJsonString().Replace("\"version\":1","\"version\":1,\"vers\\u0069on\":1");
            Bad(()=>KingdomStoryCatalog.Parse(Encoding.UTF8.GetBytes(raw)));
        });
        Case("canonical integer and field type enforced",()=> {
            string raw=Fixture().ToJsonString().Replace("\"version\":1","\"version\":1.0");Bad(()=>KingdomStoryCatalog.Parse(Encoding.UTF8.GetBytes(raw)));
            var x=Fixture();x["runtimeEnabled"]="true";Bad(()=>Parse(x));
        });
        Case("duplicate stage hero and skill identities refused",()=> {
            var x=Fixture();x["records"]!.AsArray().Add(Row(x).DeepClone());Bad(()=>Parse(x));
            x=Fixture();x["heroes"]!.AsArray().Add(x["heroes"]![0]!.DeepClone());Bad(()=>Parse(x));
            x=Fixture();var skills=x["heroes"]![0]!["skills"]!.AsArray();skills.Add(skills[0]!.DeepClone());Bad(()=>Parse(x));
        });
        Case("unknown mechanics and old or manual engine not relabeled",()=> {
            var x=Fixture();x["heroes"]![0]!["skills"]![0]!["effect"]="stun";Bad(()=>Parse(x));
            foreach(string engine in new[]{BattleInput.SupportedEngineVersion,"five-hero-effects-v2-candidate"}) {
                x=Fixture();Row(x)["engineVersion"]=engine;Bad(()=>Parse(x)); }
        });
        Case("card rewards and aggregate wallet overflow refused",()=> {
            var x=Fixture();Row(x)["repeat"]![0]!["resourceId"]="hero_card";Bad(()=>Parse(x));
            x=Fixture();Row(x)["repeat"]![0]!["quantity"]=1000000000000L;
            Row(x)["firstClear"]!.AsArray().Add(new JsonObject { ["definitionId"]="extra",["resourceId"]="food",["quantity"]=1 });Bad(()=>Parse(x));
        });
        Case("unknown and duplicate unlocks refused",()=> {
            var x=Fixture();Row(x)["unlocks"]!.AsArray().Add(new JsonObject { ["stageId"]="missing" });Bad(()=>Parse(x));
            x=Fixture();for(int i=0;i<2;i++)Row(x)["unlocks"]!.AsArray().Add(new JsonObject { ["stageId"]="fixture-stage" });Bad(()=>Parse(x));
        });
        Case("field limits trailing input and oversized image refused",()=> {
            var x=Fixture();Row(x)["stageId"]=new string('a',129);Bad(()=>Parse(x));
            x=Fixture();x["heroes"]![0]!["maximumHp"]=5400001;Bad(()=>Parse(x));
            Bad(()=>KingdomStoryCatalog.Parse(Encoding.UTF8.GetBytes(Fixture().ToJsonString()+"{}")));
            Bad(()=>KingdomStoryCatalog.Parse(new byte[4194305]));
        });
    }
}

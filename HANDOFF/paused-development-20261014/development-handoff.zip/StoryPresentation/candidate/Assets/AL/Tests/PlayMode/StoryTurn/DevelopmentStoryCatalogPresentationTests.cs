#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Reflection;
using System.Threading.Tasks;
using AL.Core.Accounts;
using AL.UI;
using NUnit.Framework;
using UnityEngine;

namespace AL.Tests.PlayMode.StoryTurn
{
    public sealed class DevelopmentStoryCatalogPresentationTests
    {
        GameObject root;
        DevelopmentStoryCatalogPresentation source;
        StoryFlowFixture.Provider provider;
        IAccountStoryProvider current;
        AccountLoginSession login;
        Sprite icon;
        bool live;
        string Catalog(string revision="synthetic",bool enabled=true)
        {
            return JsonUtility.ToJson(new DevelopmentStoryDisplayCatalog{
                version=1,enabled=enabled,developmentOnly=true,catalogRevision=revision,
                contentId="stage1",definitionRevision="synthetic_v1",
                entries=new[]{
                    Row("Stage","stage1","Stage"),Row("Hero","fixture_hero","Hero"),
                    Row("Enemy","fixture_enemy","Enemy"),Row("Skill","hit","Hit")},
                rewards=new DevelopmentStoryDisplayRow[0]});
        }
        static DevelopmentStoryDisplayRow Row(string kind,string id,string text)=>new DevelopmentStoryDisplayRow{
            kind=kind,id=id,en=text,ko="시험 "+text,spriteResource="Fixture/"+id};
        [SetUp] public void SetUp()
        {
            root=new GameObject("DevelopmentContentFixture");
            source=root.AddComponent<DevelopmentStoryCatalogPresentation>();
            provider=new StoryFlowFixture.Provider();current=provider;login=StoryFlowFixture.Session();live=true;
            icon=Sprite.Create(Texture2D.whiteTexture,new Rect(0,0,1,1),Vector2.zero);
        }
        Task<bool> Bind(string json=null,Func<string,Sprite> loader=null)=>source.BindAsync(json??Catalog(),
            "synthetic","stage1","synthetic_v1",provider,login,StoryFlowFixture.Kingdom,()=>current,()=>live,loader??(_=>icon),()=>100);
        [TearDown] public void TearDown(){UnityEngine.Object.DestroyImmediate(root);UnityEngine.Object.DestroyImmediate(icon);}


        string StructurallyValidCatalog()
        {
            var data=JsonUtility.FromJson<DevelopmentStoryDisplayCatalog>(Catalog());
            data.entries[0].spriteResource="";
            var reward=Row("Reward","fixture_gold","Gold");reward.spriteResource="";
            data.rewards=new[]{reward};
            return JsonUtility.ToJson(data);
        }
        static string ReplaceOne(string json,string before,string after,bool last=false)
        {
            int at=last?json.LastIndexOf(before,StringComparison.Ordinal):json.IndexOf(before,StringComparison.Ordinal);
            Assert.That(at,Is.GreaterThanOrEqualTo(0),"Fixture mutation must actually match");
            return json.Substring(0,at)+after+json.Substring(at+before.Length);
        }
        [Test] public async Task StrictCanonicalRowsAcceptPresentEmptyStageAndRewardSprite()
        {
            Assert.That(await Bind(StructurallyValidCatalog()),Is.True);
            Assert.That(source.RewardLabel("fixture_gold","en"),Is.EqualTo("Gold"));
            Assert.That(provider.Reads,Is.EqualTo(1));Assert.That(provider.Entries,Is.Zero);
        }
        [TestCase("unknown-top")] [TestCase("unknown-entry")] [TestCase("unknown-reward")]
        [TestCase("missing-top")] [TestCase("missing-stage-sprite")] [TestCase("missing-reward-sprite")]
        [TestCase("null-stage-sprite")] [TestCase("null-reward-sprite")]
        [TestCase("wrong-version-type")] [TestCase("wrong-enabled-type")] [TestCase("wrong-row-type")]
        [TestCase("duplicate-top")] [TestCase("duplicate-row")] [TestCase("escaped-duplicate")]
        [TestCase("trailing-object")]
        public async Task StrictStructureRejectsBeforeProviderRead(string mutation)
        {
            string json=StructurallyValidCatalog();
            switch(mutation)
            {
                case "unknown-top":json=json.Insert(1,"\"unexpected\":1,");break;
                case "unknown-entry":json=ReplaceOne(json,"\"kind\":\"Stage\"","\"unexpected\":true,\"kind\":\"Stage\"");break;
                case "unknown-reward":json=ReplaceOne(json,"\"kind\":\"Reward\"","\"unexpected\":true,\"kind\":\"Reward\"");break;
                case "missing-top":json=ReplaceOne(json,"\"enabled\":true,","");break;
                case "missing-stage-sprite":json=ReplaceOne(json,",\"spriteResource\":\"\"","");break;
                case "missing-reward-sprite":json=ReplaceOne(json,",\"spriteResource\":\"\"","",true);break;
                case "null-stage-sprite":json=ReplaceOne(json,"\"spriteResource\":\"\"","\"spriteResource\":null");break;
                case "null-reward-sprite":json=ReplaceOne(json,"\"spriteResource\":\"\"","\"spriteResource\":null",true);break;
                case "wrong-version-type":json=ReplaceOne(json,"\"version\":1","\"version\":\"1\"");break;
                case "wrong-enabled-type":json=ReplaceOne(json,"\"enabled\":true","\"enabled\":\"true\"");break;
                case "wrong-row-type":json=ReplaceOne(json,"\"id\":\"stage1\"","\"id\":7");break;
                case "duplicate-top":json=json.Insert(1,"\"enabled\":true,");break;
                case "duplicate-row":json=ReplaceOne(json,"\"kind\":\"Stage\"","\"kind\":\"Stage\",\"kind\":\"Stage\"");break;
                case "escaped-duplicate":json=json.Insert(1,"\"\\u0065nabled\":true,");break;
                case "trailing-object":json+="{}";break;
            }
            Assert.That(await Bind(json),Is.False);
            Assert.That(source.IsAvailable,Is.False);
            Assert.That(provider.Reads,Is.Zero);
            Assert.That(provider.Entries,Is.Zero);Assert.That(provider.Actions,Is.Zero);
        }

        sealed class RefusingProvider : IAccountStoryProvider
        {
            readonly string status; public int Reads,Mutations;
            public RefusingProvider(string value){status=value;}
            public Task<AccountStoryState> ReadStoryAsync(AccountLoginSession s,AccountKingdom k,System.Threading.CancellationToken c)
            {Reads++;return Task.FromResult(new AccountStoryState(k,99,"synthetic",1,2,4,status,null,Array.Empty<AccountStoryStageView>(),"",""));}
            public Task<AccountStoryAttempt> ReadStoryAttemptAsync(AccountLoginSession s,AccountKingdom k,string id,System.Threading.CancellationToken c)=>throw new InvalidOperationException();
            public Task<AccountStoryAttempt> RecoverStoryEntryAsync(AccountLoginSession s,AccountKingdom k,string id,System.Threading.CancellationToken c)=>throw new InvalidOperationException();
            public Task<AccountStoryCommandResult> EnterStoryAsync(AccountLoginSession s,AccountKingdom k,AccountStoryEntryCommand v,System.Threading.CancellationToken c)
            {Mutations++;throw new InvalidOperationException();}
            public Task<AccountStoryCommandResult> CommitStoryActionAsync(AccountLoginSession s,AccountKingdom k,AccountStoryActionCommand v,System.Threading.CancellationToken c)
            {Mutations++;throw new InvalidOperationException();}
        }
        [TestCase("service_unavailable")] [TestCase("content_missing")]
        public async Task ActualProviderRefusalKeepsFactoryUnavailable(string status)
        {
            var refusing=new RefusingProvider(status);current=refusing;
            Assert.That(await source.BindAsync(Catalog(),"synthetic","stage1","synthetic_v1",refusing,login,
                StoryFlowFixture.Kingdom,()=>current,()=>live,_=>icon,()=>100),Is.False);
            Assert.That(refusing.Reads,Is.EqualTo(1));Assert.That(refusing.Mutations,Is.Zero);
            Assert.That(source.IsAvailable,Is.False);
        }
        [Test] public async Task OldImmutableAttemptCannotUseNewCatalogBinding()
        {
            provider.Saved=StoryFlowFixture.Fresh(new AccountStoryEntryCommand(StoryFlowFixture.N('a'),
                "stage1","older_catalog",StoryFlowFixture.Heroes,1,2,3,4));
            Assert.That(await Bind(),Is.False);Assert.That(source.IsAvailable,Is.False);
            Assert.That(provider.Saved.Entry.Command.CatalogRevision,Is.EqualTo("older_catalog"));
        }

        [Test] public void StartsUnavailableWithoutFactoryOrProviderBinding()
        {Assert.That(source.IsAvailable,Is.False);Assert.That(source.Resolve(StoryCombatContentKind.Hero,"fixture_hero","en"),Is.Null);}
        [Test] public async Task CapabilityReadBindsLabelsWithoutEntryOrAction()
        {
            Assert.That(await Bind(),Is.True);
            Assert.That(source.Resolve(StoryCombatContentKind.Stage,"stage1","en").Label,Does.StartWith("PROVISIONAL"));
            Assert.That(source.Resolve(StoryCombatContentKind.Hero,"fixture_hero","ko").Icon,Is.SameAs(icon));
            Assert.That(source.Resolve(StoryCombatContentKind.Hero,"unknown","en"),Is.Null);
            Assert.That(source.RewardLabel("unmapped","en"),Is.Null);
            Assert.That(provider.Entries,Is.Zero);Assert.That(provider.Actions,Is.Zero);
        }
        [TestCase("revision")] [TestCase("disabled")] [TestCase("missing-art")]
        public async Task InvalidCatalogCannotExposeContent(string kind)
        {
            bool result=kind=="missing-art"?await Bind(loader:_=>null):
                await Bind(Catalog(kind=="revision"?"different":"synthetic",kind!="disabled"));
            Assert.That(result,Is.False);Assert.That(source.IsAvailable,Is.False);
            Assert.That(source.Resolve(StoryCombatContentKind.Stage,"stage1","en"),Is.Null);
        }
        [TestCase("provider")] [TestCase("owner")] [TestCase("disable")]
        public async Task ReplacementOrRetirementRevokesLookup(string kind)
        {
            Assert.That(await Bind(),Is.True);
            if(kind=="provider")current=new StoryFlowFixture.Provider();
            else if(kind=="owner")live=false;
            else source.enabled=false;
            Assert.That(source.IsAvailable,Is.False);
            Assert.That(source.Resolve(StoryCombatContentKind.Skill,"hit","en"),Is.Null);
            current=provider;live=true;source.enabled=true;
            Assert.That(source.IsAvailable,Is.False);
        }
        [Test] public async Task ExistingAttemptRequiresExactSnapshotAndCompleteMappings()
        {
            provider.Saved=StoryFlowFixture.Fresh();
            Assert.That(await Bind(),Is.True);Assert.That(provider.AttemptReads,Is.EqualTo(1));
            var data=JsonUtility.FromJson<DevelopmentStoryDisplayCatalog>(Catalog());
            data.entries=Array.FindAll(data.entries,x=>x.kind!="Enemy");
            Assert.That(await Bind(JsonUtility.ToJson(data)),Is.False);
            Assert.That(provider.Entries,Is.Zero);
        }
        [Test] public async Task ReplacedProviderCannotPublishLateAttemptRead()
        {
            provider.Saved=StoryFlowFixture.Fresh();
            provider.PendingAttempt=new TaskCompletionSource<AccountStoryAttempt>();
            var binding=Bind();
            current=new StoryFlowFixture.Provider();
            provider.PendingAttempt.SetResult(provider.Saved);
            Assert.That(await binding,Is.False);Assert.That(source.IsAvailable,Is.False);
        }
        [Test] public async Task ExistingCompositionRejectsUnboundContent()
        {
            var host=root.AddComponent<AccountStoryFlowHost>();
            var composition=root.AddComponent<AccountStoryComposition>();
            typeof(AccountStoryComposition).GetField("_flowHost",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(composition,host);
            typeof(AccountStoryComposition).GetField("_approvedContent",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(composition,source);
            var store=new StoryFlowFixture.MemoryStore();
            Assert.That(composition.TryConfigure(host,()=>provider,_=>store,()=>"en",_=>Task.CompletedTask),Is.False);
            Assert.That(await Bind(),Is.True);
            Assert.That(composition.TryConfigure(host,()=>provider,_=>store,()=>"en",_=>Task.CompletedTask),Is.True);
            source.Revoke("fixture-refusal");
            Assert.That(composition.TryConfigure(host,()=>provider,_=>store,()=>"en",_=>Task.CompletedTask),Is.False);
            Assert.That(provider.Entries,Is.Zero);
        }
    }
}
#endif

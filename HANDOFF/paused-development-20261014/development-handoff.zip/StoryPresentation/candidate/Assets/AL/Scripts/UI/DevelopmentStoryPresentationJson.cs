#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AL.Data.Catalogs;

namespace AL.UI
{
    // AL.Runtime already has the qualified strict parser friend access and catalog reference.
    // No Unity JSON projection occurs until exact field presence and types have been checked.
    public static class DevelopmentStoryPresentationJson
    {
        const int MaximumBytes=131072;
        public static void Validate(string json)
        {
            if(string.IsNullOrWhiteSpace(json)||json.Length>MaximumBytes)throw Invalid();
            try
            {
                var root=StrictJsonDocument.Parse(new UTF8Encoding(false,true).GetBytes(json),MaximumBytes) as StrictJsonObject;
                Keys(root,"version","enabled","developmentOnly","catalogRevision","contentId","definitionRevision","entries","rewards");
                if(!(Get(root,"version") is StrictJsonNumber version)||version.RawValue!="1"||
                    !(Get(root,"enabled") is StrictJsonBoolean enabled)||
                    !(Get(root,"developmentOnly") is StrictJsonBoolean development)||!development.Value)throw Invalid();
                Text(root,"catalogRevision",enabled.Value);Text(root,"contentId",enabled.Value);Text(root,"definitionRevision",enabled.Value);
                Rows(Get(root,"entries"),false,enabled.Value);
                Rows(Get(root,"rewards"),true,false);
            }
            catch(Exception error) when(error is StrictJsonException||error is ArgumentException)
            {throw Invalid();}
        }
        static void Rows(StrictJsonValue value,bool reward,bool enabled)
        {
            var rows=value as StrictJsonArray;
            if(rows==null||rows.Items.Count>(reward?64:256)||(enabled&&rows.Items.Count==0))throw Invalid();
            var identities=new HashSet<string>(StringComparer.Ordinal);
            foreach(var item in rows.Items)
            {
                var row=item as StrictJsonObject;
                Keys(row,"kind","id","en","ko","spriteResource");
                string kind=Text(row,"kind",true),id=Text(row,"id",true);
                if(reward?kind!="Reward":!new[]{"Stage","Hero","Enemy","Skill"}.Contains(kind))throw Invalid();
                Text(row,"en",true);Text(row,"ko",true);
                // Presence and string type are mandatory even where the icon is not rendered.
                // Stage/Reward accept empty strings; null/missing are never equivalent to empty.
                Text(row,"spriteResource",!reward&&kind!="Stage");
                if(!identities.Add(kind+"/"+id))throw Invalid();
            }
        }
        static string Text(StrictJsonObject row,string key,bool nonempty)
        {
            if(!(Get(row,key) is StrictJsonString value)||(nonempty&&string.IsNullOrWhiteSpace(value.Value)))throw Invalid();
            return value.Value;
        }
        static StrictJsonValue Get(StrictJsonObject row,string key)=>row.TryGet(key,out var value)?value:null;
        static void Keys(StrictJsonObject row,params string[] keys)
        {
            if(row==null||row.Properties.Count!=keys.Length||row.Properties.Any(p=>!keys.Contains(p.Name)))throw Invalid();
        }
        static InvalidDataException Invalid()=>new InvalidDataException("Invalid development Story presentation JSON structure.");
    }
}
#endif

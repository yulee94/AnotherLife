#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AL.Core.Accounts;
using UnityEngine;

namespace AL.UI
{
    [Serializable] public sealed class DevelopmentStoryDisplayRow
    { public string kind,id,en,ko,spriteResource; }
    [Serializable] public sealed class DevelopmentStoryDisplayCatalog
    {
        public int version;
        public bool enabled,developmentOnly;
        public string catalogRevision,contentId,definitionRevision;
        public DevelopmentStoryDisplayRow[] entries,rewards;
    }
    // No default factory/Start binding. A reviewed host must explicitly supply the real provider
    // and admitted content triple. This component reads capability; it never enters or simulates.
    public sealed class DevelopmentStoryCatalogPresentation : MonoBehaviour, IAccountStoryApprovedContentSource
    {
        readonly Dictionary<string,AccountStoryCombatContent> english=new Dictionary<string,AccountStoryCombatContent>(StringComparer.Ordinal);
        readonly Dictionary<string,AccountStoryCombatContent> korean=new Dictionary<string,AccountStoryCombatContent>(StringComparer.Ordinal);
        readonly Dictionary<string,DevelopmentStoryDisplayRow> rewards=new Dictionary<string,DevelopmentStoryDisplayRow>(StringComparer.Ordinal);
        CancellationTokenSource pending;
        Func<IAccountStoryProvider> currentProvider;
        Func<bool> currentOwner;
        Func<long> clock;
        IAccountStoryProvider provider;
        AccountLoginSession session;
        long generation;
        bool bound;
        public string Diagnostic { get; private set; }="AL-DEV-STORY-CONTENT-UNBOUND";
        public bool IsAvailable
        {
            get
            {
                if(!bound)return false;
                bool live;
                try { live=isActiveAndEnabled&&currentOwner()!=false&&ReferenceEquals(provider,currentProvider())&&
                    session.ExpiresAt>clock()&&english.Where(p=>!p.Key.StartsWith("Stage/",StringComparison.Ordinal)).All(p=>p.Value.Icon!=null); }
                catch(Exception){live=false;}
                if(!live)Revoke("AL-DEV-STORY-CONTENT-RETIRED");
                return live;
            }
        }
        public async Task<bool> BindAsync(string json,string admittedCatalogRevision,string admittedContentId,
            string admittedDefinitionRevision,IAccountStoryProvider realProvider,AccountLoginSession login,
            AccountKingdom kingdom,Func<IAccountStoryProvider> readCurrentProvider,Func<bool> stillCurrent,
            Func<string,Sprite> loadSprite=null,Func<long> utcSeconds=null)
        {
            Revoke("AL-DEV-STORY-CONTENT-BINDING");
            var tokenSource=new CancellationTokenSource();pending=tokenSource;
            long ticket=generation;
            Func<long> now=utcSeconds??(()=>DateTimeOffset.UtcNow.ToUnixTimeSeconds());
            bool Live()
            {
                try{return ticket==generation&&isActiveAndEnabled&&!tokenSource.IsCancellationRequested&&
                    realProvider!=null&&ReferenceEquals(realProvider,readCurrentProvider())&&stillCurrent()&&
                    login?.Account!=null&&kingdom!=null&&login.Account.AccountId==kingdom.AccountId&&
                    login.Account.ProfileId==kingdom.ProfileId&&login.ExpiresAt>now();}
                catch(Exception){return false;}
            }
            try
            {
                if(!Live()||string.IsNullOrWhiteSpace(admittedCatalogRevision)||string.IsNullOrWhiteSpace(admittedContentId)||
                    string.IsNullOrWhiteSpace(admittedDefinitionRevision)||string.IsNullOrWhiteSpace(json)||json.Length>131072)throw Invalid();
                DevelopmentStoryPresentationJson.Validate(json);
                var catalog=JsonUtility.FromJson<DevelopmentStoryDisplayCatalog>(json);
                if(catalog==null||catalog.version!=1||!catalog.enabled||!catalog.developmentOnly||
                    catalog.catalogRevision!=admittedCatalogRevision||catalog.contentId!=admittedContentId||
                    catalog.definitionRevision!=admittedDefinitionRevision||catalog.entries==null||
                    catalog.entries.Length<1||catalog.entries.Length>256||catalog.rewards==null||catalog.rewards.Length>64)throw Invalid();
                var state=await realProvider.ReadStoryAsync(login,kingdom,tokenSource.Token);
                if(!Live())throw Invalid();
                if(state==null||!AccountHeroRosterReadState.SameOwner(kingdom,state.Kingdom)||
                    state.CatalogRevision!=catalog.catalogRevision||
                    !(state.EntryAvailable||state.Status=="active_attempt")||
                    (state.EntryAvailable&&state.Stages.Any(s=>s.Unlocked&&s.StageId!=catalog.contentId)))throw Invalid();
                var stage=state.Stages.SingleOrDefault(s=>s.StageId==catalog.contentId);
                if(stage==null||stage.DefinitionRevision!=catalog.definitionRevision||
                    (state.EntryAvailable&&!stage.Unlocked))throw Invalid();
                AccountStoryAttempt attempt=null;
                if(state.Status=="active_attempt")
                {
                    attempt=await realProvider.ReadStoryAttemptAsync(login,kingdom,state.ActiveAttemptId,tokenSource.Token);
                    if(!Live())throw Invalid();
                    if(attempt==null||!AccountHeroRosterReadState.SameOwner(kingdom,attempt.Kingdom)||
                        attempt.Entry.AttemptId!=state.ActiveAttemptId||attempt.Entry.Command.StageId!=catalog.contentId||
                        attempt.Entry.Command.CatalogRevision!=catalog.catalogRevision||
                        attempt.Entry.DefinitionRevision!=catalog.definitionRevision||
                        attempt.Journal.Input.ContentId!=catalog.contentId||
                        attempt.Journal.Input.ContentVersion!=catalog.definitionRevision)throw Invalid();
                }
                var en=new Dictionary<string,AccountStoryCombatContent>(StringComparer.Ordinal);
                var ko=new Dictionary<string,AccountStoryCombatContent>(StringComparer.Ordinal);
                var rewardRows=new Dictionary<string,DevelopmentStoryDisplayRow>(StringComparer.Ordinal);
                var loader=loadSprite??(path=>Resources.Load<Sprite>(path));
                foreach(var row in catalog.entries)
                {
                    if(row==null||!Enum.TryParse<StoryCombatContentKind>(row.kind,false,out var kind)||
                        !Enum.IsDefined(typeof(StoryCombatContentKind),kind)||kind.ToString()!=row.kind||
                        string.IsNullOrWhiteSpace(row.id)||string.IsNullOrWhiteSpace(row.en)||string.IsNullOrWhiteSpace(row.ko))throw Invalid();
                    Sprite sprite=null;
                    if(kind!=StoryCombatContentKind.Stage)
                    {
                        if(string.IsNullOrWhiteSpace(row.spriteResource)||row.spriteResource.Contains("..")||
                            row.spriteResource.Contains(":")||row.spriteResource.StartsWith("/")||row.spriteResource.Contains("\\"))throw Invalid();
                        sprite=loader(row.spriteResource);if(sprite==null)throw Invalid();
                    }
                    else if(row.id!=catalog.contentId)throw Invalid();
                    string key=row.kind+"/"+row.id;
                    if(en.ContainsKey(key))throw Invalid();
                    en.Add(key,new AccountStoryCombatContent(kind==StoryCombatContentKind.Stage?"PROVISIONAL · "+row.en:row.en,sprite));
                    ko.Add(key,new AccountStoryCombatContent(kind==StoryCombatContentKind.Stage?"임시 콘텐츠 · "+row.ko:row.ko,sprite));
                }
                if(!en.ContainsKey("Stage/"+catalog.contentId))throw Invalid();
                foreach(var row in catalog.rewards)
                {
                    if(row==null||row.kind!="Reward"||string.IsNullOrWhiteSpace(row.id)||
                        string.IsNullOrWhiteSpace(row.en)||string.IsNullOrWhiteSpace(row.ko)||rewardRows.ContainsKey(row.id))throw Invalid();
                    rewardRows.Add(row.id,row);
                }
                if(attempt!=null)
                {
                    foreach(var hero in attempt.Journal.Input.Heroes)
                    {
                        if(!en.ContainsKey("Hero/"+hero.DefinitionId))throw Invalid();
                        foreach(var skill in hero.Skills)if(!en.ContainsKey("Skill/"+skill.Id))throw Invalid();
                    }
                    foreach(var enemy in attempt.Journal.Input.Enemies)if(!en.ContainsKey("Enemy/"+enemy.DefinitionId))throw Invalid();
                }
                if(!Live())throw Invalid();
                foreach(var p in en)english.Add(p.Key,p.Value);
                foreach(var p in ko)korean.Add(p.Key,p.Value);
                foreach(var p in rewardRows)rewards.Add(p.Key,p.Value);
                provider=realProvider;session=login;currentProvider=readCurrentProvider;currentOwner=stillCurrent;clock=now;
                bound=true;Diagnostic="";return IsAvailable;
            }
            catch(Exception)
            {
                if(ticket==generation)Revoke("AL-DEV-STORY-CONTENT-UNAVAILABLE");
                return false;
            }
            finally {if(ReferenceEquals(pending,tokenSource))pending=null;tokenSource.Dispose();}
        }
        public AccountStoryCombatContent Resolve(StoryCombatContentKind kind,string id,string locale)
        {
            if(!IsAvailable||string.IsNullOrWhiteSpace(id))return null;
            var map=locale=="ko"?korean:english;
            return map.TryGetValue(kind+"/"+id,out var result)?result:null;
        }
        public string RewardLabel(string id,string locale)
        {return IsAvailable&&id!=null&&rewards.TryGetValue(id,out var row)?(locale=="ko"?row.ko:row.en):null;}
        public void Revoke(string reason)
        {
            generation++;bound=false;pending?.Cancel();pending=null;
            english.Clear();korean.Clear();rewards.Clear();
            provider=null;session=null;currentProvider=null;currentOwner=null;clock=null;Diagnostic=reason;
        }
        void OnDisable(){Revoke("AL-DEV-STORY-CONTENT-DISABLED");}
        void OnDestroy(){Revoke("AL-DEV-STORY-CONTENT-DESTROYED");}
        static InvalidDataException Invalid()=>new InvalidDataException("Development Story presentation binding unavailable.");
    }
}
#endif

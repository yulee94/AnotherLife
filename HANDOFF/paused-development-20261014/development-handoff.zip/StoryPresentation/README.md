# r002 sealed source-only successor

# Owned Story presentation adapter candidate
Six new canonical candidate paths: three C# files and their metadata, placed in existing StoryPresentation/runtime-test assemblies. No asmdef, Boot, provider, flow, save, input or existing test changes.

DevelopmentStoryCatalogPresentation implements IAccountStoryApprovedContentSource under UNITY_EDITOR || DEVELOPMENT_BUILD. Explicit BindAsync accepts catalogue JSON, an admitted content/catalog/definition revision triple and the existing provider/session/kingdom plus current-provider/current-owner callbacks. It reads ReadStoryAsync, then ReadStoryAttemptAsync only when resuming an active attempt. It never calls EnterStoryAsync, CommitStoryActionAsync, recovery entry, creates a journal, converts TestOnly, simulates combat or grants rewards.

The interface lacks revision arguments, so each binding exposes exactly one immutable mapping. Bind/rebind first revokes old mappings; generation checks reject late completion. Provider identity, current owner callback, expiry, component lifetime and sprite lifetime are checked on lookup. A replacement requires explicit rebind. The host must rebind on capability/content/attempt changes; this component does not invent a background provider poll. The supplied stillCurrent callback must include exact session/kingdom/provider generation, as the existing Boot seam already does.

Ready state must advertise the exact admitted revision/stage and no other unlocked stage, because the unmodified flow owner otherwise could select a stage outside this single-stage mapping. Active state must return the exact attempt pointer and matching command/snapshot content revisions, plus complete hero/enemy/skill mappings. Old snapshots are never rewritten to current tuning. Unknown content/rewards return null; missing art or duplicate/invalid catalogue entries prevent binding. Stage labels visibly say PROVISIONAL / 임시 콘텐츠.

This is presentation qualification, not server authorization. The admitted triple must come from a reviewed host allocation, never a client entry command. Real provider capability refusal remains unavailable. No default factory, serialized automatic binding, Start initializer or live-host endpoint is supplied. CATALOG_TEMPLATE.json is disabled with empty revision/ID fields because actual admitted wire examples are unavailable. Code/tests are complete within this boundary; real-route activation remains off.

## Actual scene inspection
EditorBuildSettings.asset enables Assets/AL/Scenes/Boot.unity. Its BootController references:
- _storyRouteHost fileID989114492, AccountStoryFlowHost GUID ee70ce4416314c98aac647d972eb354f.
- _storyComposition fileID183199685, AccountStoryComposition GUID b472126448334017819b5b9947814515.
- composition._flowHost fileID989114492; _approvedContent fileID0.

No serialized binding candidate is emitted: the missing provider-backed admitted mapping and binding lifecycle make an active scene patch unjustified. Existing BootController and composition remain read-only. This records the real asset/seam rather than inventing a prefab or adding another EventSystem. The next reviewed host binder must complete BindAsync before TryConfigure and retire/rebind on owner/capability changes. No AL.Runtime reference to StoryPresentation is introduced.

## Tests
Focused tests in the existing Story presentation test assembly reuse StoryFlowFixture's valid typed DTO/provider fixture, without changing it. Coverage: unbound default; provider capability -> labels only; unknown ID/reward; revision/disabled/missing-art failures; provider/owner/disable retirement; immutable active attempt and complete mappings; late readback rejection; actual provider service_unavailable/content_missing refusal; old-catalog snapshot rejection; existing AccountStoryComposition refusal and successful qualified configuration.

Tests are authored, not executed. They use synthetic typed fixtures only to exercise the presentation seam, not as a real account route. No full gameplay or physical input claim. Compilation, independent source/API review and separately admitted focused/affected tests remain required. Existing11/40 validation packets are unchanged.

## Data and runtime boundaries
CATALOG_SCHEMA.json documents this new presentation-only JSON format; it is not a backend gameplay schema or a balance table. The existing StrictJsonDocument parser now checks exact structural keys/types, required presence and duplicates before JsonUtility projection; a full external JSON-schema validator was not executed. Sprite resources are existing reviewed assets resolved by Resources.Load; tests inject an explicit fixture loader. No portraits/models are generated or silently substituted.

Source-only checks and dependency hashes are recorded in VALIDATION.json and SOURCE_RECEIPT.json. No canonical or native changes occurred.

## Strict JSON correction
The new AL.Runtime helper reuses AL.GameDataCatalog strict parsing through existing InternalsVisibleTo and assembly references, matching AccountBuildingPresentationCatalog. No package, asmdef or freshness-guard change. UTF-8 is bounded to131072bytes. Duplicate JSON members (including escaped spelling), unknown fields and wrong/null types fail before any provider read. All five row fields are required. Stage and Reward spriteResource may be empty but must be present and string-valued; nonempty Stage/Reward strings remain ignored because those rows do not render icons. Hero/Enemy/Skill require nonempty resource strings and existing semantic art validation. Version uses the exact integer token1, consistent with the existing strict catalogue pattern.

Added15 malformed-structure binding cases and one valid Stage/Reward empty-sprite case. These30total authored cases have NOT been executed. r001 remains sealed. Final r001 review DC24AEFAEDB14E5A5B4991C46BE5E1A302256C7077CA2FEAC29350840ECC727A confirmed the structural issue was the only finding. This successor is sealed for independent r002 review; no runtime acceptance is claimed.

# E mechanics proposed acceptance matrix

All cases are proposed, not authored or executed. Preserve the accepted predecessor roster and v1 fixtures/goldens at each slice. Synthetic amounts are not production tuning.

| Group | Required cases |
|---|---|
| E1 contract | Default-off payload, invalid kind/shape/cap/duration; exact three-quarry maximum, duplicates/hidden/ally/dead selection; no sixth actor |
| E1 intrinsic | One Fangbound followup, intended target killed by root -> no retarget, source offense/cap/kind, Cover shared once/nonrecursive |
| E1 grant | Only other living allies, separate charges, immutable quarry set, finite affected-owner expiry, exact refresh identity, source death cancellation |
| E1 eligibility | Root positive configured Damage only; shielded/weakened zero consumes; zero/all-false/support/poison/cashout/assist do not; positive secondary scale required |
| E1 selection | Primary quarry preference then deterministic selected-secondary; no target substitution after root kill; oldest eligible source only |
| E1 snapshot | New grant cannot trigger; same-root refresh retains new sequence while old captured benefit applies; independent ally allowances |
| E1 recursion | Intrinsic plus at most one Hunt, stable order; no assist-to-assist/counter/readiness/lifesteal/LastShadow loop; terminal assist kill ordinary outcome |
| E1 atomicity | Late assist/barrier/budget/poison overflow restores root HP/cost/readiness/grants/trace; duplicate and conflict remain stable |
| E2 selector | Dead same-side only; living/self/enemy invalid; query/replay parity; ordinary Heal/Ally cannot revive; terminal cannot reopen |
| E2 restoration | MaxHP-based catalog fraction, zero-result refusal, max cap, healing-reduction distinction, target readiness zero, no old statuses restored |
| E2 history | Once per target across multiple sources and subsequent deaths; copy/hash/replay/duplicate persistence; no reset by cleanup |
| E2 queue | Revive before old slot, after old slot and after skipped slot; defer all until next round, schedule once by current speed, no catch-up ticks |
| E2 atomicity | Event/arithmetic/late-phase refusal restores HP/used/defer flags/queue/readiness; last living caster cases and outcome order |
| E3 ownership | Only caster-owned selected-target stacks; other sources remain; newly created effects excluded; exact sequence capture |
| E3 budget | Amount*remainingTurns checked, not completed/extra ticks; mixed expiry and first-eligible boundaries; zero/empty cases |
| E3 damage | Cashout-before-strike, one aggregate Magic PoisonCashout packet, shared defense/vulnerability/barriers, no Cover/penetration/area/marks amplification |
| E3 provenance | Cashout excluded from ordinary lifesteal/readiness/LastShadow and assist eligibility; ordinary surviving-target strike retains Root behavior |
| E3 bounds | Catalog maximum admission, actual over-bound refusal before removal, no silent clipping/discarding, extreme arithmetic refusal |
| E3 removal | No consumed stack's later scheduled tick; cashout kill skips strike without retarget, surviving stack sources tick normally |
| E3 atomicity | Partial removal/barrier/later strike failure restores all stacks and HP, exact replay/hash through terminal and duplicate recovery |
| Common | Every new immutable/mutable field roundtrip and copied read-only view; old/unknown domains reject; exact footprint/body preservation; no hero-name branches |
| Later bridge | Historical v1/current-family dispatch, full snapshot/journal persistence, legal dead-ally/multitarget mode projection, nonce uncertainty/restart, finite policy/capacity and terminal reward atomicity |

Before each implementation, turn the approved groups into a concrete roster and record exact baseline/hash. Source-only review cannot substitute for actual SDK/test execution or playable host/content qualification.
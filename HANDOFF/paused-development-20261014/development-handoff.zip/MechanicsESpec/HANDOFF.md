# E mechanics plan-only handoff

SPEC.md proposes three bounded sequential implementation allocations: E1 companion/Fangbound/Hunt (10 engine/8 test sources), E2 once-per-target revival with next-round eligibility (11/9), E3 owned-poison cashout (12/10). No implementation is authorized or begun. Exact prior rosters must carry forward slice by slice, starting from source-accepted D3's252 UNRUN cases.

COVERAGE.md inventories all40 named Phase1 skills across the recovered eight Celestial kits and distinguishes available engine substrate from missing mechanics and real catalog/profile admission. TEST_MATRIX.md records provenance, trigger, scheduling, budget and rollback cases. No hero-name hardcodes or production tuning values are proposed.

Root review choices include intrinsic-plus-oldest-Hunt combination, captured-target no-retarget/consumption policy, source-death invalidation, per-target revive-use and deferred queue behavior, distinct revive restoration, and cashout-first aggregate Magic/raw-budget admission semantics. Cashout/Assist origins cannot feed Root-only lifesteal/readiness/kill evidence. Existing action-start ordinary-strike charge policy is explicitly preserved when cashout kills before that strike.

Normal Story/Tower engine-family journal dispatch, complete immutable snapshots, host/UI legal actions, finite/exhaustion policy, enemy policy and capacity-to-finish remain mandatory follow-on bridge work after actual runtime proof. This plan does not establish standalone engine completion of any live hero/catalog, all120 heroes, Story/Tower content or the full game.

D3 packet remains untouched; current canonical source pause continues. No SDK/compiler/native process or canonical/index/HEAD write occurred. Input hashes are recorded; source review acceptance does not imply the252 tests ran.
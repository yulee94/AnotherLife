param([Parameter(Mandatory=$true)][string]$OutFile,[Parameter(Mandatory=$true)][string]$Selection)
. (Join-Path $PSScriptRoot 'bootstrap.ps1')
InitializeTrial $Selection
AssertTrialAdmission
$ErrorActionPreference='Stop'
$prefix=($out+'\outer-r001\')
if(-not[IO.Path]::GetFullPath($OutFile).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)-or(Test-Path -LiteralPath $OutFile)){throw 'Git context destination rejected'}
$repo=$root
$head=(& $binding.gitExecutable --no-optional-locks -C $repo rev-parse HEAD);if($LASTEXITCODE){throw 'Git HEAD unavailable'}
$indexPath=(& $binding.gitExecutable --no-optional-locks -C $repo rev-parse --path-format=absolute --git-path index);if($LASTEXITCODE){throw 'Git index path unavailable'};$index=(Get-FileHash -LiteralPath $indexPath).Hash
$status=@(& $binding.gitExecutable --no-optional-locks -C $repo status --porcelain=v1 --untracked-files=no);if($LASTEXITCODE){throw 'Git status unavailable'}
$record=@{utc=[DateTime]::UtcNow.ToString('o');head=$head;indexPath=$indexPath;indexSHA256=$index;trackedStatus=$status;scope='Fresh job-time tracked Git context; not a historical substitute'}
$record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $OutFile

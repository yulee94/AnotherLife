using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;
namespace AL.RigReadback.Identity {
    public static class Native {
        [DllImport("kernel32.dll", EntryPoint="QueryFullProcessImageNameW", ExactSpelling=true,
            CharSet=CharSet.Unicode, SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool QueryFullProcessImageNameW(
            SafeProcessHandle process, uint flags, StringBuilder image, ref uint characters);
        [DllImport("kernel32.dll", EntryPoint="GetExitCodeProcess", ExactSpelling=true, SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetExitCodeProcess(SafeProcessHandle process, out uint exitCode);
    }
}
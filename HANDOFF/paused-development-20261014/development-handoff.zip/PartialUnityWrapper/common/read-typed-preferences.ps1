param([Parameter(Mandatory=$true)][string]$OutFile,[Parameter(Mandatory=$true)][string]$Selection)
. (Join-Path $PSScriptRoot 'bootstrap.ps1')
InitializeTrial $Selection
AssertTrialAdmission
$ErrorActionPreference='Stop'
if(-not [IO.Path]::GetFullPath($OutFile).StartsWith(($out+'\outer-r001\'),[StringComparison]::OrdinalIgnoreCase)){throw 'PREF_OUTPUT_BOUNDARY'}
if(Test-Path -LiteralPath $OutFile){throw 'PREF_SNAPSHOT_EXISTS'}
$rows=@();foreach($path in @('Software\Unity\UnityEditor\DefaultCompany\AnotherLifeUnity','Software\DefaultCompany\AnotherLifeUnity')){
 $reg=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($path,$false)
 try{foreach($logical in @('AL.Kingdom.ChatBodyExpanded.v1','AL.Kingdom.ChatMinimized.v1','AL.Kingdom.ReducedCityMotion.v1')){
  $names=@(if($reg){$reg.GetValueNames()|Where-Object {$_-eq$logical-or$_.StartsWith($logical+'_h',[StringComparison]::Ordinal)}});if($names.Count-gt1){throw 'AMBIGUOUS_PREF'}
  $kind=if($names.Count){$reg.GetValueKind($names[0]).ToString()}else{$null};if($names.Count-and$kind-ne'DWord'){throw 'UNSUPPORTED_PREF_TYPE'}
  $rows+=[pscustomobject]@{registryPath=$path;logicalName=$logical;present=($names.Count-eq1);physicalName=if($names.Count){$names[0]}else{$null};registryKind=$kind;value=if($names.Count){$reg.GetValue($names[0],$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}else{$null}}
 }}finally{if($reg){$reg.Dispose()}}
}
$v=@{utc=[DateTimeOffset]::UtcNow.ToString('o');hive='HKEY_CURRENT_USER';readOnly=$true;rows=$rows};$json=($v|ConvertTo-Json -Depth 6)+"`n";$bytes=[Text.UTF8Encoding]::new($false).GetBytes($json)
$s=[IO.FileStream]::new($OutFile,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read,4096,[IO.FileOptions]::WriteThrough);try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
if([IO.File]::ReadAllText($OutFile)-ne$json){throw 'PREF_DURABLE_READBACK'}
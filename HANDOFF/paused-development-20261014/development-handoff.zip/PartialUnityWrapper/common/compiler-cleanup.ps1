# One scope-reviewed cooperative caller. No startup, compilation, kill, reattach or retries.
function AssertCompilerCleanupAdmission($lease,$config) {
 if($lease.compilerCleanupAuthorized-ne$true-or$lease.compilerCleanupIndirectAncestryAcknowledged-ne$true-or$lease.compilerCleanupConfigSHA256-ne(Get-FileHash "$ad\COMPILER_CLEANUP_CONFIG.json").Hash){throw 'Exact compiler cleanup admission absent'}
 if($config.maxInvocations-ne1-or$config.callerBudgetMilliseconds-ne60000-or[string]::IsNullOrWhiteSpace($config.pipe)-or$config.pipe-eq'UNBOUND'){throw 'Cleanup scope drift'}
}
function NewCleanupRead($stream) {
 $state=@{stream=$stream;buffer=[byte[]]::new(4096);pending=$null;bytes=[IO.MemoryStream]::new();eof=$false;limit=$false}
 $state.pending=$stream.ReadAsync($state.buffer,0,$state.buffer.Length)
 return $state
}
function PollCleanupRead($state,[bool]$scheduleNext) {
 # Never wait on a pending read; both pipes always have independent pending tasks.
 if($null-eq$state.pending-or-not$state.pending.IsCompleted){return}
 $count=$state.pending.GetAwaiter().GetResult();$state.pending=$null
 if($count-eq0){$state.eof=$true;return}
 $room=65536-[int]$state.bytes.Length;$keep=[Math]::Min($room,$count)
 if($keep-gt0){$state.bytes.Write($state.buffer,0,$keep)}
 if($count-ge$room){$state.limit=$true;throw 'CLEANUP_OUTPUT_LIMIT'}
 if($scheduleNext){$state.pending=$state.stream.ReadAsync($state.buffer,0,$state.buffer.Length)}
}
# Diagnostics only: retain the full census before either unchanged selector call.
function ObserveCleanupSelection($stage,$timing,$config,[datetime]$unityStart,[datetime]$unityExit,[bool]$acknowledged) {
 $name=switch -Exact ($stage) {
  'INITIAL' {'COMPILER_SELECTION_INITIAL.json'}
  'PRECALL' {'COMPILER_SELECTION_PRECALL.json'}
  default {throw 'Invalid cleanup observation stage'}
 }
 $path=Join-Path $out $name;Boundary $path
 if(Test-Path -LiteralPath $path){throw "Cleanup selection observation already exists: $stage"}
 $started=[datetime]::UtcNow
 $rows=@();$censusError=$null
 try{$rows=@(Census)}catch{$censusError=$_.Exception.Message}
 $completed=[datetime]::UtcNow
 $observation=@{stage=$stage;startedUtc=$started.ToString('o');completedUtc=$completed.ToString('o');rows=$rows;censusError=$censusError;unityStart=$unityStart;unityExit=$unityExit;initialCensusEmpty=$timing.initialCensusEmpty;finalPrejobCensusEmpty=$timing.finalCensusEmpty;indirectAncestryAcknowledged=$acknowledged;configSHA256=(Get-FileHash "$ad\COMPILER_CLEANUP_CONFIG.json").Hash;attempts=0;invocations=0;meaning='Raw selection evidence, not ownership proof or caller authorization'}
 try{Save $path $observation}catch{throw "Cleanup selection evidence save failed at ${stage}; censusError=$censusError; saveError=$($_.Exception.Message)"}
 try{
  if($null-ne$censusError){throw "Cleanup selection census failed: $censusError"}
  $server=SelectCleanupServer $rows $config $unityStart $unityExit $acknowledged
 }catch{
  $first=$_.Exception.Message
  $failurePath=Join-Path $out 'COMPILER_SELECTION_REJECTION.json'
  try{
   Boundary $failurePath
   if(Test-Path -LiteralPath $failurePath){throw 'Existing selection rejection must be preserved'}
   Save $failurePath @{stage=$stage;failure=$first;observationPath=$path;utc=[datetime]::UtcNow.ToString('o');attempts=0;invocations=0;accepted=$false}
  }catch{throw "Cleanup selection rejected at ${stage}: $first; rejection evidence save failed: $($_.Exception.Message)"}
  throw "Cleanup selection rejected at ${stage}: $first"
 }
 return @{rows=$rows;server=$server}
}
function InvokeScopedCompilerCleanup($timing,[datetime]$unityStart,[datetime]$unityExit,[bool]$unityIdentityVerified) {
 if(-not$unityIdentityVerified-or$timing.initialCensusEmpty-ne$true-or$timing.finalCensusEmpty-ne$true){throw 'Cleanup requires original Unity identity and both empty prejob censuses'}
 $config=Read "$ad\COMPILER_CLEANUP_CONFIG.json";$lease=Read $binding.leasePath
 AssertCompileAdmission $lease;AssertCompilerCleanupAdmission $lease $config
 $selection=ObserveCleanupSelection 'INITIAL' $timing $config $unityStart $unityExit $lease.compilerCleanupIndirectAncestryAcknowledged;$observed=@($selection.rows);$server=$selection.server
 if($null-eq$server){return @{accepted=$true;status='NO_SERVER_NO_CALLER';invocations=0;census=$observed}}
 $dir=$config.output;Boundary $dir;if(Test-Path -LiteralPath $dir){throw 'Existing cleanup output; no retry'}
 foreach($pin in @(@{path=$config.executable;hash=$config.executableSHA256},@{path=$config.dll;hash=$config.dllSHA256})){
  BoundaryExecutable $pin.path;if((Get-FileHash -LiteralPath $pin.path).Hash-ne$pin.hash){throw 'Cleanup binary drift'}
 }
 AssertRuntimePins
 if((Get-FileHash "$ad\INTEROP_ARTIFACT.json").Hash-ne$script:InteropAdmissionHash-or(Get-FileHash $script:LoadedInteropPath).Hash-ne$script:LoadedInteropHash){throw 'Cleanup loaded helper drift'}
 foreach($path in @($dir)+@($config.directories)){Boundary $path;[IO.Directory]::CreateDirectory($path)|Out-Null;Boundary $path}
 [IO.File]::WriteAllText("$dir\access.probe",'F cleanup');if([IO.File]::ReadAllText("$dir\access.probe")-cne'F cleanup'){throw 'Cleanup F access'};Move-Item -LiteralPath "$dir\access.probe" -Destination "$dir\access.verified"
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$config.executable;$info.Arguments=$config.arguments;$info.WorkingDirectory=$dir
 $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
 $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 foreach($entry in $config.environment.PSObject.Properties){$info.Environment[$entry.Name]=[string]$entry.Value}
 $savedTemp=$env:TEMP;$savedTmp=$env:TMP
 try{$env:TEMP=$config.environment.TEMP;$env:TMP=$config.environment.TMP;if([IO.Path]::GetTempPath()-cne($config.environment.TEMP+'\')){throw 'Cleanup parent managed temp mismatch'}}finally{$env:TEMP=$savedTemp;$env:TMP=$savedTmp}
 # Slow hash/path work is complete. Recheck the precise admission, resources and sole-server observation.
 $lease=Read $binding.leasePath;AssertCompileAdmission $lease;AssertCompilerCleanupAdmission $lease $config
 $r=Resources;if($r.ram-lt8-or$r.commitHeadroom-lt15-or$r.commitPercent-ge80-or$r.C-lt40-or$r.F-lt20){throw 'Cleanup fresh resource gate'}
 $selection=ObserveCleanupSelection 'PRECALL' $timing $config $unityStart $unityExit $lease.compilerCleanupIndirectAncestryAcknowledged;$nowRows=@($selection.rows);$same=$selection.server
 AssertSameCleanupServer $server $same
 if($null-eq$same){return @{accepted=$true;status='SERVER_DISAPPEARED_NO_CALLER';invocations=0;census=$nowRows}}
 if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'Cleanup STOP before caller'}
 Save "$dir\ELIGIBILITY.json" @{server=$same;unityStart=$unityStart;unityExit=$unityExit;prejobEmpty=$true;resource=$r;rootAcknowledgedIndirectAncestry=$true;ownership='Timing/exclusive-window/exact-pipe evidence only; parent chain and historical exclusive pipe ownership NOT proven';configuredEnvironment=$config.environment;runtimeRouting='Configured caller environment and managed parent temp, not exhaustive OS cache confinement'}
 $caller=$null;$callerHandle=$null;$clock=$null;$failure=$null;$extra=@();$signaled=$false;$code=$null;$identity=$false;$stdout=$null;$stderr=$null;$finalCensus=@();$censusOk=$false;$invocations=0;$observedExitMs=$null
 try {
  $clock=[Diagnostics.Stopwatch]::StartNew();$invocations=1
  $caller=[Diagnostics.Process]::Start($info)
  if($null-eq$caller){throw 'Cleanup Start returned no original Process'}
  $callerHandle=$caller.SafeHandle;AssertRetainedHandle $caller $callerHandle;[void]$script:OwnedIds.Add([int]$caller.Id)
  $stdout=NewCleanupRead $caller.StandardOutput.BaseStream;$stderr=NewCleanupRead $caller.StandardError.BaseStream
  if($clock.Elapsed.TotalMilliseconds-ge60000){throw 'CLEANUP_CALLER_DEADLINE'}
  $expected=@{imagePath=$config.executable;imageHash=$config.executableSHA256;arguments=$config.arguments;commandLine=$config.commandLine}
  # Child scope redirects identity receipts only, never overwrites original Unity identity files.
  $observation=& {param($expected,$dir,$caller,$callerHandle) $out=$dir;ObserveOriginalIdentity $caller $callerHandle $caller.Id $caller.StartTime.ToUniversalTime() $expected} $expected $dir $caller $callerHandle
  $identity=$true
  while(-not$signaled){
   if($clock.Elapsed.TotalMilliseconds-ge60000){throw 'CLEANUP_CALLER_DEADLINE'}
   PollCleanupRead $stdout $true;PollCleanupRead $stderr $true
   if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'Cleanup STOP while caller active'}
   $sample=Resources;if($sample.ram-lt8-or$sample.commitHeadroom-lt8-or$sample.commitPercent-ge80-or$sample.C-lt40-or$sample.F-lt10){throw 'Cleanup runtime resource floor'}
   $wait=GetBoundedWaitMilliseconds $clock.Elapsed.TotalMilliseconds 60000
   if($wait-eq0){throw 'CLEANUP_CALLER_DEADLINE'}
   $signaled=WaitOriginal $caller $callerHandle $wait
   if($signaled){$observedExitMs=$clock.Elapsed.TotalMilliseconds;$code=ReadOriginalExit $caller $callerHandle $true}
   if($clock.Elapsed.TotalMilliseconds-ge60000){throw 'CLEANUP_CALLER_DEADLINE'}
  }
  AssertCleanupCallerResult $signaled $code $observedExitMs
 }catch{$failure=$_.Exception.Message}
 finally {
  if($clock){$clock.Stop()}
  # No additional waits, EOF waits, stream disposal, retry or force termination here.
  foreach($pair in @(@{name='stdout';state=$stdout},@{name='stderr';state=$stderr})){
   if($null-ne$pair.state){
    try{PollCleanupRead $pair.state $false}catch{if($null-eq$failure){$failure=$_.Exception.Message}else{$extra+=$_.Exception.Message}}
    try{[IO.File]::WriteAllBytes((Join-Path $dir ($pair.name+'.bin')),$pair.state.bytes.ToArray())}catch{if($null-eq$failure){$failure=$_.Exception.Message}else{$extra+=$_.Exception.Message}}
   }
  }
  try{$finalCensus=@(Census);$censusOk=$true}catch{if($null-eq$failure){$failure=$_.Exception.Message}else{$extra+=$_.Exception.Message}}
  if($finalCensus.Count-and$null-eq$failure){$failure='CLEANUP_PENDING: caller/server/native remains'}
  $streamRows=@();foreach($pair in @(@{name='stdout';state=$stdout},@{name='stderr';state=$stderr})){if($null-ne$pair.state){$streamRows+=@{name=$pair.name;bytes=$pair.state.bytes.Length;eof=$pair.state.eof;limit=$pair.state.limit;pending=($null-ne$pair.state.pending);complete=($pair.state.eof-and-not$pair.state.limit)}}}
  $result=@{accepted=($null-eq$failure-and$signaled-and$code-eq0-and$identity-and$censusOk-and$finalCensus.Count-eq0);failure=$failure;secondaryErrors=$extra;invocations=$invocations;nativeExited=$signaled;nativeExitCode=$code;identityVerified=$identity;exitObservedMs=$observedExitMs;elapsedMs=if($clock){$clock.Elapsed.TotalMilliseconds}else{$null};streams=$streamRows;remaining=$finalCensus;censusVerified=$censusOk;slotReleased=$false;forcedTermination=$false;originalCompilationOutcomeChanged=$false;deadlineLimitation='Bounded managed waits; OS Start/identity/IO calls not externally preemptible';scope='One exact-pipe cooperative cleanup only'}
  try{Save "$dir\RESULT.json" $result}finally{[GC]::KeepAlive($callerHandle);[GC]::KeepAlive($caller);[GC]::KeepAlive($stdout);[GC]::KeepAlive($stderr)}
 }
 return $result
}

# Pure decisions only: no process, filesystem, interop, compilation or UI calls.
function AssertIdentityObservation($o,$expected) {
 if($o.handleValid-ne$true){throw 'IDENTITY_HANDLE_UNAVAILABLE'}
 if($o.imageQuerySucceeded-ne$true-or$o.imageCharacters-le0-or$o.imageCharacters-ge32768){throw 'IDENTITY_IMAGE_UNAVAILABLE'}
 if([string]::IsNullOrEmpty($o.observedImagePath)-or$o.imageCharacters-ne$o.observedImagePath.Length){throw 'IDENTITY_IMAGE_UNAVAILABLE'}
 if($o.observedImagePath-cne$expected.imagePath-or$o.observedImageHash-ne$expected.imageHash){throw 'IDENTITY_IMAGE_MISMATCH'}
 if($null-eq$o.pid-or$o.pid-le0-or$null-eq$o.cimPid-or$o.pid-ne$o.cimPid){throw 'IDENTITY_PID_MISMATCH'}
 if($null-eq$o.startUtcTicks-or$null-eq$o.cimCreationUtcTicks){throw 'IDENTITY_TIME_UNAVAILABLE'}
 $a=[long]$o.startUtcTicks;$b=[long]$o.cimCreationUtcTicks
 if(($a-($a%10))-ne($b-($b%10))){throw 'IDENTITY_CREATION_MISMATCH'}
 if([string]::IsNullOrWhiteSpace($o.cimCommandLine)-or$o.cimCommandLine-cne$expected.commandLine){throw 'IDENTITY_COMMAND_MISMATCH'}
 if(-not[string]::IsNullOrWhiteSpace($o.cimExecutablePath)-and$o.cimExecutablePath-cne$expected.imagePath){throw 'IDENTITY_CIM_IMAGE_CONFLICT'}
}
function GetBoundedWaitMilliseconds([double]$elapsedMs,[int]$budgetMs) {
 if([double]::IsNaN($elapsedMs)-or[double]::IsInfinity($elapsedMs)-or$elapsedMs-lt0-or$budgetMs-le0){throw 'WAIT_CLOCK_INVALID'}
 $remaining=[Math]::Floor($budgetMs-$elapsedMs)
 if($remaining-le0){return 0}
 return [int][Math]::Min(2000,$remaining)
}
function AssertNativeSuccess($failure,[bool]$signaled,$exitCode,[double]$elapsedSeconds) {
 if(-not[string]::IsNullOrEmpty($failure)){throw 'PRIOR_FAILURE_IMMUTABLE'}
 if(-not$signaled){throw 'EXIT_NOT_SIGNALED'}
 if($null-eq$exitCode-or[uint32]$exitCode-ne0){throw 'NATIVE_EXIT_FAILED'}
 if([double]::IsNaN($elapsedSeconds)-or[double]::IsInfinity($elapsedSeconds)-or$elapsedSeconds-lt0-or$elapsedSeconds-ge300){throw 'NATIVE_DEADLINE_FAILED'}
}
function AssertLoadedModulePins($rows,$expected) {
 foreach($pin in $expected){$matches=@($rows|Where-Object {$_.path-ceq$pin.path});if($matches.Count-ne1-or$matches[0].sha256-ne$pin.sha256){throw 'REQUIRED_LOADED_MODULE_MISMATCH'}}
}
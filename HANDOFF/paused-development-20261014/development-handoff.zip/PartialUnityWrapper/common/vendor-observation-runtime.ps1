# Called only by the admitted runner. Read-only census; no child handles or controls.
function ObserveVendorShutdown($clock,$timing,[datetime]$unityStart,[datetime]$unityExit) {
 if($null-eq$script:VendorLineage-or$timing.initialCensusEmpty-ne$true-or$timing.finalCensusEmpty-ne$true){throw 'VENDOR_PRECONDITIONS'}
 $config=Read "$ad\VENDOR_OBSERVATION_CONFIG.json";$lease=Read $binding.leasePath
 AssertJobAdmission $lease
 $steps=[Collections.Generic.List[object]]::new();$failure=$null;$decision=$null
 try {
  while($true){
   AssertVendorClock $clock.Elapsed.TotalMilliseconds
   if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'VENDOR_STOP'}
   $rows=@(Census)
   $decision=GetVendorDecision $script:VendorLineage $rows $config $unityStart $unityExit $clock.Elapsed.TotalMilliseconds $lease.compilerCleanupIndirectAncestryAcknowledged
   [void]$steps.Add(@{elapsedMs=$clock.Elapsed.TotalMilliseconds;decision=$decision;rows=$rows})
   Save "$out\VENDOR_SHUTDOWN_OBSERVATION.json" @{steps=@($steps.ToArray());failure=$null;accepted=$false;nativeCalls=0;sharedBudgetMs=90000}
   AssertVendorClock $clock.Elapsed.TotalMilliseconds
   $r=Resources
   AssertVendorClock $clock.Elapsed.TotalMilliseconds
   if($r.ram-lt8-or$r.commitHeadroom-lt8-or$r.commitPercent-ge80-or$r.C-lt40-or$r.F-lt10){throw 'VENDOR_RESOURCE_FLOOR'}
   if($decision-ne'WAIT'){break}
   $ms=GetBoundedWaitMilliseconds $clock.Elapsed.TotalMilliseconds 90000
   if($ms-le0){throw 'VENDOR_SHARED_DEADLINE'}
   Start-Sleep -Milliseconds $ms
  }
 }catch{$failure=$_.Exception.Message;throw}
 finally {
  Save "$out\VENDOR_SHUTDOWN_OBSERVATION.json" @{steps=@($steps.ToArray());failure=$failure;accepted=$false;decision=$decision;elapsedMs=$clock.Elapsed.TotalMilliseconds;sharedBudgetMs=90000;nativeCalls=0;scope='Observation only, never release acceptance; post-write deadline check, strict caller and final empty census remain mandatory'}
 }
 AssertVendorClock $clock.Elapsed.TotalMilliseconds
}

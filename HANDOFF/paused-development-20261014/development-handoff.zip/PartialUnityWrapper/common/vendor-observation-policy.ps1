# UPM role is observation only. Hash enforcement belongs to mandatory exact-input
# pre/post checks; metadata cannot prove historical executable bytes.
function TestExactUpmRow($row,$anchor,$config) {
 $u=$config.upm
 if($null-eq$u-or$u.role-cne'EXACT_UPM_NATURAL_EXIT_WAIT_ONLY'-or
    $u.executable-cne'F:\Unity\6000.6.5f1\Editor\Data\Resources\PackageManager\Server\UnityPackageManager.exe'-or
    $u.sha256-cne'8F014E53524E8AB83C8BB8973324BA9529F6F35CDD09AABB87467DCFE33D422C'-or
    $u.projectLog-cne'F:\AnotherLife\.codex-worktrees\unity-search-qualification\unity/Logs/upm.log'-or$u.ipcPrefix-cne'Unity-Upm-'-or
    $u.minimumCoobservedFrames-ne1-or$u.requiresExactInputPin-ne$true){return $false}
 $command='"'+$u.executable+'" "server" "-s" "'+[string]$anchor.pid+'" "--ipc-path" "Unity-Upm-'+[string]$anchor.pid+'" "-l" "2" "--log-file" "'+$u.projectLog+'"'
 return ($row.Name-ceq'UnityPackageManager.exe'-and$row.ExecutablePath-ceq$u.executable-and
         $row.ParentProcessId-eq$anchor.pid-and$row.CommandLine-ceq$command)
}
# Pure metadata decisions. No IO, process handles, launches or sleeps.
function GetVendorCensusScope($all,$discoveredIds) {
 # Discovery is conservative only. These IDs are never ancestry proof.
 foreach($r in $all){if($r.Name-match'^(Unity|UnityPackageManager|UnityShaderCompiler|UnityCrashHandler.*|blender|dotnet|MSBuild|csc|VBCSCompiler|python|pythonw|python3|mono|mcs|bee_backend|cl|link)(\.exe)?$'){[void]$discoveredIds.Add([int]$r.ProcessId)}}
 do{$added=$false;foreach($r in $all){if($discoveredIds.Contains([int]$r.ParentProcessId)-and$discoveredIds.Add([int]$r.ProcessId)){$added=$true}}}while($added)
 @($all|Where-Object {$discoveredIds.Contains([int]$_.ProcessId)}|Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
}
function NewVendorLineage($anchor) {
 if($anchor.handleValid-ne$true-or$anchor.imageQuerySucceeded-ne$true-or$anchor.pid-le0-or$anchor.cimCreationUtcTicks-le0-or[string]::IsNullOrWhiteSpace($anchor.cimCommandLine)){throw 'VENDOR_ANCHOR_INVALID'}
 @{anchor=$anchor;nodes=@{};instances=@{};frames=[Collections.Generic.List[object]]::new()}
}
function VendorKey($row) {
 if($row.ProcessId-le0-or$null-eq$row.CreationDate){throw 'VENDOR_INSTANCE_MISSING'}
 [string]$row.ProcessId+':'+([datetime]$row.CreationDate).ToUniversalTime().Ticks
}
function AddVendorSnapshot($state,$all,$scope,[datetime]$queryStart,[datetime]$queryEnd) {
 if($queryEnd-lt$queryStart-or$state.frames.Count-ge512-or@($all).Count-gt8192){throw 'VENDOR_SNAPSHOT_BOUND'}
 $frame=@{};foreach($r in $all){if($r.ProcessId-le0-or$null-eq$r.CreationDate){continue};$key=VendorKey $r
  if($frame.ContainsKey([string]$r.ProcessId)){throw 'VENDOR_DUPLICATE_PID'};$frame[[string]$r.ProcessId]=$key
  if(-not$state.instances.ContainsKey([string]$r.ProcessId)){$state.instances[[string]$r.ProcessId]=[Collections.Generic.HashSet[string]]::new()};[void]$state.instances[[string]$r.ProcessId].Add($key)
  if(-not$state.nodes.ContainsKey($key)){$state.nodes[$key]=@{row=$r;parents=[Collections.Generic.HashSet[string]]::new();conflict=$false}}
  else{$before=$state.nodes[$key].row
   $pathChanged=$before.ExecutablePath-cne$r.ExecutablePath
   $a=$state.anchor
   # Only the independently handle-verified original Unity instance may have
   # unavailable CIM image metadata. Never normalize another process or path.
   if($pathChanged-and$key-ceq([string]$a.pid+':'+[string]$a.cimCreationUtcTicks)-and
      $a.handleValid-eq$true-and$a.imageQuerySucceeded-eq$true-and
      -not[string]::IsNullOrWhiteSpace($a.observedImagePath)-and
      ($null-eq$before.ExecutablePath-or$before.ExecutablePath-ceq$a.observedImagePath)-and
      ($null-eq$r.ExecutablePath-or$r.ExecutablePath-ceq$a.observedImagePath)){$pathChanged=$false}
   if($before.Name-cne$r.Name-or$before.ParentProcessId-ne$r.ParentProcessId-or$pathChanged-or$before.CommandLine-cne$r.CommandLine){$state.nodes[$key].conflict=$true}
  }
 }
 foreach($r in $all){if($r.ProcessId-le0-or$null-eq$r.CreationDate){continue};$key=VendorKey $r;$parent=$frame[[string]$r.ParentProcessId];if($parent){[void]$state.nodes[$key].parents.Add($parent)}}
 [void]$state.frames.Add(@{queryStartUtc=$queryStart;queryEndUtc=$queryEnd;all=@($all);scope=@($scope)})
}
function AssertVendorClock([double]$elapsed) {
 if([double]::IsNaN($elapsed)-or[double]::IsInfinity($elapsed)-or$elapsed-lt0-or$elapsed-ge90000){throw 'VENDOR_SHARED_DEADLINE'}
}
function AssertVendorChain($state,$key,$config,[datetime]$unityStart,[datetime]$unityExit,$visiting) {
 if(-not$state.nodes.ContainsKey($key)-or-not$visiting.Add($key)){throw 'VENDOR_LINEAGE_MISSING_OR_CYCLE'}
 $node=$state.nodes[$key];$r=$node.row;$a=$state.anchor
 if($node.conflict-or$state.instances[[string]$r.ProcessId].Count-ne1){throw 'VENDOR_PID_REUSE_OR_CONFLICT'}
 $created=([datetime]$r.CreationDate).ToUniversalTime()
 if($r.ProcessId-eq$a.pid-and$created.Ticks-eq[long]$a.cimCreationUtcTicks){
  if($r.Name-cne'Unity.exe'-or$r.CommandLine-cne$a.cimCommandLine-or(-not[string]::IsNullOrWhiteSpace($r.ExecutablePath)-and$r.ExecutablePath-cne$a.observedImagePath)){throw 'VENDOR_ANCHOR_CONFLICT'}
  return
 }
 if($created-lt$unityStart-or$created-gt$unityExit-or[string]::IsNullOrWhiteSpace($r.ExecutablePath)-or[string]::IsNullOrWhiteSpace($r.CommandLine)){throw 'VENDOR_IDENTITY_OR_INTERVAL'}
 $shutdown=$r.Name-ceq'dotnet.exe'-and$r.ExecutablePath-ceq$config.executable-and$r.CommandLine-ceq$config.shutdownCommand
 $server=$r.Name-ceq'dotnet.exe'-and$r.ExecutablePath-ceq$config.executable-and$r.CommandLine-ceq$config.serverCommand
 $upm=TestExactUpmRow $r $a $config
 $console=$r.Name-ceq'conhost.exe'-and$r.ExecutablePath-ceq$config.consolePath-and$r.CommandLine-ceq$config.consoleCommand
 if(-not($shutdown-or$server-or$console-or$upm)){throw 'VENDOR_UNKNOWN_DESCENDANT'}
 if($node.parents.Count-ne1){throw 'VENDOR_PARENT_NOT_OBSERVED'}
 $parent=@($node.parents)[0];$pr=$state.nodes[$parent].row
 if(([datetime]$pr.CreationDate).ToUniversalTime()-gt$created){throw 'VENDOR_PARENT_CREATED_LATE'}
 if($upm){
  $anchorKey=[string]$a.pid+':'+[string]$a.cimCreationUtcTicks
  if($parent-cne$anchorKey){throw 'VENDOR_UPM_ORIGINAL_PARENT'}
  # parents is populated only by same-snapshot co-observation, binding both creations.
  # One overlap is required for a future job; the saved compile has 56.
 }
 if($console-and-not(($pr.Name-ceq'dotnet.exe'-and$pr.ExecutablePath-ceq$config.executable-and($pr.CommandLine-ceq$config.shutdownCommand-or$pr.CommandLine-ceq$config.serverCommand))-or(TestExactUpmRow $pr $a $config))){throw 'VENDOR_CONSOLE_PARENT'}
 AssertVendorChain $state $parent $config $unityStart $unityExit $visiting
}
function GetVendorDecision($state,$rows,$config,[datetime]$unityStart,[datetime]$unityExit,[double]$elapsed,[bool]$acknowledged) {
 AssertVendorClock $elapsed
 if($unityExit-lt$unityStart){throw 'VENDOR_UNITY_INTERVAL'}
 if(@($rows).Count-eq0){return 'EMPTY'}
 # The sole-server fallback keeps its existing acknowledged indirect-ancestry rule.
 if(@($rows).Count-eq1){$only=@($rows)[0];$key=VendorKey $only
  if($state.instances.ContainsKey([string]$only.ProcessId)-and($state.instances[[string]$only.ProcessId].Count-ne1-or$state.nodes[$key].conflict)){throw 'VENDOR_PID_REUSE_OR_CONFLICT'}
  try{$server=SelectCleanupServer $rows $config $unityStart $unityExit $acknowledged;if($null-ne$server){return 'SOLE_SERVER'}}catch{if($_.Exception.Message-notin@('CLEANUP_SERVER_IDENTITY_MISMATCH','CLEANUP_SERVER_OUTSIDE_UNITY_INTERVAL')){throw}}
 }
 foreach($r in $rows){if($r.ProcessId-eq$state.anchor.pid){throw 'VENDOR_ORIGINAL_STILL_LISTED'};AssertVendorChain $state (VendorKey $r) $config $unityStart $unityExit ([Collections.Generic.HashSet[string]]::new())}
 return 'WAIT'
}

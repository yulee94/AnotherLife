# Pure decisions; no native/IO calls. Exact pipe never derived from a PID.
function SelectCleanupServer($rows,$config,[datetime]$unityStart,[datetime]$unityExit,[bool]$acknowledged) {
 if(-not$acknowledged){throw 'CLEANUP_INDIRECT_OWNERSHIP_NOT_ACKNOWLEDGED'}
 if($unityStart.Ticks-le0-or$unityExit-lt$unityStart){throw 'CLEANUP_UNITY_INTERVAL_INVALID'}
 if(@($rows).Count-eq0){return $null}
 if(@($rows).Count-ne1){throw 'CLEANUP_NOT_SOLE_SERVER'}
 $server=@($rows)[0]
 if($server.Name-cne'dotnet.exe'-or$server.ExecutablePath-cne$config.executable-or$server.CommandLine-cne$config.serverCommand-or$server.ProcessId-le0-or$null-eq$server.CreationDate){throw 'CLEANUP_SERVER_IDENTITY_MISMATCH'}
 $created=([datetime]$server.CreationDate).ToUniversalTime()
 if($created-lt$unityStart-or$created-gt$unityExit){throw 'CLEANUP_SERVER_OUTSIDE_UNITY_INTERVAL'}
 return $server
}
function AssertSameCleanupServer($before,$after) {
 if($null-eq$after){return}
 if($before.ProcessId-ne$after.ProcessId-or([datetime]$before.CreationDate).ToUniversalTime().Ticks-ne([datetime]$after.CreationDate).ToUniversalTime().Ticks-or$before.ExecutablePath-cne$after.ExecutablePath-or$before.CommandLine-cne$after.CommandLine){throw 'CLEANUP_SERVER_CHANGED'}
}
function AssertCleanupCallerResult([bool]$signaled,$code,[double]$elapsedMs) {
 if([double]::IsNaN($elapsedMs)-or[double]::IsInfinity($elapsedMs)-or$elapsedMs-lt0-or$elapsedMs-ge60000){throw 'CLEANUP_CALLER_DEADLINE'}
 if(-not$signaled-or$null-eq$code-or[uint32]$code-ne0){throw 'CLEANUP_CALLER_EXIT_FAILED'}
}

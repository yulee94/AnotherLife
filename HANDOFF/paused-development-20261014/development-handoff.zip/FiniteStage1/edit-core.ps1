$ErrorActionPreference='Stop'
$root='F:\AnotherLife\outputs\LOCAL-BACKEND\finite-attempt-stage1-candidates-20261014-r001\source\backend'
function Edit($path,$pairs){$s=[IO.File]::ReadAllText("$root\$path");foreach($p in $pairs){if(-not $s.Contains($p[0])){throw "Missing anchor $path : $($p[0])"};$s=$s.Replace($p[0],$p[1])};[IO.File]::WriteAllText("$root\$path",$s,[Text.UTF8Encoding]::new($false))}
Edit 'StoryCombat.Core\Contracts.cs' @(
 @('public string EngineVersion{get;}','public FiniteAttemptPolicy? FinitePolicy{get;} public string EngineVersion{get;}'),
 @('IEnumerable<Hero> heroes,IEnumerable<Enemy> enemies){','IEnumerable<Hero> heroes,IEnumerable<Enemy> enemies,FiniteAttemptPolicy? finitePolicy=null){'),
 @('if(engine!=SupportedEngineVersion||','if((engine==SupportedEngineVersion?finitePolicy!=null:engine!=FiniteAttemptPolicy.Engine||finitePolicy==null)|| (finitePolicy!=null&&finitePolicy.EncounterId!=content)||'),
 @('EngineVersion=engine;ContentId=content;','FinitePolicy=finitePolicy;EngineVersion=engine;ContentId=content;'),
 @('public IReadOnlyList<int> Hp{get;}','public int AcceptedActionsUsed{get;} public int RecordedRejectionsUsed{get;} public TerminalReason TerminalReason{get;} public IReadOnlyList<int> Hp{get;}'),
 @('string inputHash,string stateHash){Hp=','string inputHash,string stateHash,int accepted=0,int rejected=0,TerminalReason reason=TerminalReason.None){AcceptedActionsUsed=accepted;RecordedRejectionsUsed=rejected;TerminalReason=reason;Hp=')
)
Edit 'StoryCombat.Core\StoryCombat.Core.csproj' @(@('<Compile Include="Contracts.cs" />','<Compile Include="Contracts.cs" /><Compile Include="FiniteAttemptPolicy.cs" />'))
Edit 'StoryCombat.Core\SnapshotCodec.cs' @(
 @('const string Format="anotherlife-combat-input-v1";','const string Format="anotherlife-combat-input-v1"; const string FiniteFormat="anotherlife-finite-attempt-input-v1";'),
 @('Text(w,Format);Text(w,input.EngineVersion);','Text(w,input.FinitePolicy==null?Format:FiniteFormat);Text(w,input.EngineVersion);'),
 @('w.Flush();if(stream.Length>MaximumBytes)', 'if(input.FinitePolicy!=null){var p=input.FinitePolicy;Text(w,p.CatalogId);Text(w,p.CatalogRevision);Text(w,p.CatalogDigest);Text(w,p.PolicyId);Text(w,p.Mode);Text(w,p.EncounterId);w.Write(p.Floor);w.Write(p.MaximumAcceptedActions);w.Write(p.MaximumRecordedRejections);Text(w,FiniteAttemptPolicy.CountRule);Text(w,FiniteAttemptPolicy.ExhaustionOutcome);Text(w,FiniteAttemptPolicy.Precedence);} w.Flush();if(stream.Length>MaximumBytes)'),
 @('if(Text(r)!=Format)throw Guard.Invalid();','string format=Text(r);if(format!=Format&&format!=FiniteFormat)throw Guard.Invalid();'),
 @('if(stream.Position!=stream.Length)throw Guard.Invalid();return new BattleInput(engine,content,version,test==1,started,order,target,heroes,enemies);', 'FiniteAttemptPolicy? policy=null;if(format==FiniteFormat){policy=new FiniteAttemptPolicy(Text(r),Text(r),Text(r),Text(r),Text(r),Text(r),r.ReadInt32(),r.ReadInt32(),r.ReadInt32());if(Text(r)!=FiniteAttemptPolicy.CountRule||Text(r)!=FiniteAttemptPolicy.ExhaustionOutcome||Text(r)!=FiniteAttemptPolicy.Precedence||engine!=FiniteAttemptPolicy.Engine)throw Guard.Invalid();}else if(engine!=BattleInput.SupportedEngineVersion)throw Guard.Invalid();if(stream.Position!=stream.Length)throw Guard.Invalid();return new BattleInput(engine,content,version,test==1,started,order,target,heroes,enemies,policy);')
)
Edit 'StoryCombat.Core\TurnReplay.cs' @(
 @('var maximum=(int[])hp.Clone();','var policy=input.FinitePolicy;int accepted=0,rejected=0;var reason=TerminalReason.None;var maximum=(int[])hp.Clone();'),
 @('else if(unique.Count>=MaximumCommands)code="CAPACITY";', 'else if(policy!=null&&outcome!=Outcome.Active)code="FINISHED"; else if(unique.Count>=MaximumCommands)code="CAPACITY";'),
 @('if(code.Length==0)' , 'if(policy!=null&&code.Length!=0&&rejected>=policy.MaximumRecordedRejections){recorded=false;code="REJECTION-STORAGE-BOUND";} if(code.Length==0)'),
 @('var receipt=new ActionReceipt(command,code,false,recorded);', 'if(recorded){if(code.Length==0){accepted++;if(policy!=null){if(outcome==Outcome.Victory)reason=TerminalReason.Victory;else if(outcome==Outcome.Defeat)reason=TerminalReason.Defeat;else if(accepted==policy.MaximumAcceptedActions){outcome=Outcome.Defeat;reason=TerminalReason.ActionBudgetExhausted;}}}else rejected++;} var receipt=new ActionReceipt(command,code,false,recorded);'),
 @('SnapshotCodec.Text(w,"anotherlife-combat-state-v1");','SnapshotCodec.Text(w,policy==null?"anotherlife-combat-state-v1":"anotherlife-finite-attempt-state-v1");'),
 @('w.Flush();stateHash=', 'if(policy!=null){w.Write(accepted);w.Write(rejected);w.Write((int)reason);} w.Flush();stateHash='),
 @('receipts,inputHash,stateHash);','receipts,inputHash,stateHash,accepted,rejected,reason);')
)
Edit 'StoryJournal.Core\Contracts.cs' @(
 @('readonly byte[] snapshot;','readonly byte[] snapshot; public int? AcceptedActionsUsed {get;} public int? RecordedRejectionsUsed {get;} public TerminalReason? TerminalReason {get;}'),
 @('IEnumerable<StoredStep> steps)','IEnumerable<StoredStep> steps,int? acceptedActionsUsed=null,int? recordedRejectionsUsed=null,TerminalReason? terminalReason=null)'),
 @('OwnerAccountId=owner;', 'AcceptedActionsUsed=acceptedActionsUsed;RecordedRejectionsUsed=recordedRejectionsUsed;TerminalReason=terminalReason;OwnerAccountId=owner;')
)
Edit 'StoryJournal.Core\StrictJournal.cs' @(
 @('string previous=Genesis(', 'if(input.FinitePolicy==null){if(stored.AcceptedActionsUsed!=null||stored.RecordedRejectionsUsed!=null||stored.TerminalReason!=null)throw Invalid();}else if(stored.AcceptedActionsUsed!=replay.AcceptedActionsUsed||stored.RecordedRejectionsUsed!=replay.RecordedRejectionsUsed||stored.TerminalReason!=replay.TerminalReason)throw Invalid(); string previous=Genesis('),
 @('stored.Steps.Append(row));','stored.Steps.Append(row),old.Input.FinitePolicy==null?(int?)null:next.AcceptedActionsUsed,old.Input.FinitePolicy==null?(int?)null:next.RecordedRejectionsUsed,old.Input.FinitePolicy==null?(TerminalReason?)null:next.TerminalReason);'),
 @('Array.Empty<StoredStep>());','Array.Empty<StoredStep>(),input.FinitePolicy==null?(int?)null:state.AcceptedActionsUsed,input.FinitePolicy==null?(int?)null:state.RecordedRejectionsUsed,input.FinitePolicy==null?(TerminalReason?)null:state.TerminalReason);')
)

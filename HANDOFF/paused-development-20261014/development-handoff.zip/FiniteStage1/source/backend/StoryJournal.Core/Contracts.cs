using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AnotherLife.StoryCombat;
namespace AnotherLife.StoryJournal
{
 // Raw storage DTOs are untrusted until StrictJournal.Load succeeds. No deserializer/route is added.
 public sealed class StoredStep
 {
  public long Sequence {get;} public long VersionBefore {get;} public long VersionAfter {get;}
  public ActionCommand Command {get;} public string Diagnostic {get;} public string PreviousHash {get;} public string CommitHash {get;}
  public StoredStep(long sequence,long before,long after,ActionCommand command,string diagnostic,string previous,string commit)
  {Sequence=sequence;VersionBefore=before;VersionAfter=after;Command=command;Diagnostic=diagnostic;PreviousHash=previous;CommitHash=commit;}
 }
 public sealed class StoredAttempt
 {
  readonly byte[] snapshot; public int? AcceptedActionsUsed {get;} public int? RecordedRejectionsUsed {get;} public TerminalReason? TerminalReason {get;}
  public string OwnerAccountId {get;} public string AttemptId {get;} public string EntryNonce {get;} public string StageId {get;}
  public byte[] SnapshotBytes=>(byte[])snapshot.Clone(); public string InputHash {get;}
  public long RowCount {get;} public long BattleVersion {get;} public Outcome Outcome {get;} public string StateHash {get;} public string HeadHash {get;}
  public IReadOnlyList<StoredStep> Steps {get;}
  public StoredAttempt(string owner,string attempt,string entry,string stage,byte[] bytes,string inputHash,long rows,long version,Outcome outcome,string stateHash,string head,IEnumerable<StoredStep> steps,int? acceptedActionsUsed=null,int? recordedRejectionsUsed=null,TerminalReason? terminalReason=null)
  {
   if(bytes==null||bytes.Length>SnapshotCodec.MaximumBytes||steps==null)throw new InvalidDataException("Invalid stored combat journal");
   var s=steps.Take(TurnReplay.MaximumCommands+1).ToArray();if(s.Length>TurnReplay.MaximumCommands)throw new InvalidDataException("Invalid stored combat journal");
   AcceptedActionsUsed=acceptedActionsUsed;RecordedRejectionsUsed=recordedRejectionsUsed;TerminalReason=terminalReason;OwnerAccountId=owner;AttemptId=attempt;EntryNonce=entry;StageId=stage;snapshot=(byte[])bytes.Clone();InputHash=inputHash;RowCount=rows;BattleVersion=version;Outcome=outcome;StateHash=stateHash;HeadHash=head;Steps=Array.AsReadOnly(s);
  }
 }
 public sealed class LoadedAttempt
 {
  public StoredAttempt Stored {get;} public BattleInput Input {get;} public ReplayResult State {get;}
  internal LoadedAttempt(StoredAttempt stored,BattleInput input,ReplayResult state){Stored=stored;Input=input;State=state;}
 }
 // Transport intent has no owner, timestamp, snapshot, damage, HP, outcome or diagnostic.
 public sealed class ActionIntent
 {
  public string RequestId {get;} public long ExpectedVersion {get;} public string ActorInstanceId {get;} public string SkillId {get;} public int TargetIndex {get;}
  public ActionIntent(string nonce,long version,string actor,string skill,int target){RequestId=nonce;ExpectedVersion=version;ActorInstanceId=actor;SkillId=skill;TargetIndex=target;}
 }
 public sealed class ActionPlan
 {
  public ActionReceipt? Receipt {get;} public string Diagnostic {get;} public ReplayResult State {get;} public StoredAttempt? Replacement {get;}
  public string RequiredOldHeadHash {get;} public long RequiredOldRowCount {get;}
  internal ActionPlan(ActionReceipt? receipt,ReplayResult state,StoredAttempt? replacement,StoredAttempt old,string? diagnostic=null){Receipt=receipt;Diagnostic=diagnostic??receipt!.Diagnostic;State=state;Replacement=replacement;RequiredOldHeadHash=old.HeadHash;RequiredOldRowCount=old.RowCount;}
 }
}

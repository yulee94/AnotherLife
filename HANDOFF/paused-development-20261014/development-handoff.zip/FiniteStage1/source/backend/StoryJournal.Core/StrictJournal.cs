using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using AnotherLife.StoryCombat;
namespace AnotherLife.StoryJournal
{
 public static class StrictJournal
 {
  public static LoadedAttempt Load(StoredAttempt stored,string expectedOwner,string expectedAttempt)
  {
   if(stored==null||!Account(expectedOwner)||!Nonce(expectedAttempt)||stored.OwnerAccountId!=expectedOwner||stored.AttemptId!=expectedAttempt||!Nonce(stored.EntryNonce)||!Hex(stored.InputHash)||!Hex(stored.StateHash)||!Hex(stored.HeadHash)||stored.RowCount!=stored.Steps.Count||stored.RowCount<0||stored.RowCount>TurnReplay.MaximumCommands||!Enum.IsDefined(typeof(Outcome),stored.Outcome))throw Invalid();
   var input=SnapshotCodec.Decode(stored.SnapshotBytes);
   if(input.ContentId!=stored.StageId)throw Invalid();
   // One engine replay, not O(n^2) prefix replays. No persisted diagnostic/result is trusted.
   if(stored.Steps.Any(s=>s==null||s.Command==null))throw Invalid();
   var replay=TurnReplay.Replay(input,stored.Steps.Select(s=>s.Command));
   if(stored.InputHash!=replay.InputHash||stored.StateHash!=replay.StateHash||stored.BattleVersion!=replay.Version||stored.Outcome!=replay.Outcome||replay.Journal.Count!=stored.Steps.Count)throw Invalid();
   if(input.FinitePolicy==null){if(stored.AcceptedActionsUsed!=null||stored.RecordedRejectionsUsed!=null||stored.TerminalReason!=null)throw Invalid();}else if(stored.AcceptedActionsUsed!=replay.AcceptedActionsUsed||stored.RecordedRejectionsUsed!=replay.RecordedRejectionsUsed||stored.TerminalReason!=replay.TerminalReason)throw Invalid(); string previous=Genesis(stored.OwnerAccountId,stored.AttemptId,stored.EntryNonce,stored.StageId,stored.InputHash);long version=1,time=input.StartedAt;
   for(int i=0;i<stored.Steps.Count;i++)
   {
    var s=stored.Steps[i];var r=replay.Receipts[i];var c=s.Command;
    if(!r.Recorded||r.Replayed||c.RequestId==stored.EntryNonce||c.RequestId==stored.AttemptId||c.CreatedAt<time||s.Sequence!=i+1L||s.VersionBefore!=version||s.Diagnostic!=r.Diagnostic||s.PreviousHash!=previous||!Hex(s.CommitHash))throw Invalid();
    time=c.CreatedAt;if(r.Accepted)version++;
    if(s.VersionAfter!=version||s.CommitHash!=StepHash(s))throw Invalid();previous=s.CommitHash;
   }
   if(previous!=stored.HeadHash||version!=stored.BattleVersion)throw Invalid();
   return new LoadedAttempt(stored,input,replay);
  }
  public static ActionPlan Plan(StoredAttempt stored,string expectedOwner,string expectedAttempt,ActionIntent intent,long trustedTime)
  {
   // Stored corruption never becomes a harmless transport retry, even for an original nonce.
   var old=Load(stored,expectedOwner,expectedAttempt);if(intent==null)throw Invalid();
   if((intent.RequestId==stored.EntryNonce||intent.RequestId==stored.AttemptId)&&intent.ExpectedVersion>=1&&Id(intent.ActorInstanceId)&&Id(intent.SkillId)&&intent.TargetIndex>=0&&intent.TargetIndex<=9&&trustedTime>=1)
    return new ActionPlan(null,old.State,null,stored,"REQUEST-CONFLICT");
   var command=new ActionCommand(intent.RequestId,intent.ExpectedVersion,intent.ActorInstanceId,intent.SkillId,intent.TargetIndex,trustedTime);
   var next=TurnReplay.Replay(old.Input,old.State.Journal.Append(command));var receipt=next.Receipts.Last();
   if(!receipt.Recorded||receipt.Replayed)return new ActionPlan(receipt,next,null,stored);
   var row=new StoredStep(stored.RowCount+1,old.State.Version,next.Version,receipt.Command,receipt.Diagnostic,stored.HeadHash,"");
   row=new StoredStep(row.Sequence,row.VersionBefore,row.VersionAfter,row.Command,row.Diagnostic,row.PreviousHash,StepHash(row));
   var replacement=new StoredAttempt(stored.OwnerAccountId,stored.AttemptId,stored.EntryNonce,stored.StageId,stored.SnapshotBytes,stored.InputHash,stored.RowCount+1,next.Version,next.Outcome,next.StateHash,row.CommitHash,stored.Steps.Append(row),old.Input.FinitePolicy==null?(int?)null:next.AcceptedActionsUsed,old.Input.FinitePolicy==null?(int?)null:next.RecordedRejectionsUsed,old.Input.FinitePolicy==null?(TerminalReason?)null:next.TerminalReason);
   return new ActionPlan(receipt,next,replacement,stored);
  }
  /// <summary>Creates and strictly validates an initial journal from caller-authorized non-test content.</summary>
  /// <remarks>
  /// This factory is not authentication or admission. The trusted caller must authenticate the owner,
  /// authorize content and hero ownership, ensure operation identities are unique in durable storage,
  /// and atomically persist this candidate with its entry receipt and energy debit.
  /// No state is persisted and no content approval is inferred from TestOnly being false.
  /// </remarks>
  public static StoredAttempt CreateTrustedAttempt(string owner,string attempt,string entry,BattleInput input)
  {
   if(!Account(owner)||!Nonce(attempt)||!Nonce(entry)||attempt==entry||input==null||input.TestOnly)throw Invalid();
   var candidate=CreateInitialAttempt(owner,attempt,entry,input);
   Load(candidate,owner,attempt);
   return candidate;
  }
  // Test-only creation is assembly-internal and exposed solely to the named regression assembly.
  internal static StoredAttempt CreateTestAttempt(string owner,string attempt,string entry,BattleInput input)
  {
   if(!Account(owner)||!Nonce(attempt)||!Nonce(entry)||input==null||!input.TestOnly)throw Invalid();
   return CreateInitialAttempt(owner,attempt,entry,input);
  }
  static StoredAttempt CreateInitialAttempt(string owner,string attempt,string entry,BattleInput input)
  {
   var state=TurnReplay.Replay(input,Array.Empty<ActionCommand>());
   return new StoredAttempt(owner,attempt,entry,input.ContentId,SnapshotCodec.Encode(input),state.InputHash,0,state.Version,state.Outcome,state.StateHash,Genesis(owner,attempt,entry,input.ContentId,state.InputHash),Array.Empty<StoredStep>(),input.FinitePolicy==null?(int?)null:state.AcceptedActionsUsed,input.FinitePolicy==null?(int?)null:state.RecordedRejectionsUsed,input.FinitePolicy==null?(TerminalReason?)null:state.TerminalReason);
  }
  static string Genesis(string owner,string attempt,string entry,string stage,string input)=>Digest(w=>{Text(w,"anotherlife-journal-chain-v1");Text(w,owner);Text(w,attempt);Text(w,entry);Text(w,stage);Text(w,input);});
  static string StepHash(StoredStep s)=>Digest(w=>{Text(w,"anotherlife-journal-row-v1");Text(w,s.PreviousHash);w.Write(s.Sequence);w.Write(s.VersionBefore);w.Write(s.VersionAfter);var c=s.Command;Text(w,c.RequestId);w.Write(c.ExpectedVersion);Text(w,c.ActorInstanceId);Text(w,c.SkillId);w.Write(c.TargetIndex);w.Write(c.CreatedAt);Text(w,s.Diagnostic);});
  static void Text(BinaryWriter w,string value){if(value==null||value.Length>128)throw Invalid();var b=Encoding.UTF8.GetBytes(value);w.Write(b.Length);w.Write(b);}
  static string Digest(Action<BinaryWriter> write){using(var m=new MemoryStream())using(var w=new BinaryWriter(m,Encoding.UTF8,true)){write(w);w.Flush();using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(m.ToArray())).Replace("-","").ToLowerInvariant();}}
  static bool Id(string s)=>!string.IsNullOrEmpty(s)&&s.Length<=128&&s.All(c=>c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='_'||c=='-'||c=='.');
  static bool Nonce(string s)=>s!=null&&s.Length==32&&s.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
  static bool Hex(string s)=>s!=null&&s.Length==64&&s.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
  static bool Account(string s)=>s!=null&&s.Length==36&&s.StartsWith("ala_",StringComparison.Ordinal)&&Nonce(s.Substring(4))&&s.Skip(4).Any(c=>c!='0');
  static InvalidDataException Invalid()=>new InvalidDataException("Invalid stored combat journal");
 }
}

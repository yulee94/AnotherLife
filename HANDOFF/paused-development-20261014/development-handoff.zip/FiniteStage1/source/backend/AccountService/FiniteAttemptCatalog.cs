using System.Security.Cryptography;
using System.Text.Json;
using AnotherLife.StoryCombat;

namespace AnotherLife.AccountService;

// Parsing and resolving terms is not host admission, capacity proof or a production factory.
public sealed class FiniteAttemptCatalog
{
    readonly IReadOnlyList<(FiniteAttemptPolicy Policy, bool Enabled)> rows;
    readonly bool enabled;
    FiniteAttemptCatalog(bool enabled, IEnumerable<(FiniteAttemptPolicy, bool)> rows)
    { this.enabled=enabled;this.rows=Array.AsReadOnly(rows.ToArray()); }
    static InvalidDataException Bad()=>new("AL-ATTEMPT-POLICY-INVALID");
    static void Fields(JsonElement e, params string[] names)
    {
        if(e.ValueKind!=JsonValueKind.Object)throw Bad();var fields=e.EnumerateObject().Select(p=>p.Name).ToArray();
        if(fields.Length!=names.Length||fields.Distinct(StringComparer.Ordinal).Count()!=fields.Length||fields.Any(f=>!names.Contains(f,StringComparer.Ordinal)))throw Bad();
    }
    static string S(JsonElement e,string n)=>e.GetProperty(n).ValueKind==JsonValueKind.String?e.GetProperty(n).GetString()!:throw Bad();
    static int N(JsonElement e,string n){var x=e.GetProperty(n);if(x.ValueKind!=JsonValueKind.Number||!x.TryGetInt32(out int v)||x.GetRawText()!=v.ToString(System.Globalization.CultureInfo.InvariantCulture))throw Bad();return v;}
    static bool B(JsonElement e,string n){var x=e.GetProperty(n);return x.ValueKind==JsonValueKind.True?true:x.ValueKind==JsonValueKind.False?false:throw Bad();}
    public static FiniteAttemptCatalog Parse(byte[] utf8)
    {
        if(utf8==null||utf8.Length==0||utf8.Length>1048576)throw Bad();
        // Own the bytes while parsing/hashing; the caller cannot mutate the admitted digest.
        var bytes=(byte[])utf8.Clone();
        try
        {
            using var doc=JsonDocument.Parse(bytes,new JsonDocumentOptions{MaxDepth=8,AllowTrailingCommas=false,CommentHandling=JsonCommentHandling.Disallow});
            var root=doc.RootElement;Fields(root,"version","catalogId","revision","runtimeEnabled","records");
            if(N(root,"version")!=1||S(root,"catalogId")!="kingdom_attempt_limits")throw Bad();
            string revision=S(root,"revision");if(revision.Length is <1 or >128||revision.Any(c=>!(char.IsAsciiLetterOrDigit(c)||c is '_' or '-' or '.')))throw Bad();
            bool enabled=B(root,"runtimeEnabled");var array=root.GetProperty("records");
            if(array.ValueKind!=JsonValueKind.Array||array.GetArrayLength()>10000)throw Bad();
            string digest=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
            var policies=new List<(FiniteAttemptPolicy,bool)>();var scopes=new HashSet<string>(StringComparer.Ordinal);var ids=new HashSet<string>(StringComparer.Ordinal);
            foreach(var row in array.EnumerateArray())
            {
                Fields(row,"policyId","mode","encounterId","floor","maxAcceptedActions","maxRecordedRejections","engineVersion","exhaustionOutcome","countRule","normalTerminalPrecedence","runtimeEnabled");
                if(S(row,"engineVersion")!=FiniteAttemptPolicy.Engine||S(row,"exhaustionOutcome")!=FiniteAttemptPolicy.ExhaustionOutcome||S(row,"countRule")!=FiniteAttemptPolicy.CountRule||S(row,"normalTerminalPrecedence")!=FiniteAttemptPolicy.Precedence)throw Bad();
                var p=new FiniteAttemptPolicy("kingdom_attempt_limits",revision,digest,S(row,"policyId"),S(row,"mode"),S(row,"encounterId"),N(row,"floor"),N(row,"maxAcceptedActions"),N(row,"maxRecordedRejections"));
                if(!ids.Add(p.PolicyId)||!scopes.Add(p.Mode+"|"+p.EncounterId+"|"+p.Floor))throw Bad();
                policies.Add((p,B(row,"runtimeEnabled")));
            }
            return new(enabled,policies);
        }
        catch(Exception e) when(e is JsonException or ArgumentException or InvalidOperationException or OverflowException){throw Bad();}
    }
    public FiniteAttemptPolicy Resolve(string mode,string encounter,int floor)
    {
        var matching=rows.Where(r=>r.Policy.Mode==mode&&r.Policy.EncounterId==encounter&&r.Policy.Floor==floor).ToArray();
        if(!enabled||matching.Length!=1||!matching[0].Enabled)throw new InvalidOperationException("AL-ATTEMPT-POLICY-UNAVAILABLE");
        return matching[0].Policy;
    }
}

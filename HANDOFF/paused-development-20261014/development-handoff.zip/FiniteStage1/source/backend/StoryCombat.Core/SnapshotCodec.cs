using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace AnotherLife.StoryCombat
{
 // Standalone combat input format; does not allocate an account/save schema version.
 public static class SnapshotCodec
 {
  public const int MaximumBytes=65536;
  const string Format="anotherlife-combat-input-v1"; const string FiniteFormat="anotherlife-finite-attempt-input-v1";
  static readonly Encoding Utf8=new UTF8Encoding(false,true);
  internal static void Text(BinaryWriter writer,string value)
  {
   var bytes=Utf8.GetBytes(value);if(bytes.Length>128)throw Guard.Invalid();
   writer.Write((ushort)bytes.Length);writer.Write(bytes);
  }
  static string Text(BinaryReader reader)
  {
   int length=reader.ReadUInt16();if(length>128)throw Guard.Invalid();
   var bytes=reader.ReadBytes(length);if(bytes.Length!=length)throw Guard.Invalid();return Utf8.GetString(bytes);
  }
  public static byte[] Encode(BattleInput input)
  {
   if(input==null)throw Guard.Invalid();
   using(var stream=new MemoryStream())
   using(var w=new BinaryWriter(stream,Utf8,true))
   {
    Text(w,input.FinitePolicy==null?Format:FiniteFormat);Text(w,input.EngineVersion);Text(w,input.ContentId);Text(w,input.ContentVersion);
    w.Write((byte)(input.TestOnly?1:0));w.Write(input.StartedAt);Text(w,input.TurnOrder);Text(w,input.EnemyTarget);w.Write((byte)input.Heroes.Count);
    foreach(var h in input.Heroes)
    {
     Text(w,h.InstanceId);Text(w,h.DefinitionId);Text(w,h.DefinitionVersion);w.Write(h.MaximumHp);w.Write(h.Damage);w.Write((byte)h.Skills.Count);
     foreach(var s in h.Skills){Text(w,s.Id);w.Write((byte)s.Target);w.Write((byte)s.Effect);w.Write(s.Multiplier);}
    }
    w.Write((byte)input.Enemies.Count);foreach(var e in input.Enemies){Text(w,e.DefinitionId);w.Write(e.MaximumHp);w.Write(e.Attack);}
    if(input.FinitePolicy!=null){var p=input.FinitePolicy;Text(w,p.CatalogId);Text(w,p.CatalogRevision);Text(w,p.CatalogDigest);Text(w,p.PolicyId);Text(w,p.Mode);Text(w,p.EncounterId);w.Write(p.Floor);w.Write(p.MaximumAcceptedActions);w.Write(p.MaximumRecordedRejections);Text(w,FiniteAttemptPolicy.CountRule);Text(w,FiniteAttemptPolicy.ExhaustionOutcome);Text(w,FiniteAttemptPolicy.Precedence);} w.Flush();if(stream.Length>MaximumBytes)throw Guard.Invalid();return stream.ToArray();
   }
  }
  public static BattleInput Decode(byte[] bytes)
  {
   if(bytes==null||bytes.Length>MaximumBytes)throw Guard.Invalid();
   try
   {
    using(var stream=new MemoryStream(bytes,false))
    using(var r=new BinaryReader(stream,Utf8))
    {
     string format=Text(r);if(format!=Format&&format!=FiniteFormat)throw Guard.Invalid();
     string engine=Text(r),content=Text(r),version=Text(r);byte test=r.ReadByte();if(test>1)throw Guard.Invalid();
     long started=r.ReadInt64();string order=Text(r),target=Text(r);
     if(r.ReadByte()!=5)throw Guard.Invalid();var heroes=new Hero[5];
     for(int i=0;i<5;i++)
     {
      string instance=Text(r),definition=Text(r),definitionVersion=Text(r);int hp=r.ReadInt32(),damage=r.ReadInt32();int count=r.ReadByte();if(count<1||count>6)throw Guard.Invalid();var skills=new Skill[count];
      for(int j=0;j<count;j++)skills[j]=new Skill(Text(r),(Target)r.ReadByte(),(Effect)r.ReadByte(),r.ReadInt32());
      heroes[i]=new Hero(instance,definition,definitionVersion,hp,damage,skills);
     }
     int enemyCount=r.ReadByte();if(enemyCount<1||enemyCount>5)throw Guard.Invalid();var enemies=new Enemy[enemyCount];
     for(int i=0;i<enemyCount;i++)enemies[i]=new Enemy(Text(r),r.ReadInt32(),r.ReadInt32());
     FiniteAttemptPolicy? policy=null;if(format==FiniteFormat){policy=new FiniteAttemptPolicy(Text(r),Text(r),Text(r),Text(r),Text(r),Text(r),r.ReadInt32(),r.ReadInt32(),r.ReadInt32());if(Text(r)!=FiniteAttemptPolicy.CountRule||Text(r)!=FiniteAttemptPolicy.ExhaustionOutcome||Text(r)!=FiniteAttemptPolicy.Precedence||engine!=FiniteAttemptPolicy.Engine)throw Guard.Invalid();}else if(engine!=BattleInput.SupportedEngineVersion)throw Guard.Invalid();if(stream.Position!=stream.Length)throw Guard.Invalid();return new BattleInput(engine,content,version,test==1,started,order,target,heroes,enemies,policy);
    }
   }
   catch(Exception e) when(e is EndOfStreamException||e is DecoderFallbackException||e is ArgumentException){throw Guard.Invalid();}
  }
  internal static string Digest(byte[] bytes){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();}
 }
}

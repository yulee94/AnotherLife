using System;
using System.Linq;

namespace AnotherLife.StoryCombat
{
    // Independent format family, not the manual-combat V2 mechanics engine.
    public sealed class FiniteAttemptPolicy
    {
        public const string Engine = "five-hero-finite-attempt-v1";
        public const string CountRule = "accepted-player-action";
        public const string ExhaustionOutcome = "defeat";
        public const string ExhaustionReason = "action_budget_exhausted";
        public const string Precedence = "ordinary-terminal-first";
        public string CatalogId { get; }
        public string CatalogRevision { get; }
        public string CatalogDigest { get; }
        public string PolicyId { get; }
        public string Mode { get; }
        public string EncounterId { get; }
        public int Floor { get; }
        public int MaximumAcceptedActions { get; }
        public int MaximumRecordedRejections { get; }
        public FiniteAttemptPolicy(string catalogId, string revision, string digest, string policyId,
            string mode, string encounterId, int floor, int accepted, int rejected)
        {
            if (!Guard.Id(catalogId) || !Guard.Id(revision) || !Guard.Id(policyId) || !Guard.Id(encounterId) ||
                digest == null || digest.Length != 64 || digest.Any(c => !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f')) ||
                (mode != "story" && mode != "tower") || (mode == "story" ? floor != 0 : floor < 1) ||
                accepted < 1 || accepted > TurnReplay.MaximumCommands || rejected < 0 || rejected > TurnReplay.MaximumCommands ||
                (long)accepted + rejected > TurnReplay.MaximumCommands) throw Guard.Invalid();
            CatalogId = catalogId; CatalogRevision = revision; CatalogDigest = digest; PolicyId = policyId;
            Mode = mode; EncounterId = encounterId; Floor = floor;
            MaximumAcceptedActions = accepted; MaximumRecordedRejections = rejected;
        }
    }
    public enum TerminalReason { None, Victory, Defeat, ActionBudgetExhausted }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
namespace AnotherLife.StoryCombat
{
 public static class TurnReplay
 {
  public const int MaximumCommands=10000; // Unique journal entries, accepted or rejected.
  public const int MaximumRequestBatch=MaximumCommands+1; // Existing journal plus one new request/retry.
  public static ReplayResult Replay(BattleInput input,IEnumerable<ActionCommand> commands)
  {
   if(input==null||commands==null)throw Guard.Invalid();
   var hp=input.Heroes.Select(h=>h.MaximumHp).Concat(input.Enemies.Select(e=>e.MaximumHp)).ToArray();
   var policy=input.FinitePolicy;int accepted=0,rejected=0;var reason=TerminalReason.None;var maximum=(int[])hp.Clone();int cursor=0;long version=1,time=input.StartedAt;var outcome=Outcome.Active;
   var receipts=new List<ActionReceipt>();var unique=new Dictionary<string,ActionReceipt>(StringComparer.Ordinal);int count=0;
   foreach(var command in commands)
   {
    if(++count>MaximumRequestBatch||command==null)throw Guard.Invalid();string code="";bool recorded=false;
    if(policy!=null&&command.RequestId!=null&&unique.TryGetValue(command.RequestId,out var frozen)){receipts.Add(frozen.Command.Same(command)?new ActionReceipt(frozen.Command,frozen.Diagnostic,true,true):new ActionReceipt(command,"REQUEST-CONFLICT"));continue;} if(!Guard.Nonce(command.RequestId)||!Guard.Id(command.ActorInstanceId)||!Guard.Id(command.SkillId)||command.ExpectedVersion<1||command.TargetIndex<0||command.TargetIndex>9||command.CreatedAt<1)code="COMMAND-INVALID";
    else if(unique.TryGetValue(command.RequestId,out var prior))
    {
     if(prior.Command.Same(command))receipts.Add(new ActionReceipt(prior.Command,prior.Diagnostic,true,true));else receipts.Add(new ActionReceipt(command,"REQUEST-CONFLICT"));continue;
    }
    else if(policy!=null&&outcome!=Outcome.Active)code="FINISHED"; else if(unique.Count>=MaximumCommands)code="CAPACITY";
    else if(command.CreatedAt<time)code="CLOCK-REVERSED";
    else
    {
     // Valid rejected gameplay commands have immutable nonce receipts, matching practice.
     // Structural errors, rollback and nonce conflict do not enter the journal.
     if(policy==null)time=command.CreatedAt;recorded=true;Skill? skill=null;
     if(outcome!=Outcome.Active)code="FINISHED";
     else if(command.ExpectedVersion!=version||version==long.MaxValue)code="VERSION-CONFLICT";
     else if(command.ActorInstanceId!=input.Heroes[cursor].InstanceId)code="NOT-YOUR-TURN";
     else
     {
      skill=input.Heroes[cursor].Skills.SingleOrDefault(s=>s.Id==command.SkillId);
      if(skill==null)code="SKILL-UNAVAILABLE";
      else if(command.TargetIndex>=hp.Length||hp[command.TargetIndex]<=0||(skill.Target==Target.Enemy?command.TargetIndex<5:command.TargetIndex>=5))code="TARGET-INVALID";
     }
     if(policy!=null&&code.Length!=0&&rejected>=policy.MaximumRecordedRejections){recorded=false;code="REJECTION-STORAGE-BOUND";} if(code.Length==0)
     {
      long amount=(long)input.Heroes[cursor].Damage*skill!.Multiplier;int target=command.TargetIndex;
      hp[target]=(int)(skill.Effect==Effect.Damage?Math.Max(0,hp[target]-amount):Math.Min(maximum[target],hp[target]+amount));version++;
      if(hp.Skip(5).All(h=>h==0))outcome=Outcome.Victory;
      else
      {
       int next=cursor+1;while(next<5&&hp[next]==0)next++;
       if(next<5)cursor=next;
       else
       {
        for(int i=5;i<hp.Length;i++){if(hp[i]==0)continue;int victim=Array.FindIndex(hp,0,5,h=>h>0);if(victim<0)break;hp[victim]=Math.Max(0,hp[victim]-input.Enemies[i-5].Attack);}
        next=Array.FindIndex(hp,0,5,h=>h>0);if(next<0)outcome=Outcome.Defeat;else cursor=next;
       }
      }
     }
    }
    if(recorded){if(policy!=null)time=command.CreatedAt;if(code.Length==0){accepted++;if(policy!=null){if(outcome==Outcome.Victory)reason=TerminalReason.Victory;else if(outcome==Outcome.Defeat)reason=TerminalReason.Defeat;else if(accepted==policy.MaximumAcceptedActions){outcome=Outcome.Defeat;reason=TerminalReason.ActionBudgetExhausted;}}}else rejected++;} var receipt=new ActionReceipt(command,code,false,recorded);receipts.Add(receipt);if(recorded)unique.Add(command.RequestId,receipt);
   }
   string inputHash=SnapshotCodec.Digest(SnapshotCodec.Encode(input));string stateHash;
   using(var stream=new MemoryStream())
   using(var w=new BinaryWriter(stream,Encoding.UTF8,true))
   {
    SnapshotCodec.Text(w,policy==null?"anotherlife-combat-state-v1":"anotherlife-finite-attempt-state-v1");SnapshotCodec.Text(w,inputHash);w.Write(version);w.Write(cursor);w.Write((int)outcome);w.Write(hp.Length);foreach(int h in hp)w.Write(h);
    var journal=receipts.Where(r=>r.Recorded&&!r.Replayed).ToArray();w.Write(journal.Length);
    foreach(var r in journal){var c=r.Command;SnapshotCodec.Text(w,c.RequestId);w.Write(c.ExpectedVersion);SnapshotCodec.Text(w,c.ActorInstanceId);SnapshotCodec.Text(w,c.SkillId);w.Write(c.TargetIndex);w.Write(c.CreatedAt);SnapshotCodec.Text(w,r.Diagnostic);}
    if(policy!=null){w.Write(accepted);w.Write(rejected);w.Write((int)reason);} w.Flush();stateHash=SnapshotCodec.Digest(stream.ToArray());
   }
   return new ReplayResult(hp,cursor,version,outcome,receipts,inputHash,stateHash,accepted,rejected,reason);
  }
 }
}

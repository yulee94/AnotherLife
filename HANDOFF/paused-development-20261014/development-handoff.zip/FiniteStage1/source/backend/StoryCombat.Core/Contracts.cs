using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
namespace AnotherLife.StoryCombat
{
 public enum Outcome { Active, Victory, Defeat }
 public enum Target { Enemy, Ally }
 public enum Effect { Damage, Heal }
 public sealed class Skill
 {
  public string Id{get;} public Target Target{get;} public Effect Effect{get;} public int Multiplier{get;}
  public Skill(string id,Target target,Effect effect,int multiplier){if(!Guard.Id(id)||!Enum.IsDefined(typeof(Target),target)||!Enum.IsDefined(typeof(Effect),effect)||multiplier<1||multiplier>10||(effect==Effect.Damage?target!=Target.Enemy:target!=Target.Ally))throw Guard.Invalid();Id=id;Target=target;Effect=effect;Multiplier=multiplier;}
 }
 public sealed class Hero
 {
  public string InstanceId{get;} public string DefinitionId{get;} public string DefinitionVersion{get;} public int MaximumHp{get;} public int Damage{get;} public IReadOnlyList<Skill> Skills{get;}
  public Hero(string instance,string definition,string version,int maximumHp,int damage,IEnumerable<Skill> skills){var rows=skills?.ToArray();if(!Guard.Id(instance)||!Guard.Id(definition)||!Guard.Id(version)||maximumHp<1||maximumHp>5400000||damage<1||damage>5400000||rows==null||rows.Length<1||rows.Length>6||rows.Any(s=>s==null)||rows.Select(s=>s.Id).Distinct(StringComparer.Ordinal).Count()!=rows.Length)throw Guard.Invalid();InstanceId=instance;DefinitionId=definition;DefinitionVersion=version;MaximumHp=maximumHp;Damage=damage;Skills=Array.AsReadOnly(rows);}
 }
 public sealed class Enemy
 {
  public string DefinitionId{get;} public int MaximumHp{get;} public int Attack{get;}
  public Enemy(string definition,int maximumHp,int attack){if(!Guard.Id(definition)||maximumHp<1||maximumHp>10000000||attack<1||attack>1000000)throw Guard.Invalid();DefinitionId=definition;MaximumHp=maximumHp;Attack=attack;}
 }
 public sealed class BattleInput
 {
  public const string SupportedEngineVersion="five-hero-practice-parity-v1";
  public FiniteAttemptPolicy? FinitePolicy{get;} public string EngineVersion{get;} public string ContentId{get;} public string ContentVersion{get;} public bool TestOnly{get;} public long StartedAt{get;}
  public string TurnOrder{get;} public string EnemyTarget{get;} public IReadOnlyList<Hero> Heroes{get;} public IReadOnlyList<Enemy> Enemies{get;}
  public BattleInput(string engine,string content,string version,bool testOnly,long startedAt,string order,string enemyTarget,IEnumerable<Hero> heroes,IEnumerable<Enemy> enemies,FiniteAttemptPolicy? finitePolicy=null){var h=heroes?.ToArray();var e=enemies?.ToArray();if((engine==SupportedEngineVersion?finitePolicy!=null:engine!=FiniteAttemptPolicy.Engine||finitePolicy==null)|| (finitePolicy!=null&&finitePolicy.EncounterId!=content)||!Guard.Id(content)||!Guard.Id(version)||startedAt<1||order!="party-then-enemies"||enemyTarget!="first-living-party"||h==null||h.Length!=5||h.Any(x=>x==null)||h.Select(x=>x.InstanceId).Distinct(StringComparer.Ordinal).Count()!=5||e==null||e.Length<1||e.Length>5||e.Any(x=>x==null))throw Guard.Invalid();FinitePolicy=finitePolicy;EngineVersion=engine;ContentId=content;ContentVersion=version;TestOnly=testOnly;StartedAt=startedAt;TurnOrder=order;EnemyTarget=enemyTarget;Heroes=Array.AsReadOnly(h);Enemies=Array.AsReadOnly(e);}
 }
 // Actions contain no outcome, HP, damage, reward or trusted result supplied by the caller.
 public sealed class ActionCommand
 {
  public string RequestId{get;} public long ExpectedVersion{get;} public string ActorInstanceId{get;} public string SkillId{get;} public int TargetIndex{get;} public long CreatedAt{get;}
  public ActionCommand(string request,long expected,string actor,string skill,int target,long createdAt){RequestId=request;ExpectedVersion=expected;ActorInstanceId=actor;SkillId=skill;TargetIndex=target;CreatedAt=createdAt;}
  // Host time is excluded from retry payload identity; retain the original committed time.
  internal bool Same(ActionCommand b)=>RequestId==b.RequestId&&ExpectedVersion==b.ExpectedVersion&&ActorInstanceId==b.ActorInstanceId&&SkillId==b.SkillId&&TargetIndex==b.TargetIndex;
 }
 public sealed class ActionReceipt
 {
  public ActionCommand Command{get;} public string Diagnostic{get;} public bool Accepted=>Diagnostic.Length==0;public bool Replayed{get;} public bool Recorded{get;}
  internal ActionReceipt(ActionCommand command,string diagnostic,bool replayed=false,bool recorded=false){Command=command;Diagnostic=diagnostic;Replayed=replayed;Recorded=recorded;}
 }
 public sealed class ReplayResult
 {
  public int AcceptedActionsUsed{get;} public int RecordedRejectionsUsed{get;} public TerminalReason TerminalReason{get;} public string TerminalReasonCode => TerminalReason==TerminalReason.ActionBudgetExhausted?FiniteAttemptPolicy.ExhaustionReason:TerminalReason==TerminalReason.Victory?"victory":TerminalReason==TerminalReason.Defeat?"defeat":""; public IReadOnlyList<int> Hp{get;} public int Cursor{get;} public long Version{get;} public Outcome Outcome{get;} public IReadOnlyList<ActionReceipt> Receipts{get;} public IReadOnlyList<ActionCommand> Journal{get;} public string InputHash{get;} public string StateHash{get;}
  internal ReplayResult(int[] hp,int cursor,long version,Outcome outcome,IEnumerable<ActionReceipt> receipts,string inputHash,string stateHash,int accepted=0,int rejected=0,TerminalReason reason=TerminalReason.None){AcceptedActionsUsed=accepted;RecordedRejectionsUsed=rejected;TerminalReason=reason;Hp=Array.AsReadOnly((int[])hp.Clone());Cursor=cursor;Version=version;Outcome=outcome;Receipts=Array.AsReadOnly(receipts.ToArray());Journal=Array.AsReadOnly(Receipts.Where(r=>r.Recorded&&!r.Replayed).Select(r=>r.Command).ToArray());InputHash=inputHash;StateHash=stateHash;}
 }
 internal static class Guard
 {
  internal static bool Id(string s)=>!string.IsNullOrEmpty(s)&&s.Length<=128&&s.All(c=>c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='_'||c=='-'||c=='.');
  internal static bool Nonce(string s)=>s!=null&&s.Length==32&&s.All(c=>c>='a'&&c<='f'||c>='0'&&c<='9');
  internal static InvalidDataException Invalid()=>new InvalidDataException("Invalid five-hero combat input");
 }
}

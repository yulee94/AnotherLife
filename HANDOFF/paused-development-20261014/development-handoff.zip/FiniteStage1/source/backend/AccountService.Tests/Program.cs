using System.Text.Json;
using AL.Core.Accounts;
using AnotherLife.AccountService;

if (args.Length == 2 && (args[0] == "--heroes-http-fixture" || args[0] == "--heroes-http-prepare"))
    return await HeroesHttpFixtureHost.Run(args[1], args[0] == "--heroes-http-prepare");

var tests = new List<(string Name, Func<Task> Run)>();
void Add(string name, Func<Task> run) => tests.Add((name, run));
void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
void Rejected(Action action, string code)
{
    try { action(); throw new Exception("Expected rejection: " + code); }
    catch (LoginServiceException error) { Check(error.Code == code, "Unexpected diagnostic."); }
}
async Task RejectedAsync(Func<Task> action, string code)
{
    try { await action(); throw new Exception("Expected rejection: " + code); }
    catch (LoginServiceException error) { Check(error.Code == code, "Unexpected diagnostic."); }
}
LoginPolicy Policy() => new() { Issuer = "test-email", CodeLifetimeSeconds = 600, ResendSeconds = 60,
    MaximumCodeAttempts = 5, SessionLifetimeSeconds = 3600, MaximumChallenges = 10, MaximumSessions = 10,
    MaximumRequestsPerSourceWindow = 30, SourceWindowSeconds = 600 };
KingdomProgressSeed ProgressSeed(long food = 7) => new("fixture-starter-v1",
    new Dictionary<string, long> { ["food"] = food, ["wood"] = 11, ["stone"] = 13, ["gold"] = 17 },
    new[] { new KingdomBuildingLevel("town_hall", 1), new KingdomBuildingLevel("farm", 0) });
KingdomProgressCatalog ProgressCatalog(string folder, bool enabled = true)
{
    string progressPath = Path.Combine(folder, "progress.json"), buildingsPath = Path.Combine(folder, "buildings.json");
    File.WriteAllText(progressPath, JsonSerializer.Serialize(new { version = 1, catalogId = "kingdom_progress_defaults", runtimeEnabled = enabled,
        revision = "fixture-starter-v1", resources = new { food = 7, wood = 11, stone = 13, gold = 17 },
        buildings = new[] { new { id = "town_hall", level = 1 }, new { id = "farm", level = 0 } } }));
    File.WriteAllText(buildingsPath, JsonSerializer.Serialize(new { records = new[] { new { id = "town_hall", max_level = 10 }, new { id = "farm", max_level = 10 } } }));
    return KingdomProgressCatalog.Load(progressPath, buildingsPath);
}
AccountIdentityRecord ClientAccount() => new("ala_" + new string('a', 32), "issuer", "subject", "one@example.test", "", 1);
AccountKingdom ClientKingdom() => new(ClientAccount().AccountId, "alp_" + new string('b', 32), "alk_" + new string('c', 32), "crownlands", "fixture-site");
HttpAccountProvider.KingdomProgressDto ProgressWire(long revision = 1)
{
    var k = ClientKingdom();
    return new() { version = 1, revision = revision, catalogRevision = "fixture-starter-v1",
        kingdom = new() { accountId = k.AccountId, profileId = k.ProfileId, kingdomId = k.KingdomId, realmId = k.RealmId, innerRealmSiteId = k.InnerRealmSiteId },
        resources = new[] { new HttpAccountProvider.ResourceDto { id = "food", amount = "7" }, new() { id = "wood", amount = "11" },
            new() { id = "stone", amount = "13" }, new() { id = "gold", amount = "17" } },
        buildings = new[] { new HttpAccountProvider.BuildingDto { id = "town_hall", level = "1" } } };
}
HttpAccountProvider.ConstructionStateDto ConstructionWire(long revision = 2, bool completed = false)
{
    var progress = ProgressWire(revision); progress.buildings[0].level = completed ? "2" : "1";
    return new() { version = 1, serverNow = completed ? "160" : "100", progress = progress,
        jobs = new[] { new HttpAccountProvider.ConstructionJobDto { requestId = new string('c', 32), buildingId = "town_hall",
            fromLevel = "1", targetLevel = "2", startedAt = "100", dueAt = "160", completed = completed ? "1" : "0", catalogRevision = "fixture",
            costs = new[] { new HttpAccountProvider.ResourceDto { id = "food", amount = "1" }, new() { id = "wood", amount = "0" },
                new() { id = "stone", amount = "0" }, new() { id = "gold", amount = "0" } } } } };
}
async Task<AccountLoginSession> ClientLogin(HttpAccountProvider provider, FakeWire wire, WireCodec codec)
{
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200,
        codec.Encode(new { token = "secret-token", expiresAt = 1000L, account = ClientAccount() })));
    return await provider.VerifyCodeAsync("challenge", "123456", default);
}
async Task Store(Func<string, Task> action)
{
    string dir = Path.Combine(Path.GetTempPath(), "AL-server-tests-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(dir);
    try { await action(Path.Combine(dir, "accounts.xml")); }
    finally { Directory.Delete(dir, true); }
}

Add("Email verification creates durable identity; restart invalidates sessions", () => Store(async path =>
{
    var mail = new CaptureEmail(); var registry = new FileAccountRegistry(path);
    var authority = new EmailLoginAuthority(Policy(), registry, mail, () => 100);
    var challenge = await authority.RequestAsync("one@example.test", "source", default);
    Check(!File.Exists(path), "Requesting a code must not register an account.");
    var session = authority.Verify(challenge.Id, mail.Code, "source");
    Check(authority.Authenticate(session.Token).AccountId == session.Account.AccountId, "Session account mismatch.");
    Rejected(() => authority.Verify(challenge.Id, mail.Code, "source"), "AL-LOGIN-CODE-REJECTED");
    var restarted = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 200);
    Rejected(() => restarted.Authenticate(session.Token), "AL-LOGIN-SESSION-REJECTED");
    var again = await restarted.RequestAsync("one@example.test", "source", default);
    Check(restarted.Verify(again.Id, mail.Code, "source").Account.AccountId == session.Account.AccountId, "Restart lost durable account.");
}));
Add("Unconfigured email never returns a fake challenge", () => Store(async path =>
{
    var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), new CaptureEmail { IsConfigured = false });
    await RejectedAsync(() => authority.RequestAsync("one@example.test", "source", default), "AL-LOGIN-EMAIL-UNAVAILABLE");
    Check(!File.Exists(path), "Unavailable mail created account storage.");
}));
Add("Delivery failure does not leak sender secrets or register an account", () => Store(async path =>
{
    var mail = new CaptureEmail { Throw = true };
    var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 100);
    await RejectedAsync(() => authority.RequestAsync("one@example.test", "source", default), "AL-LOGIN-EMAIL-UNAVAILABLE");
    Check(!File.Exists(path), "Failed delivery registered an account.");
}));
Add("Five wrong codes consume challenge", () => Store(async path =>
{
    var mail = new CaptureEmail(); var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 100);
    var challenge = await authority.RequestAsync("one@example.test", "source", default);
    string wrong = mail.Code == "000000" ? "000001" : "000000";
    for (int i = 0; i < 5; i++) Rejected(() => authority.Verify(challenge.Id, wrong, "source"), "AL-LOGIN-CODE-REJECTED");
    Rejected(() => authority.Verify(challenge.Id, mail.Code, "source"), "AL-LOGIN-CODE-REJECTED");
    Check(!File.Exists(path), "Failed codes registered account.");
}));
Add("Resend invalidates previous code and honors shared mailbox cooldown", () => Store(async path =>
{
    long time = 100; var mail = new CaptureEmail();
    var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => time);
    var old = await authority.RequestAsync("one@example.test", "source", default); string oldCode = mail.Code;
    await RejectedAsync(() => authority.RequestAsync("one@example.test", "another-source", default), "AL-LOGIN-RESEND-WAIT");
    await RejectedAsync(() => authority.RequestAsync("ONE@EXAMPLE.TEST", "another-source", default), "AL-LOGIN-RESEND-WAIT");
    time = 160; var fresh = await authority.RequestAsync("one@example.test", "source", default);
    Rejected(() => authority.Verify(old.Id, oldCode, "source"), "AL-LOGIN-CODE-REJECTED");
    authority.Verify(fresh.Id, mail.Code, "source");
}));
Add("Code and session expiry plus logout are enforced by server clock", () => Store(async path =>
{
    long time = 100; var mail = new CaptureEmail();
    var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => time);
    var expired = await authority.RequestAsync("one@example.test", "source", default); time = 700;
    Rejected(() => authority.Verify(expired.Id, mail.Code, "source"), "AL-LOGIN-CODE-REJECTED");
    var challenge = await authority.RequestAsync("one@example.test", "source", default);
    var session = authority.Verify(challenge.Id, mail.Code, "source"); time = session.ExpiresAt;
    Rejected(() => authority.Authenticate(session.Token), "AL-LOGIN-SESSION-REJECTED");
    var fresh = await authority.RequestAsync("one@example.test", "source", default);
    session = authority.Verify(fresh.Id, mail.Code, "source"); authority.Revoke(session.Token);
    Rejected(() => authority.Authenticate(session.Token), "AL-LOGIN-SESSION-REJECTED");
}));
Add("Source rate limit resets after its window", () => Store(async path =>
{
    long time = 100; var mail = new CaptureEmail(); var policy = Policy(); policy.MaximumRequestsPerSourceWindow = 1;
    var authority = new EmailLoginAuthority(policy, new FileAccountRegistry(path), mail, () => time);
    await authority.RequestAsync("one@example.test", "source", default);
    await RejectedAsync(() => authority.RequestAsync("two@example.test", "source", default), "AL-LOGIN-RATE-LIMIT");
    time = 700; await authority.RequestAsync("two@example.test", "source", default);
}));
Add("Pending delivery cannot authenticate; canceled delivery is discarded", () => Store(async path =>
{
    var mail = new CaptureEmail { Pending = new TaskCompletionSource() };
    var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 100);
    using var cancellation = new CancellationTokenSource();
    var pending = authority.RequestAsync("one@example.test", "source", cancellation.Token);
    Check(!pending.IsCompleted, "Pending delivery published challenge.");
    cancellation.Cancel(); mail.Pending.SetResult();
    await RejectedAsync(() => pending, "AL-LOGIN-EMAIL-UNAVAILABLE");
    Check(!File.Exists(path), "Canceled delivery registered account.");
}));
Add("Case variants retain permanent account and random login subject", () => Store(async path =>
{
    var mail = new CaptureEmail(); var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 100);
    var first = await authority.RequestAsync("one@example.test", "source", default);
    var account = authority.Verify(first.Id, mail.Code, "source").Account;
    var otherCase = await authority.RequestAsync("ONE@EXAMPLE.TEST", "source", default);
    var same = authority.Verify(otherCase.Id, mail.Code, "source").Account;
    Check(same.AccountId == account.AccountId && same.Subject == account.Subject, "Case change duplicated account.");
    Check(account.Subject != account.VerifiedEmail, "Email became login subject.");
}));
Add("Client account fields cannot manufacture a server session", () => Store(async path =>
{
    var mail = new CaptureEmail(); var authority = new EmailLoginAuthority(Policy(), new FileAccountRegistry(path), mail, () => 100);
    var challenge = await authority.RequestAsync("one@example.test", "source", default);
    var session = authority.Verify(challenge.Id, mail.Code, "source");
    Rejected(() => authority.Authenticate(session.Account.AccountId), "AL-LOGIN-SESSION-REJECTED");
    Rejected(() => authority.Authenticate(session.Token + "changed"), "AL-LOGIN-SESSION-REJECTED");
}));
Add("Version-one registry loads unchanged and atomically provisions a version-two kingdom", () => Store(path =>
{
    var principal = new VerifiedEmailPrincipal("test", "subject", "one@example.test", true);
    var registry = new FileAccountRegistry(path); var account = registry.ResolveVerifiedLogin(principal).Record;
    var original = File.ReadAllBytes(path);
    Check(File.ReadAllText(path).Contains("version=\"1\""), "Not an old-format fixture.");
    Check(registry.ReadVerifiedKingdom(principal, account.AccountId).State.Status == AccountKingdomStatus.NeedsRealm, "Old account failed to load.");
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Old-format read rewrote persistence.");
    var committed = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site-1" });
    Check(committed.Accepted && committed.State.Status == AccountKingdomStatus.Ready, "Commit failed.");
    Check(committed.State.Account.ProfileId == committed.State.Kingdom.ProfileId && committed.State.Account.Revision == account.Revision + 1, "Profile and kingdom did not commit together.");
    Check(File.ReadAllText(path).Contains("version=\"2\""), "Migration version missing.");
    var reopened = new FileAccountRegistry(path).ReadVerifiedKingdom(principal, account.AccountId);
    Check(reopened.State.Kingdom.KingdomId == committed.State.Kingdom.KingdomId, "Restart lost kingdom.");
    var bytes = File.ReadAllBytes(path);
    var retry = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('b', 32), Array.Empty<string>());
    Check(retry.State.Kingdom.KingdomId == committed.State.Kingdom.KingdomId && bytes.SequenceEqual(File.ReadAllBytes(path)), "Retry duplicated or mutated kingdom.");
    Check(registry.CommitVerifiedRealm(principal, account.AccountId, "umbral", new string('c', 32), new[] { "fixture-site-2" }).Diagnostic == "AL-KINGDOM-REALM-LOCKED", "Realm changed after commitment.");
    Check(bytes.SequenceEqual(File.ReadAllBytes(path)), "Rejected realm mutated persistence.");
    return Task.CompletedTask;
}));
Add("Occupied site and invalid principal cannot bind another profile", () => Store(path =>
{
    var registry = new FileAccountRegistry(path);
    var one = new VerifiedEmailPrincipal("test", "one", "one@example.test", true);
    var two = new VerifiedEmailPrincipal("test", "two", "two@example.test", true);
    var first = registry.ResolveVerifiedLogin(one).Record; var second = registry.ResolveVerifiedLogin(two).Record;
    Check(registry.CommitVerifiedRealm(one, first.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site" }).Accepted, "First site failed.");
    var bytes = File.ReadAllBytes(path);
    Check(registry.CommitVerifiedRealm(two, second.AccountId, "crownlands", new string('b', 32), new[] { "fixture-site" }).Diagnostic == "AL-KINGDOM-NO-QUALIFIED-SITE", "Occupied site reused.");
    Check(!registry.CommitVerifiedRealm(one, second.AccountId, "crownlands", new string('b', 32), new[] { "other-fixture" }).Accepted, "Foreign principal accepted.");
    Check(bytes.SequenceEqual(File.ReadAllBytes(path)), "Rejected command changed file.");
    return Task.CompletedTask;
}));
Add("Legacy profile requires migration and login refresh preserves provisioned kingdom", () => Store(path =>
{
    var registry = new FileAccountRegistry(path);
    var principal = new VerifiedEmailPrincipal("test", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    var kingdom = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site" }).State.Kingdom;
    var updated = new VerifiedEmailPrincipal("test", "one", "updated@example.test", true);
    registry.ResolveVerifiedLogin(updated);
    Check(registry.ReadVerifiedKingdom(updated, account.AccountId).State.Kingdom.KingdomId == kingdom.KingdomId, "Login refresh lost kingdom.");
    var legacyPrincipal = new VerifiedEmailPrincipal("test", "legacy", "legacy@example.test", true);
    var legacy = registry.ResolveVerifiedLogin(legacyPrincipal).Record;
    registry.AttachOwnedProfile(legacyPrincipal, legacy.AccountId, legacy.Revision, "alp_" + new string('d', 32));
    var bytes = File.ReadAllBytes(path);
    Check(registry.CommitVerifiedRealm(legacyPrincipal, legacy.AccountId, "crownlands", new string('b', 32), new[] { "other-fixture" }).State.Status == AccountKingdomStatus.MigrationRequired, "Legacy save overwritten.");
    Check(bytes.SequenceEqual(File.ReadAllBytes(path)), "Legacy migration requirement changed file.");
    return Task.CompletedTask;
}));
Add("Authenticated kingdom command derives ownership and refuses unavailable placement", () => Store(async path =>
{
    var registry = new FileAccountRegistry(path); var mail = new CaptureEmail();
    var login = new EmailLoginAuthority(Policy(), registry, mail, () => 100);
    var challenge = await login.RequestAsync("one@example.test", "source", default);
    var session = login.Verify(challenge.Id, mail.Code, "source");
    var kingdoms = new KingdomAuthority(login, registry, KingdomPlacementCatalog.Unconfigured());
    Check(kingdoms.Read(session.Token).Status == AccountKingdomStatus.NeedsRealm, "New account needs realm.");
    var bytes = File.ReadAllBytes(path);
    Rejected(() => kingdoms.Commit(session.Token, "crownlands", new string('a', 32)), "AL-KINGDOM-PLACEMENT-UNAVAILABLE");
    Rejected(() => kingdoms.Commit(session.Token, "crownlands", "bad"), "AL-KINGDOM-COMMAND-INVALID");
    Check(bytes.SequenceEqual(File.ReadAllBytes(path)), "Unavailable placement mutated account.");
    login.Revoke(session.Token);
    Rejected(() => kingdoms.Read(session.Token), "AL-LOGIN-SESSION-REJECTED");
    Rejected(() => kingdoms.Commit(session.Token, "crownlands", new string('a', 32)), "AL-LOGIN-SESSION-REJECTED");
}));
Add("Host catalog binds valid realm sites; retries survive disabled placement", () => Store(async path =>
{
    string folder = Path.GetDirectoryName(path)!;
    string[] ids = { "crownlands", "stonehold", "eldergrove", "umbral" };
    string realmPath = Path.Combine(folder, "realms.json"), sitePath = Path.Combine(folder, "sites.json");
    File.WriteAllText(realmPath, JsonSerializer.Serialize(new { records = ids.Select(id => new { id, inner_realm_id = "inner_" + id }) }));
    // Fixture evidence only; these are NOT qualified game-world placements.
    var sites = ids.Select(id => new { id = "fixture-" + id, realmId = id, innerRealmId = "inner_" + id,
        qualification = "qualified", qualificationEvidence = "test-fixture-only", worldRevision = "fixture-revision", x = 0, y = 0, z = 0 }).ToArray();
    File.WriteAllText(sitePath, JsonSerializer.Serialize(new { version = 1, catalogId = "kingdom_inner_placement", runtimeEnabled = true, sites }));
    var placement = KingdomPlacementCatalog.Load(realmPath, sitePath);
    Rejected(() => placement.QualifiedSites("foreign"), "AL-KINGDOM-REALM-INVALID");
    var registry = new FileAccountRegistry(path); var mail = new CaptureEmail();
    var login = new EmailLoginAuthority(Policy(), registry, mail, () => 100);
    var challenge = await login.RequestAsync("one@example.test", "source", default);
    var session = login.Verify(challenge.Id, mail.Code, "source");
    var noProgress = new KingdomAuthority(login, registry, placement);
    var beforeCommit = File.ReadAllBytes(path);
    Rejected(() => noProgress.Commit(session.Token, "crownlands", new string('a', 32)), "AL-KINGDOM-PROGRESS-CONFIG-UNAVAILABLE");
    Check(beforeCommit.SequenceEqual(File.ReadAllBytes(path)), "Missing progress catalog partially registered kingdom.");
    var kingdoms = new KingdomAuthority(login, registry, placement, ProgressCatalog(folder));
    var state = kingdoms.Commit(session.Token, "crownlands", new string('a', 32));
    Check(state.Kingdom.AccountId == session.Account.AccountId && state.Kingdom.InnerRealmSiteId == "fixture-crownlands", "Server realm/site binding wrong.");
    var progress = kingdoms.ReadProgress(session.Token);
    Check(progress.Kingdom.KingdomId == state.Kingdom.KingdomId && progress.Resources["food"] == 7 && progress.Buildings.Single(row => row.Id == "town_hall").Level == 1,
        "Account-owned progress was not atomically provisioned.");
    var disabled = new KingdomAuthority(login, registry, KingdomPlacementCatalog.Unconfigured());
    Check(disabled.Commit(session.Token, "crownlands", new string('b', 32)).Kingdom.KingdomId == state.Kingdom.KingdomId, "Retry requires new placement.");
    Rejected(() => disabled.Commit(session.Token, "umbral", new string('c', 32)), "AL-KINGDOM-REALM-LOCKED");
    var invalid = File.ReadAllText(sitePath).Replace("inner_crownlands", "inner_umbral");
    File.WriteAllText(sitePath, invalid);
    try { KingdomPlacementCatalog.Load(realmPath, sitePath); throw new Exception("Cross-realm site accepted."); }
    catch (InvalidDataException) { }
}));
Add("Realm HTTP contract rejects client account and site fields", () =>
{
    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
    foreach (var field in new[] { "accountId", "profileId", "siteId", "sites" })
    {
        string json = "{\"realmId\":\"crownlands\",\"requestId\":\"" + new string('a', 32) + "\",\"" + field + "\":\"fake\"}";
        try { JsonSerializer.Deserialize<RealmCommitRequest>(json, options); throw new Exception("Client ownership field accepted."); }
        catch (JsonException) { }
    }
    return Task.CompletedTask;
});
Add("Phone adapter holds opaque bearer and rejects reconstructed presentation sessions", async () =>
{
    var codec = new WireCodec(); var wire = new FakeWire();
    var account = new AccountIdentityRecord("ala_" + new string('a', 32), "issuer", "subject", "one@example.test", "", 1);
    wire.Reply = (_, path, _, bearer, _) => Task.FromResult(new AccountHttpResponse(200,
        path.Contains("verify") ? codec.Encode(new { token = "secret-token", expiresAt = 1000L, account }) :
        codec.Encode(new { status = 0, account, kingdom = (object?)null })));
    using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await provider.VerifyCodeAsync("challenge", "123456", default);
    Check((await provider.ReadAsync(session, default)).Status == AccountKingdomStatus.NeedsRealm, "Adapter failed to read onboarding.");
    Check(wire.LastBearer == "secret-token", "Server credential missing.");
    int calls = wire.Calls;
    try { await provider.ReadAsync(new AccountLoginSession(account, session.ExpiresAt), default); throw new Exception("Forged view authorized."); }
    catch (AccountSessionExpiredException) { }
    Check(wire.Calls == calls, "Forged view reached network.");
    provider.ClearSession();
    try { await provider.ReadAsync(session, default); throw new Exception("Cleared view authorized."); }
    catch (AccountSessionExpiredException) { }
});
Add("Canceled verification cannot install a token after a late network response", async () =>
{
    var codec = new WireCodec(); var wire = new FakeWire();
    var response = new TaskCompletionSource<AccountHttpResponse>();
    wire.Reply = (_, _, _, _, _) => response.Task;
    using var provider = new HttpAccountProvider(wire, codec, () => 100);
    using var cancellation = new CancellationTokenSource();
    var task = provider.VerifyCodeAsync("challenge", "123456", cancellation.Token);
    cancellation.Cancel();
    response.SetResult(new AccountHttpResponse(200, codec.Encode(new { token = "secret-token", expiresAt = 1000L,
        account = new AccountIdentityRecord("ala_" + new string('a', 32), "issuer", "subject", "one@example.test", "", 1) })));
    try { await task; throw new Exception("Canceled verification published."); } catch (OperationCanceledException) { }
});
Add("Expired server session sends onboarding back to login instead of retrying commit", async () =>
{
    var codec = new WireCodec(); var wire = new FakeWire();
    wire.Reply = (_, path, _, _, _) => Task.FromResult(path.Contains("verify") ?
        new AccountHttpResponse(200, codec.Encode(new { token = "secret-token", expiresAt = 1000L,
            account = new AccountIdentityRecord("ala_" + new string('a', 32), "issuer", "subject", "one@example.test", "", 1) })) :
        new AccountHttpResponse(401, "private-error-text"));
    using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await provider.VerifyCodeAsync("challenge", "123456", default);
    using var onboarding = new KingdomOnboarding(provider, session, new[] { "crownlands" }, () => 100);
    await onboarding.LoadAsync();
    Check(onboarding.Read().Phase == KingdomOnboardingPhase.SessionExpired, "401 did not require sign-in.");
    int calls = wire.Calls;
    try { await provider.ReadAsync(session, default); throw new Exception("Revoked credential reused."); } catch (AccountSessionExpiredException) { }
    Check(wire.Calls == calls, "Revoked token reached server again.");
});
Add("Malformed response and foreign ownership do not become a phone kingdom", async () =>
{
    var codec = new WireCodec(); var wire = new FakeWire();
    var account = new AccountIdentityRecord("ala_" + new string('a', 32), "issuer", "subject", "one@example.test", "", 1);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200,
        codec.Encode(new { token = "secret-token", expiresAt = 1000L, account })));
    using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await provider.VerifyCodeAsync("challenge", "123456", default);
    foreach (string body in new[] { "{", new string('x', 32769), codec.Encode(new { account, kingdom = (object?)null }),
        codec.Encode(new { status = 0, account = new AccountIdentityRecord("ala_" + new string('b', 32), "issuer", "subject", "one@example.test", "", 1) }) })
    {
        wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, body));
        try { await provider.ReadAsync(session, default); throw new Exception("Invalid response accepted."); }
        catch (InvalidOperationException error) { Check(error.Message == "AL-ACCOUNT-RESPONSE-UNAVAILABLE", "Private data escaped."); }
    }
});
Add("Registry backup restores permanent account and committed kingdom without overwrite", () => Store(path =>
{
    var registry = new FileAccountRegistry(path);
    var principal = new VerifiedEmailPrincipal("test", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    var state = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site" }).State;
    string snapshotPath = Path.Combine(Path.GetDirectoryName(path)!, "verified-backup.xml");
    var receipt = registry.CreateVerifiedSnapshot(snapshotPath);
    Check(receipt.Accounts == 1 && receipt.Kingdoms == 1 && receipt.Version == 2 && receipt.Sha256.Length == 64, "Snapshot receipt incomplete.");
    Check(File.ReadAllBytes(path).SequenceEqual(File.ReadAllBytes(snapshotPath)), "Backup differs from registry.");
    registry.ResolveVerifiedLogin(new VerifiedEmailPrincipal("test", "one", "changed@example.test", true));
    var restored = new FileAccountRegistry(snapshotPath).ReadVerifiedKingdom(principal, account.AccountId).State;
    Check(restored.Account.VerifiedEmail == "one@example.test" && restored.Kingdom.KingdomId == state.Kingdom.KingdomId &&
        restored.Account.ProfileId == state.Account.ProfileId && restored.Kingdom.InnerRealmSiteId == "fixture-site", "Restore lost identity or ownership.");
    var saved = File.ReadAllBytes(snapshotPath);
    try { registry.CreateVerifiedSnapshot(snapshotPath); throw new Exception("Existing backup overwritten."); } catch (IOException) { }
    Check(saved.SequenceEqual(File.ReadAllBytes(snapshotPath)), "Existing backup changed.");
    return Task.CompletedTask;
}));
Add("Corrupt registry cannot produce a verified backup or reset account state", () => Store(path =>
{
    File.WriteAllText(path, "<accounts version=\"999\" />");
    var bytes = File.ReadAllBytes(path); string backup = Path.Combine(Path.GetDirectoryName(path)!, "backup.xml");
    try { new FileAccountRegistry(path).CreateVerifiedSnapshot(backup); throw new Exception("Unknown schema backed up as verified."); }
    catch (InvalidDataException) { }
    Check(!File.Exists(backup) && bytes.SequenceEqual(File.ReadAllBytes(path)), "Failure created backup or rewrote unknown data.");
    return Task.CompletedTask;
}));
Add("Kingdom progress survives restart, retries, mailbox changes and rejects foreign principals", () => Store(path =>
{
    var registry = new FileAccountRegistry(path);
    var principal = new VerifiedEmailPrincipal("fixture", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    var kingdom = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32),
        new[] { "fixture-site" }, ProgressSeed()).State.Kingdom;
    var restored = new FileAccountRegistry(path).ReadVerifiedKingdomProgress(principal, account.AccountId);
    Check(restored.Accepted && restored.Progress.Revision == 1 && restored.Progress.Resources["food"] == 7 &&
        restored.Progress.Resources["gold"] == 17 && restored.Progress.Kingdom.KingdomId == kingdom.KingdomId, "Restart lost progress.");
    registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('b', 32), Array.Empty<string>(), ProgressSeed(999));
    registry.ResolveVerifiedLogin(new VerifiedEmailPrincipal("fixture", "one", "changed@example.test", true));
    Check(registry.ReadVerifiedKingdomProgress(principal, account.AccountId).Progress.Resources["food"] == 7, "Retry or login reset balances.");
    var foreign = new VerifiedEmailPrincipal("fixture", "foreign", "foreign@example.test", true);
    Check(registry.ReadVerifiedKingdomProgress(foreign, account.AccountId).Diagnostic == "AL-ACCOUNT-PRINCIPAL-MISMATCH", "Foreign account read accepted.");
    return Task.CompletedTask;
}));
Add("Old v2 registry migrates without resetting old kingdoms or downgrading v3", () => Store(path =>
{
    var registry = new FileAccountRegistry(path);
    var oldPrincipal = new VerifiedEmailPrincipal("fixture", "old", "old@example.test", true);
    var oldAccount = registry.ResolveVerifiedLogin(oldPrincipal).Record;
    var oldKingdom = registry.CommitVerifiedRealm(oldPrincipal, oldAccount.AccountId, "stonehold", new string('a', 32), new[] { "old-site" }).State.Kingdom;
    var oldBytes = File.ReadAllBytes(path);
    Check(new FileAccountRegistry(path).ReadVerifiedKingdomProgress(oldPrincipal, oldAccount.AccountId).Diagnostic ==
        "AL-KINGDOM-PROGRESS-MIGRATION-REQUIRED" && oldBytes.SequenceEqual(File.ReadAllBytes(path)), "Old read wrote guessed progress.");
    string backup = Path.Combine(Path.GetDirectoryName(path)!, "old-v2-backup.xml"); registry.CreateVerifiedSnapshot(backup);
    var freshPrincipal = new VerifiedEmailPrincipal("fixture", "new", "new@example.test", true);
    var fresh = registry.ResolveVerifiedLogin(freshPrincipal).Record;
    registry.CommitVerifiedRealm(freshPrincipal, fresh.AccountId, "crownlands", new string('b', 32), new[] { "new-site" }, ProgressSeed());
    var automaticBackups = Directory.GetFiles(Path.GetDirectoryName(path)!, Path.GetFileName(path) + ".migration-v2-*.xml");
    Check(automaticBackups.Length == 1 && new FileAccountRegistry(automaticBackups[0]).ReadVerifiedKingdom(oldPrincipal, oldAccount.AccountId).State.Kingdom.KingdomId == oldKingdom.KingdomId,
        "Schema upgrade lacked a restorable automatic backup.");
    var reloaded = new FileAccountRegistry(path);
    Check(reloaded.ReadVerifiedKingdom(oldPrincipal, oldAccount.AccountId).State.Kingdom.KingdomId == oldKingdom.KingdomId &&
        reloaded.ReadVerifiedKingdomProgress(oldPrincipal, oldAccount.AccountId).Diagnostic == "AL-KINGDOM-PROGRESS-MIGRATION-REQUIRED" &&
        reloaded.ReadVerifiedKingdomProgress(freshPrincipal, fresh.AccountId).Progress.Resources["food"] == 7, "Migration lost or fabricated old progress.");
    var thirdPrincipal = new VerifiedEmailPrincipal("fixture", "third", "third@example.test", true);
    var third = reloaded.ResolveVerifiedLogin(thirdPrincipal).Record;
    reloaded.CommitVerifiedRealm(thirdPrincipal, third.AccountId, "umbral", new string('c', 32), new[] { "third-site" });
    Check(File.ReadAllText(path).Contains("version=\"3\"") && new FileAccountRegistry(path).ReadVerifiedKingdomProgress(freshPrincipal, fresh.AccountId).Accepted,
        "Older API downgraded schema or lost progress.");
    Check(oldBytes.SequenceEqual(File.ReadAllBytes(backup)) && new FileAccountRegistry(backup).ReadVerifiedKingdom(oldPrincipal, oldAccount.AccountId).Accepted,
        "Old snapshot cannot be restored.");
    return Task.CompletedTask;
}));
Add("v3 backup restores progress with ownership, balances and buildings", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    var kingdom = registry.CommitVerifiedRealm(principal, account.AccountId, "eldergrove", new string('a', 32), new[] { "fixture-site" }, ProgressSeed()).State.Kingdom;
    string backup = Path.Combine(Path.GetDirectoryName(path)!, "v3-backup.xml");
    var receipt = registry.CreateVerifiedSnapshot(backup);
    var restored = new FileAccountRegistry(backup).ReadVerifiedKingdomProgress(principal, account.AccountId).Progress;
    Check(receipt.Version == 3 && receipt.ProgressRecords == 1 && restored.Kingdom.ProfileId == kingdom.ProfileId && restored.Resources["stone"] == 13 &&
        restored.Buildings.Single(row => row.Id == "town_hall").Level == 1, "Progress restore failed.");
    return Task.CompletedTask;
}));
Add("Corrupt progress and oathmark balances fail closed without rewriting", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    registry.CommitVerifiedRealm(principal, account.AccountId, "umbral", new string('a', 32), new[] { "fixture-site" }, ProgressSeed());
    string valid = File.ReadAllText(path);
    foreach (var corrupt in new[] { valid.Replace("id=\"food\" amount=\"7\"", "id=\"food\" amount=\"-1\""),
        valid.Replace("id=\"gold\"", "id=\"oathmarks\""), valid.Replace("revision=\"1\"", "revision=\"0\"") })
    {
        File.WriteAllText(path, corrupt); var bytes = File.ReadAllBytes(path);
        try { registry.ReadVerifiedKingdomProgress(principal, account.AccountId); throw new Exception("Corrupt progress accepted."); }
        catch (InvalidDataException) { }
        Check(bytes.SequenceEqual(File.ReadAllBytes(path)), "Corrupt progress was replaced.");
    }
    return Task.CompletedTask;
}));
Add("Catalog seed bounds prevent illegal resources, duplicate buildings and client mutation", () =>
{
    var resources = new Dictionary<string, long> { ["food"] = 1, ["wood"] = 2, ["stone"] = 3, ["gold"] = 4 };
    var seed = new KingdomProgressSeed("fixture", resources, new[] { new KingdomBuildingLevel("town_hall", 1) });
    resources["food"] = 999; Check(seed.Resources["food"] == 1, "Seed retained mutable input.");
    foreach (string invalid in new[] { "negative", "oathmarks", "duplicate" })
    {
        var balances = new Dictionary<string, long> { ["food"] = 1, ["wood"] = 2, ["stone"] = 3, ["gold"] = 4 };
        if (invalid == "negative") balances["food"] = -1;
        if (invalid == "oathmarks") { balances.Remove("gold"); balances.Add("oathmarks", 4); }
        var buildings = invalid == "duplicate" ? new[] { new KingdomBuildingLevel("town_hall", 1), new KingdomBuildingLevel("town_hall", 2) } : new[] { new KingdomBuildingLevel("town_hall", 1) };
        try { new KingdomProgressSeed("fixture", balances, buildings); throw new Exception("Invalid seed accepted."); } catch (ArgumentException) { }
    }
    return Task.CompletedTask;
});
Add("Progress catalogs reject unknown buildings and disabled catalogs cannot provision", () => Store(path =>
{
    string folder = Path.GetDirectoryName(path)!;
    var disabled = ProgressCatalog(folder, false);
    Rejected(() => disabled.RequireSeed(), "AL-KINGDOM-PROGRESS-CONFIG-UNAVAILABLE");
    string seedPath = Path.Combine(folder, "progress.json"), definitionsPath = Path.Combine(folder, "buildings.json");
    string valid = File.ReadAllText(seedPath);
    foreach (string invalid in new[] { valid.Replace("town_hall", "unknown_building"), valid.Replace("\"level\":1", "\"level\":11") })
    {
        File.WriteAllText(seedPath, invalid);
        try { KingdomProgressCatalog.Load(seedPath, definitionsPath); throw new Exception("Invalid building seed accepted."); }
        catch (InvalidDataException) { }
    }
    return Task.CompletedTask;
}));
Add("Client progress response is account-bound, preserves balances and rejects copied sessions", async () =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    wire.Reply = (method, path, body, token, _) =>
    {
        Check(method == "GET" && path == "/v1/account/kingdom/progress" && body == null && token == "secret-token", "Progress request escaped its authenticated route.");
        return Task.FromResult(new AccountHttpResponse(200, codec.Encode(ProgressWire())));
    };
    var progress = await provider.ReadProgressAsync(session, ClientKingdom(), default);
    Check(progress.Resources["food"] == 7 && progress.Buildings.Single().Level == 1 && progress.Kingdom.ProfileId == ClientKingdom().ProfileId,
        "Client progress values/binding incorrect.");
    int calls = wire.Calls;
    try { await provider.ReadProgressAsync(new AccountLoginSession(session.Account, session.ExpiresAt), ClientKingdom(), default); throw new Exception("Copied session authorized progress."); }
    catch (AccountSessionExpiredException) { }
    Check(wire.Calls == calls, "Copied session sent request.");
});
Add("Client rejects foreign or malformed progress without inventing defaults", async () =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    var mutations = new Action<HttpAccountProvider.KingdomProgressDto>[]
    {
        row => row.version = -1, row => row.revision = 0,
        row => row.kingdom.accountId = "ala_" + new string('d', 32), row => row.kingdom.profileId = "alp_" + new string('d', 32),
        row => row.kingdom.realmId = "umbral", row => row.kingdom.innerRealmSiteId = "foreign-site",
        row => row.resources[0].amount = null!, row => row.resources[0].amount = "-1", row => row.resources[0].amount = "1000000000001",
        row => row.resources[0].id = "oathmarks", row => row.resources[0].id = "gold",
        row => row.buildings[0].level = null!, row => row.buildings = new[] { row.buildings[0], row.buildings[0] }
    };
    foreach (var mutate in mutations)
    {
        var row = ProgressWire(); mutate(row);
        wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(row)));
        try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Invalid progress accepted."); }
        catch (InvalidOperationException error) { Check(error.Message == "AL-ACCOUNT-RESPONSE-UNAVAILABLE", "Private wire values leaked."); }
    }
});
Add("Client progress revisions cannot regress or change values without a new revision", async () =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    var row = ProgressWire(2);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(row)));
    await provider.ReadProgressAsync(session, ClientKingdom(), default);
    row = ProgressWire(1);
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Old revision accepted."); } catch (InvalidOperationException) { }
    row = ProgressWire(2); row.resources[0].amount = "999";
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Conflicting revision accepted."); } catch (InvalidOperationException) { }
    row = ProgressWire(3); row.resources[0].amount = "999";
    Check((await provider.ReadProgressAsync(session, ClientKingdom(), default)).Resources["food"] == 999, "New revision did not advance.");
});
Add("Late progress response cannot survive cleared session or canceled load", async () =>
{
    foreach (bool cancel in new[] { false, true })
    {
        var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
        var session = await ClientLogin(provider, wire, codec); using var cancellation = new CancellationTokenSource();
        var pending = new TaskCompletionSource<AccountHttpResponse>(); wire.Reply = (_, _, _, _, _) => pending.Task;
        var read = provider.ReadProgressAsync(session, ClientKingdom(), cancellation.Token);
        if (cancel) cancellation.Cancel(); else provider.ClearSession();
        pending.SetResult(new AccountHttpResponse(200, codec.Encode(ProgressWire())));
        try { await read; throw new Exception("Late progress published."); }
        catch (OperationCanceledException) when (cancel) { }
        catch (AccountSessionExpiredException) when (!cancel) { }
    }
});
Add("Progress migration and expired sessions remain separate from malformed responses", async () =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(409, "{\"code\":\"AL-KINGDOM-PROGRESS-MIGRATION-REQUIRED\"}"));
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Migration fabricated a progress result."); } catch (AccountKingdomProgressMigrationException) { }
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(401, "private-backend-error"));
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Expired progress accepted."); } catch (AccountSessionExpiredException) { }
    int calls = wire.Calls;
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Expired session reused."); } catch (AccountSessionExpiredException) { }
    Check(wire.Calls == calls, "Expired session reached network again.");
});
Add("Server progress DTO serializes all required wire fields and round trips to client", () => Store(async path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record;
    var kingdom = registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site" }, ProgressSeed()).State.Kingdom;
    var progress = registry.ReadVerifiedKingdomProgress(principal, account.AccountId).Progress;
    string json = JsonSerializer.Serialize(HttpAccountProvider.KingdomProgressDto.FromProgress(progress), new JsonSerializerOptions { IncludeFields = true });
    if (args.Length == 1) File.WriteAllText(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0]))!, "PROGRESS_WIRE_FIXTURE.json"), json);
    using var document = JsonDocument.Parse(json);
    Check(document.RootElement.GetProperty("version").GetInt32() == 1 && document.RootElement.GetProperty("resources").GetArrayLength() == 4, "Fields disappeared during endpoint serialization.");
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(new { token = "secret-token", expiresAt = 1000L,
        account = registry.ReadVerifiedAccount(principal, account.AccountId).Record })));
    var session = await provider.VerifyCodeAsync("challenge", "123456", default);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, json));
    Check((await provider.ReadProgressAsync(session, kingdom, default)).Resources["gold"] == 17, "Server wire cannot be read by client.");
}));
Add("Construction start charges once and completion grants one level across restart; v3 backup restores", () => Store(path =>
{
    var principal = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true);
    var registry = new FileAccountRegistry(path); var account = registry.ResolveVerifiedLogin(principal).Record;
    registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('b', 32), new[] { "site" }, ProgressSeed());
    byte[] v3 = File.ReadAllBytes(path);
    var quote = new KingdomConstructionQuote("fixture-build-v1", "farm", 0, 60,
        new Dictionary<string, long> { ["food"] = 2, ["wood"] = 3, ["stone"] = 4, ["gold"] = 5 });
    string request = new string('c', 32);
    var started = registry.StartVerifiedConstruction(principal, account.AccountId, request, "farm", 1, 100, (_, _) => quote);
    Check(started.Accepted && started.Progress.Revision == 2 && started.Progress.Resources["food"] == 5 &&
        started.Progress.Buildings.Single(b => b.Id == "farm").Level == 0, "Start did not atomically charge without granting level.");
    string backup = Directory.GetFiles(Path.GetDirectoryName(path)!, "accounts.xml.migration-v3-*.xml").Single();
    Check(v3.SequenceEqual(File.ReadAllBytes(backup)), "Pre-upgrade snapshot changed.");
    Check(new FileAccountRegistry(backup).ReadVerifiedKingdomProgress(principal, account.AccountId).Progress.Resources["food"] == 7,
        "Old save failed to load.");
    registry = new FileAccountRegistry(path);
    var retry = registry.StartVerifiedConstruction(principal, account.AccountId, request, "farm", 1, 200, (_, _) => throw new Exception("Retry consulted changed catalog."));
    Check(retry.Accepted && retry.Progress.Revision == 2 && retry.Jobs.Single().DueAt == 160, "Retry charged or retimed job.");
    Check(registry.CompleteVerifiedConstruction(principal, account.AccountId, request, 159).Diagnostic == "AL-CONSTRUCTION-NOT-DUE", "Completed early.");
    var done = registry.CompleteVerifiedConstruction(principal, account.AccountId, request, 160);
    Check(done.Accepted && done.Progress.Revision == 3 && done.Progress.Buildings.Single(b => b.Id == "farm").Level == 1, "Due job not granted.");
    registry = new FileAccountRegistry(path);
    Check(registry.CompleteVerifiedConstruction(principal, account.AccountId, request, 200).Progress.Revision == 3, "Completion repeated.");
    Check(registry.StartVerifiedConstruction(principal, account.AccountId, request, "farm", 1, 200, (_, _) => quote).Progress.Revision == 3, "Old start receipt reused reward.");
    return Task.CompletedTask;
}));
Add("Construction rejects foreign ownership, conflicting receipts, stale revisions, busy and insufficient resources without mutation", () => Store(path =>
{
    var p = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true);
    var registry = new FileAccountRegistry(path); var a = registry.ResolveVerifiedLogin(p).Record;
    registry.CommitVerifiedRealm(p, a.AccountId, "crownlands", new string('b', 32), new[] { "site" }, ProgressSeed());
    var quote = new KingdomConstructionQuote("fixture", "farm", 0, 60,
        new Dictionary<string, long> { ["food"] = 8, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    byte[] original = File.ReadAllBytes(path); string request = new string('c', 32);
    Check(registry.StartVerifiedConstruction(new("fixture", "other", "other@example.test", true), a.AccountId, request, "farm", 1, 100, (_, _) => quote).Diagnostic == "AL-ACCOUNT-PRINCIPAL-MISMATCH", "Foreign start accepted.");
    Check(registry.StartVerifiedConstruction(p, a.AccountId, request, "farm", 2, 100, (_, _) => quote).Diagnostic == "AL-KINGDOM-PROGRESS-CONFLICT", "Stale start accepted.");
    Check(registry.StartVerifiedConstruction(p, a.AccountId, request, "farm", 1, 100, (_, _) => quote).Diagnostic == "AL-CONSTRUCTION-RESOURCES-INSUFFICIENT", "Overspend accepted.");
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Rejected commands changed save.");
    quote = new("fixture", "farm", 0, 60, new Dictionary<string, long> { ["food"] = 0, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    Check(registry.StartVerifiedConstruction(p, a.AccountId, request, "farm", 1, 100, (_, _) => quote).Accepted, "Start rejected.");
    original = File.ReadAllBytes(path);
    Check(registry.StartVerifiedConstruction(p, a.AccountId, request, "town_hall", 2, 100, (_, _) => quote).Diagnostic == "AL-CONSTRUCTION-REQUEST-CONFLICT", "Receipt conflict accepted.");
    Check(registry.StartVerifiedConstruction(p, a.AccountId, new string('d', 32), "farm", 2, 100, (_, _) => quote).Diagnostic == "AL-CONSTRUCTION-BUSY", "Second job accepted.");
    Check(registry.CompleteVerifiedConstruction(p, a.AccountId, new string('e', 32), 200).Diagnostic == "AL-CONSTRUCTION-JOB-MISSING", "Unknown completion accepted.");
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Rejected active-job commands changed save.");
    return Task.CompletedTask;
}));
Add("Construction catalog validates exact building levels, four resource costs, duration and disabled configuration", () => Store(path =>
{
    string folder = Path.GetDirectoryName(path)!; ProgressCatalog(folder);
    string construction = Path.Combine(folder, "construction.json"), buildings = Path.Combine(folder, "buildings.json");
    string Json(bool enabled, int from = 0, long duration = 60, string resource = "gold") => JsonSerializer.Serialize(new {
        version = 1, catalogId = "kingdom_construction", runtimeEnabled = enabled, revision = "fixture", upgrades = new[] {
            new { buildingId = "farm", fromLevel = from, durationSeconds = duration,
                costs = new Dictionary<string, long> { ["food"] = 1, ["wood"] = 2, ["stone"] = 3, [resource] = 4 } } } });
    File.WriteAllText(construction, Json(true)); var catalog = KingdomConstructionCatalog.Load(construction, buildings);
    Check(catalog.RequireQuote("farm", 0).Costs["gold"] == 4, "Catalog quote mismatch.");
    Rejected(() => catalog.RequireQuote("farm", 1), "AL-CONSTRUCTION-UPGRADE-UNAVAILABLE");
    File.WriteAllText(construction, Json(false));
    Rejected(() => KingdomConstructionCatalog.Load(construction, buildings).RequireQuote("farm", 0), "AL-CONSTRUCTION-CONFIG-UNAVAILABLE");
    foreach (string invalid in new[] { Json(true, 10), Json(true, -1), Json(true, 0, 0), Json(true, 0, 60, "oathmarks") })
    { File.WriteAllText(construction, invalid); try { KingdomConstructionCatalog.Load(construction, buildings); throw new Exception("Invalid construction catalog loaded."); } catch (InvalidDataException) { } }
    return Task.CompletedTask;
}));
Add("Construction malformed saves fail closed; current snapshot restores jobs and progress", () => Store(path =>
{
    var p = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true);
    var registry = new FileAccountRegistry(path); var a = registry.ResolveVerifiedLogin(p).Record;
    registry.CommitVerifiedRealm(p, a.AccountId, "crownlands", new string('b', 32), new[] { "site" }, ProgressSeed());
    var quote = new KingdomConstructionQuote("fixture", "farm", 0, 60,
        new Dictionary<string, long> { ["food"] = 0, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    registry.StartVerifiedConstruction(p, a.AccountId, new string('c', 32), "farm", 1, 100, (_, _) => quote);
    var snapshot = registry.CreateVerifiedSnapshot(Path.Combine(Path.GetDirectoryName(path)!, "snapshot.xml"));
    Check(snapshot.Version == 16 && snapshot.ConstructionRecords == 1, "Snapshot omitted construction receipt.");
    Check(new FileAccountRegistry(snapshot.Path).ReadVerifiedConstruction(p, a.AccountId).Jobs.Single().DueAt == 160, "Snapshot lost timer.");
    string original = File.ReadAllText(path);
    foreach (string corrupted in new[] { original.Replace("due=\"160\"", "due=\"159\""), original.Replace("completed=\"0\"", "completed=\"1\""),
        original.Replace("duration=\"60\"", "duration=\"0\""), original.Replace("<cost id=\"gold\"", "<cost id=\"oathmarks\"") })
    {
        File.WriteAllText(path, corrupted);
        try { registry.ReadVerifiedConstruction(p, a.AccountId); throw new Exception("Corrupted construction save accepted."); } catch (InvalidDataException) { }
        Check(File.ReadAllText(path) == corrupted, "Malformed read reset save.");
    }
    File.WriteAllText(path, original); return Task.CompletedTask;
}));
Add("Authenticated construction authority survives catalog disable on retry, uses server clock and rejects revoked sessions", () => Store(async path =>
{
    long now = 100; var registry = new FileAccountRegistry(path); var mail = new CaptureEmail();
    var login = new EmailLoginAuthority(Policy(), registry, mail, () => now);
    var challenge = await login.RequestAsync("builder@example.test", "source", default);
    var session = login.Verify(challenge.Id, mail.Code, "source");
    registry.CommitVerifiedRealm(new VerifiedEmailPrincipal(session.Account.Issuer, session.Account.Subject,
        session.Account.VerifiedEmail, true), session.Account.AccountId, "crownlands", new string('b', 32), new[] { "site" }, ProgressSeed());
    string folder = Path.GetDirectoryName(path)!; ProgressCatalog(folder);
    string catalogPath = Path.Combine(folder, "construction.json");
    File.WriteAllText(catalogPath, "{\"version\":1,\"catalogId\":\"kingdom_construction\",\"runtimeEnabled\":true,\"revision\":\"fixture\",\"upgrades\":[{\"buildingId\":\"farm\",\"fromLevel\":0,\"durationSeconds\":60,\"costs\":{\"food\":1,\"wood\":0,\"stone\":0,\"gold\":0}}]}");
    var authority = new KingdomConstructionAuthority(login, registry, KingdomConstructionCatalog.Load(catalogPath, Path.Combine(folder, "buildings.json")), () => now);
    string request = new string('c', 32);
    var shown = authority.Preview(session.Token, "farm");
    Check(shown.Progress.revision == 1 && shown.FromLevel == "0" && shown.TargetLevel == "1" && shown.DurationSeconds == "60" &&
        shown.Costs.Single(c => c.id == "food").amount == "1", "Authority preview lost saved level or quoted terms.");
    if (args.Length == 1) File.WriteAllText(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0]))!, "CONSTRUCTION_PREVIEW_WIRE_FIXTURE.json"),
        JsonSerializer.Serialize(shown, new JsonSerializerOptions { IncludeFields = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase }));
    var start = authority.Start(session.Token, request, "farm", 1, shown.Fingerprint);
    Check(start.jobs.Single().dueAt == "160", "Authority did not use server time.");
    var disabled = new KingdomConstructionAuthority(login, new FileAccountRegistry(path), KingdomConstructionCatalog.Unconfigured(), () => now);
    Check(disabled.Start(session.Token, request, "farm", 1).progress.revision == 2, "Disabled catalog invalidated durable retry.");
    Rejected(() => disabled.Complete(session.Token, request), "AL-CONSTRUCTION-NOT-DUE"); now = 160;
    var complete = disabled.Complete(session.Token, request);
    Check(complete.jobs.Single().completed == "1" && complete.progress.revision == 3, "Completion required current catalog or failed.");
    var options = new JsonSerializerOptions { IncludeFields = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
    using var wire = JsonDocument.Parse(JsonSerializer.Serialize(complete, options));
    Check(wire.RootElement.GetProperty("progress").GetProperty("resources").GetArrayLength() == 4, "Construction wire dropped progress fields.");
    Check(disabled.Read(session.Token).jobs.Length == 0, "Read returned unbounded history.");
    login.Revoke(session.Token);
    Rejected(() => disabled.Complete(session.Token, request), "AL-LOGIN-SESSION-REJECTED");
}));
Add("Authenticated construction server DTO round trips through client start retry read completion and logout", () => Store(async path =>
{
    long now = 100; var registry = new FileAccountRegistry(path); var mail = new CaptureEmail();
    var login = new EmailLoginAuthority(Policy(), registry, mail, () => now);
    var challenge = await login.RequestAsync("builder@example.test", "source", default);
    var serverSession = login.Verify(challenge.Id, mail.Code, "source");
    var p = new VerifiedEmailPrincipal(serverSession.Account.Issuer, serverSession.Account.Subject, serverSession.Account.VerifiedEmail, true);
    var kingdom = registry.CommitVerifiedRealm(p, serverSession.Account.AccountId, "crownlands", new string('b', 32), new[] { "site" }, ProgressSeed()).State.Kingdom;
    string folder = Path.GetDirectoryName(path)!; ProgressCatalog(folder); string catalogPath = Path.Combine(folder, "construction.json");
    File.WriteAllText(catalogPath, "{\"version\":1,\"catalogId\":\"kingdom_construction\",\"runtimeEnabled\":true,\"revision\":\"fixture\",\"upgrades\":[{\"buildingId\":\"farm\",\"fromLevel\":0,\"durationSeconds\":60,\"costs\":{\"food\":1,\"wood\":0,\"stone\":0,\"gold\":0}}]}");
    var authority = new KingdomConstructionAuthority(login, registry, KingdomConstructionCatalog.Load(catalogPath, Path.Combine(folder, "buildings.json")), () => now);
    var codec = new WireCodec(); var wire = new FakeWire(); using var client = new HttpAccountProvider(wire, codec, () => now);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(serverSession)));
    var session = await client.VerifyCodeAsync(challenge.Id, mail.Code, default);
    wire.Reply = (method, endpoint, json, bearer, _) =>
    {
        Check(bearer == serverSession.Token, "Construction lost private bearer.");
        try
        {
            HttpAccountProvider.ConstructionStateDto result;
            if (endpoint.EndsWith("/start"))
            { var command = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json); result = authority.Start(bearer, command.requestId, command.buildingId, command.expectedRevision); }
            else if (endpoint.EndsWith("/complete"))
            { var command = codec.Decode<HttpAccountProvider.ConstructionCompleteDto>(json); result = authority.Complete(bearer, command.requestId); }
            else { Check(method == "GET", "Read used wrong method."); result = authority.Read(bearer); }
            return Task.FromResult(new AccountHttpResponse(200, codec.Encode(result)));
        }
        catch (LoginServiceException error) { return Task.FromResult(new AccountHttpResponse(error.Status, codec.Encode(new { code = error.Code }))); }
    };
    string request = new string('c', 32);
    var started = await client.StartConstructionAsync(session, kingdom, request, "farm", 1, default);
    Check(started.Progress.Resources["food"] == 6 && started.Jobs.Single().DueAt == 160, "Client lost committed costs/time.");
    Check((await client.StartConstructionAsync(session, kingdom, request, "farm", 1, default)).Progress.Revision == 2, "Retry changed state.");
    Check((await client.ReadConstructionAsync(session, kingdom, default)).Jobs.Single().RequestId == request, "Read lost job.");
    try { await client.CompleteConstructionAsync(session, kingdom, request, default); throw new Exception("Early complete accepted."); }
    catch (AccountKingdomConstructionException error) { Check(error.Diagnostic == "AL-CONSTRUCTION-NOT-DUE", "Early complete became generic or leaked error."); }
    now = 160; var done = await client.CompleteConstructionAsync(session, kingdom, request, default);
    Check(done.Progress.Buildings.Single(b => b.Id == "farm").Level == 1 && done.Jobs.Single().Completed, "Client lost complete grant.");
    if (args.Length == 1) File.WriteAllText(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0]))!, "CONSTRUCTION_WIRE_FIXTURE.json"), codec.Encode(authority.Complete(serverSession.Token, request)));
    Check((await client.ReadConstructionAsync(session, kingdom, default)).Jobs.Count == 0, "Completed history leaked into read.");
    login.Revoke(serverSession.Token);
    try { await client.ReadConstructionAsync(session, kingdom, default); throw new Exception("Revoked construction session accepted."); } catch (AccountSessionExpiredException) { }
    int calls = wire.Calls;
    try { await client.ReadConstructionAsync(session, kingdom, default); throw new Exception("Revoked session reused."); } catch (AccountSessionExpiredException) { }
    Check(wire.Calls == calls, "Expired construction reached network again.");
}));
Add("Construction client rejects missing malformed foreign and mismatched jobs before caching", async () =>
{
    Action<HttpAccountProvider.ConstructionStateDto>[] changes = {
        row => row.version = -1, row => row.serverNow = null!, row => row.jobs = null!, row => row.progress.kingdom.accountId = "ala_" + new string('d',32),
        row => row.jobs[0].fromLevel = null!, row => row.jobs[0].targetLevel = "3", row => row.jobs[0].startedAt = null!,
        row => row.jobs[0].dueAt = "99", row => row.jobs[0].completed = null!, row => row.jobs[0].catalogRevision = "",
        row => row.jobs[0].costs[0].amount = null!, row => row.jobs[0].costs[3].id = "oathmarks",
        row => row.jobs[0].requestId = new string('d',32), row => row.jobs[0].buildingId = "farm",
        row => row.jobs = new[] { row.jobs[0], row.jobs[0] }, row => row.progress.buildings[0].level = "2" };
    foreach (var change in changes)
    {
        var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
        var session = await ClientLogin(provider, wire, codec); var malformed = ConstructionWire(); change(malformed);
        wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(malformed)));
        try { await provider.StartConstructionAsync(session, ClientKingdom(), new string('c',32), "town_hall", 1, default); throw new Exception("Malformed job accepted."); }
        catch (InvalidOperationException error) { Check(error.Message == "AL-ACCOUNT-RESPONSE-UNAVAILABLE", "Malformed job leaked content."); }
        wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(ConstructionWire())));
        Check((await provider.StartConstructionAsync(session, ClientKingdom(), new string('c',32), "town_hall", 1, default)).Progress.Revision == 2, "Bad response poisoned cache.");
    }
});
Add("Construction response cannot rewrite active quote or regress shared progress; canceled and signed-out late replies do not publish", async () =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(ConstructionWire())));
    await provider.ReadConstructionAsync(session, ClientKingdom(), default);
    var changed = ConstructionWire(); changed.jobs[0].dueAt = "161";
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(changed)));
    try { await provider.ReadConstructionAsync(session, ClientKingdom(), default); throw new Exception("Saved timer rewritten."); } catch (InvalidOperationException) { }
    var stale = ProgressWire(1); wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(stale)));
    try { await provider.ReadProgressAsync(session, ClientKingdom(), default); throw new Exception("Construction progress regressed."); } catch (InvalidOperationException) { }
    var pending = new TaskCompletionSource<AccountHttpResponse>(); wire.Reply = (_, _, _, _, _) => pending.Task;
    using var canceled = new CancellationTokenSource(); var late = provider.ReadConstructionAsync(session, ClientKingdom(), canceled.Token);
    canceled.Cancel(); pending.SetResult(new AccountHttpResponse(200, codec.Encode(ConstructionWire(3, true))));
    try { await late; throw new Exception("Canceled state published."); } catch (OperationCanceledException) { }
    pending = new(); wire.Reply = (_, _, _, _, _) => pending.Task;
    late = provider.ReadConstructionAsync(session, ClientKingdom(), default); provider.ClearSession();
    pending.SetResult(new AccountHttpResponse(200, codec.Encode(ConstructionWire())));
    try { await late; throw new Exception("Signed-out state published."); } catch (AccountSessionExpiredException) { }
});
Add("Construction flow journals before sending and reuses original request across uncertain outcome and restart", () => Store(async path =>
{
    string folder = Path.GetDirectoryName(path)!; var journal = new FileConstructionIntentStore(folder);
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec); var kingdom = ClientKingdom(); double ticks = 10;
    HttpAccountProvider.ConstructionStateDto Empty() => new() { version = 1, serverNow = "100", progress = ProgressWire(), jobs = Array.Empty<HttpAccountProvider.ConstructionJobDto>() };
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(Empty())));
    var flow = new AccountConstructionFlow(provider, journal, session, kingdom, new[] { "town_hall" }, () => 100, () => ticks);
    await flow.LoadAsync(); string sentId = "";
    wire.Reply = (_, _, json, _, _) =>
    {
        var sent = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json); sentId = sent.requestId;
        Check(journal.Read(kingdom.AccountId, kingdom.KingdomId)?.RequestId == sentId, "Request sent before durable journal.");
        return Task.FromException<AccountHttpResponse>(new IOException("private-network-error"));
    };
    await flow.StartAsync("town_hall");
    Check(flow.Snapshot.Phase == AccountConstructionPhase.PendingRetry && flow.Snapshot.Pending.RequestId == sentId, "Ambiguous start lost intent.");
    flow.Dispose();
    flow = new(provider, new FileConstructionIntentStore(folder), session, kingdom, new[] { "town_hall" }, () => 100, () => ticks);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(Empty())));
    await flow.LoadAsync(); Check(flow.Snapshot.Phase == AccountConstructionPhase.PendingRetry, "Restart ignored pending request.");
    int calls = wire.Calls;
    try { await flow.StartAsync("town_hall"); throw new Exception("New start replaced uncertain request."); } catch (InvalidOperationException) { }
    Check(wire.Calls == calls, "Pending request allowed a new mutation.");
    wire.Reply = (_, _, json, _, _) =>
    {
        var sent = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json);
        Check(sent.requestId == sentId && sent.expectedRevision == 1, "Retry replaced nonce or original revision.");
        var result = ConstructionWire(); result.jobs[0].requestId = sentId;
        return Task.FromResult(new AccountHttpResponse(200, codec.Encode(result)));
    };
    await flow.RetryPendingAsync(); Check(flow.Snapshot.Phase == AccountConstructionPhase.Ready && flow.Snapshot.Pending == null &&
        journal.Read(kingdom.AccountId, kingdom.KingdomId) == null, "Acknowledged intent remained blocking.");
    Check(flow.RemainingSeconds == 60, "Saved timer not presented."); ticks = 130;
    Check(flow.RemainingSeconds == 0 && flow.Snapshot.State.Progress.Buildings[0].Level == 1, "Client timer granted a level.");
    wire.Reply = (_, _, json, _, _) =>
    {
        Check(codec.Decode<HttpAccountProvider.ConstructionCompleteDto>(json).requestId == sentId, "Completion used new receipt.");
        var result = ConstructionWire(3, true); result.jobs[0].requestId = sentId;
        return Task.FromResult(new AccountHttpResponse(200, codec.Encode(result)));
    };
    await flow.CompleteAsync(); Check(flow.Snapshot.State.Progress.Buildings[0].Level == 2, "Server completion not presented.");
    flow.Dispose();
}));
Add("Construction flow observes accepted active receipt on restart without resending a mutation", () => Store(async path =>
{
    var journal = new FileConstructionIntentStore(Path.GetDirectoryName(path)!); var k = ClientKingdom();
    var intent = new ConstructionIntent(k.AccountId, k.KingdomId, new string('c',32), "town_hall", 1); journal.Save(intent);
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    wire.Reply = (method, endpoint, _, _, _) =>
    { Check(method == "GET" && endpoint.EndsWith("/construction"), "Startup submitted a mutation."); return Task.FromResult(new AccountHttpResponse(200, codec.Encode(ConstructionWire()))); };
    using var flow = new AccountConstructionFlow(provider, journal, session, k, new[] { "town_hall" }, () => 100, () => 0);
    await flow.LoadAsync(); Check(flow.Snapshot.Phase == AccountConstructionPhase.Ready && journal.Read(k.AccountId, k.KingdomId) == null,
        "Observed receipt did not reconcile journal.");
}));
Add("Construction journal corruption and write failure never reset file or send an unjournaled start", () => Store(async path =>
{
    var folder = Path.GetDirectoryName(path)!; var k = ClientKingdom(); var journal = new FileConstructionIntentStore(folder);
    var intent = new ConstructionIntent(k.AccountId, k.KingdomId, new string('c',32), "town_hall", 1); journal.Save(intent);
    string file = Directory.GetFiles(folder, "construction-*.xml").Single(); File.WriteAllText(file, "<constructionIntent version=\"77\" />");
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec); int calls = wire.Calls;
    using (var flow = new AccountConstructionFlow(provider, journal, session, k, new[] { "town_hall" }, () => 100, () => 0))
    {
        await flow.LoadAsync(); Check(flow.Snapshot.Phase == AccountConstructionPhase.RecoveryRequired && wire.Calls == calls, "Corrupt journal reached backend.");
        Check(File.ReadAllText(file) == "<constructionIntent version=\"77\" />", "Corrupt journal reset.");
    }
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(new HttpAccountProvider.ConstructionStateDto {
        version = 1, serverNow = "100", progress = ProgressWire(), jobs = Array.Empty<HttpAccountProvider.ConstructionJobDto>() })));
    using var failed = new AccountConstructionFlow(provider, new FailedIntentStore(), session, k, new[] { "town_hall" }, () => 100, () => 0);
    await failed.LoadAsync(); calls = wire.Calls; await failed.StartAsync("town_hall");
    Check(failed.Snapshot.Phase == AccountConstructionPhase.RecoveryRequired && wire.Calls == calls, "Unjournaled command sent after disk failure.");
}));
Add("Construction flow clears definitive rejection but retains ambiguity and suppresses disposed late acknowledgement", () => Store(async path =>
{
    var journal = new FileConstructionIntentStore(Path.GetDirectoryName(path)!); var k = ClientKingdom();
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec);
    var initial = new HttpAccountProvider.ConstructionStateDto { version = 1, serverNow = "100", progress = ProgressWire(), jobs = Array.Empty<HttpAccountProvider.ConstructionJobDto>() };
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(initial)));
    using var flow = new AccountConstructionFlow(provider, journal, session, k, new[] { "town_hall" }, () => 100, () => 0);
    await flow.LoadAsync();
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(409, "{\"code\":\"AL-CONSTRUCTION-RESOURCES-INSUFFICIENT\"}"));
    await flow.StartAsync("town_hall");
    Check(flow.Snapshot.Pending == null && journal.Read(k.AccountId, k.KingdomId) == null, "Definitive rejection permanently blocked account.");
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(initial))); await flow.LoadAsync();
    var pending = new TaskCompletionSource<AccountHttpResponse>(); string requestId = "";
    wire.Reply = (_, _, json, _, _) => { requestId = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json).requestId; return pending.Task; };
    var late = flow.StartAsync("town_hall"); flow.Dispose(); var result = ConstructionWire(); result.jobs[0].requestId = requestId;
    pending.SetResult(new AccountHttpResponse(200, codec.Encode(result))); await late;
    Check(flow.Snapshot.State == null && journal.Read(k.AccountId, k.KingdomId)?.RequestId == requestId, "Disposed acknowledgement published or deleted pending recovery.");
}));
Add("Construction preview is read-only account-owned and fingerprints every quoted term deterministically", () => Store(path =>
{
    var p = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true); var registry = new FileAccountRegistry(path);
    var account = registry.ResolveVerifiedLogin(p).Record;
    registry.CommitVerifiedRealm(p, account.AccountId, "crownlands", new string('b',32), new[] { "site" }, ProgressSeed());
    var costs = new Dictionary<string, long> { ["food"] = 2, ["wood"] = 3, ["stone"] = 4, ["gold"] = 5 };
    var quote = new KingdomConstructionQuote("fixture", "farm", 0, 60, costs); byte[] original = File.ReadAllBytes(path);
    var preview = registry.PreviewVerifiedConstruction(p, account.AccountId, "farm", (id, level) =>
    { Check(id == "farm" && level == 0, "Preview did not use saved level."); return quote; });
    Check(preview.Accepted && preview.Progress.Revision == 1 && preview.Quote.Costs["wood"] == 3, "Preview dropped terms.");
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Preview changed authoritative save.");
    var reordered = costs.Reverse().ToDictionary(c => c.Key, c => c.Value);
    Check(new KingdomConstructionQuote("fixture", "farm", 0, 60, reordered).Fingerprint == quote.Fingerprint, "Dictionary order changed quote identity.");
    reordered["food"] = 3;
    Check(new KingdomConstructionQuote("fixture", "farm", 0, 60, reordered).Fingerprint != quote.Fingerprint &&
        new KingdomConstructionQuote("fixture", "farm", 0, 61, costs).Fingerprint != quote.Fingerprint &&
        new KingdomConstructionQuote("fixture-v2", "farm", 0, 60, costs).Fingerprint != quote.Fingerprint, "Changed term reused quote identity.");
    var foreign = registry.PreviewVerifiedConstruction(new("fixture", "other", "other@example.test", true), account.AccountId, "farm", (_, _) => quote);
    Check(!foreign.Accepted && foreign.Progress == null && foreign.Quote == null, "Foreign preview leaked state.");
    return Task.CompletedTask;
}));
Add("Confirmed quote mismatch cannot charge; accepted fingerprint retry survives changed catalog and restart", () => Store(path =>
{
    var p = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true); var registry = new FileAccountRegistry(path);
    var account = registry.ResolveVerifiedLogin(p).Record;
    registry.CommitVerifiedRealm(p, account.AccountId, "crownlands", new string('b',32), new[] { "site" }, ProgressSeed());
    var costs = new Dictionary<string, long> { ["food"] = 1, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 };
    var old = new KingdomConstructionQuote("fixture", "farm", 0, 60, costs);
    var updated = new KingdomConstructionQuote("fixture", "farm", 0, 61, costs); string request = new string('c',32);
    byte[] original = File.ReadAllBytes(path);
    var rejected = registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 100, (_, _) => updated, old.Fingerprint);
    Check(rejected.Diagnostic == "AL-CONSTRUCTION-QUOTE-CHANGED" && original.SequenceEqual(File.ReadAllBytes(path)), "Changed quote charged or wrote a job.");
    var accepted = registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 100, (_, _) => old, old.Fingerprint);
    Check(accepted.Accepted && accepted.Progress.Resources["food"] == 6, "Matching quote not charged once.");
    registry = new FileAccountRegistry(path);
    Check(registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 200, (_, _) => updated, old.Fingerprint).Progress.Revision == 2,
        "Accepted retry depended on changed catalog.");
    Check(registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 200, (_, _) => updated, updated.Fingerprint).Diagnostic == "AL-CONSTRUCTION-REQUEST-CONFLICT",
        "Changed confirmed terms reinterpreted original receipt.");
    return Task.CompletedTask;
}));
Add("Mandatory new-start quote guard rejects missing terms while old accepted receipts remain recoverable", () => Store(path =>
{
    var p = new VerifiedEmailPrincipal("fixture", "builder", "builder@example.test", true); var registry = new FileAccountRegistry(path);
    var account = registry.ResolveVerifiedLogin(p).Record;
    registry.CommitVerifiedRealm(p, account.AccountId, "crownlands", new string('b',32), new[] { "site" }, ProgressSeed());
    var quote = new KingdomConstructionQuote("fixture", "farm", 0, 60,
        new Dictionary<string,long> { ["food"] = 1, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    string request = new string('c',32); byte[] original = File.ReadAllBytes(path);
    Check(registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 100, (_, _) => quote, null, true).Diagnostic == "AL-CONSTRUCTION-QUOTE-REQUIRED",
        "Mandatory start accepted unreviewed terms.");
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Missing quote charged or changed save.");
    Check(registry.StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 100, (_, _) => quote).Accepted, "Historical fixture start failed.");
    var committed = File.ReadAllBytes(path);
    Check(new FileAccountRegistry(path).StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 200,
        (_, _) => throw new Exception("Old retry quoted again."), null, true).Diagnostic == "AL-CONSTRUCTION-REQUEST-CONFLICT",
        "Required reviewed quote was omitted on retry.");
    Check(new FileAccountRegistry(path).StartVerifiedConstruction(p, account.AccountId, request, "farm", 1, 200,
        (_, _) => throw new Exception("Exact retry quoted again."), quote.Fingerprint, true).Progress.Revision == 2, "Exact accepted receipt cannot reconcile.");
    Check(committed.SequenceEqual(File.ReadAllBytes(path)), "Retry changed accepted state.");
    return Task.CompletedTask;
}));
Add("Construction journal v2 retains confirmed fingerprint and loads old v1 byte-for-byte without rewriting", () => Store(path =>
{
    var k = ClientKingdom(); var journal = new FileConstructionIntentStore(Path.GetDirectoryName(path)!);
    var old = new ConstructionIntent(k.AccountId, k.KingdomId, new string('c',32), "town_hall", 1); journal.Save(old);
    string file = Directory.GetFiles(Path.GetDirectoryName(path)!, "construction-*.xml").Single(); byte[] before = File.ReadAllBytes(file);
    var restored = new FileConstructionIntentStore(Path.GetDirectoryName(path)!).Read(k.AccountId, k.KingdomId);
    Check(restored.RequestId == old.RequestId && restored.QuoteFingerprint == null && before.SequenceEqual(File.ReadAllBytes(file)), "Old pending command reset or rewritten.");
    journal.Clear(restored);
    var next = new ConstructionIntent(k.AccountId, k.KingdomId, new string('d',32), "town_hall", 2, new string('a',64)); journal.Save(next);
    Check(new FileConstructionIntentStore(Path.GetDirectoryName(path)!).Read(k.AccountId, k.KingdomId).QuoteFingerprint == next.QuoteFingerprint,
        "Confirmed terms lost on restart.");
    try { journal.Clear(old); throw new Exception("Old acknowledgement erased new confirmed request."); } catch (InvalidOperationException) { }
    Check(journal.Read(k.AccountId, k.KingdomId).RequestId == next.RequestId, "Wrong acknowledgement changed pending request.");
    return Task.CompletedTask;
}));
Add("Client construction preview verifies exact fingerprint and confirmation persists reviewed terms before sending", () => Store(async path =>
{
    var wire = new FakeWire(); var codec = new WireCodec(); using var provider = new HttpAccountProvider(wire, codec, () => 100);
    var session = await ClientLogin(provider, wire, codec); var k = ClientKingdom();
    var initial = new HttpAccountProvider.ConstructionStateDto { version = 1, serverNow = "100", progress = ProgressWire(), jobs = Array.Empty<HttpAccountProvider.ConstructionJobDto>() };
    var quote = new KingdomConstructionQuote("fixture", "town_hall", 1, 60, new Dictionary<string,long> { ["food"] = 1, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    var preview = new HttpAccountProvider.ConstructionPreviewDto { version = 1, progress = ProgressWire(), fingerprint = quote.Fingerprint,
        catalogRevision = "fixture", buildingId = "town_hall", fromLevel = "1", targetLevel = "2", durationSeconds = "60", costs = ConstructionWire().jobs[0].costs };
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(initial)));
    var journal = new FileConstructionIntentStore(Path.GetDirectoryName(path)!);
    var flow = new AccountConstructionFlow(provider, journal, session, k, new[] { "town_hall" }, () => 100, () => 0);
    await flow.LoadAsync();
    wire.Reply = (_, endpoint, _, _, _) => { Check(endpoint.EndsWith("/preview"), "Preview mutated a job."); return Task.FromResult(new AccountHttpResponse(200, codec.Encode(preview))); };
    await flow.PreviewAsync("town_hall"); var reviewed = flow.ReviewedPreview;
    Check(reviewed.Quote.Fingerprint == quote.Fingerprint && reviewed.Quote.Costs["food"] == 1 && journal.Read(k.AccountId, k.KingdomId) == null,
        "Preview failed validation or journaled a mutation.");
    string nonce = "";
    wire.Reply = (_, _, json, _, _) =>
    {
        var command = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json); nonce = command.requestId;
        Check(command.expectedQuoteFingerprint == quote.Fingerprint && journal.Read(k.AccountId, k.KingdomId).QuoteFingerprint == quote.Fingerprint,
            "Confirmation failed to persist/send reviewed terms.");
        return Task.FromException<AccountHttpResponse>(new IOException("fixture-network-loss"));
    };
    await flow.ConfirmStartAsync(reviewed); Check(flow.Snapshot.Phase == AccountConstructionPhase.PendingRetry, "Ambiguous confirmed start dropped intent."); flow.Dispose();
    flow = new(provider, new FileConstructionIntentStore(Path.GetDirectoryName(path)!), session, k, new[] { "town_hall" }, () => 100, () => 0);
    wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(initial))); await flow.LoadAsync();
    wire.Reply = (_, _, json, _, _) =>
    {
        var command = codec.Decode<HttpAccountProvider.ConstructionStartDto>(json);
        Check(command.requestId == nonce && command.expectedQuoteFingerprint == quote.Fingerprint, "Quoted retry changed terms.");
        var state = ConstructionWire(); state.jobs[0].requestId = nonce;
        return Task.FromResult(new AccountHttpResponse(200, codec.Encode(state)));
    };
    await flow.RetryPendingAsync(); Check(flow.Snapshot.Phase == AccountConstructionPhase.Ready && journal.Read(k.AccountId, k.KingdomId) == null, "Quoted receipt failed recovery."); flow.Dispose();
}));
Add("Client preview refuses missing fields changed prices and foreign ownership without cache pollution", async () =>
{
    var quote = new KingdomConstructionQuote("fixture", "town_hall", 1, 60, new Dictionary<string,long> { ["food"] = 1, ["wood"] = 0, ["stone"] = 0, ["gold"] = 0 });
    Action<HttpAccountProvider.ConstructionPreviewDto>[] edits = { r => r.fingerprint = null!, r => r.durationSeconds = null!,
        r => r.costs[0].amount = "2", r => r.targetLevel = "3", r => r.progress.kingdom.realmId = "other", r => r.fromLevel = null! };
    foreach (var edit in edits)
    {
        var wire = new FakeWire(); var codec = new WireCodec(); using var client = new HttpAccountProvider(wire, codec, () => 100);
        var session = await ClientLogin(client, wire, codec);
        HttpAccountProvider.ConstructionPreviewDto Valid() => new() { version = 1, progress = ProgressWire(), fingerprint = quote.Fingerprint,
            catalogRevision = "fixture", buildingId = "town_hall", fromLevel = "1", targetLevel = "2", durationSeconds = "60", costs = ConstructionWire().jobs[0].costs };
        var bad = Valid(); edit(bad); wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(bad)));
        try { await client.PreviewConstructionAsync(session, ClientKingdom(), "town_hall", default); throw new Exception("Malformed preview accepted."); } catch (InvalidOperationException) { }
        wire.Reply = (_, _, _, _, _) => Task.FromResult(new AccountHttpResponse(200, codec.Encode(Valid())));
        Check((await client.PreviewConstructionAsync(session, ClientKingdom(), "town_hall", default)).Quote.Fingerprint == quote.Fingerprint, "Malformed preview poisoned cache.");
    }
});
Add("Loopback HTTP login construction logout and restart preserve account and progress", () => Store(LoopbackAccountIntegration.Run));
Add("Production settlement preserves fractions across polling and saturates long downtime without overflow", () =>
{
    var rule = new KingdomProductionRule("fixture","farm",1,"food",3,7,100);
    var initial = new KingdomProductionCheckpoint(rule,100,0,0);
    var polled = initial;
    for (long time = 101; time <= 131; time++) polled = polled.Settle(time);
    var direct = initial.Settle(131);
    Check(polled.BufferedUnits == 12 && direct.BufferedUnits == polled.BufferedUnits && direct.RemainderSeconds == polled.RemainderSeconds,
        "Polling frequency changed production.");
    Check(initial.BufferedUnits == 0 && direct.RemainderSeconds == 3, "Settlement mutated an earlier checkpoint or lost fractions.");
    var full = initial.Settle(long.MaxValue);
    Check(full.BufferedUnits == 100 && full.RemainderSeconds == 0 && full.Settle(long.MaxValue).BufferedUnits == 100,
        "Long downtime overflowed or full storage continued accruing.");
    var huge = new KingdomProductionCheckpoint(new KingdomProductionRule("fixture","gold_mine",1,"gold",1000000000000L,1,1000000000000L),0,0,0).Settle(long.MaxValue);
    Check(huge.BufferedUnits == 1000000000000L, "Large rate multiplied before saturation.");
    try { polled.Settle(130); throw new Exception("Reversed server clock accepted."); } catch (InvalidOperationException error) { Check(error.Message == "AL-PRODUCTION-CLOCK-REVERSED","Wrong clock diagnostic."); }
    return Task.CompletedTask;
});
Add("Production cannot mint oathmarks or operate an unbuilt structure", () =>
{
    foreach (var input in new[] { (0,"food"), (1,"oathmark") }) {
        try { new KingdomProductionRule("fixture","farm",input.Item1,input.Item2,1,1,10); throw new Exception("Invalid kingdom production accepted."); }
        catch (ArgumentException) { }
    }
    var rule = new KingdomProductionRule("fixture","farm",1,"food",1,5,10);
    try { new KingdomProductionCheckpoint(rule,0,10,1); throw new Exception("Full storage retained hidden production."); } catch (ArgumentException) { }
    return Task.CompletedTask;
});
Add("Production catalog selects only canonical built levels and fails closed when disabled", () => Store(path =>
{
    string folder = Path.GetDirectoryName(path)!, buildings = Path.Combine(folder,"buildings.json"), production = Path.Combine(folder,"production.json");
    File.WriteAllText(buildings, JsonSerializer.Serialize(new { records = new[] { new { id = "farm", max_level = 2 }, new { id = "town_hall", max_level = 10 } } }));
    object Rule(string building = "farm",int level = 1,string resource = "food") => new { buildingId = building,level,resourceId = resource,unitsPerInterval = 3,intervalSeconds = 7,storageCapacity = 100 };
    string Json(bool enabled,object[] producers) => JsonSerializer.Serialize(new { version = 1,catalogId = "kingdom_resource_production",runtimeEnabled = enabled,revision = "fixture",producers });
    File.WriteAllText(production,Json(true,new[] { Rule() }));
    var catalog = KingdomProductionCatalog.Load(production,buildings);
    Check(catalog.Select("farm",0) == null && catalog.Select("town_hall",1) == null && catalog.Select("farm",1)!.UnitsPerInterval == 3,
        "Catalog produced an unbuilt structure or changed terms.");
    Rejected(() => catalog.Select("farm",2),"AL-PRODUCTION-LEVEL-UNAVAILABLE");
    File.WriteAllText(production,Json(false,new[] { Rule() }));
    Rejected(() => KingdomProductionCatalog.Load(production,buildings).Select("farm",1),"AL-PRODUCTION-CONFIG-UNAVAILABLE");
    foreach (string invalid in new[] { Json(true,Array.Empty<object>()),Json(true,new[] { Rule(),Rule() }),Json(true,new[] { Rule("foreign") }),
        Json(true,new[] { Rule(level:3) }),Json(true,new[] { Rule(resource:"oathmark") }),Json(true,new[] { Rule(level:0) }),
        Json(true,new[] { Rule() }).Replace("\"unitsPerInterval\":3","\"unitsPerInterval\":0"),
        Json(true,new[] { Rule() }).Replace("\"producers\":","\"clientBalance\":99,\"producers\":") })
    {
        File.WriteAllText(production,invalid);
        try { KingdomProductionCatalog.Load(production,buildings); throw new Exception("Invalid production catalog accepted."); }
        catch (Exception error) when (error is InvalidDataException || error is JsonException) { }
    }
    return Task.CompletedTask;
}));
Add("Production cutover uses old rates and collection cannot recover capped downtime", () =>
{
    var old = new KingdomProductionRule("old", "farm", 1, "food", 3, 7, 100);
    var initial = new KingdomProductionCheckpoint(old, 100, 0, 0);
    var next = new KingdomProductionRule("new", "farm", 2, "food", 20, 5, 200);
    var changed = initial.ChangeRule(next, 131);
    Check(changed.BufferedUnits == 12 && changed.RemainderSeconds == 0 && changed.ObservedAt == 131,
        "New production terms applied retroactively or retained old-rate partial time.");
    Check(changed.Settle(136).BufferedUnits == 32 && initial.BufferedUnits == 0, "Cutover lost old income or mutated its prior state.");
    var full = initial.Settle(10000);
    var partial = full.Collect(20000, 30);
    Check(partial.Amount == 30 && partial.Checkpoint.BufferedUnits == 70 && partial.Checkpoint.RemainderSeconds == 0,
        "Collection dropped surplus storage or retained hidden full-storage time.");
    Check(partial.Checkpoint.Settle(20000).BufferedUnits == 70 && partial.Checkpoint.Settle(20007).BufferedUnits == 73,
        "Capped downtime reappeared after collection.");
    var blocked = full.Collect(20000, 0);
    Check(blocked.Amount == 0 && blocked.Checkpoint.BufferedUnits == 100, "Full wallet destroyed stored resources.");
    Check(initial.Settle(104).Collect(104, 100).Checkpoint.RemainderSeconds == 4, "Collection lost an incomplete interval.");
    Check(initial.ChangeRule(new KingdomProductionRule("same-rate", "farm", 2, "food", 3, 7, 200), 104).RemainderSeconds == 4,
        "Unchanged timing discarded progress.");
    foreach (var invalid in new[] { new KingdomProductionRule("new", "other", 2, "food", 3, 7, 100),
        new KingdomProductionRule("new", "farm", 2, "gold", 3, 7, 100), new KingdomProductionRule("new", "farm", 2, "food", 3, 7, 1) })
    {
        try { initial.ChangeRule(invalid, 131); throw new Exception("Unsafe production transition accepted."); }
        catch (InvalidOperationException) { }
    }
    try { initial.Collect(100, -1); throw new Exception("Negative wallet room accepted."); } catch (ArgumentException) { }
    return Task.CompletedTask;
});
Add("Production v4 migration and restart retain progress and exact collection receipts", () => Store(path =>
{
    var principal = new VerifiedEmailPrincipal("fixture", "producer", "producer@example.test", true);
    var registry = new FileAccountRegistry(path); var account = registry.ResolveVerifiedLogin(principal).Record;
    registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('b',32), new[] { "site" }, ProgressSeed());
    var costs = new Dictionary<string,long> { ["food"]=0,["wood"]=0,["stone"]=0,["gold"]=0 };
    var jobId = new string('c',32);
    registry.StartVerifiedConstruction(principal,account.AccountId,jobId,"farm",1,100,
        (_,_) => new KingdomConstructionQuote("fixture","farm",0,10,costs));
    var built = registry.CompleteVerifiedConstruction(principal,account.AccountId,jobId,110);
    // Build an actual historical v4 fixture: current starts now persist schema16 metadata.
    var legacy = System.Xml.Linq.XDocument.Load(path); legacy.Root!.SetAttributeValue("version", "4");
    foreach (var receipt in legacy.Root.Elements("construction")) receipt.Attribute("expectedRevision")?.Remove();
    legacy.Save(path); registry = new FileAccountRegistry(path);
    byte[] v4 = File.ReadAllBytes(path);
    KingdomProductionRule? Select(string id,int level) => id == "farm" && level > 0 ? new("fixture",id,level,"food",level == 1 ? 3 : 20,level == 1 ? 7 : 5,200) : null;
    var initialized = registry.ReadVerifiedProduction(principal,account.AccountId,1000,Select!);
    Check(initialized.Accepted && initialized.Checkpoints.Single().BufferedUnits == 0 && initialized.Progress.Revision == built.Progress.Revision,
        "Migration invented retrospective income or changed existing progress.");
    string backup = Directory.GetFiles(Path.GetDirectoryName(path)!,"accounts.xml.migration-v4-*.xml").Single();
    Check(v4.SequenceEqual(File.ReadAllBytes(backup)) && new FileAccountRegistry(backup).ReadVerifiedKingdomProgress(principal,account.AccountId).Progress.Resources["food"] == 7,
        "Old v4 save was not backed up and loadable.");
    registry = new FileAccountRegistry(path);
    var collected = registry.CollectVerifiedProduction(principal,account.AccountId,new string('d',32),"farm",3,1021);
    Check(collected.Accepted && collected.Receipt.Amount == 9 && collected.Progress.Resources["food"] == 16 && collected.Progress.Revision == 4,
        "Wallet and receipt did not commit together.");
    byte[] committed = File.ReadAllBytes(path);
    registry = new FileAccountRegistry(path);
    var replay = registry.CollectVerifiedProduction(principal,account.AccountId,new string('d',32),"farm",3,2000);
    Check(replay.Receipt.Amount == 9 && replay.Progress.Revision == 4 && committed.SequenceEqual(File.ReadAllBytes(path)),
        "Restart/retry produced another grant or changed its receipt.");
    Check(registry.CollectVerifiedProduction(principal,account.AccountId,new string('e',32),"farm",3,2000).Diagnostic == "AL-KINGDOM-PROGRESS-CONFLICT",
        "Stale competing collection accepted.");
    Check(registry.CollectVerifiedProduction(principal,account.AccountId,new string('d',32),"town_hall",3,2000).Diagnostic == "AL-PRODUCTION-REQUEST-CONFLICT",
        "Reused request changed its building.");
    Check(committed.SequenceEqual(File.ReadAllBytes(path)), "Rejected collection mutated durable state.");
    var start = registry.StartVerifiedConstruction(principal,account.AccountId,new string('f',32),"farm",4,1100,
        (_,_) => new KingdomConstructionQuote("fixture","farm",1,10,costs));
    Check(start.Accepted && File.ReadAllText(path).Contains("version=\"16\""), "Construction command schema was not retained.");
    var blocked = registry.CompleteVerifiedConstruction(principal,account.AccountId,new string('f',32),1200);
    Check(blocked.Diagnostic == "AL-PRODUCTION-CONFIG-UNAVAILABLE", "Completion bypassed production cutover.");
    var done = registry.CompleteVerifiedConstruction(principal,account.AccountId,new string('f',32),1200,Select!);
    Check(done.Accepted && done.Progress.Buildings.Single(b => b.Id == "farm").Level == 2, "Production-aware upgrade failed.");
    var output = new FileAccountRegistry(path).ReadVerifiedProduction(principal,account.AccountId,1205,Select!);
    Check(output.Checkpoints.Single().BufferedUnits == 95, "Upgrade produced retroactive new-rate income.");
    var snapshot = registry.CreateVerifiedSnapshot(Path.Combine(Path.GetDirectoryName(path)!,"production-snapshot.xml"));
    Check(snapshot.Version == 16 && snapshot.ProductionRecords == 1 && snapshot.CollectionReceipts == 1,
        "Snapshot omitted production/receipt inventory.");
    return Task.CompletedTask;
}));
Add("Production full-wallet collection preserves buffer and rejects foreign ownership and corrupt saves", () => Store(path =>
{
    var principal = new VerifiedEmailPrincipal("fixture","full","full@example.test",true);
    var registry = new FileAccountRegistry(path); var account = registry.ResolveVerifiedLogin(principal).Record;
    var seed = new KingdomProgressSeed("fixture",new Dictionary<string,long> { ["food"]=999999999995L,["wood"]=0,["stone"]=0,["gold"]=0 },
        new[] { new KingdomBuildingLevel("farm",1) });
    registry.CommitVerifiedRealm(principal,account.AccountId,"crownlands",new string('b',32),new[] { "site" },seed);
    KingdomProductionRule Rule(string id,int level) => new("fixture",id,level,"food",1,1,100);
    registry.ReadVerifiedProduction(principal,account.AccountId,100,Rule);
    var collected = registry.CollectVerifiedProduction(principal,account.AccountId,new string('c',32),"farm",1,200);
    Check(collected.Receipt.Amount == 5 && collected.Progress.Resources["food"] == 1000000000000L && collected.Checkpoints.Single().BufferedUnits == 95,
        "Wallet overflowed or capped collection dropped stored resources.");
    var full = new FileAccountRegistry(path).CollectVerifiedProduction(principal,account.AccountId,new string('d',32),"farm",2,300);
    Check(full.Receipt.Amount == 0 && full.Checkpoints.Single().BufferedUnits == 100, "Full wallet generated excess transfer or erased buffer.");
    byte[] valid = File.ReadAllBytes(path);
    var foreign = new VerifiedEmailPrincipal("fixture","other","other@example.test",true);
    Check(registry.CollectVerifiedProduction(foreign,account.AccountId,new string('e',32),"farm",3,400).Diagnostic == "AL-ACCOUNT-PRINCIPAL-MISMATCH" &&
        valid.SequenceEqual(File.ReadAllBytes(path)), "Foreign principal collected or mutated production.");
    File.WriteAllText(path,File.ReadAllText(path).Replace("resource=\"food\"","resource=\"oathmark\""));
    try { registry.ReadVerifiedKingdomProgress(principal,account.AccountId); throw new Exception("Corrupt production accepted."); }
    catch (InvalidDataException) { }
    return Task.CompletedTask;
}));
Add("Production client rejects malformed checkpoints and mismatched receipts without poisoning progress", async () =>
{
    var codec = new WireCodec(); var wire = new FakeWire();
    using var client = new HttpAccountProvider(wire,codec,() => 100);
    var session = await ClientLogin(client,wire,codec);
    HttpAccountProvider.ProductionStateDto Valid() => new() { version=1,serverNow="100",progress=ProgressWire(),
        producers = new[] { new HttpAccountProvider.ProductionCheckpointDto { buildingId="town_hall",level="1",resourceId="food",catalogRevision="fixture",
            unitsPerInterval="3",intervalSeconds="7",storageCapacity="100",observedAt="100",bufferedUnits="0",remainderSeconds="0" } } };
    foreach (Action<HttpAccountProvider.ProductionStateDto> edit in new Action<HttpAccountProvider.ProductionStateDto>[] {
        r => r.version=2, r => r.producers=null!, r => r.producers=new[] { r.producers[0],r.producers[0] },
        r => r.producers[0].level="0", r => r.producers[0].resourceId="oathmark", r => r.producers[0].bufferedUnits="101",
        r => r.producers[0].observedAt="101", r => r.producers[0].intervalSeconds="0", r => r.producers[0].remainderSeconds="7",
        r => r.progress.kingdom.accountId="ala_"+new string('f',32), r => r.receipt=new(), r => r.serverNow="-1" })
    {
        var invalid = Valid(); edit(invalid);
        wire.Reply=(_,_,_,_,_) => Task.FromResult(new AccountHttpResponse(200,codec.Encode(invalid)));
        try { await client.ReadProductionAsync(session,ClientKingdom(),default); throw new Exception("Malformed production accepted."); } catch (InvalidOperationException) { }
        wire.Reply=(_,_,_,_,_) => Task.FromResult(new AccountHttpResponse(200,codec.Encode(Valid())));
        Check((await client.ReadProductionAsync(session,ClientKingdom(),default)).Progress.Revision == 1,"Malformed response poisoned client progress.");
    }
    var collected = Valid(); collected.serverNow="107"; collected.producers[0].observedAt="107";
    collected.progress.revision=2; collected.progress.resources.Single(r=>r.id=="food").amount="10";
    collected.receipt=new() { requestId=new string('c',32),buildingId="town_hall",resourceId="wood",expectedRevision="1",amount="3",collectedAt="107" };
    wire.Reply=(_,_,_,_,_) => Task.FromResult(new AccountHttpResponse(200,codec.Encode(collected)));
    try { await client.CollectProductionAsync(session,ClientKingdom(),new string('c',32),"town_hall",1,default); throw new Exception("Wrong receipt resource accepted."); }
    catch (InvalidOperationException) { }
    collected.receipt.resourceId="food";
    Check((await client.CollectProductionAsync(session,ClientKingdom(),new string('c',32),"town_hall",1,default)).Receipt.Amount == 3,
        "Invalid receipt changed cache or valid receipt amount.");
    wire.Reply=(_,_,_,_,_) => Task.FromResult(new AccountHttpResponse(200,codec.Encode(Valid())));
    try { await client.ReadProductionAsync(session,ClientKingdom(),default); throw new Exception("Stale production progress accepted."); } catch (InvalidOperationException) { }
    wire.Reply=(_,_,_,_,_) => Task.FromResult(new AccountHttpResponse(503,codec.Encode(new { code="AL-PRODUCTION-CONFIG-UNAVAILABLE" })));
    try { await client.ReadProductionAsync(session,ClientKingdom(),default); throw new Exception("Disabled production succeeded."); }
    catch (AccountKingdomProductionException e) { Check(e.Diagnostic=="AL-PRODUCTION-CONFIG-UNAVAILABLE","Lost safe production diagnostic."); }
});
CollectionRecoveryTests.Register(Add);
object RegistryCodec(FileAccountRegistry registry, string method, params object[] values)
{
    var member = typeof(FileAccountRegistry).GetMethod(method, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
    Check(member != null, "Registry image codec is missing: " + method);
    try { return member!.Invoke(registry, values)!; }
    catch (System.Reflection.TargetInvocationException error) when (error.InnerException != null) { throw error.InnerException; }
}
Add("Detached image codec reads without live state or either lease and shares exact writer bytes", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture-codec", "one", "one@example.test", true);
    registry.ResolveVerifiedLogin(principal); byte[] durable = File.ReadAllBytes(path); string image = path + ".image.xml"; File.WriteAllBytes(image, durable);
    File.WriteAllText(path, "<accounts version=\"99\" />"); byte[] corruptLive = File.ReadAllBytes(path);
    using (var liveLease = new FileStream(path + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
    using (var detachedLease = new FileStream(image + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
    {
        object document = RegistryCodec(registry, "ReadImageDetached", image);
        Check(durable.SequenceEqual((byte[])RegistryCodec(registry, "SerializeDocument", document)), "Shared image writer changed actual persisted bytes.");
        RegistryCodec(registry, "RequireEquivalentImages", document, RegistryCodec(registry, "ReadImageDetached", image));
    }
    Check(corruptLive.SequenceEqual(File.ReadAllBytes(path)) && durable.SequenceEqual(File.ReadAllBytes(image)), "Detached read touched live/image bytes.");
    return Task.CompletedTask;
}));
Add("Detached image codec rejects missing malformed oversized and foreign formats without creating authority", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); string image = path + ".image.xml";
    var cases = new string?[] { null, "<accounts version=\"1\"><broken", "<!DOCTYPE accounts [<!ENTITY e SYSTEM 'file:///never-read'>]><accounts version=\"1\">&e;</accounts>", "<accounts version=\"99\" />", "<accounts version=\"story-storage-test-v1\" />", "<accounts version=\"1\" extra=\"x\" />", "<accounts version=\"1\"/><accounts version=\"1\"/>" };
    foreach (string? text in cases)
    {
        if (File.Exists(image)) File.Delete(image); if (text != null) File.WriteAllText(image, text); byte[]? bytes = text == null ? null : File.ReadAllBytes(image);
        bool refused = false; try { RegistryCodec(registry, "ReadImageDetached", image); } catch (Exception error) when (error is InvalidDataException || error is IOException || error is System.Xml.XmlException) { refused = true; }
        Check(refused, "Detached malformed/missing image accepted."); Check(!File.Exists(path) && !File.Exists(path + ".lock") && !File.Exists(image + ".lock"), "Detached failure created live/image authority or lease.");
        Check(bytes == null ? !File.Exists(image) : bytes.SequenceEqual(File.ReadAllBytes(image)), "Detached refusal changed image.");
    }
    using (var file = new FileStream(image, FileMode.Create, FileAccess.Write)) file.SetLength(16L * 1024 * 1024 + 1);
    try { RegistryCodec(registry, "ReadImageDetached", image); throw new Exception("Oversized detached image accepted."); } catch (InvalidDataException) { }
    Check(new FileInfo(image).Length == 16L * 1024 * 1024 + 1 && !File.Exists(path + ".lock"), "Oversize refusal mutated inputs.");
    return Task.CompletedTask;
}));
Add("Complete image comparison rejects same-count identity balance building and revision changes", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture-codec", "one", "one@example.test", true);
    var account = registry.ResolveVerifiedLogin(principal).Record; registry.CommitVerifiedRealm(principal, account.AccountId, "crownlands", new string('a', 32), new[] { "fixture-site" }, ProgressSeed());
    byte[] original = File.ReadAllBytes(path); object before = RegistryCodec(registry, "ReadImageDetached", path);
    var mutations = new Action<System.Xml.Linq.XDocument>[] { x => x.Root!.Element("account")!.SetAttributeValue("revision", (long)x.Root.Element("account")!.Attribute("revision")! + 1), x => x.Root!.Element("account")!.SetAttributeValue("email", "other@example.test"), x => x.Root!.Element("kingdom")!.SetAttributeValue("site", "other-site"), x => x.Root!.Element("progress")!.SetAttributeValue("revision", "2"), x => x.Descendants("resource").First().SetAttributeValue("amount", "123"), x => x.Descendants("building").First().SetAttributeValue("level", "2") };
    foreach (var mutate in mutations)
    {
        using var source = new MemoryStream(original); var xml = System.Xml.Linq.XDocument.Load(source); mutate(xml); string image = path + ".changed.xml"; xml.Save(image);
        object after = RegistryCodec(registry, "ReadImageDetached", image); bool refused = false;
        try { RegistryCodec(registry, "RequireEquivalentImages", before, after); } catch (InvalidDataException) { refused = true; }
        Check(refused, "Same-count changed field passed complete comparison.");
    }
    Check(original.SequenceEqual(File.ReadAllBytes(path)), "Semantic comparison wrote live state.");
    return Task.CompletedTask;
}));
Add("Shared image codec preserves snapshot bytes no-overwrite and missing live bootstrap", () => Store(path =>
{
    var registry = new FileAccountRegistry(path); var principal = new VerifiedEmailPrincipal("fixture-codec", "one", "one@example.test", true); registry.ResolveVerifiedLogin(principal);
    byte[] original = File.ReadAllBytes(path); object document = RegistryCodec(registry, "ReadImageDetached", path); string image = path + ".snapshot.xml"; registry.CreateVerifiedSnapshot(image);
    RegistryCodec(registry, "RequireEquivalentImages", document, RegistryCodec(registry, "ReadImageDetached", image)); Check(original.SequenceEqual(File.ReadAllBytes(image)), "Snapshot serialization replaced raw original bytes.");
    try { registry.CreateVerifiedSnapshot(image); throw new Exception("Snapshot destination overwritten."); } catch (IOException) { }
    Check(original.SequenceEqual(File.ReadAllBytes(image)), "No-overwrite failure changed snapshot.");
    return Task.CompletedTask;
}));

KingdomQuestCatalogTests.Register(Add);
KingdomQuestTests.Register(Add);
IntegrationQuestClientTests.Register(Add);
IntegrationQuestHttpTests.Register(Add);
IntegrationKingdomQuestTests.Register(Add);
IntegrationQuestMigrationTests.Register(Add);
BuildingInstancePolicyTests.Register(Add);
SecurityBoundaryRegressionTests.Register(Add);
SummoningBatchConservationTests.Register(Add);
FirstJourneyEnrollmentTests.Register(Add);
FirstJourneyHttpTests.Register(Add);
FirstJourneySummoningHttpTests.Register(Add);
ConstructionProductionBoundaryTests.Register(Add);
SummoningPreviewConsistencyTests.Register(Add);
NonEnrolledProgressionContractTests.Register(Add);
AccountStoreParityTests.Register(Add);
AccountMigrationExportTests.Register(Add);
ProductionDeploymentConfigurationTests.Register(Add);
AccountDatabaseMigrationTests.Register(Add);
SqliteAccountStoreParityTests.Register(Add);
SqliteIdentityRealmOracleTests.Register(Add);
SqliteSeededRealmParityTests.Register(Add);
SqliteSeededRealmOracleTests.Register(Add);
SqliteConstructionParityTests.Register(Add);
SqliteConstructionOracleTests.Register(Add);
SqliteConstructionProgressionParityTests.Register(Add);
SqliteConstructionProgressionOracleTests.Register(Add);
SqliteCapacityResearchParityTests.Register(Add);
SqliteCapacityResearchOracleTests.Register(Add);
SqliteQuestParityTests.Register(Add);
SqliteQuestOracleTests.Register(Add);
SqliteProductionParityTests.Register(Add);
SqliteProductionOracleTests.Register(Add);
FiniteAttemptTests.Register(Add);
// Explicit bounded developer run; default still executes the whole versioned suite.
if (Environment.GetEnvironmentVariable("AL_N1_SUMMONING_BATCH_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("Summoning batch: ", StringComparison.Ordinal)).ToList();
if (Environment.GetEnvironmentVariable("AL_FIRST_JOURNEY_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("First journey: ", StringComparison.Ordinal)).ToList();
if (Environment.GetEnvironmentVariable("AL_RECRUITMENT_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("Recruitment bridge: ", StringComparison.Ordinal)).ToList();
if (Environment.GetEnvironmentVariable("AL_HEROES_DIAGNOSTIC_ONLY") == "1")
    tests = new List<(string Name, Func<Task> Run)> { ("Heroes diagnostic: preserved progression owner v1 rejection and v2 read", HeroesConstructionReadDiagnosticTests.Run) };
if (Environment.GetEnvironmentVariable("AL_SUMMONING_PREVIEW_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("Summoning preview: ", StringComparison.Ordinal)).ToList();
if (Environment.GetEnvironmentVariable("AL_ACCOUNT_STORE_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("Account store seam: ", StringComparison.Ordinal)).ToList();
if (Environment.GetEnvironmentVariable("AL_NONENROLLED_ONLY") == "1")
    tests = tests.Where(t => t.Name.StartsWith("Non-enrolled progression: ", StringComparison.Ordinal)).ToList();
if (tests.Count == 0) throw new InvalidOperationException("No tests selected.");
var rows = new List<object>(); int failed = 0;
foreach (var test in tests)
{
    try { await test.Run(); rows.Add(new { test.Name, passed = true }); }
    catch (Exception error) { failed++; rows.Add(new { test.Name, passed = false, error = error.Message }); Console.Error.WriteLine(test.Name + ": " + error.Message); }
}
if (args.Length != 1) throw new ArgumentException("Evidence output path required.");
File.WriteAllText(args[0], JsonSerializer.Serialize(new { passed = tests.Count - failed, failed, tests = rows }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Account server: {tests.Count - failed} passed, {failed} failed. No real emails sent.");
return failed == 0 ? 0 : 1;

sealed class CaptureEmail : IVerificationEmailSender
{
    public bool IsConfigured { get; set; } = true;
    public string Code = "";
    public bool Throw;
    public TaskCompletionSource? Pending;
    public Task SendAsync(string email, string code, int lifetime, CancellationToken cancellation)
    { Code = code; if (Throw) throw new Exception("private-smtp-password"); return Pending?.Task ?? Task.CompletedTask; }
}

sealed class WireCodec : IAccountJsonCodec
{
    private readonly JsonSerializerOptions options = new() { IncludeFields = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
    public string Encode(object value) => JsonSerializer.Serialize(value, value.GetType(), options);
    public T Decode<T>(string json) where T : class => JsonSerializer.Deserialize<T>(json, options)!;
}
sealed class FakeWire : IAccountHttpTransport
{
    public Func<string, string, string, string, CancellationToken, Task<AccountHttpResponse>> Reply = null!;
    public string LastBearer = ""; public int Calls;
    public Task<AccountHttpResponse> SendAsync(string method, string path, string json, string bearer, CancellationToken cancellation)
    { Calls++; LastBearer = bearer; return Reply(method, path, json, bearer, cancellation); }
}
sealed class FailedIntentStore : IConstructionIntentStore
{
    public ConstructionIntent Read(string accountId, string kingdomId) => null!;
    public void Save(ConstructionIntent intent) => throw new IOException("private-disk-path");
    public void Clear(ConstructionIntent acknowledged) => throw new IOException("private-disk-path");
}

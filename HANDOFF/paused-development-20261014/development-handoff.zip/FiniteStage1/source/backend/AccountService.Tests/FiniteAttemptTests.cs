using System.Text;
using System.Text.Json;
using AnotherLife.AccountService;
using AnotherLife.StoryCombat;
using AnotherLife.StoryJournal;

internal static class FiniteAttemptTests
{
    static void Need(bool value,string why){if(!value)throw new Exception(why);}
    static void Bad(Action action){try{action();}catch(Exception e) when(e is InvalidDataException or InvalidOperationException or ArgumentException){return;}throw new Exception("Expected refusal");}
    static string N(int n)=>n.ToString("x32");
    static string Owner=>"ala_"+N(1);
    static FiniteAttemptPolicy Policy(int a=3,int r=1)=>new("fixture","fixture-v1",new string('a',64),"fixture-policy","story","fixture-encounter",0,a,r);
    // Synthetic non-test-flag input exercises the trusted journal seam; no shipping content is converted or enabled.
    static BattleInput Input(FiniteAttemptPolicy? p,int hp=100,int enemyHp=10000000,int attack=1)=>new(
        p==null?BattleInput.SupportedEngineVersion:FiniteAttemptPolicy.Engine,"fixture-encounter","fixture-v1",false,100,
        "party-then-enemies","first-living-party",Enumerable.Range(0,5).Select(i=>new Hero("hero-"+i,"fixture-hero","fixture-v1",hp,1,
            new[]{new Skill("hit",Target.Enemy,Effect.Damage,1),new Skill("heal",Target.Ally,Effect.Heal,1)})),new[]{new Enemy("fixture-enemy",enemyHp,attack)},p);
    static StoredAttempt Start(BattleInput b)=>StrictJournal.CreateTrustedAttempt(Owner,N(100),N(101),b);
    static ActionIntent Choose(StoredAttempt s,int nonce,string skill="hit")
    {var x=StrictJournal.Load(s,Owner,N(100));return new(N(nonce),s.BattleVersion,x.Input.Heroes[x.State.Cursor].InstanceId,skill,skill=="heal"?x.State.Cursor:5);}
    static StoredAttempt Advance(StoredAttempt s,int nonce,string skill="hit")=>StrictJournal.Plan(s,Owner,N(100),Choose(s,nonce,skill),100+nonce).Replacement??throw new Exception("Accepted replacement missing");
    static StoredAttempt Copy(StoredAttempt s,int? a,int? r,TerminalReason? reason,IEnumerable<StoredStep>? steps=null)=>new(s.OwnerAccountId,s.AttemptId,s.EntryNonce,s.StageId,s.SnapshotBytes,s.InputHash,s.RowCount,s.BattleVersion,s.Outcome,s.StateHash,s.HeadHash,steps??s.Steps,a,r,reason);
    static string Catalog(bool enabled=true,int a=3,int r=1)=>JsonSerializer.Serialize(new{version=1,catalogId="kingdom_attempt_limits",revision="fixture-v1",runtimeEnabled=enabled,records=new[]{new{
        policyId="fixture-policy",mode="story",encounterId="fixture-encounter",floor=0,maxAcceptedActions=a,maxRecordedRejections=r,
        engineVersion=FiniteAttemptPolicy.Engine,exhaustionOutcome=FiniteAttemptPolicy.ExhaustionOutcome,countRule=FiniteAttemptPolicy.CountRule,normalTerminalPrecedence=FiniteAttemptPolicy.Precedence,runtimeEnabled=true}}});
    static FiniteAttemptPolicy Resolve(string json)=>FiniteAttemptCatalog.Parse(Encoding.UTF8.GetBytes(json)).Resolve("story","fixture-encounter",0);
    public static void Register(Action<string,Func<Task>> add)
    {
        void Case(string name,Action body)=>add("Finite attempt Stage1: "+name,()=>{body();return Task.CompletedTask;});
        Case("A minus one active then exhaustion without falsified HP",()=>{
            var s=Advance(Advance(Start(Input(Policy())),1),2);Need(s.Outcome==Outcome.Active&&s.AcceptedActionsUsed==2,"Early terminal");
            s=Advance(s,3);var x=StrictJournal.Load(s,Owner,N(100));Need(s.Outcome==Outcome.Defeat&&s.TerminalReason==TerminalReason.ActionBudgetExhausted&&s.BattleVersion==4&&x.State.Hp.All(h=>h>0),"Exhaustion semantics");
        });
        Case("full health healing consumes A and cannot loop forever",()=>{
            var s=Start(Input(Policy(7,0)));for(int i=1;i<=7;i++)s=Advance(s,i,"heal");
            Need(s.AcceptedActionsUsed==7&&s.TerminalReason==TerminalReason.ActionBudgetExhausted&&s.RecordedRejectionsUsed==0,"Healing loop");
        });
        Case("ordinary victory on A wins over exhaustion",()=>{
            var s=Start(Input(Policy(3,0),enemyHp:3));for(int i=1;i<=3;i++)s=Advance(s,i);
            Need(s.Outcome==Outcome.Victory&&s.TerminalReason==TerminalReason.Victory&&s.AcceptedActionsUsed==3,"Victory overridden");
        });
        Case("maximum HP low damage battle has a finite accepted suffix",()=>{
            var s=Start(Input(Policy(5,0),hp:5400000));for(int i=1;i<=5;i++)s=Advance(s,i);
            var x=StrictJournal.Load(s,Owner,N(100));Need(x.State.Hp.All(h=>h>0)&&x.State.TerminalReasonCode=="action_budget_exhausted"&&s.BattleVersion==6,"High HP trap remains");
        });
        Case("natural defeat before and on A preserves ordinary reason",()=>{
            foreach(int a in new[]{15,16}){var s=Start(Input(Policy(a,0),hp:1,attack:100));for(int i=1;s.Outcome==Outcome.Active;i++){Need(i<=15,"Defeat bound");s=Advance(s,i);}
                Need(s.AcceptedActionsUsed==15&&s.TerminalReason==TerminalReason.Defeat,"Natural defeat replaced");}
        });
        Case("durable rejection quota cannot steal accepted terminal capacity",()=>{
            var s=Start(Input(Policy(1,1)));var wrong=new ActionIntent(N(1),1,"hero-1","hit",5);
            var reject=StrictJournal.Plan(s,Owner,N(100),wrong,101);Need(reject.Receipt!.Recorded&&!reject.Receipt.Accepted,"First rejection not durable");s=reject.Replacement!;
            var full=StrictJournal.Plan(s,Owner,N(100),new ActionIntent(N(2),1,"hero-1","hit",5),102);
            Need(full.Replacement==null&&!full.Receipt!.Recorded&&full.Diagnostic=="REJECTION-STORAGE-BOUND","R exceeded");
            s=Advance(s,3);Need(s.RowCount==2&&s.AcceptedActionsUsed==1&&s.RecordedRejectionsUsed==1&&s.Outcome==Outcome.Defeat,"Accepted slot stolen");
            var retry=StrictJournal.Plan(s,Owner,N(100),wrong,999);Need(retry.Receipt!.Replayed&&retry.Diagnostic==reject.Diagnostic&&retry.Replacement==null,"Rejected replay lost");
        });
        Case("terminal replay survives snapshot reload and new nonce does not grow",()=>{
            var s=Start(Input(Policy(1,0)));var command=Choose(s,1);s=Advance(s,1);s=Copy(s,s.AcceptedActionsUsed,s.RecordedRejectionsUsed,s.TerminalReason);
            var retry=StrictJournal.Plan(s,Owner,N(100),command,999);Need(retry.Receipt!.Replayed&&retry.Replacement==null,"Last action replay");
            var late=StrictJournal.Plan(s,Owner,N(100),new ActionIntent(N(2),2,"hero-1","hit",5),1000);Need(late.Diagnostic=="FINISHED"&&!late.Receipt!.Recorded&&late.Replacement==null,"Terminal journal growth");
        });
        Case("technical row ceiling reserves the last accepted action after R",()=>{
            var b=Input(Policy(1,9999));var commands=Enumerable.Range(1,9999).Select(i=>new ActionCommand(N(i),1,"hero-1","hit",5,100+i)).ToList();
            commands.Add(new ActionCommand(N(20000),1,"hero-0","hit",5,20000));var r=TurnReplay.Replay(b,commands);
            Need(r.Journal.Count==10000&&r.RecordedRejectionsUsed==9999&&r.AcceptedActionsUsed==1&&r.Outcome==Outcome.Defeat&&r.TerminalReason==TerminalReason.ActionBudgetExhausted,"Rejections stole final slot");
        });
        Case("finite old nonce conflict precedes new structural validation",()=>{
            var s=Advance(Start(Input(Policy())),1);
            var p=StrictJournal.Plan(s,Owner,N(100),new ActionIntent(N(1),0,"!","!",-1),0);
            Need(p.Diagnostic=="REQUEST-CONFLICT"&&p.Replacement==null,"Original nonce ignored");
        });
        Case("nondurable rejection does not advance durable clock",()=>{
            var b=Input(Policy(1,0));var r=TurnReplay.Replay(b,new[]{new ActionCommand(N(1),1,"hero-1","hit",5,999),new ActionCommand(N(2),1,"hero-0","hit",5,101)});
            Need(!r.Receipts[0].Recorded&&r.Receipts[1].Accepted&&r.AcceptedActionsUsed==1,"Unstored timestamp leaked");
        });
        Case("frozen snapshot survives current catalog changes",()=>{
            var p=Resolve(Catalog(a:3));var bytes=SnapshotCodec.Encode(Input(p));var newer=Resolve(Catalog(a:4));
            var old=SnapshotCodec.Decode(bytes);Need(old.FinitePolicy!.MaximumAcceptedActions==3&&newer.MaximumAcceptedActions==4&&old.FinitePolicy.CatalogDigest!=newer.CatalogDigest,"Policy replaced");
            Need(bytes.SequenceEqual(SnapshotCodec.Encode(old)),"Noncanonical snapshot roundtrip");
        });
        Case("strict journal rejects missing tampered counters reason and reordered rows",()=>{
            var s=Advance(Advance(Start(Input(Policy())),1),2);
            foreach(var bad in new[]{Copy(s,null,null,null),Copy(s,1,0,TerminalReason.None),Copy(s,2,1,TerminalReason.None),Copy(s,2,0,TerminalReason.Defeat),Copy(s,2,0,TerminalReason.None,s.Steps.Reverse()),Copy(s,2,0,TerminalReason.None,new[]{s.Steps[0],s.Steps[0]})})Bad(()=>StrictJournal.Load(bad,Owner,N(100)));
        });
        Case("strict catalog rejects disabled missing duplicate unknown and overflow terms",()=>{
            Bad(()=>Resolve(Catalog(false)));Bad(()=>Resolve(Catalog(a:10000,r:1)));Bad(()=>Resolve(Catalog(a:int.MaxValue,r:int.MaxValue)));
            Bad(()=>Resolve(Catalog().Replace("\"mode\":\"story\"","\"mode\":\"endless\"")));
            Bad(()=>Resolve(Catalog().Replace("\"floor\":0,","")));Bad(()=>Resolve(Catalog().Replace("\"floor\":0","\"floor\":0,\"floor\":0")));
            Bad(()=>Resolve(Catalog().Replace("\"floor\":0","\"floor\":0,\"bytes\":100")));
            Bad(()=>Resolve(Catalog().Replace(FiniteAttemptPolicy.Engine,"five-hero-effects-v2-candidate")));
            var valid=Catalog();int start=valid.IndexOf("[{",StringComparison.Ordinal);string row=valid.Substring(start+1,valid.Length-start-3);Bad(()=>Resolve(valid.Substring(0,start)+"["+row+","+row+"]}"));
            Bad(()=>FiniteAttemptCatalog.Parse(Encoding.UTF8.GetBytes(Catalog())).Resolve("tower","fixture-encounter",1));
        });
        Case("recognized format dispatch rejects missing policy trailing bytes and manual V2",()=>{
            Bad(()=>new BattleInput(FiniteAttemptPolicy.Engine,"fixture-encounter","v",false,100,"party-then-enemies","first-living-party",Input(null).Heroes,Input(null).Enemies));
            Bad(()=>new BattleInput(BattleInput.SupportedEngineVersion,"fixture-encounter","v",false,100,"party-then-enemies","first-living-party",Input(null).Heroes,Input(null).Enemies,Policy()));
            var bytes=SnapshotCodec.Encode(Input(Policy()));Bad(()=>SnapshotCodec.Decode(bytes.Take(bytes.Length-1).ToArray()));Bad(()=>SnapshotCodec.Decode(bytes.Append((byte)0).ToArray()));bytes[2]=(byte)'x';Bad(()=>SnapshotCodec.Decode(bytes));
        });
        Case("v1 durable rejections and terminal FINISHED rows stay unchanged",()=>{
            var s=Start(Input(null,enemyHp:1));var bad=new ActionIntent(N(1),1,"hero-1","hit",5);s=StrictJournal.Plan(s,Owner,N(100),bad,101).Replacement!;
            Need(s.RowCount==1&&s.BattleVersion==1&&s.AcceptedActionsUsed==null,"Legacy rejected row changed");s=Advance(s,2);
            var p=StrictJournal.Plan(s,Owner,N(100),new ActionIntent(N(3),2,"hero-1","hit",5),103);Need(p.Replacement!=null&&p.Receipt!.Recorded&&p.Diagnostic=="FINISHED","Legacy terminal policy changed");
        });
        Case("v1 canonical input and terminal golden hashes remain exact",LegacyGoldens);
    }
    static void LegacyGoldens()
    {
        // Existing test-only fixture; pinned as an external read dependency in this candidate packet.
        using var doc=JsonDocument.Parse(File.ReadAllBytes(@"F:\AnotherLife\backend\StoryCombat.Tests\Fixtures\test-story-1-1.json"));var x=doc.RootElement;
        string S(JsonElement e,string n)=>e.GetProperty(n).GetString()!;int I(JsonElement e,string n)=>e.GetProperty(n).GetInt32();
        var b=new BattleInput(S(x,"engineVersion"),S(x,"contentId"),S(x,"contentVersion"),true,x.GetProperty("startedAt").GetInt64(),S(x,"turnOrder"),S(x,"enemyTarget"),
            x.GetProperty("heroes").EnumerateArray().Select(h=>new Hero(S(h,"instanceId"),S(h,"definitionId"),S(h,"definitionVersion"),I(h,"maxHp"),I(h,"damage"),h.GetProperty("skills").EnumerateArray().Select(s=>new Skill(S(s,"id"),Enum.Parse<Target>(S(s,"target")),Enum.Parse<Effect>(S(s,"effect")),I(s,"multiplier"))))),
            x.GetProperty("enemies").EnumerateArray().Select(e=>new Enemy(S(e,"definitionId"),I(e,"maxHp"),I(e,"attack"))));
        var commands=new List<ActionCommand>();var r=TurnReplay.Replay(b,commands);Need(r.InputHash=="35f1ffdeec667c24c07f780646f9a9114b1e18e89fe25aa6c9889f4387002afd","Legacy input hash");
        for(int n=1;r.Outcome==Outcome.Active&&n<100;n++){commands.Add(new(N(n),r.Version,b.Heroes[r.Cursor].InstanceId,b.Heroes[r.Cursor].Skills[0].Id,Enumerable.Range(5,b.Enemies.Count).First(i=>r.Hp[i]>0),1000+n));r=TurnReplay.Replay(b,commands);}
        Need(r.Outcome==Outcome.Victory&&r.StateHash=="baa6ed05122f36528215d5e10c4360da80a85cd0b89a5b2a7ad01b8c38e2cad0","Legacy terminal hash");
        Need(SnapshotCodec.Encode(b).SequenceEqual(SnapshotCodec.Encode(SnapshotCodec.Decode(SnapshotCodec.Encode(b)))),"Legacy bytes roundtrip");
    }
}

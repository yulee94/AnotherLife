param([Parameter(Mandatory)][string]$Mode,[Parameter(Mandatory)][string]$Log,[Parameter(Mandatory)][int]$ExitCode,[Parameter(Mandatory)][string]$Result)
$ErrorActionPreference='Stop'
$guards=@(Get-Content "$PSScriptRoot\NEGATIVE_GUARDS.json" -Raw|ConvertFrom-Json|Where-Object{$Mode -in $_.modes})
if($guards.Count -eq 0 -or $ExitCode -eq 0){throw 'Negative mode/exit is not an expected guard failure'}
$text=[IO.File]::ReadAllText($Log)
$errorLines=@($text -split '\r?\n'|Where-Object{$_ -match '\berror(?:\s+[A-Z]+\d+)?\s*:'})
if($errorLines.Count -eq 0){throw 'No designated compiler diagnostic'}
$observed=@()
foreach($line in $errorLines){
    if($line -notmatch '^\s*(?:\d+>)?(?<file>F:\\.+?\.cs)\((?<line>\d+),(?<column>\d+)\):\s*error\s+(?<code>CS\d+):\s*#error:\s*''(?<message>[^'']+)''\s+\[(?<project>[^\]]+)\]'){
        throw "Unrelated or unparsed error: $line"
    }
    $file=$Matches.file;$number=[int]$Matches.line;$code=$Matches.code;$message=$Matches.message;$project=$Matches.project
    if($code -ne 'CS1029' -or $project -ne "F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-qualification-graph-20261014-r001\graphs\$Mode\AccountService\AccountService.csproj"){throw 'Unexpected compiler error or assembly'}
    $match=@($guards|Where-Object{$_.source -eq $file -and $_.line -eq $number -and $_.message -ceq $message})
    if($match.Count -ne 1){throw "Non-designated guard: $file : $number : $message"}
    $observed+=$file+'|'+$number+'|'+$message
}
foreach($g in $guards){if(($g.source+'|'+$g.line+'|'+$g.message) -notin $observed){throw 'Required dependency guard absent'}}
# Fatal runtime/restore failures must not hide behind a coincident compiler diagnostic.
if($text -match '(?im)^\s*(?:Unhandled exception|A fatal error|Out of memory|Process terminated|MSBUILD\s*:)'){throw 'Additional fatal failure'}
[ordered]@{status='EXPECTED_GUARDS_ONLY';mode=$Mode;exit=$ExitCode;diagnosticLines=$errorLines.Count;uniqueGuards=@($observed|Sort-Object -Unique);rawLogSha256=(Get-FileHash -LiteralPath $Log).Hash}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $Result

# NOT ADMITTED. Root must supply a fresh matching admission and exclusive lease.
$ErrorActionPreference='Stop'
$recipe=$PSScriptRoot
$r=Get-Content "$recipe\RECIPE.json" -Raw|ConvertFrom-Json
$run=$r.run
$phases=@(Get-Content "$recipe\PHASES.json" -Raw|ConvertFrom-Json)
$startFile="$run\JOB_START.json"
$child=$null
$savedEnv=@{}
function Save($name,$value){$value|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$run\$name"}
function Pins($path){foreach($p in (Get-Content -LiteralPath $path -Raw|ConvertFrom-Json)){if((Get-FileHash -LiteralPath $p.path).Hash -ne $p.sha256){throw "Pin changed: $($p.path)"}}}
function FPath([string]$path){
    $p=[IO.Path]::GetFullPath($path)
    if(-not $p.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)){throw 'Non-F path'}
    $item=if(Test-Path -LiteralPath $p){Get-Item -LiteralPath $p}else{[IO.DirectoryInfo]$p}
    if($item.Exists -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse output/input'}
    $d=if($item -is [IO.FileInfo]){$item.Directory}else{$item}
    for(;$null -ne $d;$d=$d.Parent){if($d.Exists -and ($d.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse ancestor'}}
}
function Admission {
    $a=Get-Content "$run\ROOT_ADMISSION.json" -Raw|ConvertFrom-Json
    $lease=Get-Content 'F:\AnotherLife\.agent\NATIVE_SLOT_RESERVATION.json' -Raw|ConvertFrom-Json
    if($a.status -ne 'ADMITTED' -or $a.nativeExecutionAuthorized -ne $true -or $a.run -ne $run -or $a.phaseCount -ne 18 -or $a.deadlineSeconds -ne 600 -or $a.perPhaseMaximumSeconds -ne 120 -or $a.expectedCaseExecutions -ne 66){throw 'Fresh admission fields mismatch'}
    if($a.recipePacketSha256 -ne (Get-FileHash "$recipe\PACKET_SHA256.json").Hash -or $a.graphReviewSha256 -ne $r.sourceGraphReviewSha256){throw 'Admission does not bind recipe and graph review'}
    if($lease.status -ne 'ADMITTED' -or $lease.nativeExecutionAuthorized -ne $true -or $lease.exclusiveNativeWindow -ne $true -or $lease.nativeHeavySlotsReserved -ne 1 -or $lease.leaseId -ne $a.leaseId -or $lease.admissionPath -ne "$run\ROOT_ADMISSION.json"){throw 'Exclusive native lease mismatch'}
    if($lease.admissionSha256 -ne (Get-FileHash "$run\ROOT_ADMISSION.json").Hash){throw 'Lease admission hash mismatch'}
    return $a
}
function Resources($label){
    $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 5;$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -OperationTimeoutSec 5
    $v=@{cFree=(Get-PSDrive C).Free;fFree=(Get-PSDrive F).Free;ramFree=[long]$os.FreePhysicalMemory*1KB;commitHeadroom=[long]$m.CommitLimit-[long]$m.CommittedBytes;commitPercent=[double]$m.PercentCommittedBytesInUse;utc=[DateTime]::UtcNow.ToString('o')}
    Save "$label-RESOURCES.json" $v
    if($v.cFree -lt 40GB -or $v.fFree -lt 20GB -or $v.ramFree -lt 8GB -or $v.commitHeadroom -lt 15GB -or $v.commitPercent -ge 80){throw 'Resource gate failed; no retry'}
}
function Deadline {
    $s=Get-Content -LiteralPath $startFile -Raw|ConvertFrom-Json
    if([DateTime]::UtcNow -ge ([DateTime]$s.deadlineUtc).ToUniversalTime()){throw 'Original job deadline expired'}
}
function Census($label){
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5|Select-Object ProcessId,ParentProcessId,Name,CreationDate,ExecutablePath)
    Save "$label-CENSUS.json" $all
    return $all
}
function NoWorkers($label){
    $all=Census $label
    if(@($all|Where-Object{$_.Name -match '^(Unity|UnityShaderCompiler|UnityPackageManager|UnityCrashHandler.*|bee_backend|dotnet|MSBuild|VBCSCompiler|csc|il2cpp|java|adb|blender|python|pythonw|python3|mono|mcs|cl|link)(\.exe)?$'}).Count){throw 'Native workers present; Root disposition required'}
}
function SetEnv($name,$value){
    if(-not $savedEnv.ContainsKey($name)){$savedEnv[$name]=[Environment]::GetEnvironmentVariable($name,'Process')}
    [Environment]::SetEnvironmentVariable($name,$value,'Process')
}
function VerifyTests($phase){
    $result=Get-Content "$run\$($phase.mode)-results.json" -Raw|ConvertFrom-Json
    $expected=@((Get-Content "$($r.graph)\EXPECTED_SELECTION.json" -Raw|ConvertFrom-Json).($phase.mode))
    $actual=@($result.tests|ForEach-Object Name)
    if($result.failed -ne 0 -or $result.passed -ne $phase.expectedCases -or $actual.Count -ne $expected.Count -or @($result.tests|Where-Object{$_.passed -ne $true}).Count -or (@($actual|Sort-Object) -join '|') -cne (@($expected|Sort-Object) -join '|')){throw 'Test count/name/result mismatch; no weaker selector'}
}
function Native($phase){
    $null=Admission;Deadline;Resources $phase.label;NoWorkers $phase.label
    Pins "$recipe\PACKET_SHA256.json";Pins "$recipe\BASELINE_PINS.json";Pins "$recipe\SDK_CRITICAL_PINS.json"
    if(Test-Path "$run\$($phase.label).START.json"){throw 'Phase already attempted'}
    if($phase.executable -ne "$($r.sdk)\dotnet.exe" -or $phase.cwd -ne $recipe){throw 'Executable/cwd mismatch'}
    if($phase.kind -eq 'tests'){
        $dll="$run\artifacts\$($phase.mode)\bin\AccountService.Tests\debug\AccountService.Tests.dll"
        if($phase.arguments.Count -ne 2 -or $phase.arguments[0] -ne $dll -or $phase.arguments[1] -ne "$run\$($phase.mode)-results.json"){throw 'Unsafe test invocation'}
        SetEnv 'AL_TOWER_QUALIFICATION_MODE' $phase.mode
        foreach($pair in @{AL_STORY_ATOMIC_TEST_ROOT='atomic';AL_STORY_MIGRATION_TEST_ROOT='migration';AL_TOWER_CAPABILITY_TEST_ROOT='capability'}.GetEnumerator()){
            $dir="$run\fixtures\$($phase.mode)\$($pair.Value)";FPath $dir;[void][IO.Directory]::CreateDirectory($dir);SetEnv $pair.Key $dir
        }
    }
    $info=[Diagnostics.ProcessStartInfo]::new($phase.executable);$info.WorkingDirectory=$recipe;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
    foreach($arg in $phase.arguments){[void]$info.ArgumentList.Add([string]$arg)}
    $script:child=[Diagnostics.Process]::new();$child.StartInfo=$info
    Deadline
    $began=[DateTime]::UtcNow
    Save "$($phase.label).START.json" @{phase=$phase;utc=$began.ToString('o')}
    Deadline
    if(-not $child.Start()){throw 'Process launch failed'}
    Save "$($phase.label).PID.json" @{pid=$child.Id;utc=$began.ToString('o');executable=$phase.executable;parent=$PID}
    $stdout=[IO.File]::Create("$run\$($phase.label).stdout.log");$stderr=[IO.File]::Create("$run\$($phase.label).stderr.log")
    try{
        $outTask=$child.StandardOutput.BaseStream.CopyToAsync($stdout);$errTask=$child.StandardError.BaseStream.CopyToAsync($stderr)
        $ticks=0
        while(-not $child.WaitForExit(1000)){
            Deadline
            if(([DateTime]::UtcNow-$began).TotalSeconds -ge 120){throw 'Phase deadline expired'}
            if($stdout.Length+$stderr.Length -gt 128MB){throw 'Phase log bound exceeded'}
            if(++$ticks % 5 -eq 0){$null=Admission;Resources "$($phase.label)-live"}
        }
        while(-not($outTask.IsCompleted -and $errTask.IsCompleted)){
            Deadline
            if(([DateTime]::UtcNow-$began).TotalSeconds -ge 120){throw 'Output drain deadline expired; Root descendant disposition required'}
            Start-Sleep -Milliseconds 100
        }
        $outTask.GetAwaiter().GetResult();$errTask.GetAwaiter().GetResult();$exit=$child.ExitCode
        if($stdout.Length+$stderr.Length -gt 128MB){throw 'Phase log bound exceeded'}
    } finally {
        if(-not $child.HasExited){$child.Kill($true);$child.WaitForExit(5000)|Out-Null}
        $stdout.Dispose();$stderr.Dispose()
    }
    Save "$($phase.label).EXIT.json" @{exit=$exit;utc=[DateTime]::UtcNow.ToString('o')}
    $log="$run\$($phase.label).log"
    [IO.File]::WriteAllText($log,[IO.File]::ReadAllText("$run\$($phase.label).stdout.log")+"`r`n"+[IO.File]::ReadAllText("$run\$($phase.label).stderr.log"))
    if($phase.kind -eq 'build'){
        $raw=@([IO.File]::ReadAllLines($log)|Where-Object{$_ -match '(?i)csc\.dll.* /noconfig'})
        if($raw.Count -eq 0){throw 'Raw csc invocation absent in diagnostic log'}
        $raw|Set-Content "$run\$($phase.mode)-RAW_CSC.txt"
    }
    if($phase.expectedExit -eq 'designated-guards-only'){
        & "$recipe\Verify-Negative.ps1" -Mode $phase.mode -Log $log -ExitCode $exit -Result "$run\$($phase.mode)-NEGATIVE_RESULT.json"
        & "$recipe\Verify-Evidence.ps1" -Mode $phase.mode -Negative
    }else{
        if($exit -ne 0){throw "Unexpected native exit $exit"}
        if($phase.kind -eq 'build'){& "$recipe\Verify-Evidence.ps1" -Mode $phase.mode}
        if($phase.kind -eq 'tests'){VerifyTests $phase}
    }
    Deadline;NoWorkers "$($phase.label)-after"
    $child.Dispose();$script:child=$null
}
FPath $recipe;FPath $run
$null=Admission
if(Test-Path -LiteralPath $startFile){throw 'Frozen original job clock exists; no reuse'}
if(Test-Path -LiteralPath "$run\ATTEMPT.json"){throw 'Prior machine attempt exists, including preflight failure; use a separately reviewed successor'}
Save 'ATTEMPT.json' @{utc=[DateTime]::UtcNow.ToString('o');admissionSha256=(Get-FileHash "$run\ROOT_ADMISSION.json").Hash;retryAuthorized=$false}
Pins "$recipe\PACKET_SHA256.json";Pins "$recipe\BASELINE_PINS.json";Pins "$recipe\SDK_TREE_PINS.json"
Resources 'preflight';NoWorkers 'preflight'
foreach($folder in @('artifacts','evidence','feed','nuget-packages')){
    FPath "$run\$folder"
    if((Test-Path "$run\$folder") -and @(Get-ChildItem -LiteralPath "$run\$folder" -Force).Count){throw 'Fresh isolated machine output required'}
}
if((Test-Path "$run\machine-access.verified") -or (Test-Path "$run\machine-access.pending")){throw 'Prior machine preparation exists'}
[IO.File]::WriteAllText("$run\machine-access.pending",'F-only write/read/rename')
if([IO.File]::ReadAllText("$run\machine-access.pending") -ne 'F-only write/read/rename'){throw 'Run read probe failed'}
[IO.File]::Move("$run\machine-access.pending","$run\machine-access.verified")
$forbidden=@('DOTNET_STARTUP_HOOKS','DOTNET_ADDITIONAL_DEPS','DOTNET_SHARED_STORE','DOTNET_DiagnosticPorts','CORECLR_ENABLE_PROFILING','CORECLR_PROFILER','CORECLR_PROFILER_PATH','COR_ENABLE_PROFILING','COR_PROFILER','COR_PROFILER_PATH','NUGET_PLUGIN_PATHS','NUGET_CREDENTIALPROVIDERS_PATH','DOTNET_MSBUILD_SDK_RESOLVER_SDKS_DIR','DOTNET_MSBUILD_SDK_RESOLVER_SDKS_VER','DOTNET_MSBUILD_SDK_RESOLVER_CLI_DIR','MSBuildSDKsPath','MSBUILD_EXE_PATH','MSBuildExtensionsPath','MSBuildExtensionsPath32','MSBuildExtensionsPath64','CustomBeforeMicrosoftCommonTargets','CustomAfterMicrosoftCommonTargets','DirectoryBuildPropsPath','DirectoryBuildTargetsPath','DirectoryPackagesPropsPath','MSBuildUserExtensionsPath','MSBUILDADDITIONALSDKRESOLVERSFOLDER','DOTNET_HOST_PATH')
foreach($name in $forbidden){if(-not [string]::IsNullOrEmpty([Environment]::GetEnvironmentVariable($name,'Process'))){throw "Inherited override rejected: $name"}}
$now=[DateTime]::UtcNow
Save 'JOB_START.json' @{startedUtc=$now.ToString('o');deadlineUtc=$now.AddSeconds(600).ToString('o');deadlineSeconds=600;recipePacketSha256=(Get-FileHash "$recipe\PACKET_SHA256.json").Hash}
try{
    foreach($e in (Get-Content "$recipe\ENVIRONMENT.json" -Raw|ConvertFrom-Json -AsHashtable).GetEnumerator()){
        if($e.Value.StartsWith($run,[StringComparison]::OrdinalIgnoreCase)){FPath $e.Value;[void][IO.Directory]::CreateDirectory($e.Value)}
        SetEnv $e.Key $e.Value
    }
    foreach($name in @('AL_N1_SUMMONING_BATCH_ONLY','AL_FIRST_JOURNEY_ONLY','AL_RECRUITMENT_ONLY','AL_HEROES_DIAGNOSTIC_ONLY','AL_SUMMONING_PREVIEW_ONLY','AL_ACCOUNT_STORE_ONLY','AL_NONENROLLED_ONLY')){SetEnv $name $null}
    if([IO.Path]::GetTempPath().TrimEnd('\') -ne "$run\temp"){throw 'Parent managed temp route mismatch'}
    Save 'ROUTING.json' @{parentManagedTemp=[IO.Path]::GetTempPath();plan=(Get-Content "$recipe\ENVIRONMENT.json" -Raw|ConvertFrom-Json);scope='Process-local; child MSBuild verifies actual temp/runtime in evidence target; no global no-C-write claim'}
    $cache="$run\nuget-packages"
    if(@(Get-ChildItem -LiteralPath $cache -Force).Count -ne 0){throw 'Fresh cache required'}
    [void][IO.Directory]::CreateDirectory("$run\feed")
    foreach($p in (Get-Content "$recipe\PACKAGES.json" -Raw|ConvertFrom-Json)){
        FPath $p.source;FPath $p.futureCopyDestination
        if((Get-FileHash -LiteralPath $p.source).Hash -ne $p.sha256 -or (Test-Path $p.futureCopyDestination)){throw 'Package pin/destination mismatch'}
        [IO.File]::Copy($p.source,$p.futureCopyDestination,$false)
        if((Get-FileHash -LiteralPath $p.futureCopyDestination).Hash -ne $p.sha256){throw 'Package copy mismatch'}
    }
    foreach($phase in $phases){Native $phase}
    Pins "$recipe\BASELINE_PINS.json";Pins "$recipe\SDK_TREE_PINS.json";NoWorkers 'final';Deadline
    Save 'RESULT.json' @{status='ALL_PLANNED_PHASES_PASSED';phases=18;testProcesses=4;caseExecutions=66;productionAccepted=$false;rootIndependentReviewRequired=$true}
}catch{
    Save 'FAILED.json' @{utc=[DateTime]::UtcNow.ToString('o');error=$_.Exception.Message;retryAuthorized=$false}
    throw
}finally{
    try {
        if($null -ne $child){
            try{if(-not $child.HasExited){$child.Kill($true);$child.WaitForExit(5000)|Out-Null}}
            catch{Save 'CLEANUP_ERROR.json' @{error=$_.Exception.Message;rootDispositionRequired=$true}}
            finally{$child.Dispose()}
        }
        try { $null=Census 'closeout' }
        catch {
            try { Save 'CLOSEOUT_CENSUS_ERROR.json' @{error=$_.Exception.Message;rootDispositionRequired=$true} }
            finally { throw }
        }
    } finally {
        foreach($name in $savedEnv.Keys){
            $prior=$savedEnv[$name]
            if($null -eq $prior){[Environment]::SetEnvironmentVariable($name,[NullString]::Value,'Process')}
            else{[Environment]::SetEnvironmentVariable($name,$prior,'Process')}
        }
    }
}

param([Parameter(Mandatory)][string]$Mode,[switch]$Negative)
$ErrorActionPreference='Stop'
$r=Get-Content "$PSScriptRoot\RECIPE.json" -Raw|ConvertFrom-Json
$graph=Get-Content "$($r.graph)\SOURCE_GRAPH.json" -Raw|ConvertFrom-Json
$matrix=Get-Content "$($r.graph)\MATRIX.json" -Raw|ConvertFrom-Json
$wanted=($matrix|Where-Object name -eq $Mode).symbols -split ';'|Where-Object{$_}
$sourcePins=@{};foreach($p in (Get-Content "$PSScriptRoot\BASELINE_PINS.json" -Raw|ConvertFrom-Json)){$sourcePins[$p.path]=$p.sha256}
$sdkPins=@{};foreach($p in (Get-Content "$PSScriptRoot\SDK_TREE_PINS.json" -Raw|ConvertFrom-Json)){$sdkPins[$p.path]=$p.sha256}
$evidence=@();$artifactRoot="$($r.run)\artifacts\$Mode\"
function Capture($p){
    if(-not(Test-Path -LiteralPath $p -PathType Leaf)){throw "Missing evidence: $p"}
    [ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash;bytes=(Get-Item -LiteralPath $p).Length}
}
foreach($g in $graph){
    if($Negative -and $g.name -eq 'AccountService.Tests'){continue}
    $dir="$($r.run)\evidence\$Mode\$($g.name)"
    $paths=@([IO.File]::ReadAllLines("$dir\sources.txt")|Where-Object{$_})
    if(@($paths|Sort-Object -Unique).Count -ne $paths.Count){throw 'Duplicate compiler source'}
    foreach($f in $g.files){if($f -notin $paths){throw "Missing expected source $f"}}
    foreach($f in $paths){
        if($f -in $g.files){if((Get-FileHash -LiteralPath $f).Hash -ne $sourcePins[$f]){throw 'Compiler source drift'}}
        elseif(-not $f.StartsWith($artifactRoot,[StringComparison]::OrdinalIgnoreCase) -or ([IO.Path]::GetFileName($f) -notmatch '^(?:\.NET(?:CoreApp|Standard),Version=v[\d.]+\.AssemblyAttributes\.cs|[A-Za-z.]+\.(?:AssemblyInfo|GlobalUsings\.g)\.cs)$')){throw "Unexpected generated source $f"}
        $evidence+=Capture $f
    }
    $symbols=@([IO.File]::ReadAllLines("$dir\symbols.txt")|Where-Object{$_ -like 'ACCOUNT_*'}|Sort-Object)
    if(($symbols -join ';') -ne (@($wanted|Sort-Object) -join ';')){throw "Symbol mismatch $($g.name)"}
    $refs=@([IO.File]::ReadAllLines("$dir\project-references.txt")|Where-Object{$_})
    $expected=@($g.references|ForEach-Object{"$($r.graph)\graphs\$Mode\$_\$_.csproj"})
    if((@($refs|Sort-Object) -join '|') -ne (@($expected|Sort-Object) -join '|')){throw 'Project edge mismatch'}
    foreach($list in @('references','analyzers','imports')){
        foreach($p in @([IO.File]::ReadAllLines("$dir\$list.txt")|Where-Object{$_})){
            if($sdkPins.ContainsKey($p)){if((Get-FileHash -LiteralPath $p).Hash -ne $sdkPins[$p]){throw 'SDK reference/import drift'}}
            elseif($sourcePins.ContainsKey($p)){if((Get-FileHash -LiteralPath $p).Hash -ne $sourcePins[$p]){throw 'Project import drift'}}
            elseif($p.StartsWith("$PSScriptRoot\",[StringComparison]::OrdinalIgnoreCase)){
                $pin=Get-Content "$PSScriptRoot\PACKET_SHA256.json" -Raw|ConvertFrom-Json|Where-Object path -eq $p
                if($null -eq $pin -or (Get-FileHash -LiteralPath $p).Hash -ne $pin.sha256){throw 'Recipe import drift'}
            }
            elseif(-not($p.StartsWith($artifactRoot,[StringComparison]::OrdinalIgnoreCase) -or $p.StartsWith("$($r.run)\nuget-packages\",[StringComparison]::OrdinalIgnoreCase))){throw "Unapproved reference/import $p"}
            if($p.StartsWith("$($r.run)\nuget-packages\",[StringComparison]::OrdinalIgnoreCase)){
                $relative=$p.Substring(("$($r.run)\nuget-packages\").Length).Replace('\','/')
                $parts=$relative.Split('/');if($parts.Length -lt 3){throw 'Invalid package reference path'}
                $archive="$($r.run)\nuget-packages\$($parts[0])\$($parts[1])\$($parts[0]).$($parts[1]).nupkg"
                $zip=[IO.Compression.ZipFile]::OpenRead($archive)
                try{
                    $entry=$zip.GetEntry(($parts[2..($parts.Length-1)] -join '/'))
                    if($null -eq $entry){throw 'Reference/import not present in pinned package archive'}
                    $stream=$entry.Open();$sha=[Security.Cryptography.SHA256]::Create()
                    try{$expectedHash=[Convert]::ToHexString($sha.ComputeHash($stream))}finally{$stream.Dispose();$sha.Dispose()}
                    if((Get-FileHash -LiteralPath $p).Hash -ne $expectedHash){throw 'Extracted package reference/import changed'}
                }finally{$zip.Dispose()}
            }
            $evidence+=Capture $p
        }
    }
    $assets="$artifactRoot"+'obj\'+$g.name+'\project.assets.json'
    $a=Get-Content -LiteralPath $assets -Raw|ConvertFrom-Json
    if(@($a.packageFolders.PSObject.Properties.Name).Count -ne 1 -or @($a.packageFolders.PSObject.Properties.Name)[0].TrimEnd('\') -ne "$($r.run)\nuget-packages"){throw 'Unexpected package cache'}
    foreach($lib in $a.libraries.PSObject.Properties){if($lib.Value.type -eq 'package'){
        $archive=Join-Path "$($r.run)\nuget-packages" ($lib.Value.path+'\'+(($lib.Name -split '/')[0])+'.'+(($lib.Name -split '/')[1])+'.nupkg')
        $pkg=Get-Content "$PSScriptRoot\PACKAGES.json" -Raw|ConvertFrom-Json|Where-Object{[IO.Path]::GetFileName($_.source) -eq [IO.Path]::GetFileName($archive)}
        if($null -eq $pkg -or (Get-FileHash -LiteralPath $archive).Hash -ne $pkg.sha256){throw 'Unpinned restored package'}
        $sha512=[Convert]::ToBase64String([Security.Cryptography.SHA512]::HashData([IO.File]::ReadAllBytes($archive)))
        if(([string]$lib.Value.sha512).Replace('sha512-','') -cne $sha512){throw 'Assets package content hash mismatch'}
    }}
    $evidence+=Capture $assets
    if(-not($Negative -and $g.name -eq 'AccountService')){
        $argsFile="$dir\csc-arguments.txt"
        if(-not(Test-Path -LiteralPath $argsFile) -or (Get-Item $argsFile).Length -eq 0){throw 'Raw compiler arguments absent'}
        $evidence+=Capture $argsFile
        $bin="$artifactRoot"+'bin\'+$g.name+'\debug\'
        $evidence+=Capture ($bin+$g.name+'.dll');$evidence+=Capture ($bin+$g.name+'.pdb');$evidence+=Capture ($bin+$g.name+'.deps.json')
        $pdb=[IO.File]::ReadAllBytes($bin+$g.name+'.pdb')
        if([Text.Encoding]::ASCII.GetString($pdb,0,4) -ne 'BSJB'){throw 'Portable PDB expected'}
    }
}
if(-not $Negative){
    $runtime="$artifactRoot"+'bin\AccountService.Tests\debug\AccountService.Tests.runtimeconfig.json'
    $cfg=Get-Content -LiteralPath $runtime -Raw|ConvertFrom-Json
    $frameworks=@($cfg.runtimeOptions.frameworks)+@($cfg.runtimeOptions.framework)|Where-Object{$_}
    if($cfg.runtimeOptions.rollForward -ne 'Disable' -or @($frameworks|Where-Object{$_.version -ne '8.0.21'}).Count -or $frameworks.Count -lt 1){throw 'Runtime not fixed to8.0.21'}
    $evidence+=Capture $runtime
}
@($evidence|Sort-Object path -Unique)|ConvertTo-Json -Depth 8|Set-Content "$($r.run)\$Mode-COMPILER_EVIDENCE.json"

$ErrorActionPreference='Stop'
$recipe='F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-machine-recipe-20261014-r002'
$graph='F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-qualification-graph-20261014-r001'
$run='F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-machine-run-20261014-r002'
$sdk='F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk'
function Save($name,$v){[IO.File]::WriteAllText("$recipe\$name",$v,[Text.UTF8Encoding]::new($false))}
function Json($name,$v){Save $name (ConvertTo-Json -InputObject $v -Depth 25)}
function Pin($p){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash;bytes=(Get-Item -LiteralPath $p).Length}}
$review='F:\AnotherLife\outputs\LOCAL-COORD\tower-xml24-graph-review-20261014-r001\REVIEW.md'
if((Get-FileHash $review).Hash -ne 'F42E3496250043297BA31F0991C144CCBD102225201A9605035358D8E6DFB3C0'){throw 'Graph review mismatch'}
$null=[IO.File]::ReadAllText($review)
$base=Get-Content "$graph\PACKET_SHA256.json" -Raw|ConvertFrom-Json
$sources=Get-Content "$graph\SOURCE_PINS.json" -Raw|ConvertFrom-Json
foreach($p in @($base)+@($sources)){if((Get-FileHash -LiteralPath $p.path).Hash -ne $p.sha256){throw "Source drift $($p.path)"}}
Json 'BASELINE_PINS.json' @(@($base)+@($sources)+@(Pin "$graph\PACKET_SHA256.json")+@(Pin $review)|Sort-Object path -Unique)
Json 'GRAPH_ACCEPTANCE.json' (Pin $review)
# Read/hash only; never execute this SDK while preparing the recipe.
$sdkFiles=@(Get-ChildItem -LiteralPath $sdk -Recurse -File|Sort-Object FullName)
foreach($f in $sdkFiles){if($f.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'SDK reparse'};for($a=$f.Directory;$null -ne $a;$a=$a.Parent){if($a.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'SDK ancestor reparse'}}}
Json 'SDK_TREE_PINS.json' @($sdkFiles|ForEach-Object{Pin $_.FullName})
Json 'SDK_CRITICAL_PINS.json' (Get-Content "$graph\SDK_PINS.json" -Raw|ConvertFrom-Json)
$packages=Get-Content "$graph\OFFLINE_PACKAGE_PINS.json" -Raw|ConvertFrom-Json
foreach($p in $packages){if((Get-FileHash -LiteralPath $p.source).Hash -ne $p.sha256){throw 'Package changed'};$p.futureCopyDestination="$run\feed\$([IO.Path]::GetFileName($p.source))"}
Json 'PACKAGES.json' $packages
Save 'NuGet.Config' ('<configuration><packageSources><clear /><add key="frozen-feed" value="'+$run+'\feed" /></packageSources><fallbackPackageFolders><clear /></fallbackPackageFolders><disabledPackageSources><clear /></disabledPackageSources></configuration>')
Json 'global.json' @{sdk=@{version='8.0.318';rollForward='disable';allowPrerelease=$false}}
$g=Get-Content "$graph\SOURCE_GRAPH.json" -Raw|ConvertFrom-Json
$expected=@('<Project>')
foreach($project in $g){
    $expected+='<PropertyGroup Condition="''$(MSBuildProjectName)'' == '''+$project.name+'''"><TowerExpectedProject>true</TowerExpectedProject></PropertyGroup>'
    $expected+='<ItemGroup Condition="''$(MSBuildProjectName)'' == '''+$project.name+'''">'
    foreach($p in $project.files){$expected+='<_TowerExpectedSource Include="'+[Security.SecurityElement]::Escape($p)+'" />'}
    $expected+='</ItemGroup>'
}
$expected+='</Project>';Save 'ExpectedSources.targets' ($expected -join "`r`n")
$envPlan=Get-Content "$graph\ENVIRONMENT_PLAN.json" -Raw|ConvertFrom-Json -AsHashtable
foreach($k in @($envPlan.Keys)){$envPlan[$k]=$envPlan[$k].Replace('F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-qualification-run-20261014-r001',$run)}
$envPlan['DOTNET_ROLL_FORWARD']='Disable';$envPlan['DOTNET_ROLL_FORWARD_TO_PRERELEASE']='0';$envPlan['DOTNET_CLI_UI_LANGUAGE']='en-US';$envPlan['VSLANG']='1033';$envPlan['NUGET_CERT_REVOCATION_MODE']='offline';$envPlan['MSBUILDTEMPPATH']="$run\temp"
Json 'ENVIRONMENT.json' $envPlan
$modes=Get-Content "$graph\MATRIX.json" -Raw|ConvertFrom-Json
$phases=@();$index=0
foreach($m in $modes){
    $n=$m.name;$p="$graph\graphs\$n\AccountService.Tests\AccountService.Tests.csproj"
    $props=@("-p:ArtifactsPath=$run\artifacts\$n",'-p:UseArtifactsOutput=true','-p:UseAppHost=false','-p:UseSharedCompilation=false','-p:ProvideCommandLineArgs=true','-p:SkipCompilerExecution=false','-p:NuGetAudit=false','-p:MSBuildEnableWorkloadResolver=false','-p:Configuration=Debug','-p:BuildInParallel=false','-p:ImportDirectoryBuildProps=false','-p:ImportDirectoryBuildTargets=false','-p:ImportDirectoryPackagesProps=false','-p:RuntimeFrameworkVersion=8.0.21','-p:RollForward=Disable','-p:PreferredUILang=en-US',"-p:TowerRecipeRoot=$recipe","-p:TowerRunRoot=$run","-p:TowerMode=$n",'-p:TowerMachineRecipe=xml24-machine-r002',"-p:CustomAfterMicrosoftCommonTargets=$recipe\Evidence.targets",'-m:1','-nr:false')
    $phases += [ordered]@{index=++$index;label="$n-restore";kind='restore';mode=$n;expectedExit='zero';executable="$sdk\dotnet.exe";cwd=$recipe;arguments=@('restore',$p,'--configfile',"$recipe\NuGet.Config",'--disable-parallel','--packages',"$run\nuget-packages")+$props}
    $phases += [ordered]@{index=++$index;label="$n-build";kind='build';mode=$n;expectedExit=$(if($m.tests -gt 0){'zero'}else{'designated-guards-only'});executable="$sdk\dotnet.exe";cwd=$recipe;arguments=@('build',$p,'--no-restore','--disable-build-servers','-v:diag',"-bl:$run\$n-build.binlog;ProjectImports=Embed")+$props}
    if($m.tests -gt 0){$phases += [ordered]@{index=++$index;label="$n-tests";kind='tests';mode=$n;expectedExit='zero';expectedCases=$m.tests;executable="$sdk\dotnet.exe";cwd=$recipe;arguments=@("$run\artifacts\$n\bin\AccountService.Tests\debug\AccountService.Tests.dll","$run\$n-results.json")}}
}
Json 'PHASES.json' $phases
$guards=@(
 @{source='F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-writer-candidates-20261014-r001\source\backend\AccountService\AccountTowerLedger.cs';line=3;message='Tower24 requires explicit Story23 and batch21 capability support.';modes=@('tower-without-story','tower-without-batch','tower-alone')},
 @{source='F:\AnotherLife\outputs\LOCAL-BACKEND\tower-xml24-writer-candidates-20261014-r001\source\backend\AccountService\AccountStoryRegistry.cs';line=3;message='Story root23 requires the existing collection21 capability and conservation validator.';modes=@('tower-without-batch')}
)
foreach($x in $guards){$lines=[IO.File]::ReadAllLines($x.source);if($lines[$x.line-1] -ne ('#error '+$x.message)){throw 'Guard source changed'}}
Json 'NEGATIVE_GUARDS.json' $guards
Json 'RECIPE.json' @{status='OUTPUT_ONLY_NOT_ADMITTED';graph=$graph;run=$run;sdk=$sdk;runtime='8.0.21';sdkVersion='8.0.318';phaseCount=$phases.Count;restoreCount=7;buildCount=7;testProcessCount=4;expectedCaseExecutions=66;deadlineSeconds=600;perPhaseMaximumSeconds=120;automaticRetries=0;gates=@{cFreeGiB=40;fFreeGiB=20;ramFreeGiB=8;commitHeadroomGiB=15;commitPercentBelow=80};sourceGraphReviewSha256='F42E3496250043297BA31F0991C144CCBD102225201A9605035358D8E6DFB3C0';newAdmissionRequired=$true}
@{sdkFiles=$sdkFiles.Count;phases=$phases.Count;packages=$packages.Count;nativeExecutions=0}|ConvertTo-Json

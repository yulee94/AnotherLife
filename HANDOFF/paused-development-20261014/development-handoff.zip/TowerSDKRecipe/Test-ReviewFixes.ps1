$ErrorActionPreference='Stop'
$text=[IO.File]::ReadAllText("$PSScriptRoot\Run-Machine.ps1")
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Wrapper syntax'}
$results=[Collections.Generic.List[object]]::new()
function Check($name,$condition){$results.Add(@{name=$name;passed=[bool]$condition});if(-not $condition){throw "Regression: $name"}}
$phases=@(Get-Content "$PSScriptRoot\PHASES.json" -Raw|ConvertFrom-Json)
foreach($p in $phases|Where-Object{$_.kind -in @('restore','build')}){
    Check ($p.label+' explicit package-import disable') (@($p.arguments|Where-Object{$_ -ceq '-p:ImportDirectoryPackagesProps=false'}).Count -eq 1)
}
# Actual pinned NuGet.props condition, interpreted as a pure property-condition probe; no MSBuild.
$nuget='F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk\sdk\8.0.318\Current\Microsoft.Common.props'
$sdkRoot='F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk\sdk\8.0.318'
$nugetFile=@(Get-ChildItem -LiteralPath $sdkRoot -Filter 'NuGet.props' -Recurse -File)[0].FullName
[xml]$props=[IO.File]::ReadAllText($nugetFile)
$imports=@($props.SelectNodes('//Import')|Where-Object{$_.Project -match 'DirectoryPackagesPropsPath'})
Check 'pinned NuGet import is conditioned on explicit true' ($imports.Count -eq 1 -and $imports[0].Condition.Contains("'`$(ImportDirectoryPackagesProps)' == 'true'"))
foreach($p in $phases|Where-Object{$_.kind -in @('restore','build')}){
    $value=($p.arguments|Where-Object{$_ -like '-p:ImportDirectoryPackagesProps=*'}) -replace '^-p:ImportDirectoryPackagesProps=',''
    Check ($p.label+' mock ancestor import remains off') ($value -cne 'true')
}
# Execute the actual outer finally statements, with only census/cleanup dependencies mocked.
$outer=@($ast.EndBlock.Statements|Where-Object{$_ -is [Management.Automation.Language.TryStatementAst]})[-1]
$finallyText=$outer.Finally.Extent.Text
$finallyBody=[scriptblock]::Create($finallyText.Substring(1,$finallyText.Length-2))
foreach($scenario in @('normal','census-throws','census-and-evidence-throw','dispose-throws')){
    $keyA='AL_XML24_REGRESSION_RESTORE_VALUE';$keyB='AL_XML24_REGRESSION_RESTORE_ABSENT'
    $originalA=[Environment]::GetEnvironmentVariable($keyA,'Process');$originalB=[Environment]::GetEnvironmentVariable($keyB,'Process')
    $savedEnv=@{};$savedEnv[$keyA]='original';$savedEnv[$keyB]=$null
    [Environment]::SetEnvironmentVariable($keyA,'changed','Process');[Environment]::SetEnvironmentVariable($keyB,'changed','Process')
    $script:mockScenario=$scenario;$script:savedCleanup=$false;$child=$null
    function Census($label){if($script:mockScenario -like 'census*'){throw 'Mock census unavailable'};return @()}
    function Save($name,$data){$script:savedCleanup=$true;if($script:mockScenario -eq 'census-and-evidence-throw'){throw 'Mock evidence write failure'}}
    if($scenario -eq 'dispose-throws'){$child=[pscustomobject]@{HasExited=$true};$child|Add-Member ScriptMethod Dispose {throw 'Mock disposal failure'}}
    $thrown=$false
    try{& $finallyBody}catch{$thrown=$true}finally{
        $restored=([Environment]::GetEnvironmentVariable($keyA,'Process') -ceq 'original' -and $null -eq [Environment]::GetEnvironmentVariable($keyB,'Process'))
        foreach($restore in @(@{key=$keyA;value=$originalA},@{key=$keyB;value=$originalB})){
            if($null -eq $restore.value){[Environment]::SetEnvironmentVariable($restore.key,[NullString]::Value,'Process')}
            else{[Environment]::SetEnvironmentVariable($restore.key,$restore.value,'Process')}
        }
    }
    Check ($scenario+' restores real process environment') $restored
    Check ($scenario+' preserves failure disposition') ($thrown -eq ($scenario -ne 'normal'))
    if($scenario -like 'census*'){Check ($scenario+' attempts cleanup evidence') $script:savedCleanup}
}
# Execute the actual Native prefix through Start, replacing only Process construction with a fake.
$native=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Native'},$false).Extent.Text
$end="if(-not `$child.Start()){throw 'Process launch failed'}"
$prefix=$native.Substring(0,$native.IndexOf($end)+$end.Length)+"`n}"
$prefix=$prefix.Replace('function Native($phase)','function Invoke-MockedNative($phase)')
$creation='$script:child=[Diagnostics.Process]::new();$child.StartInfo=$info'
if(-not $prefix.Contains($creation)){throw 'Native mock seam changed'}
$fake='$script:child=[pscustomobject]@{StartInfo=$info};$child | Add-Member ScriptMethod Start {$script:launches++;return $true}'
$prefix=$prefix.Replace($creation,$fake)
. ([scriptblock]::Create($prefix))
function Admission { return @{} }
function Deadline {if($script:expired){throw 'Mock original deadline expired'}}
function Resources($label){if($script:expireAt -eq 'resources'){$script:expired=$true}}
function NoWorkers($label){if($script:expireAt -eq 'census'){$script:expired=$true}}
function Pins($path){if($script:expireAt -eq 'pins'){$script:expired=$true}}
function Save($name,$data){if($script:expireAt -eq 'record'){$script:expired=$true}}
$r=Get-Content "$PSScriptRoot\RECIPE.json" -Raw|ConvertFrom-Json
$recipe=$PSScriptRoot;$run=$r.run
$phase=$phases[0]
foreach($when in @('never','initial','resources','census','pins','record')){
    $script:expireAt=$when;$script:expired=($when -eq 'initial');$script:launches=0;$thrown=$false
    try{Invoke-MockedNative $phase}catch{$thrown=$true}
    Check ($when+' deadline launch disposition') ($script:launches -eq $(if($when -eq 'never'){1}else{0}) -and $thrown -eq ($when -ne 'never'))
}
$results|ConvertTo-Json -Depth 5|Set-Content "$PSScriptRoot\REGRESSION_RESULTS.json"
@{checks=$results.Count;passed=@($results|Where-Object passed).Count;nativeLaunches=0;mockLaunches=1;source='Actual wrapper AST finally and Native prefix; actual phase arguments; pinned NuGet import XML'}|ConvertTo-Json

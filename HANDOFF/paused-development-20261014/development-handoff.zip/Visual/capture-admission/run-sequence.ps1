$ErrorActionPreference='Stop'
$ad='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-supervisor-composition-20261014-r010\capture-admission'
$destination='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001'
$evidence='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001\outer-r001'
$failure=$null;$secondary=@();$changed=@();$before=@();$remaining=@();$censusVerified=$false;$created=$false
$timing=@{preflightStartedUtc=$null;preflightCompletedUtc=$null;preflightElapsedSeconds=$null;pinCheckSeconds=$null;nativeStartedUtc=$null;nativeDeadlineUtc=$null;nativeElapsedSeconds=$null;postExitPinSeconds=$null}
try {
 if(-not(Test-Path -LiteralPath "$ad\POSTPROMOTION_SEAL.json")){throw 'Missing promotion seal'}
 if((Get-Content -Raw -LiteralPath "$ad\POSTPROMOTION_SEAL.json"|ConvertFrom-Json).sealed-ne$true){throw 'Postpromotion source seal pending; execution disabled'}
 if((Get-Content -Raw -LiteralPath "$ad\JOB_ADMISSION.json"|ConvertFrom-Json).coordinatorAdmitted-ne$true){throw 'Root compile admission disabled'}
 if(Test-Path -LiteralPath $destination){throw 'Fresh compile output required'}
 if(Test-Path -LiteralPath $evidence){throw 'Existing outer evidence; no retry'}
 $cursor=$evidence;while($cursor){if((Test-Path -LiteralPath $cursor)-and((Get-Item -LiteralPath $cursor).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Outer evidence reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
 [IO.Directory]::CreateDirectory($evidence)|Out-Null;$created=$true

 foreach($path in @('F:\AnotherLife\unity\ProjectSettings\EditorBuildSettings.asset','F:\AnotherLife\unity\ProjectSettings\ProjectSettings.asset')){
  $copy=Join-Path $evidence ('before-'+[IO.Path]::GetFileName($path));[IO.File]::Copy($path,$copy,$false)
  $hash=(Get-FileHash -LiteralPath $path).Hash;if((Get-FileHash -LiteralPath $copy).Hash-ne$hash){throw 'Settings snapshot race'}
  $before+=@{path=$path;copy=$copy;sha256=$hash}
 }
 & "$ad\capture-git-context.ps1" -OutFile "$evidence\GIT_BEFORE.json"
 $timing.preflightStartedUtc=[datetime]::UtcNow.ToString('o');$timing.preflightClock=[Diagnostics.Stopwatch]::StartNew()
 & (Join-Path $ad 'run-job.ps1') -Timing $timing
} catch {$failure=$_.Exception.Message}
finally {
 if($timing.preflightClock){$timing.preflightClock.Stop();if($null-eq$timing.preflightElapsedSeconds){$timing.preflightElapsedSeconds=$timing.preflightClock.Elapsed.TotalSeconds;$timing.preflightCompletedUtc=[datetime]::UtcNow.ToString('o')};$timing.Remove('preflightClock')}
 try{$remaining=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.Name-match'^(Unity|UnityPackageManager|UnityShaderCompiler|UnityCrashHandler.*|blender|dotnet|MSBuild|csc|VBCSCompiler|python|pythonw|python3|mono|mcs|bee_backend|cl|link)(\.exe)?$'}|Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath);$censusVerified=$true}catch{$secondary+=('Final census: '+$_.Exception.Message)}
 try{if($created){& "$ad\capture-git-context.ps1" -OutFile "$evidence\GIT_AFTER.json"}}catch{$secondary+=('Git evidence: '+$_.Exception.Message)}
 foreach($item in $before){try{
  if((Get-FileHash -LiteralPath $item.path).Hash-ne$item.sha256){
   $changed+=$item.path
   [IO.File]::Copy($item.path,(Join-Path $evidence ('changed-'+[IO.Path]::GetFileName($item.path))),$false)
  }
 }catch{$secondary+=('Settings evidence: '+$_.Exception.Message)}}
 if($changed.Count-and-not$failure){$failure='Project settings changed; preserved only, no automatic restoration'}
 $receipt=@{utc=[datetime]::UtcNow.ToString('o');failure=$failure;timing=$timing;settings=$before;changedSettings=$changed;secondaryErrors=$secondary;remaining=$remaining;censusVerified=$censusVerified;slotReleased=$false;scope='Detect-only settings; outer pre-entry/cleanup evidence, consult compile RESULT.json for success'}
 if($created){try{$receipt|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $evidence 'WRAPPER_RESULT.json')}catch{$secondary+=('Receipt write: '+$_.Exception.Message);$receipt.secondaryErrors=$secondary}}
 $receipt|ConvertTo-Json -Depth 6
}
if($failure){throw $failure}
if($remaining.Count){throw 'Final native census not empty'}
if($secondary.Count){throw 'Outer validation evidence incomplete'}

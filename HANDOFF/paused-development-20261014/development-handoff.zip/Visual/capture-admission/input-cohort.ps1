$ErrorActionPreference='Stop'
function GetShippingInputMembers([string]$Repository) {
 $base=[IO.Path]::GetFullPath($Repository).TrimEnd('\');$members=[Collections.Generic.List[string]]::new()
 foreach($relative in @('unity\Assets','unity\Packages','unity\ProjectSettings','unity\SharedContracts')) {
  $queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue((Join-Path $base $relative))
  while($queue.Count){$directory=$queue.Dequeue();$item=Get-Item -LiteralPath $directory -Force
   if($item.Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Input directory reparse'}
   foreach($child in Get-ChildItem -LiteralPath $directory -Force){if($child.Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Input reparse'};if($child.PSIsContainer){$queue.Enqueue($child.FullName)}else{$members.Add($child.FullName.Substring($base.Length+1).Replace('\','/'))}}
  }
 }
 @($members|Sort-Object -CaseSensitive)
}
function AssertShippingInputCohort([string]$Repository,$Pins,$CriticalPins=$Pins) {
 $expected=@($Pins|ForEach-Object path|Sort-Object -CaseSensitive)
 if(@($expected|Select-Object -Unique).Count-ne$expected.Count){throw 'Duplicate input'}
 $actual=@(GetShippingInputMembers $Repository)
 if(($actual|ConvertTo-Json -Compress)-cne($expected|ConvertTo-Json -Compress)){throw 'Unexpected source/meta/settings membership change'}
 $manifest=@{};foreach($item in $Pins){$manifest[$item.path]=$item.sha256}; foreach($pin in $CriticalPins){if(-not$manifest.ContainsKey($pin.path)-or$manifest[$pin.path]-ne$pin.sha256){throw 'Critical pin outside declared cohort'};$path=Join-Path $Repository $pin.path;if((Get-FileHash -LiteralPath $path).Hash-ne$pin.sha256){throw "Source/meta/settings hash changed: $($pin.path)"}}
 $seal=Read "$ad\POSTPROMOTION_SEAL.json"
 if((& git --no-optional-locks -C $Repository rev-parse HEAD).Trim()-ne$seal.head-or(Get-FileHash -LiteralPath $seal.indexPath).Hash-ne$seal.indexSHA256){throw 'Sealed HEAD/index drift'}
 AssertExactReadbackPins
}
function AssertExactReadbackPins {
 foreach($pin in (Read "$ad\EXACT_INPUT_PINS.json")){
  $path=[IO.Path]::GetFullPath($pin.path);if(-not$path.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)){throw 'Exact pin outside F'}
  $cursor=$path;while($cursor){if((Get-Item -LiteralPath $cursor).Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Exact input reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  if((Get-FileHash -LiteralPath $path).Hash-ne$pin.sha256){throw "Exact input drift: $path"}
 }
}
function AssertCompletedReadbackLog([string]$text) {
 $shutdownPattern="(?m)^SearchTask '[^'\r\n]+' (?:thread did not stop within 5 seconds\.|had active threads when disposed \(From Dispose\)\.)\r?$|^Crash!!!\r?$"
 $shutdownMatches=@([regex]::Matches($text,$shutdownPattern)|ForEach-Object {$_.Value.TrimEnd("`r")})
 Save "$out\SHUTDOWN_SIGNATURE_CHECK.json" @{matches=$shutdownMatches;accepted=($shutdownMatches.Count-eq0);scope='Completed log; same bounded shutdown signatures as accepted Story graphics recipe'}
 if($shutdownMatches.Count){throw 'Completed-log Search shutdown/crash signature'}
}

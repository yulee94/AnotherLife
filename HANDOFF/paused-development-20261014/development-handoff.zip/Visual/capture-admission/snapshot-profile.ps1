param([Parameter(Mandatory=$true)][string]$OutFile)
$ErrorActionPreference='Stop'
if(-not [IO.Path]::GetFullPath($OutFile).StartsWith('F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001\outer-r001\',[StringComparison]::OrdinalIgnoreCase)){throw 'F receipt boundary'}
$profile='C:\Users\yulee\AppData\LocalLow\DefaultCompany\AnotherLifeUnity'
$journalRoots=@("$profile\construction-v2-intents","$profile\account-summoning-onboarding-intents")
$entries=@()
foreach($root in $journalRoots){
 if(-not(Test-Path -LiteralPath $root)){$entries+=[pscustomobject]@{path=$root;exists=$false};continue}
 $queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($root)
 while($queue.Count){$path=$queue.Dequeue();$i=Get-Item -LiteralPath $path -Force;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Journal reparse cannot be compared safely'}
  $entries+=[pscustomobject]@{path=$path;exists=$true;directory=$i.PSIsContainer;createdUtc=$i.CreationTimeUtc.ToString('o');modifiedUtc=$i.LastWriteTimeUtc.ToString('o');attributes=$i.Attributes.ToString();bytes=if($i.PSIsContainer){$null}else{$i.Length};sha256=if($i.PSIsContainer){$null}else{(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}}
  if($entries.Count -gt 256){throw 'Scoped profile metadata ceiling'}
  if($i.PSIsContainer){foreach($child in Get-ChildItem -LiteralPath $path -Force){$queue.Enqueue($child.FullName)}}
 }
}
$top=@(Get-ChildItem -LiteralPath $profile -Force|Select-Object Name,PSIsContainer,@{n='createdUtc';e={$_.CreationTimeUtc.ToString('o')}},@{n='modifiedUtc';e={$_.LastWriteTimeUtc.ToString('o')}})
$result=[pscustomobject]@{utc=[DateTimeOffset]::UtcNow.ToString('o');profile=$profile;journalRoots=$journalRoots;entries=@($entries|Sort-Object path);topLevel=$top;CMutationPerformed=$false;scope='Exact two known journal trees plus top-level project-profile names; not a trace of transient filesystem activity.'}
[IO.File]::WriteAllText($OutFile,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{journalEntries=$entries.Count;journalFiles=@($entries|Where-Object {$_.exists -and -not $_.directory}).Count;topLevelEntries=$top.Count;output=$OutFile}|ConvertTo-Json
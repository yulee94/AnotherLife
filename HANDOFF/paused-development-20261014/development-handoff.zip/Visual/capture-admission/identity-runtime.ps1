# Fixed readback identity operations. Load only after reviewed interop artifact admission.
function AssertRetainedHandle($process,$handle) {
 if($null-eq$process-or$null-eq$handle-or$handle.IsClosed-or$handle.IsInvalid){throw 'ORIGINAL_HANDLE_LOST'}
}
function WaitOriginal($process,$handle,[int]$milliseconds) {
 AssertRetainedHandle $process $handle
 if($milliseconds-lt0-or$milliseconds-gt2000){throw 'WAIT_ARGUMENT_OUT_OF_BOUND'}
 [bool]$process.WaitForExit($milliseconds)
}
function ReadOriginalExit($process,$handle,[bool]$signaled) {
 AssertRetainedHandle $process $handle
 if(-not$signaled){throw 'EXIT_READ_BEFORE_SIGNAL'}
 [uint32]$value=0
 $ok=[AL.RigReadback.Identity.Native]::GetExitCodeProcess($handle,[ref]$value)
 $errorCode=[Runtime.InteropServices.Marshal]::GetLastPInvokeError()
 if(-not$ok){throw "EXIT_QUERY_ERROR:$errorCode"}
 return $value
}
function AssertRuntimePins {
 $runtime=Read "$ad\RUNTIME_PINS.json"
 foreach($pin in $runtime){if((Get-FileHash -LiteralPath $pin.path).Hash-ne$pin.sha256){throw 'Installed runtime changed'}}
 if(@($runtime|Where-Object {$_.path-ceq[Environment]::ProcessPath}).Count-ne1-or@($runtime|Where-Object {$_.path-ceq[Diagnostics.Process].Assembly.Location}).Count-ne1){throw 'Unreviewed executing runtime'}
}
function ImportReviewedInterop($lease) {
 AssertRuntimePins
 $receipt="$ad\INTEROP_ARTIFACT.json";Boundary $receipt
 if($lease.interopArtifactSHA256-ne(Get-FileHash $receipt).Hash){throw 'Interop artifact not root bound'}
 $a=Read $receipt
 if($a.accepted-ne$true-or$a.path-cne'F:\AnotherLife\outputs\LOCAL-RIG\unity-existing-rig-route-20261014\runner-r004\interop-build\AL.RigReadback.Identity.dll'-or$a.sha256-notmatch'^[A-Fa-f0-9]{64}$'-or$a.sourceSHA256-ne(Get-FileHash "$ad\ReadbackIdentity.Native.cs").Hash){throw 'Unreviewed compiled interop'}
 foreach($row in @(@{p=$a.path;h=$a.sha256},@{p=$a.compileEvidencePath;h=$a.compileEvidenceSHA256},@{p=$a.qaReviewPath;h=$a.qaReviewSHA256},@{p=$a.rootCompileAdmissionPath;h=$a.rootCompileAdmissionSHA256},@{p=$a.sourcePath;h=$a.sourceSHA256})){
  if($row.h-notmatch'^[A-Fa-f0-9]{64}$'){throw 'Interop evidence hash absent'};Boundary $row.p;if((Get-FileHash -LiteralPath $row.p).Hash-ne$row.h){throw 'Interop artifact/evidence drift'}
 }
 if('AL.RigReadback.Identity.Native'-as[type]){throw 'Interop already loaded; fresh host required'}
 $assembly=[Reflection.Assembly]::LoadFrom($a.path)
 if($assembly.Location-cne$a.path){throw 'Unexpected loaded interop location'}
 $script:LoadedInteropPath=$a.path;$script:LoadedInteropHash=$a.sha256;$script:InteropAdmissionHash=(Get-FileHash $receipt).Hash
 # No compiler invocation or automatic build exists in this runner.
}
function ObserveOriginalIdentity($process,$handle,[int]$producerId,[datetime]$startedUtc,$expected) {
 AssertRetainedHandle $process $handle
 $builder=[Text.StringBuilder]::new(32768);[uint32]$characters=32768
 $ok=[AL.RigReadback.Identity.Native]::QueryFullProcessImageNameW($handle,0,$builder,[ref]$characters)
 $queryError=[Runtime.InteropServices.Marshal]::GetLastPInvokeError()
 Save "$out\IMAGE_QUERY.json" @{succeeded=$ok;win32Error=$queryError;characters=$characters;rawImage=if($ok){$builder.ToString()}else{$null};calls=1;flags=0;bufferCharacters=32768}
 $path=if($ok){[IO.Path]::GetFullPath($builder.ToString())}else{$null}
 $hash=$null
 if($path){if($path-cne$expected.imagePath){throw 'IDENTITY_IMAGE_MISMATCH'};BoundaryExecutable $path;$hash=(Get-FileHash -LiteralPath $path).Hash}
 $cim=Get-CimInstance Win32_Process -Filter "ProcessId=$producerId"
 $rows=@($cim);if($rows.Count-ne1){throw 'IDENTITY_CIM_UNAVAILABLE'}
 $o=@{handleValid=$true;pid=$producerId;startUtcTicks=$startedUtc.Ticks;imageQuerySucceeded=$ok;imageQueryError=$queryError;imageCharacters=$characters;observedImagePath=$path;observedImageHash=$hash;cimPid=$cim.ProcessId;cimCreationUtcTicks=if($cim.CreationDate){([datetime]$cim.CreationDate).ToUniversalTime().Ticks}else{$null};cimCommandLine=$cim.CommandLine;cimExecutablePath=$cim.ExecutablePath;declaredExecutable=$expected.imagePath;declaredArguments=$expected.arguments;declarationIsNotObservedImage=$true}
 Save "$out\IDENTITY_OBSERVATION.json" $o
 AssertIdentityObservation $o $expected
 return $o
}
function BoundaryExecutable([string]$path) {
 if(-not$path.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)){throw 'Executable outside F'}
 $cursor=$path;while($cursor){if((Get-Item -LiteralPath $cursor).Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Executable reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
}
# Read-only preservation guard. Never modifies or restores Search.index.
function AssertOriginalSearch([string]$phase){
 $path='F:\AnotherLife\unity\UserSettings\Search.index'
 Boundary $path
 $expected='88443AB2F8377DD2B8FD3068C9F631BBBF99EFDDE5C2F01BC19B96190F241B6D'
 $copy=Join-Path $out ('Search.index.'+$phase)
 [IO.File]::Copy($path,$copy,$false)
 $observed=(Get-FileHash -LiteralPath $copy).Hash
 $live=(Get-FileHash -LiteralPath $path).Hash
 Save (Join-Path $out ('SEARCH_PRESERVATION_'+$phase+'.json')) @{path=$path;expectedSha256=$expected;observedSha256=$observed;liveSha256=$live;copy=$copy;unchanged=($observed-ceq$expected-and$live-ceq$expected);mutationAttempted=$false;utc=[datetime]::UtcNow.ToString('o')}
 if($observed-cne$expected-or$live-cne$expected){throw 'Original Search.index changed; preserve evidence, no automatic restoration'}
}
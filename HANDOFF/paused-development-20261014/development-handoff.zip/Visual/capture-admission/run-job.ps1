param([Parameter(Mandatory=$true)][hashtable]$Timing)
function ReadLiveLog($path){$stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);try{if($stream.Length-gt8MB){throw 'Log bound'};$reader=[IO.StreamReader]::new($stream);try{$reader.ReadToEnd()}finally{$reader.Dispose()}}finally{$stream.Dispose()}}
$ErrorActionPreference='Stop'
$ad='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-supervisor-composition-20261014-r010\capture-admission'
$out='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001'
$root='F:\AnotherLife';$exe='F:\Unity\6000.5.3f1\Editor\Unity.exe'

. (Join-Path $ad 'input-cohort.ps1')
. (Join-Path $ad 'job-admission.ps1')
. (Join-Path $ad 'artifact-qualification.ps1')
. (Join-Path $ad 'identity-policy.ps1')
. (Join-Path $ad 'identity-runtime.ps1')
. (Join-Path $ad 'verify-search-index.ps1')
. (Join-Path $ad 'compiler-cleanup-policy.ps1')
. (Join-Path $ad 'compiler-cleanup.ps1')
. (Join-Path $ad 'vendor-observation-policy.ps1')
. (Join-Path $ad 'vendor-observation-runtime.ps1')
$script:VendorLineage=$null
$script:OwnedIds=[Collections.Generic.HashSet[int]]::new()
function Save($path,$value){[IO.File]::WriteAllText($path,($value|ConvertTo-Json -Depth 12))}
function Read($path){Get-Content -LiteralPath $path -Raw|ConvertFrom-Json}
function Boundary($p){$p=[IO.Path]::GetFullPath($p);if(-not$p.StartsWith('F:\AnotherLife\',[StringComparison]::OrdinalIgnoreCase)){throw 'F boundary'};while($p){if((Test-Path -LiteralPath $p)-and((Get-Item -LiteralPath $p).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse'};$p=[IO.Path]::GetDirectoryName($p)}}
function Census {
 $queryStart=[datetime]::UtcNow; $all=@(Get-CimInstance Win32_Process -ErrorAction Stop); $queryEnd=[datetime]::UtcNow
 if($script:OwnedIds){do{$added=$false;foreach($item in $all){if($script:OwnedIds.Contains([int]$item.ParentProcessId)-and$script:OwnedIds.Add([int]$item.ProcessId)){$added=$true}}}while($added)}
 $scoped=@(GetVendorCensusScope $all $script:OwnedIds)
 if($null-ne$script:VendorLineage){
  $raw=@($all|Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
  AddVendorSnapshot $script:VendorLineage $raw $scoped $queryStart $queryEnd
  Save "$out\VENDOR_LINEAGE_OBSERVATIONS.json" @{anchor=$script:VendorLineage.anchor;frames=@($script:VendorLineage.frames.ToArray());scope='Complete raw process snapshots; no process control or inferred ancestry'}
 }
 $scoped
}
function Resources{$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if(-not$m.CommitLimit){throw 'Memory unavailable'};@{ram=$m.AvailableBytes/1GB;commitHeadroom=($m.CommitLimit-$m.CommittedBytes)/1GB;commitPercent=100*$m.CommittedBytes/$m.CommitLimit;C=(Get-PSDrive C).Free/1GB;F=(Get-PSDrive F).Free/1GB}}
function CheckPins{AssertMotionArtifactQualification $lease;AssertShippingInputCohort $root $pins $criticalPins;if((& git --no-optional-locks -C $root rev-parse HEAD).Trim()-ne$head){throw 'HEAD drift'};git --no-optional-locks -C $root diff-index --cached --quiet $head --;if($LASTEXITCODE){throw 'Index content drift'}}
function Snap($suffix){& "$ad\read-typed-preferences.ps1" -OutFile "$out\outer-r001\PREFS_$suffix.json";& "$ad\snapshot-viewport.ps1" -OutputDirectory "$out\outer-r001\viewport-$suffix";& "$ad\snapshot-profile.ps1" -OutFile "$out\outer-r001\PROFILE_$suffix.json"|Out-Null}
Boundary $out;Boundary $ad;Boundary "$root\unity";if((Test-Path "$out\temp")-or(Test-Path "$out\RESULT.json")-or-not(Test-Path "$out\outer-r001")){throw 'Fresh outer-owned compile output required'};if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'Stop marker present'}
if(@(Census).Count){throw 'Competing native process'}
$Timing.initialCensusEmpty=$true
$sampleStartedUtc=[datetime]::UtcNow.ToString('o');$r=Resources
$Timing.initialAdmission=@{sampleStartedUtc=$sampleStartedUtc;sampleCompletedUtc=[datetime]::UtcNow.ToString('o');resource=$r.Clone();thresholds=@{ramMinimumGiB=8;commitHeadroomMinimumGiB=15;commitPercentExclusiveMaximum=80;CMinimumGiB=40;FMinimumGiB=20};scope='Actual initial admission sample; recorded before gate, not a later diagnostic'}
if($r.ram-lt8-or$r.commitHeadroom-lt15-or$r.commitPercent-ge80-or$r.C-lt40-or$r.F-lt20){throw 'Admission resource gate'}
$lease=Read "$root\.agent\NATIVE_SLOT_RESERVATION.json";AssertJobAdmission $lease
$pins=Read "$ad\REVIEWED_MEMBERSHIP_PINS.json";$criticalPins=Read "$ad\CRITICAL_SOURCE_PINS.json";$head=(& git --no-optional-locks -C $root rev-parse HEAD).Trim()
PrepareJobEvidence
[IO.Directory]::CreateDirectory("$out\temp")|Out-Null; Boundary "$out\temp"; [IO.File]::WriteAllText("$out\temp\access.probe",'F native temp'); if([IO.File]::ReadAllText("$out\temp\access.probe")-ne'F native temp'){throw 'Temp access'}; Move-Item -LiteralPath "$out\temp\access.probe" -Destination "$out\temp\access.verified"
[IO.File]::WriteAllText("$out\access.probe",'F viewport');if([IO.File]::ReadAllText("$out\access.probe")-ne'F viewport'){throw 'Access'};Move-Item -LiteralPath "$out\access.probe" -Destination "$out\access.verified"
Copy-Item -LiteralPath "$ad\JOB_ADMISSION.json" -Destination "$out\JOB_ADMISSION.json";Snap 'BEFORE';AssertOriginalSearch 'BEFORE'
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;
try {
$env:TEMP='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001\temp';$env:TMP=$env:TEMP
if([IO.Path]::GetTempPath()-ne'F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001\temp\'){throw 'Managed temp mismatch'}
$proc=$null;$safe=$null;$producerId=$null;$launchAttempted=$false;$signaled=$false;$nativeCode=$null
$stop=$null;$cleanup=@();$samples=@();$nativeClock=$null;$identityVerified=$false;$remaining=@();$censusVerified=$false;$unityExitObservedUtc=$null
try {
 ImportReviewedInterop $lease
 $fixed=Read "$ad\FIXED_LAUNCH.json";$unityHash=(Get-FileHash $exe).Hash
 if($fixed.imagePath-cne$exe-or$fixed.imageHash-ne$unityHash-or$fixed.workingDirectory-cne"$root\unity"-or$fixed.useShellExecute-ne$false-or$fixed.createNoWindow-ne$true){throw 'Fixed launch drift'}
 $pinClock=[Diagnostics.Stopwatch]::StartNew();try{CheckPins}finally{$pinClock.Stop();$Timing.pinCheckSeconds=$pinClock.Elapsed.TotalSeconds}
 if(@(Census).Count){throw 'Competing native process after preflight'}
 $Timing.finalCensusEmpty=$true
 $r=Resources;if($r.ram-lt8-or$r.commitHeadroom-lt15-or$r.commitPercent-ge80-or$r.C-lt40-or$r.F-lt20){throw 'Fresh admission resource gate'}
 AssertExactReadbackPins;AssertRuntimePins
 if((Get-FileHash "$ad\INTEROP_ARTIFACT.json").Hash-ne$script:InteropAdmissionHash-or(Get-FileHash -LiteralPath $script:LoadedInteropPath).Hash-ne$script:LoadedInteropHash){throw 'Loaded interop pin drift'}
 $lease=Read "$root\.agent\NATIVE_SLOT_RESERVATION.json";AssertJobAdmission $lease
 if($lease.interopArtifactSHA256-ne$script:InteropAdmissionHash){throw 'Fresh lease interop mismatch'}
 if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'STOP at final launch boundary'}
 $Timing.preflightClock.Stop();$Timing.preflightElapsedSeconds=$Timing.preflightClock.Elapsed.TotalSeconds;$Timing.preflightCompletedUtc=[datetime]::UtcNow.ToString('o')
 Save "$out\ADMISSION.json" @{utc=[datetime]::UtcNow.ToString('o');head=$head;sourcePins=$pins.Count;resource=$r;declaredLaunch=$fixed;temp=$env:TEMP;unitySha256=$unityHash;noForceKill=$true;preflightElapsedSeconds=$Timing.preflightElapsedSeconds;pinCheckSeconds=$Timing.pinCheckSeconds;runtimeTempProof='Parent process-local temp only; no native cache confinement claim';status='PREFLIGHT_PASSED_NOT_LAUNCHED'}
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$fixed.imagePath;$info.Arguments=$fixed.arguments;$info.WorkingDirectory=$fixed.workingDirectory
 $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
 $info.Environment['TEMP']=$env:TEMP;$info.Environment['TMP']=$env:TMP
 SetJobEnvironment $info
 # Fresh object; no credentials, redirected streams or event subscriptions.
 $nativeStart=[datetime]::UtcNow;$Timing.nativeStartedUtc=$nativeStart.ToString('o');$Timing.nativeDeadlineUtc=$nativeStart.AddSeconds(300).ToString('o')
 $nativeClock=[Diagnostics.Stopwatch]::StartNew();$launchAttempted=$true
 $proc=[Diagnostics.Process]::Start($info)
 if($null-eq$proc){throw 'Direct launch returned no original object'}
 $safe=$proc.SafeHandle;AssertRetainedHandle $proc $safe
 $producerId=$proc.Id;[void]$script:OwnedIds.Add([int]$producerId)
 $startedUtc=$proc.StartTime.ToUniversalTime()
 $identity=ObserveOriginalIdentity $proc $safe $producerId $startedUtc $fixed;$identityVerified=$true
 $script:VendorLineage=NewVendorLineage $identity;[void](Census)
 Save "$out\LAUNCH.json" @{pid=$producerId;startUtc=$startedUtc.ToString('o');identity=$identity;temp=$env:TEMP;tmp=$env:TMP;nativeStartedUtc=$Timing.nativeStartedUtc;nativeDeadlineUtc=$Timing.nativeDeadlineUtc;freshResource=$r}
 while(-not$signaled){
  $waitMs=GetBoundedWaitMilliseconds $nativeClock.Elapsed.TotalMilliseconds 300000
  if($waitMs-eq0){throw '300 second native stop'}
  $signaled=WaitOriginal $proc $safe $waitMs
  if($signaled){$unityExitObservedUtc=[datetime]::UtcNow}
  if($nativeClock.Elapsed.TotalSeconds-ge300){throw '300 second native stop'}
  if((Test-Path "$ad\STOP")-or(Test-Path "$out\STOP")){throw 'Coordinator stop marker'}
  if($signaled){break}
  $r=Resources;$samples+=@{utc=[datetime]::UtcNow.ToString('o');resource=$r};Save "$out\RESOURCE_SAMPLES.json" $samples
  if($r.ram-lt8-or$r.commitHeadroom-lt8-or$r.commitPercent-ge80-or$r.C-lt40-or$r.F-lt10){throw 'Runtime resource floor'}
  [void](Census) # Read-only descendant discovery; never used to attach or control.
  $log=if(Test-Path "$out\Editor.log"){ReadLiveLog "$out\Editor.log"}else{''}
  if($log-match'\berror CS\d+:|0x800711[Cc]7|0x[cC]0[eE]90002|application control policy.*blocked'){throw 'Compiler or application control failure'}
  if([regex]::Matches($log,'Access version should be odd when acquiring lock').Count-ge2){throw 'Repeated locking signature'}
 }
 $nativeCode=ReadOriginalExit $proc $safe $signaled
 $terminalLog=ReadLiveLog "$out\Editor.log"
 if($terminalLog-match'\berror CS\d+:|0x800711[Cc]7|0x[cC]0[eE]90002|application control policy.*blocked'){throw 'Terminal compiler/application failure'}
 AssertCompletedReadbackLog $terminalLog
 $graphicsReady=$terminalLog-match'(?m)^\s*Version:\s+Direct3D\s+(?:11|12)\b'-and$terminalLog-match'(?m)^\s*Renderer:\s+(?!Null\b)\S+'-and$terminalLog-notmatch'(?im)^\s*(?:NullGfxDevice|Renderer:\s+Null\b)'
 Save "$out\GRAPHICS_CHECK.json" @{accepted=$graphicsReady;scope='Graphics initialization only, no pixel acceptance'}
 if(-not$graphicsReady){throw 'Graphics-enabled profile not evidenced in final log'}
 AssertNativeSuccess $stop $signaled $nativeCode $nativeClock.Elapsed.TotalSeconds
 if(-not$identityVerified){throw 'Initial identity never qualified'}
 AssertJobResult
 AssertNativeSuccess $stop $signaled $nativeCode $nativeClock.Elapsed.TotalSeconds
} catch {$stop=$_.Exception.Message}
finally {
 $cleanupClock=[Diagnostics.Stopwatch]::StartNew()
 if($nativeClock){$nativeClock.Stop();$Timing.nativeElapsedSeconds=$nativeClock.Elapsed.TotalSeconds}
 if($launchAttempted-and-not$signaled){
  $grace=$cleanupClock
  try {
   AssertRetainedHandle $proc $safe
   while(-not$signaled){$ms=GetBoundedWaitMilliseconds $grace.Elapsed.TotalMilliseconds 90000;if($ms-eq0){break};$signaled=WaitOriginal $proc $safe $ms;if($signaled){$unityExitObservedUtc=[datetime]::UtcNow}}
   if($signaled){$nativeCode=ReadOriginalExit $proc $safe $signaled}
  }catch{$cleanup+=('CLEANUP_PENDING: '+$_.Exception.Message)}finally{$Timing.gracefulWaitSeconds=$grace.Elapsed.TotalSeconds}
  if(-not$signaled){$cleanup+='CLEANUP_PENDING: original process exit unconfirmed; root retains disposition'}
 }
 # A late exit is evidence only: $stop is never cleared.
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 # Cleanup cannot change the original Unity failure. All eight following guards stay independent.
 if($launchAttempted-and$signaled-and$identityVerified){
  try{
   ObserveVendorShutdown $cleanupClock $Timing $startedUtc $unityExitObservedUtc
   $cleanupClock.Stop();$Timing.sharedWaitObservationSeconds=$cleanupClock.Elapsed.TotalSeconds
   $compilerCleanup=InvokeScopedCompilerCleanup $Timing $startedUtc $unityExitObservedUtc $identityVerified
   Save "$out\COMPILER_CLEANUP_SUMMARY.json" $compilerCleanup
   if(-not$compilerCleanup.accepted){$cleanup+=('Compiler cleanup: '+$compilerCleanup.failure)}
  }catch{$cleanup+=('Compiler cleanup: '+$_.Exception.Message)}
 }
 if(-not$launchAttempted-or$signaled){
  # Independent evidence operations: no earlier cleanup fault suppresses later capture/comparison.
  try{AssertOriginalSearch 'AFTER'}catch{$cleanup+=('After Search: '+$_.Exception.Message)}
  try{CaptureCompilerOutputs}catch{$cleanup+=('Compiler artifacts: '+$_.Exception.Message)}
  try{& "$ad\read-typed-preferences.ps1" -OutFile "$out\outer-r001\PREFS_AFTER.json"}catch{$cleanup+=('After preferences snapshot: '+$_.Exception.Message)}
  try{& "$ad\snapshot-viewport.ps1" -OutputDirectory "$out\outer-r001\viewport-AFTER"}catch{$cleanup+=('After viewport snapshot: '+$_.Exception.Message)}
  try{& "$ad\snapshot-profile.ps1" -OutFile "$out\outer-r001\PROFILE_AFTER.json"|Out-Null}catch{$cleanup+=('After profile snapshot: '+$_.Exception.Message)}
  try{
   if(-not(Test-Path "$out\outer-r001\PREFS_BEFORE.json")-or-not(Test-Path "$out\outer-r001\PREFS_AFTER.json")){throw 'Before/after preferences evidence unavailable'}
   $a=Read "$out\outer-r001\PREFS_BEFORE.json";$b=Read "$out\outer-r001\PREFS_AFTER.json"
   if(($a.rows|ConvertTo-Json -Compress)-cne($b.rows|ConvertTo-Json -Compress)){throw 'Typed preferences changed'}
  }catch{$cleanup+=('Preferences comparison: '+$_.Exception.Message)}
  try{
   if(-not(Test-Path "$out\outer-r001\viewport-BEFORE\SNAPSHOT.json")-or-not(Test-Path "$out\outer-r001\viewport-AFTER\SNAPSHOT.json")){throw 'Before/after viewport evidence unavailable'}
   $a=Read "$out\outer-r001\viewport-BEFORE\SNAPSHOT.json";$b=Read "$out\outer-r001\viewport-AFTER\SNAPSHOT.json"
   if($a.customSizeAssetSha256-ne$b.customSizeAssetSha256-or($a.selectedSizes|ConvertTo-Json -Compress)-cne($b.selectedSizes|ConvertTo-Json -Compress)-or($a.targetSize|ConvertTo-Json -Compress)-cne($b.targetSize|ConvertTo-Json -Compress)){throw 'Viewport restoration mismatch'}
  }catch{$cleanup+=('Viewport comparison: '+$_.Exception.Message)}
  try{
   if(-not(Test-Path "$out\outer-r001\PROFILE_BEFORE.json")-or-not(Test-Path "$out\outer-r001\PROFILE_AFTER.json")){throw 'Before/after profile evidence unavailable'}
   $a=Read "$out\outer-r001\PROFILE_BEFORE.json";$b=Read "$out\outer-r001\PROFILE_AFTER.json"
   if(($a.entries|ConvertTo-Json -Depth 6 -Compress)-cne($b.entries|ConvertTo-Json -Depth 6 -Compress)){throw 'Profile journal drift'}
  }catch{$cleanup+=('Profile comparison: '+$_.Exception.Message)}
 }else{$cleanup+='Post-state snapshots deferred while original producer exit unconfirmed'}
 $postPinClock=[Diagnostics.Stopwatch]::StartNew();try{CheckPins}catch{$cleanup+=$_.Exception.Message}finally{$postPinClock.Stop();$Timing.postExitPinSeconds=$postPinClock.Elapsed.TotalSeconds}
 try{$remaining=@(Census);$censusVerified=$true}catch{$cleanup+=('CLEANUP_PENDING: census unavailable: '+$_.Exception.Message)}
 if($remaining.Count){$cleanup+='CLEANUP_PENDING: native/crash-handler/observed descendant remains'}
 $cleanupClock.Stop();$Timing.sharedWaitObservationSeconds=$cleanupClock.Elapsed.TotalSeconds
 Save "$out\RESULT.json" @{utc=[datetime]::UtcNow.ToString('o');stop=$stop;cleanupErrors=$cleanup;remaining=$remaining;censusVerified=$censusVerified;nativeExited=$signaled;nativeExitCode=$nativeCode;identityVerified=$identityVerified;accepted=($null-eq$stop-and$signaled-and$nativeCode-eq0-and$identityVerified-and$cleanup.Count-eq0-and$censusVerified-and$remaining.Count-eq0);slotReleased=$false;forcedTermination=$false;scope='Motion capture confirmation only; no rig, weights, continuous-motion or final appearance acceptance'}
 [GC]::KeepAlive($safe);[GC]::KeepAlive($proc)
}
Get-Content "$out\RESULT.json" -Raw;if(-not(Read "$out\RESULT.json").accepted){throw 'Motion job or cleanup rejected'}
} finally { $env:TEMP=$oldTemp;$env:TMP=$oldTmp }
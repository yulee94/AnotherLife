# Separate current-artifact gate. Never rewrites or accepts the failed compile job.
function AssertMotionArtifactQualification($lease) {
 $path="$ad\ARTIFACT_QUALIFICATION.json";$q=Read $path
 $hash=(Get-FileHash -LiteralPath $path).Hash
 if($q.schema-cne'MOTION_ARTIFACT_QUALIFICATION_V1'-or$q.rootQualified-ne$true-or$q.currentDependencyQualified-ne$true-or
    $q.historicalDependencyEqualityClaimed-ne$false-or$lease.motionArtifactQualificationSHA256-ne$hash){throw 'Separate artifact qualification absent'}
 if($q.originalResultPath-cne'F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-compile-r001\RESULT.json'-or
    $q.originalResultSHA256-cne'96A3209C856C905132440873CE20A84450B89FF8DA42424850EC504ACF751730'-or
    $q.originalReleasePath-cne'F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-compile-r001\ROOT_RELEASE.json'-or
    $q.originalReleaseSHA256-cne'F88004DD81D237585AAF7E4B897DCFE4A2C1B04EF871831F30C394A83A30ABBC'){throw 'Original failed evidence binding'}
 foreach($pair in @(@{path=$q.originalResultPath;sha256=$q.originalResultSHA256},@{path=$q.originalReleasePath;sha256=$q.originalReleaseSHA256},
   @{path=$q.artifactReviewPath;sha256=$q.artifactReviewSHA256},@{path=$q.dependencyReviewPath;sha256=$q.dependencyReviewSHA256},
   @{path="$ad\CURRENT_DEPENDENCY_EVIDENCE.json";sha256=$q.dependencyEvidenceSHA256},@{path="$ad\CURRENT_DEPENDENCY_PINS.json";sha256=$q.dependencyPinsSHA256},
   @{path="$ad\REQUIRED_SIX_PINS.json";sha256=$q.requiredSixPinsSHA256})){
  if([string]::IsNullOrWhiteSpace($pair.path)-or$pair.sha256-notmatch'^[A-Fa-f0-9]{64}$'){throw 'Qualification review/evidence missing'}
  Boundary $pair.path;if((Get-FileHash -LiteralPath $pair.path).Hash-ne$pair.sha256){throw 'Qualification evidence drift'}
 }
 $failed=Read $q.originalResultPath;$release=Read $q.originalReleasePath
 if($failed.accepted-ne$false-or$failed.nativeExited-ne$true-or$failed.nativeExitCode-ne0-or$failed.identityVerified-ne$true-or
    $failed.forcedTermination-ne$false-or$failed.censusVerified-ne$true-or@($failed.remaining).Count-ne0-or
    $release.status-cne'RELEASED_VALIDATION_FAILED_CLEANUP'-or$release.captureAdmitted-ne$false){throw 'Failed compile provenance changed'}
 $dep=Read "$ad\CURRENT_DEPENDENCY_PINS.json"
 $required=Read "$ad\REQUIRED_SIX_PINS.json"
 if(@($required).Count-ne6){throw 'Required PDB/runtime pin inventory'}
 foreach($p in $required){
  $match=@($dep|Where-Object path -ceq $p.path)
  if($match.Count-ne1-or$match[0].sha256-ne$p.sha256){throw 'Required PDB/runtime pin missing'}
 }
 foreach($p in $dep){
  $full=[IO.Path]::GetFullPath($p.path)
  if(-not$full.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)-or$p.sha256-notmatch'^[A-Fa-f0-9]{64}$'){throw 'Dependency pin scope'}
  $cursor=$full;while($cursor){if((Get-Item -LiteralPath $cursor).Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Dependency reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  if((Get-FileHash -LiteralPath $full).Hash-ne$p.sha256){throw 'Current dependency drift'}
 }
 if(@($dep|Where-Object path -ceq 'F:\AnotherLife\unity\Library\ScriptAssemblies\AL.Runtime.dll').Count-ne1){throw 'Current AL.Runtime pin missing'}
 # Current evidence acceptance requires a separately hashed independent review.
 # Runtime resolution/compatibility must be addressed there, not inferred from old hashes.
}

param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(-not [IO.Path]::GetFullPath($OutputDirectory).StartsWith('F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-capture-r001\outer-r001\',[StringComparison]::OrdinalIgnoreCase)){throw 'VIEWPORT_OUTPUT_BOUNDARY'}
if(Test-Path -LiteralPath $OutputDirectory){throw 'VIEWPORT_SNAPSHOT_EXISTS'}
[IO.Directory]::CreateDirectory($OutputDirectory)|Out-Null
$layout='F:\AnotherLife\unity\UserSettings\Layouts\default-6000.dwlt'
$sizes='C:\Users\yulee\AppData\Roaming\Unity\Editor-5.x\Preferences\GameViewSizes.asset'
$rows=@();foreach($p in @($layout,$sizes)){
 if(-not(Test-Path -LiteralPath $p)){throw 'VIEWPORT_SOURCE_MISSING'}
 $copy=Join-Path $OutputDirectory ([IO.Path]::GetFileName($p));[IO.File]::Copy($p,$copy,$false)
 $hash=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant();if($hash-ne(Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'VIEWPORT_COPY_RACE'}
 $rows+=@{source=$p;copy=$copy;sha256=$hash}
}
$text=[IO.File]::ReadAllText($layout);$selected=@([regex]::Matches($text,'(?m)^  m_SelectedSizes: (.*)$')|ForEach-Object {$_.Groups[1].Value.Trim()})
$target=@([regex]::Matches($text,'(?m)^  m_TargetSize: (.*)$')|ForEach-Object {$_.Groups[1].Value.Trim()})
if($selected.Count-ne1-or$target.Count-ne1){throw 'VIEWPORT_LAYOUT_AMBIGUOUS'}
$v=@{utc=[DateTimeOffset]::UtcNow.ToString('o');files=$rows;selectedSizes=$selected;targetSize=$target;customSizeAssetSha256=(Get-FileHash -LiteralPath $sizes -Algorithm SHA256).Hash.ToLowerInvariant();physicalSelectionSnapshot=$true;runtimeTransientDimensionsObserved=$false}
[IO.File]::WriteAllText((Join-Path $OutputDirectory 'SNAPSHOT.json'),($v|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
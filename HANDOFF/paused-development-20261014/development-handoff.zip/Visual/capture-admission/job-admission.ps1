# Job-specific composition atop retained arena identity/cohort/cleanup mechanisms.
function AssertPostpromotionSeal {
 $seal=Read "$ad\POSTPROMOTION_SEAL.json"
 if($seal.sealed-ne$true){throw 'Actual two-file promotion/cohort seal pending'}
 Boundary $seal.promotionReceiptPath
 if((Get-FileHash -LiteralPath $seal.promotionReceiptPath).Hash-ne$seal.promotionReceiptSHA256){throw 'Promotion receipt drift'}
 foreach($pair in @(@{name='REVIEWED_MEMBERSHIP_PINS.json';hash=$seal.membershipSHA256},@{name='CRITICAL_SOURCE_PINS.json';hash=$seal.criticalSHA256},@{name='ADAPTER_SOURCE_PINS.json';hash=$seal.adapterPinsSHA256})){
  if($pair.hash-notmatch'^[a-fA-F0-9]{64}$'-or(Get-FileHash "$ad\$($pair.name)").Hash-ne$pair.hash){throw 'Actual cohort seal drift'}
 }
 $members=Read "$ad\REVIEWED_MEMBERSHIP_PINS.json";$critical=Read "$ad\CRITICAL_SOURCE_PINS.json"
 if(@($members).Count-ne$seal.memberCount-or@($critical).Count-ne$seal.criticalCount){throw 'Cohort count drift'}
 $source='F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-adapter-candidates-20261014-r003\ExistingMaleMotionCapture.cs'
 $stage='F:\AnotherLife\unity\Assets\AL\Scripts\Editor\ExistingMaleRigReadback\ExistingMaleMotionCapture.cs'
 foreach($item in @(@{suffix='';hash='23059D086194C6E0DD67F710CDB7072541F4905C34333DFDBA3D3E3355BB1295'},@{suffix='.meta';hash='A689E8E853110A203853644FCCC00F7E7373FEB03F9745B33B5F1E4EAF0C0900'})){
  foreach($path in @(($source+$item.suffix),($stage+$item.suffix))){Boundary $path;if((Get-FileHash $path).Hash-ne$item.hash){throw 'Adapter source/meta promotion mismatch'}}
 }
}
function AssertCaptureContract($lease) {
 $receipt="$ad\CAPTURE_ADMISSION.json";$a=Read $receipt;$hash=(Get-FileHash $receipt).Hash.ToLowerInvariant()
 if($a.coordinatorAdmitted-ne$true-or$a.output-cne$out-or$a.maxInvocations-ne1-or$a.leaseId-cne$lease.leaseId-or$lease.motionCaptureOutput-cne$out-or$lease.motionCaptureAdmissionSHA256-cne$hash){throw 'Capture adapter lease scope absent'}
 $age=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0-$a.observedUnixSeconds
 if($age-lt0-or$age-gt1800){throw 'Stale adapter admission'}
 if($a.sourceSHA256-cne'23059d086194c6e0dd67f710cdb7072541f4905c34333dfdba3d3e3355bb1295'-or$a.metaSHA256-cne'a689e8e853110a203853644fccc00f7e7373feb03f9745b33b5f1e4eaf0c0900'){throw 'Adapter source contract'}
 $asmdef='F:\AnotherLife\unity\Assets\AL\Scripts\Editor\ExistingMaleRigReadback\AL.ExistingMaleRigReadback.Editor.asmdef'
 if($a.asmdefSHA256-cne(Get-FileHash $asmdef).Hash.ToLowerInvariant()){throw 'Adapter asmdef contract'}
 if($a.sourcePinsPath-cne"$ad\ADAPTER_SOURCE_PINS.json"-or$a.sourcePinsSHA256-cne(Get-FileHash $a.sourcePinsPath).Hash.ToLowerInvariant()){throw 'Adapter cohort contract'}
 Boundary $a.qaReviewPath
 if($a.qaReviewSHA256-cne(Get-FileHash $a.qaReviewPath).Hash.ToLowerInvariant()){throw 'Adapter source QA drift'}
 $contract=Read "$ad\COMPILE_CORRESPONDENCE.json"
 if($contract.accepted-ne$true-or$contract.sourceSHA256-ne$a.sourceSHA256-or$contract.promotionReceiptSHA256-ne(Read "$ad\POSTPROMOTION_SEAL.json").promotionReceiptSHA256){throw 'Actual new compile correspondence required'}
 $dll='F:\AnotherLife\unity\Library\ScriptAssemblies\AL.ExistingMaleRigReadback.Editor.dll'
 $pdb='F:\AnotherLife\unity\Library\ScriptAssemblies\AL.ExistingMaleRigReadback.Editor.pdb'
 foreach($required in @($dll,$pdb)){if(@($contract.pins|Where-Object {$_.path-ceq$required}).Count-ne1){throw 'New DLL/PDB correspondence membership'}}
 foreach($pin in $contract.pins){Boundary $pin.path;if($pin.sha256-notmatch'^[a-fA-F0-9]{64}$'-or(Get-FileHash $pin.path).Hash-ne$pin.sha256){throw 'Compiled correspondence drift'}}
 if($a.assemblySHA256-cne(Get-FileHash $dll).Hash.ToLowerInvariant()){throw 'Loaded adapter assembly contract'}
 if($contract.rootReleasePath-cne'F:\AnotherLife\outputs\LOCAL-RIG\unity-owned-motion-compile-r001\ROOT_RELEASE.json'){throw 'Exact motion compile release required'}
 Boundary $contract.rootReleasePath
 $release=Read $contract.rootReleasePath
 if((Get-FileHash $contract.rootReleasePath).Hash-ne$contract.rootReleaseSHA256){throw 'Original compile release drift'};AssertMotionArtifactQualification $lease
 Boundary $contract.qaReviewPath
 if((Get-FileHash $contract.qaReviewPath).Hash-ne$contract.qaReviewSHA256){throw 'Compile correspondence QA required'}
}
function AssertJobAdmission($lease) {
 AssertPostpromotionSeal
 $planPath="$ad\PLAN.json";$plan=Read $planPath;$config=Read "$ad\JOB_CONFIG.json"
 if($lease.status-ne'RESERVED_FOR_VALIDATION'-or$lease.nativeExecutionAuthorized-ne$true-or$lease.nativeHeavySlotsReserved-ne1-or$lease.exclusiveNativeWindow-ne$true-or$lease.canonicalWritesPermitted-ne$false-or$lease.admissionPath-cne$planPath-or$lease.admissionSha256-ne(Get-FileHash $planPath).Hash-or$lease.scriptPath-cne"$ad\run-sequence.ps1"-or$lease.scriptSha256-ne(Get-FileHash "$ad\run-sequence.ps1").Hash){throw 'Exact reviewed job lease absent'}
 foreach($pin in $plan.wrapperPins){Boundary $pin.path;if((Get-FileHash -LiteralPath $pin.path).Hash-ne$pin.sha256){throw 'Wrapper/input drift'}}
 $review=Read "$ad\SOURCE_QA.json"
 if($review.accepted-ne$true-or$review.planSHA256-ne(Get-FileHash $planPath).Hash-or$review.qaReviewSHA256-notmatch'^[a-fA-F0-9]{64}$'){throw 'Final composed source QA absent'}
 Boundary $review.qaReviewPath;if((Get-FileHash $review.qaReviewPath).Hash-ne$review.qaReviewSHA256){throw 'Source QA drift'}
 $receipt="$ad\JOB_ADMISSION.json";$a=Read $receipt;$hash=(Get-FileHash $receipt).Hash
 $kind=if($config.phase-ceq'compile'){'UNITY_MOTION_COMPILE'}elseif($config.phase-ceq'capture'){'UNITY_MOTION_CAPTURE'}else{throw 'Unknown phase'}
 if($a.coordinatorAdmitted-ne$true-or$a.jobKind-cne$kind-or$a.maxInvocations-ne1-or$a.output-cne$out-or$a.leaseId-cne$lease.leaseId-or[string]::IsNullOrWhiteSpace($a.leaseId)-or$lease.jobOutput-cne$out-or$lease.jobAdmissionSHA256-ne$hash){throw 'Root job receipt scope absent'}
 $age=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0-$a.observedUnixSeconds
 if($age-lt0-or$age-gt1800){throw 'Stale job receipt'}
 if($a.promotionReceiptSHA256-ne(Read "$ad\POSTPROMOTION_SEAL.json").promotionReceiptSHA256){throw 'Root promotion mismatch'}
 if($lease.interopArtifactSHA256-ne(Get-FileHash "$ad\INTEROP_ARTIFACT.json").Hash){throw 'Reviewed helper not root bound'}
 AssertCompilerCleanupAdmission $lease (Read "$ad\COMPILER_CLEANUP_CONFIG.json")
 if($config.phase-ceq'capture'){AssertCaptureContract $lease}
}
# Compatibility for the BYTE-IDENTICAL reviewed cooperative cleanup caller.
function AssertCompileAdmission($lease) { AssertJobAdmission $lease }
function CaptureCompilerOutputs {
 $dir="$out\post-artifacts";Boundary $dir;if(Test-Path $dir){throw 'Post artifacts exist'};[IO.Directory]::CreateDirectory($dir)|Out-Null
 $rows=@();foreach($assembly in (Read "$ad\AFFECTED_ASSEMBLIES.json").runtime){foreach($ext in @('dll','pdb')){
  $path="F:\AnotherLife\unity\Library\ScriptAssemblies\$assembly.$ext";Boundary $path;$hash=(Get-FileHash $path).Hash
  $copy=Join-Path $dir ([IO.Path]::GetFileName($path));[IO.File]::Copy($path,$copy,$false)
  if((Get-FileHash $copy).Hash-ne$hash-or(Get-FileHash $path).Hash-ne$hash){throw 'Compiled output changed during copy'}
  $rows+=@{assembly=$assembly;path=$path;copy=$copy;afterSHA256=$hash}
 }}
 Save "$out\COMPILER_ARTIFACTS.json" @{rows=$rows;scope='Observed DLL/PDB bytes only; source/compiler correspondence and Root release separately required'}
}
function PrepareJobEvidence {
 if((Read "$ad\JOB_CONFIG.json").phase-ceq'capture'){
  foreach($name in @('captures','evidence')){$path=Join-Path $out $name;Boundary $path;if(Test-Path $path){throw 'Capture subtree not fresh'};[IO.Directory]::CreateDirectory($path)|Out-Null}
  [IO.File]::Copy("$ad\CAPTURE_ADMISSION.json","$out\CAPTURE_ADMISSION.json",$false)
  if((Get-FileHash "$ad\CAPTURE_ADMISSION.json").Hash-ne(Get-FileHash "$out\CAPTURE_ADMISSION.json").Hash){throw 'Adapter receipt copy mismatch'}
 }
}
function SetJobEnvironment($info) {
 [void]$info.Environment.Remove('AL_RIG_READBACK_ADMISSION_SHA256');[void]$info.Environment.Remove('AL_MOTION_CAPTURE_ADMISSION_SHA256')
 if((Read "$ad\JOB_CONFIG.json").phase-ceq'capture'){$info.Environment['AL_MOTION_CAPTURE_ADMISSION_SHA256']=(Get-FileHash "$out\CAPTURE_ADMISSION.json").Hash.ToLowerInvariant()}
}
function AssertJobResult {
 if((Read "$ad\JOB_CONFIG.json").phase-ceq'compile'){return}
 $path="$out\CAPTURE_REPORT.json";Boundary $path
 if((Get-Item $path).Length-gt8MB){throw 'Capture report bound'}
 $r=Read $path
 if($r.status-cne'CAPTURED_SAMPLES'-or$r.qualification-cne'TIMED_DEFORMATION_SAMPLES_ONLY'-or$r.weights-cne'UNEVALUATED'-or$r.bindposes-cne'UNEVALUATED'-or$r.sourcePinsUnchanged-ne$true-or$r.cleanupComplete-ne$true-or-not[string]::IsNullOrEmpty($r.error)-or@($r.secondaryCleanupErrors).Count-ne0){throw 'Adapter failure or false qualification'}
 if($r.admissionSHA256-cne(Get-FileHash "$out\CAPTURE_ADMISSION.json").Hash.ToLowerInvariant()-or$r.pipeline-cne'BuiltIn'-or@($r.shaders).Count-ne4-or@($r.shaders|Where-Object {$_-cne'Standard'}).Count){throw 'Capture admission/pipeline/shader mismatch'}
 if(@($r.frames).Count-ne12-or@($r.poses).Count-ne6-or@($r.controls).Count-ne2){throw 'Capture inventory incomplete'}
 $expectedPng=@();$expectedGeometry=@();$names=@('AL_Humanoid_Walk','AL_Humanoid_SkillCast');$views=@('front_three_quarter','side');$fractions=@(0,0.25,0.75)
 for($clip=0;$clip-lt2;$clip++){for($phase=0;$phase-lt3;$phase++){
  $geometry="pose_${clip}_${phase}.bin";$expectedGeometry+=$geometry
  $poses=@($r.poses|Where-Object {$_.clip-ceq$names[$clip]-and$_.fraction-eq$fractions[$phase]})
  if($poses.Count-ne1-or$poses[0].geometryFile-cne$geometry-or$poses[0].vertices-ne20933-or$poses[0].subMeshes-ne4){throw 'Pose identity/inventory mismatch'}
  $pose=$poses[0];$file="$out\evidence\$geometry";Boundary $file
  if((Get-FileHash $file).Hash-ne$pose.geometrySHA256){throw 'Saved geometry hash mismatch'}
  foreach($view in $views){
   $name="clip_${clip}_phase_${phase}_${view}.png";$expectedPng+=$name;$frames=@($r.frames|Where-Object {$_.file-ceq$name})
   if($frames.Count-ne1){throw 'PNG record absent/duplicate'};$f=$frames[0]
   if($f.clip-cne$pose.clip-or$f.view-cne$view-or$f.seconds-ne$pose.requestedSeconds-or$f.geometrySHA256-cne$pose.geometrySHA256-or$f.foregroundPixels-lt64){throw 'Pose-to-image correspondence mismatch'}
   $file="$out\captures\$name";Boundary $file;if((Get-FileHash $file).Hash-ne$f.pngSHA256){throw 'PNG hash mismatch'}
  }
 }}
 if((@(Get-ChildItem "$out\captures" -File|ForEach-Object Name|Sort-Object)|ConvertTo-Json -Compress)-cne(@($expectedPng|Sort-Object)|ConvertTo-Json -Compress)){throw 'Unexpected capture file inventory'}
 if((@(Get-ChildItem "$out\evidence" -File|ForEach-Object Name|Sort-Object)|ConvertTo-Json -Compress)-cne(@($expectedGeometry|Sort-Object)|ConvertTo-Json -Compress)){throw 'Unexpected geometry file inventory'}
 foreach($view in $views){$controls=@($r.controls|Where-Object {$_.view-ceq$view});if($controls.Count-ne1-or$controls[0].originalPixelsSHA256-cne$controls[0].repeatPixelsSHA256-or$controls[0].originalPixelsSHA256-ceq$controls[0].shiftedPixelsSHA256){throw 'Repeat/shift control failure'}}
 Save "$out\CAPTURE_INVENTORY_CHECK.json" @{accepted=$true;pngs=12;poses=6;scope='File/record correspondence; actual PNG pixels and appearance require separate visual review';weights='UNEVALUATED';bindposes='UNEVALUATED'}
}

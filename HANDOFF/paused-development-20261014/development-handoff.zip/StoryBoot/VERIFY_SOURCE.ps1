$ErrorActionPreference='Stop'
$taskRoot='F:\AnotherLife\outputs\LOCAL-WEB\owned-story-boot-preparation-hook-20261014-r001'
$candidate=Join-Path $taskRoot 'candidate'
$declared=(Get-Content -LiteralPath (Join-Path $taskRoot 'DECLARED_FOOTPRINT.json') -Raw | ConvertFrom-Json).candidatePaths
$actual=@(Get-ChildItem -LiteralPath $candidate -Recurse -File | ForEach-Object{$_.FullName.Substring($candidate.Length+1).Replace('\','/')})
if(@(Compare-Object ($declared | Sort-Object) ($actual | Sort-Object)).Count){throw 'Candidate footprint mismatch'}
$pins=Get-Content -LiteralPath (Join-Path $taskRoot 'SOURCE_PINS.json') -Raw | ConvertFrom-Json
foreach($pin in $pins){if((Get-FileHash -LiteralPath $pin.path -Algorithm SHA256).Hash -ne $pin.sha256){throw "Dependency changed: $($pin.path)"}}
$runtime=Get-Content -LiteralPath 'F:\AnotherLife\unity\Assets\AL\Scripts\AL.Runtime.asmdef' -Raw | ConvertFrom-Json
$story=Get-Content -LiteralPath 'F:\AnotherLife\unity\Assets\AL\Scripts\UI\StoryTurn\AL.StoryPresentation.asmdef' -Raw | ConvertFrom-Json
if($runtime.references -contains 'AL.StoryPresentation' -or $story.references -notcontains 'AL.Runtime'){throw 'Assembly dependency boundary mismatch'}
$boot=[IO.File]::ReadAllText((Join-Path $candidate 'Assets/AL/Scripts/UI/BootController.cs'))
$baseline=[IO.File]::ReadAllText((Join-Path $taskRoot 'preimages/BootController.cs'))
if($boot.Contains('DevelopmentStoryCatalogPresentation') -or $boot.Contains('System.Reflection')){throw 'Boot crosses assembly/implementation boundary'}
if([regex]::Matches($boot,'async\s+void').Count -ne [regex]::Matches($baseline,'async\s+void').Count){throw 'New async void introduced'}
function Remove-DevelopmentBlocks([string]$text) {
    $skip=$false;$out=[Collections.Generic.List[string]]::new()
    foreach($line in ($text -split "\r?\n")){
        if($line.Trim() -eq '#if UNITY_EDITOR || DEVELOPMENT_BUILD'){if($skip){throw 'Unexpected nested conditional'};$skip=$true;continue}
        if($line.Trim() -eq '#endif'){if(!$skip){throw 'Unexpected conditional end'};$skip=$false;continue}
        if(!$skip){$out.Add($line)}
    }
    if($skip){throw 'Unclosed conditional'}
    return [regex]::Replace(($out -join "`n"),'\s+','')
}
$composition=[IO.File]::ReadAllText((Join-Path $candidate 'Assets/AL/Scripts/UI/StoryTurn/AccountStoryComposition.cs'))
$original=[IO.File]::ReadAllText((Join-Path $taskRoot 'preimages/AccountStoryComposition.cs'))
if((Remove-DevelopmentBlocks $composition) -ne ([regex]::Replace($original,'\s+',''))){throw 'Production composition tokens changed'}
$tests=[IO.File]::ReadAllText((Join-Path $candidate 'Assets/AL/Tests/PlayMode/StoryTurn/AccountStoryPreparationTests.cs'))
$cases=[regex]::Matches($tests,'\[Test\]').Count+[regex]::Matches($tests,'\[TestCase\(').Count
$methods=@([regex]::Matches($tests,'public\s+(?:async\s+)?(?:Task|void)\s+(\w+)\(') | ForEach-Object{$_.Groups[1].Value} | Where-Object{$_ -notin @('Setup','Teardown')})
if($actual.Count -ne 6){throw 'Expected six-file candidate'}
[ordered]@{
    scope='Source checks only; not C# compilation, Unity test execution or runtime qualification'
    exactFootprint=$actual.Count
    dependencyPinsVerified=$pins.Count
    unchangedAssemblyGraph=$true
    productionCompositionTokensUnchanged=$true
    noNewAsyncVoid=$true
    authoredTests=$cases
    authoredTestMethods=$methods
    testsRun=0
    compilerRuns=0
    nativeRuns=0
    sealedR002Unchanged=$true
    canonicalWrites=0
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'SOURCE_VALIDATION.json') -Encoding utf8
Write-Output "Source checks passed; $cases authored cases; 0 tests run."

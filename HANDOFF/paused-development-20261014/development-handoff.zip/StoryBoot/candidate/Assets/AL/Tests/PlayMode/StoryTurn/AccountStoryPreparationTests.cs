#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AL.Core.Accounts;
using AL.Services;
using AL.UI;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using static AL.Tests.PlayMode.StoryTurn.StoryCompositionTestData;

namespace AL.Tests.PlayMode.StoryTurn
{
    // Fixture identities and transport are test-only; no runtime account factory is introduced.
    public sealed class AccountStoryPreparationTests
    {
        GameObject root;EventSystem input,previous;AccountLoginSession session;
        HttpAccountProvider provider;Transport transport;Codec codec;
        AccountServiceHost service;AccountKingdomManagementPanel panel;AccountKingdomMobileShell shell;
        AccountStoryFlowHost flow;AccountStoryComposition composition;DevelopmentStoryCatalogPresentation content;BootController boot;
        StoryFlowFixture.MemoryStore store;
        GameObject Child(string name,params Type[] types){var go=new GameObject(name,types);go.transform.SetParent(root.transform,false);return go;}
        Text Label(string name){var t=Child(name,typeof(RectTransform),typeof(Text)).GetComponent<Text>();t.font=AL.UI.Presentation.PresentationChrome.ResolveFont();return t;}
        Button Action(string name)=>Child(name,typeof(RectTransform),typeof(Button)).GetComponent<Button>();
        [SetUp] public void Setup()
        {
            root=new GameObject("StoryCompositionFixture",typeof(RectTransform),typeof(Canvas));
            previous=EventSystem.current;input=Child("Input").AddComponent<EventSystem>();EventSystem.current=input;
            session=StoryFlowFixture.Session();transport=new Transport();codec=new Codec();provider=Provider(transport,codec,session);store=new StoryFlowFixture.MemoryStore();
            service=Child("AccountServices").AddComponent<AccountServiceHost>();Set(service,"provider",provider);
            panel=Child("Panel",typeof(RectTransform)).AddComponent<AccountKingdomManagementPanel>();
            Set(panel,"provider",provider);Set(panel,"session",session);Set(panel,"initialProgress",Progress());Set(panel,"legacyDisplayedProgress",Progress());Set(panel,"bindingLive",true);
            Set(panel,"constructionMode",Enum.Parse(panel.GetType().GetNestedType("ConstructionMode",Private),"Legacy"));
            foreach(string name in new[]{"resources","status","terms","productionStatus"})Set(panel,name,Label(name));
            foreach(string name in new[]{"confirm","refresh","retry","finish","collectionRetry"})Set(panel,name,Action(name));
            shell=Child("Shell",typeof(RectTransform)).AddComponent<AccountKingdomMobileShell>();Set(shell,"panel",panel);
            foreach(string name in new[]{"menuVisibility","chatVisibility","drawerVisibility"})Set(shell,name,Child(name,typeof(CanvasGroup)).GetComponent<CanvasGroup>());
            foreach(string name in new[]{"connection","artNotice","title","notice"})Set(shell,name,Label(name));
            Set(shell,"drawer",Child("Drawer",typeof(RectTransform)).GetComponent<RectTransform>());
            var scroll=Child("Scroll",typeof(RectTransform),typeof(ScrollRect)).GetComponent<ScrollRect>();scroll.content=Child("ScrollContent",typeof(RectTransform)).GetComponent<RectTransform>();Set(shell,"scroll",scroll);
            var labels=(Text[])Get(shell,"resourceLabels");for(int i=0;i<labels.Length;i++)labels[i]=Label("Balance"+i);
            var body=Child("MenuBody",typeof(RectTransform)).GetComponent<RectTransform>();var bodyText=Label("MenuText");bodyText.transform.SetParent(body,false);Set(shell,"approvedBody",body);Set(shell,"approvedBodyText",bodyText);
            var ids=new[]{"story","tower","endless_wave","heroes","guild","alliance","events","rankings","redeem_code","cash_shop","settings","help","profile"};
            var menu=new Phase1ShellState(ids.Select(id=>new ShellMenuEntry(id,id,id=="settings"?ShellMenuRole.Settings:id=="help"?ShellMenuRole.Help:id=="profile"?ShellMenuRole.Profile:ShellMenuRole.Feature,true)),new[]{"one","two","three"});
            menu.OpenMenu();menu.SelectMenu("story");Set(shell,"approvedShell",menu);((CanvasGroup)Get(shell,"menuVisibility")).alpha=1;
            flow=Child("Flow").AddComponent<AccountStoryFlowHost>();composition=Child("Composition").AddComponent<AccountStoryComposition>();content=Child("SyntheticContent").AddComponent<DevelopmentStoryCatalogPresentation>();
            Set(composition,"_flowHost",flow);Set(composition,"_approvedContent",content);
            presentation=new TextAsset(Catalog());
            Set(composition,"_prepareDevelopmentContent",true);Set(composition,"_developmentPresentation",presentation);
            Set(composition,"_admittedCatalogRevision","synthetic");Set(composition,"_admittedContentId","stage1");Set(composition,"_admittedDefinitionRevision","synthetic_v1");
            boot=Child("Boot").AddComponent<BootController>();Set(boot,"_suppressBootInitializationForTests",true);
            Set(boot,"_accountHost",service);Set(boot,"_storyRouteHost",flow);Set(boot,"_storyComposition",composition);Set(boot,"_storyIntentStore",store);
            Set(boot,"_safeAreaRoot",root.GetComponent<RectTransform>());Set(boot,"_kingdomAccountSession",session);Set(boot,"_accountProgress",Progress());Set(boot,"_accountKingdomPanel",panel);Set(boot,"_accountKingdomShell",shell);
        }
        [TearDown] public void Teardown(){UnityEngine.Object.DestroyImmediate(root);UnityEngine.Object.DestroyImmediate(presentation);provider.Dispose();replacementProvider?.Dispose();if(previous!=null&&previous.isActiveAndEnabled)EventSystem.current=previous;}
        void Bind()=>Call(boot,"BindStoryRoute",session,StoryFlowFixture.Kingdom,panel,shell);

        HttpAccountProvider replacementProvider;
        TextAsset presentation;
        Task Preparation => (Task)Get(boot,"_storyPreparationTask");
        string Catalog(bool missingArt=false)=>JsonUtility.ToJson(new DevelopmentStoryDisplayCatalog{
            version=1,enabled=true,developmentOnly=true,catalogRevision="synthetic",contentId="stage1",
            definitionRevision="synthetic_v1",entries=missingArt?new[]{
                new DevelopmentStoryDisplayRow{kind="Stage",id="stage1",en="Stage",ko="시험",spriteResource=""},
                new DevelopmentStoryDisplayRow{kind="Hero",id="missing",en="Missing",ko="없음",spriteResource="Missing/Unshipped"}
            }:new[]{new DevelopmentStoryDisplayRow{kind="Stage",id="stage1",en="Stage",ko="시험",spriteResource=""}},
            rewards=Array.Empty<DevelopmentStoryDisplayRow>()});
        void AssertClosed()
        {
            Assert.That(Get(shell,"storyRoute"),Is.Null);
            Assert.That(Get(flow,"owner"),Is.Null);
            Assert.That(content.IsAvailable,Is.False);
            Assert.That(store.Saves,Is.Zero);Assert.That(store.Clears,Is.Zero);
            Assert.That(transport.Calls.All(c=>c=="GET /v1/account/kingdom/story"),Is.True);
        }
        [Test] public void RuntimeBoundaryDoesNotReferencePresentationAssembly()
        {
            Assert.That(typeof(IAccountStoryPreparation).Assembly,Is.SameAs(typeof(BootController).Assembly));
            Assert.That(typeof(BootController).Assembly.GetReferencedAssemblies().Any(a=>a.Name=="AL.StoryPresentation"),Is.False);
            Assert.That(typeof(AccountStoryComposition).Assembly.GetReferencedAssemblies().Any(a=>a.Name=="AL.Runtime"),Is.True);
        }
        [Test] public void NewCompositionDefaultsToOptOutAndUnsetContent()
        {
            var fresh=Child("Unconfigured").AddComponent<AccountStoryComposition>();
            Assert.That(fresh.RequiresPreparation,Is.False);
            Assert.That(Get(fresh,"_developmentPresentation"),Is.Null);
            foreach(var key in new[]{"_admittedCatalogRevision","_admittedContentId","_admittedDefinitionRevision"})
                Assert.That(string.IsNullOrEmpty((string)Get(fresh,key)),Is.True);
        }
        [Test] public void OptOutPreservesExistingSynchronousComposition()
        {
            Set(composition,"_prepareDevelopmentContent",false);
            var ordinary=Child("Ordinary").AddComponent<SyntheticStoryContent>();
            Set(composition,"_approvedContent",ordinary);
            Bind();
            Assert.That(Preparation,Is.Null);Assert.That(Get(shell,"storyRoute"),Is.SameAs(flow));
            Assert.That(((AccountStoryFlowOwner)Get(flow,"owner")).IsLive,Is.True);
            Assert.That(transport.Calls.Count,Is.EqualTo(1));
        }
        [Test] public async Task PendingPreparationPublishesOnlyAfterSameSourceIsReady()
        {
            var held=new TaskCompletionSource<AccountHttpResponse>();transport.Pending=held;
            Bind();var pending=Preparation;
            Assert.That(pending.IsCompleted,Is.False);AssertClosed();
            transport.Pending=null;held.SetResult(transport.Response);await pending;
            Assert.That(content.IsAvailable,Is.True);Assert.That(Get(composition,"_preparedSource"),Is.SameAs(Get(composition,"_approvedContent")));
            Assert.That(Get(shell,"storyRoute"),Is.SameAs(flow));
            Assert.That(((AccountStoryFlowOwner)Get(flow,"owner")).IsLive,Is.True);
            Assert.That(transport.Calls.Count,Is.EqualTo(2)); // capability then existing flow initialization
            Assert.That(store.Saves,Is.Zero);
        }
        [TestCase("retire")] [TestCase("logout")] [TestCase("disable")] [TestCase("expiry")]
        [TestCase("provider")] [TestCase("source")] [TestCase("configuration")] [TestCase("composition")]
        [TestCase("input")] [TestCase("owner")] [TestCase("opt-out")]
        public async Task PendingReadCannotPublishAfterLifetimeChanges(string change)
        {
            var held=new TaskCompletionSource<AccountHttpResponse>();transport.Pending=held;
            Bind();var pending=Preparation;
            var token=((CancellationTokenSource)Get(content,"pending")).Token;
            switch(change)
            {
                case "retire":Call(boot,"RetireStoryRoute","test");break;
                case "logout":Call(boot,"RetireStoryRoute","logout");provider.ClearSession();Set(boot,"_kingdomAccountSession",null);break;
                case "disable":boot.enabled=false;break;
                case "expiry":typeof(AccountLoginSession).GetProperty("ExpiresAt").GetSetMethod(true).Invoke(session,new object[]{1L});break;
                case "provider":replacementProvider=Provider(new Transport(),new Codec(),session);Set(service,"provider",replacementProvider);break;
                case "source":Set(composition,"_approvedContent",Child("OtherSource").AddComponent<DevelopmentStoryCatalogPresentation>());break;
                case "configuration":Set(composition,"_admittedDefinitionRevision","different");break;
                case "opt-out":Set(composition,"_prepareDevelopmentContent",false);break;
                case "composition":composition.enabled=false;break;
                case "input":EventSystem.current=null;break;
                case "owner":Set(boot,"_kingdomAccountSession",StoryFlowFixture.Session());break;
            }
            if(change=="retire"||change=="logout"||change=="disable"||change=="composition")
                Assert.That(token.IsCancellationRequested,Is.True,"Retirement must cancel the adapter's pending read.");
            transport.Pending=null;held.SetResult(transport.Response);await pending;
            AssertClosed();Assert.That(Get(boot,"_storyRouteGeneration"),Is.Null);
        }
        [TestCase(200)] [TestCase(401)]
        public async Task LateOldCompletionCannotRevokeNewGeneration(int oldStatus)
        {
            var held=new TaskCompletionSource<AccountHttpResponse>();transport.Pending=held;Bind();var old=Preparation;
            var oldCurrent=(Func<bool>)Get(boot,"_storyRouteCurrent");
            var oldToken=((CancellationTokenSource)Get(content,"pending")).Token;
            transport.Pending=null;Bind();await Preparation;
            var nextGeneration=Get(boot,"_storyRouteGeneration");var nextOwner=Get(flow,"owner");
            Assert.That(oldToken.IsCancellationRequested,Is.True);Assert.That(oldCurrent(),Is.False);
            held.SetResult(new AccountHttpResponse(oldStatus,oldStatus==200?transport.Response.Json:""));await old;
            Assert.That(content.IsAvailable,Is.True);Assert.That(Get(shell,"storyRoute"),Is.SameAs(flow));
            Assert.That(Get(flow,"owner"),Is.SameAs(nextOwner));Assert.That(((AccountStoryFlowOwner)nextOwner).IsLive,Is.True);
            Assert.That(Get(boot,"_storyRouteGeneration"),Is.SameAs(nextGeneration));
        }
        [Test] public async Task ReplacingSourcePreparesOnlyTheNewCompositionSource()
        {
            var held=new TaskCompletionSource<AccountHttpResponse>();transport.Pending=held;Bind();var old=Preparation;
            var first=content;
            content=Child("ReplacementContent").AddComponent<DevelopmentStoryCatalogPresentation>();
            Set(composition,"_approvedContent",content);transport.Pending=null;Bind();await Preparation;
            held.SetResult(transport.Response);await old;
            Assert.That(first.IsAvailable,Is.False);Assert.That(content.IsAvailable,Is.True);
            Assert.That(Get(composition,"_preparedSource"),Is.SameAs(content));
            Assert.That(Get(shell,"storyRoute"),Is.SameAs(flow));
        }
        [TestCase("asset")] [TestCase("catalog")] [TestCase("content")] [TestCase("definition")]
        [TestCase("wrong-source")] [TestCase("missing-art")]
        public async Task MissingExplicitAdmissionOrContentNeverEnablesRoute(string missing)
        {
            switch(missing)
            {
                case "asset":Set(composition,"_developmentPresentation",null);break;
                case "catalog":Set(composition,"_admittedCatalogRevision","");break;
                case "content":Set(composition,"_admittedContentId","");break;
                case "definition":Set(composition,"_admittedDefinitionRevision","");break;
                case "wrong-source":Set(composition,"_approvedContent",Child("NotAdapter").AddComponent<SyntheticStoryContent>());break;
                case "missing-art":UnityEngine.Object.DestroyImmediate(presentation);presentation=new TextAsset(Catalog(true));Set(composition,"_developmentPresentation",presentation);break;
            }
            Bind();await Preparation;AssertClosed();
            Assert.That(transport.Calls.Count,Is.EqualTo(missing=="missing-art"?1:0));
        }
        [Test] public async Task SuccessfulPreparationIsRevokedWhenBootRetiresAfterCompletion()
        {
            Bind();await Preparation;Assert.That(content.IsAvailable,Is.True);
            Call(boot,"RetireStoryRoute","logout");
            AssertClosed();Assert.That(Get(composition,"_preparedSource"),Is.Null);
        }
        [Test] public async Task ProviderFailureIsObservedWithoutPublishing()
        {
            var held=new TaskCompletionSource<AccountHttpResponse>();transport.Pending=held;
            Bind();var pending=Preparation;held.SetException(new InvalidOperationException("fixture failure"));
            await pending;Assert.That(pending.IsFaulted,Is.False);AssertClosed();
        }

    }
}
#endif

using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using AL.Core;
using AL.Core.Interfaces;
using AL.Input;
using AL.RealmSelection;
using AL.Services.Local;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace AL.UI
{
    public class BootController : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private string _realmSelectionScene = "RealmSelection";

        // Retained only for scene/descriptor compatibility while the first-user route contract is
        // integrated. Realm identity is deliberately never used to activate this route.
        [SerializeField] private string _kingdomScene = "Kingdom";

        [Header("Presentation")]
        [SerializeField] private bool _buildRuntimeSplash = true;
        [SerializeField] private string _buildLabel = "TEMPORARY — launch splash";

        private LaunchReadinessCoordinator _readiness;
        private LaunchCinematicLifecycle _launchLifecycle;
        private CurrentBootLoadReceipt _bootReceipt;
        private CurrentRealmCatalogReceipt _catalogReceipt;

        [SerializeField] private MonoBehaviour _storyRouteHost;
        [SerializeField] private MonoBehaviour _storyComposition;
        private AL.Core.Accounts.IStoryPendingIntentStore _storyIntentStore;
        private IAccountStoryRouteHost _boundStoryRoute;
        private object _storyRouteGeneration;
        private AccountKingdomMobileShell _accountKingdomShell;
        private AccountKingdomMobileShell _storyRouteShell;
        private Func<bool> _storyRouteCurrent;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        private IAccountStoryPreparation _storyPreparation;
        private CancellationTokenSource _storyPreparationCancellation;
        private Task _storyPreparationTask;
#endif
        private RectTransform _safeAreaRoot;
        private GameObject _splashContent;
        private bool _kingdomPhoneLogin;
        private EmailCodeLoginPanel _emailLoginPanel;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        private DevelopmentKingdomPreviewLauncher _localDevelopmentPreview;
#endif
        private AccountKingdomOnboardingPanel _kingdomOnboardingPanel;
        private AccountKingdomManagementPanel _accountKingdomPanel;
        private AL.Services.AccountServiceHost _accountHost;
#if UNITY_EDITOR
        private AL.Services.AccountEndpointCatalog _phase1FixtureConfiguration;
        private bool _phase1FixtureEntry;
#endif
        private Coroutine _phoneLoginInitialization;
        private CancellationTokenSource _kingdomProgressRequest;
        private AL.Core.Accounts.AccountKingdomProgress _accountProgress;
        private AL.Core.Accounts.AccountLoginSession _kingdomAccountSession;
        private AccountPresentationData _accountPresentationData;
        private Text _statusText;
        private Text _detailText;
        private Button _continueButton;
        private Button _startNewMvpButton;
        private Button _retryButton;
        private bool _startNewMvpConfirmation;
        private bool _approvalResetInProgress;
        private string _approvalResetError = string.Empty;
#if UNITY_INCLUDE_TESTS
        private bool _suppressDestinationLoadForTests;
        private bool _suppressBootInitializationForTests;
        private Func<Transform, AL.Core.Accounts.AccountLoginSession, AL.Core.Accounts.AccountKingdomProgress,
            Action, IGameDataService, AccountBuildingPresentationCatalog, AccountKingdomManagementPanel> _accountPanelFactoryForTests;
#endif
        private int _readyFrame = -1;
        private int _focusedGeneration;
        private Button _focusedAction;
        private bool _submitArmed;
        private int _lastScreenWidth = -1;
        private int _lastScreenHeight = -1;
        private Rect _lastSafeArea = new Rect(-1f, -1f, -1f, -1f);
        private LaunchReadinessState _lastRenderedState = (LaunchReadinessState)(-1);
        private LaunchReadinessFailure _lastRenderedFailure = (LaunchReadinessFailure)(-1);
        private int _lastRenderedGeneration = -1;

        private void Start()
        {
#if UNITY_INCLUDE_TESTS
            if (_suppressBootInitializationForTests) return;
#endif
            Debug.Log("AL Boot Sequence Started...");
            _kingdomPhoneLogin = Bootloader.UsesAccountKingdomLogin(Application.platform, MvpApprovalSlotRuntime.IsApprovalFlavor);
            _readiness = new LaunchReadinessCoordinator();
            _launchLifecycle = new LaunchCinematicLifecycle();
            _launchLifecycle.MarkPreparing();

            if (_buildRuntimeSplash)
            {
                BuildRuntimeSplash();
            }
            else
            {
                // The current production Boot scene has no authored launch UI. Keep the gate visible
                // even if an old serialized flag is disabled instead of silently auto-routing.
                BuildRuntimeSplash();
            }

            if (_kingdomPhoneLogin)
            {
                _statusText.text = "Preparing sign-in…";
                _phoneLoginInitialization = StartCoroutine(InitializeKingdomPhoneLogin());
                return;
            }

            _launchLifecycle.FailToFallback("approved-media-unavailable");
            _readiness.TryEstablishMedia(
                _readiness.AttemptGeneration,
                LaunchMediaPresentation.StaticFallbackEstablished);
            RefreshPresentation(force: true);
        }

        private void Update()
        {
            if (_storyRouteCurrent != null && !_storyRouteCurrent()) RetireStoryRoute("owner-unavailable");
            if (_readiness == null)
            {
                return;
            }

            UpdateSafeAreaIfNeeded();
            if (_kingdomPhoneLogin)
            {
                if (_kingdomAccountSession != null && _kingdomAccountSession.ExpiresAt <= DateTimeOffset.UtcNow.ToUnixTimeSeconds()) CancelKingdomProgress();
                return;
            }
            RefreshReadinessEvidence();
            RefreshPresentation(force: false);
            PollExplicitSubmit();
        }

        private void OnDisable()
        {
            if (_accountKingdomPanel != null) _accountKingdomPanel.gameObject.SetActive(false);
            CancelKingdomProgress();
            if (_phoneLoginInitialization != null) StopCoroutine(_phoneLoginInitialization);
            _phoneLoginInitialization = null;
            if (_accountHost != null) _accountHost.enabled = false;
            _submitArmed = false;
            _readyFrame = -1;
            _focusedGeneration = 0;
            _focusedAction = null;
            _startNewMvpConfirmation = false;
            _approvalResetInProgress = false;
        }

        private void OnDestroy()
        {
            RetireStoryRoute("destroy");
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            if (_localDevelopmentPreview != null) Destroy(_localDevelopmentPreview.gameObject);
#endif
            if (_accountKingdomPanel != null) { _accountKingdomPanel.RetireMutationOwner("logout-replacement-or-destroy");Destroy(_accountKingdomPanel.gameObject); }
            if (_kingdomOnboardingPanel != null) Destroy(_kingdomOnboardingPanel.gameObject);
            _accountPresentationData?.Dispose(); _accountPresentationData = null;
            if (_continueButton != null)
            {
                _continueButton.onClick.RemoveListener(OnContinueRequested);
            }

            if (_retryButton != null)
            {
                _retryButton.onClick.RemoveListener(OnRetryRequested);
            }

            if (_startNewMvpButton != null)
            {
                _startNewMvpButton.onClick.RemoveListener(OnStartNewMvpRequested);
            }
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused)
            {
                RetireStoryRoute("pause");
                _submitArmed = false;
            }
            else if (_accountKingdomPanel != null && _accountProgress != null)
                BindStoryRoute(_kingdomAccountSession, _accountProgress.Kingdom, _accountKingdomPanel, _accountKingdomShell);
        }

        private void OnApplicationFocus(bool focused)
        {
            if (!focused)
            {
                _submitArmed = false;
            }
        }

        private void RefreshReadinessEvidence()
        {
            LaunchReadinessSnapshot snapshot = _readiness.Snapshot;
            if (snapshot.State == LaunchReadinessState.Failed ||
                snapshot.State == LaunchReadinessState.Transitioning)
            {
                return;
            }

            int generation = snapshot.AttemptGeneration;
            if (_bootReceipt == null)
            {
                BootLoadReadinessProbeStatus bootStatus =
                    BootLoadReadinessProbe.TryCapture(generation, out _bootReceipt);
                if (bootStatus == BootLoadReadinessProbeStatus.Ready)
                {
                    _readiness.TryPublishBootLoad(_bootReceipt.Evidence);
                }
                else if (bootStatus == BootLoadReadinessProbeStatus.Unavailable)
                {
                    _readiness.TryFail(
                        generation,
                        LaunchReadinessFailure.BootLoadUnavailable,
                        retryAllowed: false);
                    return;
                }
            }
            else if (!BootLoadReadinessProbe.IsCurrent(_bootReceipt))
            {
                _readiness.TryFail(
                    generation,
                    LaunchReadinessFailure.EvidenceStale,
                    retryAllowed: false);
                return;
            }

            if (_catalogReceipt == null)
            {
                if (RealmCatalogReadinessProbe.TryCapture(generation, out _catalogReceipt))
                {
                    _readiness.TryPublishCatalog(_catalogReceipt.Evidence);
                }
                else if (RealmCatalogRuntime.Status == RealmCatalogRuntimeStatus.Unavailable)
                {
                    _readiness.TryFail(
                        generation,
                        LaunchReadinessFailure.RequiredCatalogUnavailable,
                        retryAllowed: true);
                    return;
                }
            }
            else if (!RealmCatalogReadinessProbe.IsCurrent(_catalogReceipt))
            {
                _readiness.TryFail(
                    generation,
                    LaunchReadinessFailure.EvidenceStale,
                    retryAllowed: true);
                return;
            }

            if (string.IsNullOrWhiteSpace(_realmSelectionScene) ||
                string.Equals(
                    _realmSelectionScene,
                    _kingdomScene,
                    StringComparison.Ordinal))
            {
                _readiness.TryFail(
                    generation,
                    LaunchReadinessFailure.DestinationUnavailable,
                    retryAllowed: false);
            }
            else
            {
                string destination = ResolveFirstUserDestination();
                if (Application.CanStreamedLevelBeLoaded(destination))
                {
                    _readiness.TryPublishDestination(
                        new LaunchDestinationEvidence(generation, destination));
                }
                else if (_catalogReceipt != null)
                {
                    _readiness.TryFail(
                        generation,
                        LaunchReadinessFailure.DestinationUnavailable,
                        retryAllowed: true);
                }
            }
        }

        private void RefreshPresentation(bool force)
        {
            LaunchReadinessSnapshot snapshot = _readiness.Snapshot;
            if (!force &&
                snapshot.State == _lastRenderedState &&
                snapshot.Failure == _lastRenderedFailure &&
                snapshot.AttemptGeneration == _lastRenderedGeneration)
            {
                return;
            }

            _lastRenderedState = snapshot.State;
            _lastRenderedFailure = snapshot.Failure;
            _lastRenderedGeneration = snapshot.AttemptGeneration;

            bool ready = snapshot.CanContinue;
            bool failed = snapshot.State == LaunchReadinessState.Failed;
            bool approvalCanReset =
                MvpApprovalSlotRuntime.IsApprovalFlavor &&
                !_approvalResetInProgress &&
                MvpApprovalSlotRuntime.CanStartNewJourney(out _);
            bool confirmationVisible = _startNewMvpConfirmation && approvalCanReset;
            if (_continueButton != null)
            {
                _continueButton.gameObject.SetActive(ready || confirmationVisible);
                _continueButton.interactable = ready || confirmationVisible;
                SetButtonLabel(
                    _continueButton,
                    confirmationVisible
                        ? "Keep Current Journey"
                        : MvpApprovalSlotRuntime.IsApprovalFlavor
                            ? "Continue MVP Journey"
                            : "Continue");
            }

            if (_startNewMvpButton != null)
            {
                bool showStartNew = approvalCanReset && (ready || failed || confirmationVisible);
                _startNewMvpButton.gameObject.SetActive(showStartNew);
                _startNewMvpButton.interactable = showStartNew;
                SetButtonLabel(
                    _startNewMvpButton,
                    confirmationVisible ? "Confirm Start New" : "Start New MVP Journey");
            }

            if (_retryButton != null)
            {
                _retryButton.gameObject.SetActive(failed && snapshot.RetryAllowed);
                _retryButton.interactable = failed && snapshot.RetryAllowed;
            }

            if (_statusText != null)
            {
                _statusText.text = StatusFor(snapshot);
            }

            if (_detailText != null)
            {
                _detailText.text = !string.IsNullOrWhiteSpace(_approvalResetError)
                    ? _approvalResetError
                    : MvpApprovalSlotRuntime.IsApprovalFlavor && (ready || approvalCanReset)
                        ? confirmationVisible
                            ? "Confirming starts a fresh isolated approval journey. Keep Current Journey cancels without changing any save."
                            : "This approval journey is isolated. Your normal save is not read, replaced, or deleted."
                        : DetailFor(snapshot);
            }

            if (confirmationVisible)
            {
                _readyFrame = Time.frameCount;
                _submitArmed = false;
                FocusCurrentAction(snapshot.AttemptGeneration, _startNewMvpButton);
            }
            else if (ready)
            {
                _launchLifecycle.MarkAwaitingContinue(mandatoryReadinessReady: true);
                _readyFrame = Time.frameCount;
                _submitArmed = false;
                FocusCurrentAction(snapshot.AttemptGeneration, _continueButton);
            }
            else if (failed && snapshot.RetryAllowed)
            {
                _readyFrame = Time.frameCount;
                _submitArmed = false;
                FocusCurrentAction(snapshot.AttemptGeneration, _retryButton);
            }
            else if (approvalCanReset && failed)
            {
                _readyFrame = Time.frameCount;
                _submitArmed = false;
                FocusCurrentAction(snapshot.AttemptGeneration, _startNewMvpButton);
            }
            else
            {
                _readyFrame = -1;
                _submitArmed = false;
                ClearFocusedAction();
            }
        }

        private void FocusCurrentAction(int generation, Button button)
        {
            if (button == null)
            {
                return;
            }

            bool alreadyFocused =
                _focusedGeneration == generation &&
                _focusedAction == button;
            _focusedGeneration = generation;
            _focusedAction = button;

            if (EventSystem.current == null ||
                (alreadyFocused &&
                 EventSystem.current.currentSelectedGameObject == button.gameObject))
            {
                return;
            }

            EventSystem.current.SetSelectedGameObject(button.gameObject);
        }

        private void ClearFocusedAction()
        {
            if (_focusedAction != null &&
                EventSystem.current != null &&
                EventSystem.current.currentSelectedGameObject == _focusedAction.gameObject)
            {
                EventSystem.current.SetSelectedGameObject(null);
            }

            _focusedAction = null;
        }

        private void PollExplicitSubmit()
        {
            LaunchReadinessSnapshot snapshot = _readiness.Snapshot;
            if (_startNewMvpConfirmation && GameInput.CancelPressed())
            {
                CancelStartNewConfirmation();
                return;
            }

            bool canContinue = snapshot.CanContinue;
            bool canRetry =
                snapshot.State == LaunchReadinessState.Failed &&
                snapshot.RetryAllowed;
            bool canStartNew =
                _startNewMvpButton != null &&
                _startNewMvpButton.gameObject.activeInHierarchy &&
                _startNewMvpButton.interactable;
            if ((!canContinue && !canRetry && !canStartNew) || Time.frameCount <= _readyFrame)
            {
                return;
            }

            if (!_submitArmed)
            {
                if (!AnySubmitControlHeld())
                {
                    _submitArmed = true;
                }

                return;
            }

            if (GameInput.SubmitPressed())
            {
                if (canStartNew && _focusedAction == _startNewMvpButton)
                {
                    OnStartNewMvpRequested();
                }
                else if (canContinue || _startNewMvpConfirmation)
                {
                    OnContinueRequested();
                }
                else
                {
                    OnRetryRequested();
                }
            }
        }

        private static bool AnySubmitControlHeld()
        {
            return GameInput.SubmitHeld();
        }

        private void OnContinueRequested()
        {
            if (_kingdomPhoneLogin) return;
            if (_startNewMvpConfirmation)
            {
                CancelStartNewConfirmation();
                return;
            }

            if (_readiness == null || Time.frameCount <= _readyFrame)
            {
                return;
            }

            int generation = _readiness.AttemptGeneration;
            if (!_readiness.TryBeginTransition(generation))
            {
                return;
            }

            if (_continueButton != null)
            {
                _continueButton.interactable = false;
            }

            _submitArmed = false;
            _launchLifecycle.TryContinue(mandatoryReadinessReady: true);
            RefreshPresentation(force: true);
#if UNITY_INCLUDE_TESTS
            if (_suppressDestinationLoadForTests)
            {
                return;
            }
#endif
            StartCoroutine(LoadFirstUserDestination(generation));
        }

        private void OnStartNewMvpRequested()
        {
            if (!MvpApprovalSlotRuntime.IsApprovalFlavor ||
                _approvalResetInProgress ||
                _readiness == null ||
                Time.frameCount <= _readyFrame ||
                !MvpApprovalSlotRuntime.CanStartNewJourney(out _))
            {
                return;
            }

            if (!_startNewMvpConfirmation)
            {
                _startNewMvpConfirmation = true;
                _approvalResetError = string.Empty;
                RefreshPresentation(force: true);
                return;
            }

            StartNewMvpJourney();
        }

        private void CancelStartNewConfirmation()
        {
            _startNewMvpConfirmation = false;
            _approvalResetError = string.Empty;
            RefreshPresentation(force: true);
        }

        private void StartNewMvpJourney()
        {
            if (!_startNewMvpConfirmation || _approvalResetInProgress)
            {
                return;
            }

            _approvalResetInProgress = true;
            _submitArmed = false;
            RefreshPresentation(force: true);
            MvpApprovalStartNewDisposition disposition =
                MvpApprovalSlotRuntime.TryStartNewJourney(out _);
            if (disposition == MvpApprovalStartNewDisposition.Succeeded)
            {
                _approvalResetInProgress = false;
                _startNewMvpConfirmation = false;
                _readyFrame = -1;
                RefreshPresentation(force: true);
                _readyFrame = -1;
                OnContinueRequested();
                return;
            }

            if (disposition == MvpApprovalStartNewDisposition.ReloadBootRequired)
            {
                if (MvpApprovalSlotRuntime.TryReloadBootAfterReset(out _))
                {
                    return;
                }

                _approvalResetInProgress = false;
                _startNewMvpConfirmation = false;
                _approvalResetError =
                    "The isolated approval journey was cleared. Restart the game to begin fresh; your normal save was not changed.";
                RefreshPresentation(force: true);
                return;
            }

            _approvalResetInProgress = false;
            _startNewMvpConfirmation = false;
            _approvalResetError =
                "The isolated approval journey could not be reset. Your normal save was not changed.";
            RefreshPresentation(force: true);
        }


        private IEnumerator LoadFirstUserDestination(int attemptGeneration)
        {
            AsyncOperation operation = null;
            try
            {
                string destination = ResolveFirstUserDestination();
                operation = SceneManager.LoadSceneAsync(destination, LoadSceneMode.Single);
            }
            catch (Exception exception)
            {
                Debug.LogError("[AL-LAUNCH-DESTINATION-FAILED] " + exception.GetType().Name);
            }

            if (operation == null)
            {
                _readiness.TryFailTransition(
                    attemptGeneration,
                    LaunchReadinessFailure.DestinationUnavailable,
                    retryAllowed: true);
                RefreshPresentation(force: true);
                yield break;
            }

            while (!operation.isDone)
            {
                yield return null;
            }
        }

        private string ResolveFirstUserDestination()
        {
            ISaveGameService saveGameService = null;
            ServiceLocator.TryGet(out saveGameService);
            if (saveGameService?.CurrentSave != null)
            {
                AL.Data.Runtime.MvpLoopSaveCodec.RestoreSessionIdentity(saveGameService.CurrentSave);
            }
            bool gameplayLoadable =
                Application.CanStreamedLevelBeLoaded(
                    FirstUserBootDestinationResolver.GameplaySceneName);
            return FirstUserBootDestinationResolver.ResolveSceneName(
                saveGameService,
                _realmSelectionScene,
                gameplayLoadable);
        }

        private IEnumerator InitializeKingdomPhoneLogin()
        {
            AL.Services.AccountEndpointCatalog configuration = null;
            yield return AL.Services.AccountEndpointCatalog.Load(row => configuration = row);
#if UNITY_EDITOR
            _phase1FixtureConfiguration = configuration;
#endif
            if (!isActiveAndEnabled) yield break;
#if UNITY_EDITOR
            bool ordinaryEntry = false;
            Phase1DeveloperFixturePath.InitializeLogin(ReadPhase1FixtureContext("crownlands", false),
                () => ordinaryEntry = true,
                path =>
                {
                    _phase1FixtureEntry = true;
                    _splashContent.SetActive(false);
                    _emailLoginPanel = EmailCodeLoginPanel.Create(_safeAreaRoot, null,
                        OpenLocalDevelopmentPreview, null, offlineOnly: true);
                },
                () =>
                {
                    _phase1FixtureEntry = true;
                    if (_statusText != null) _statusText.text = "Local development preview unavailable.";
                    if (_detailText != null) _detailText.text = "Start a fresh Phase 1 development entry with offline configuration.";
                });
            if (!ordinaryEntry) { _phoneLoginInitialization = null; yield break; }
#endif
            if (configuration != null && configuration.enabled)
            {
                var host = new GameObject("AccountServices");
                host.transform.SetParent(transform, false);
                try
                {
                    _accountHost = host.AddComponent<AL.Services.AccountServiceHost>();
                    _accountHost.Initialize(configuration.endpoint);
                }
                catch (Exception) { Destroy(host); } // Panel shows service unavailable; no endpoint/secrets in logs.
            }
            _splashContent.SetActive(false);
            #if UNITY_EDITOR || DEVELOPMENT_BUILD
            _emailLoginPanel = EmailCodeLoginPanel.Create(_safeAreaRoot, OnKingdomLoginAuthenticated,
                configuration == null || !configuration.enabled ? OpenLocalDevelopmentPreview : (Action)null,
                configuration == null || !configuration.enabled ? OpenStoneholdDevelopmentPreview : (Action)null);
#else
            _emailLoginPanel = EmailCodeLoginPanel.Create(_safeAreaRoot, OnKingdomLoginAuthenticated);
#endif
#if UNITY_EDITOR
            if (Application.platform == RuntimePlatform.WindowsEditor && Bootloader.IsEditorPhase1KingdomSelected)
                _emailLoginPanel.DescribePhase1DesktopDevelopment(configuration != null && configuration.enabled);
#endif
            _phoneLoginInitialization = null;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            _cityTestStoneholdProfile = DevelopmentKingdomPreviewLauncher.ShouldOpenCityTestStonehold(
                Application.identifier, Debug.isDebugBuild, Application.platform, configuration != null && configuration.enabled);
            if (_cityTestStoneholdProfile)
            {
                _emailLoginPanel.DescribeCityTestStoneholdProfile();
                OpenStoneholdDevelopmentPreview();
            }
#endif
        }

#if UNITY_EDITOR
        private Phase1DeveloperFixturePath.MountContext ReadPhase1FixtureContext(string realm, bool isolatedStonehold)
        {
            return new Phase1DeveloperFixturePath.MountContext(
                Application.platform == RuntimePlatform.WindowsEditor,
                Bootloader.IsEditorPhase1KingdomSelected, MvpApprovalSlotRuntime.IsApprovalFlavor,
                UnityEditor.SessionState.GetString(Phase1DeveloperFixturePath.SessionPathKey, ""),
                UnityEditor.SessionState.GetString(Phase1DeveloperFixturePath.SessionOwnerKey, ""),
                _phase1FixtureConfiguration == null ? (bool?)null : _phase1FixtureConfiguration.enabled,
                _phase1FixtureConfiguration?.endpoint, realm, isolatedStonehold);
        }
#endif
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        private bool _cityTestStoneholdProfile;
        private void OpenLocalDevelopmentPreview()=>OpenDevelopmentPreview("crownlands");
        private void OpenStoneholdDevelopmentPreview()=>OpenDevelopmentPreview("stonehold",_cityTestStoneholdProfile);
        private void OpenDevelopmentPreview(string realm,bool isolatedStonehold=false)
        {
            if (_localDevelopmentPreview != null || _emailLoginPanel == null) return;
            try
            {
                string fixtureDirectory = null;
#if UNITY_EDITOR
                var context = ReadPhase1FixtureContext(realm, isolatedStonehold);
                if (_phase1FixtureEntry || context.Attempted || Application.platform == RuntimePlatform.WindowsEditor)
                    fixtureDirectory = Phase1DeveloperFixturePath.ResolveForMount(context);
#endif
                Action returned = () =>
                {
                    _localDevelopmentPreview = null;
                    if (_emailLoginPanel != null) _emailLoginPanel.gameObject.SetActive(true);
                };
                _localDevelopmentPreview = isolatedStonehold
                    ? DevelopmentKingdomPreviewLauncher.OpenCityTestStoneholdVisualProfile(_safeAreaRoot, returned)
                    : DevelopmentKingdomPreviewLauncher.Open(_safeAreaRoot, returned, previewDirectory: fixtureDirectory, mobileShell: true, accountShell: true, previewRealm: realm);
                _emailLoginPanel.gameObject.SetActive(false);
            }
            catch (Exception)
            {
                if (_emailLoginPanel != null) _emailLoginPanel.ShowLocalPreviewUnavailable();
                Debug.LogWarning("Local development preview unavailable.");
            }
        }
#endif

        private void OnKingdomLoginAuthenticated(AL.Core.Accounts.AccountLoginSession session)
        {
            if (_kingdomOnboardingPanel != null) return;
            _emailLoginPanel.gameObject.SetActive(false);
            _kingdomAccountSession = session;
            _kingdomOnboardingPanel = AccountKingdomOnboardingPanel.Create(_safeAreaRoot, session,
                ReturnToKingdomLogin, OnAccountKingdomReady);
        }

        private async void ReturnToKingdomLogin()
        {
            RetireStoryRoute("logout");
            if (_accountKingdomPanel != null) { _accountKingdomPanel.RetireMutationOwner("logout-replacement-or-destroy");Destroy(_accountKingdomPanel.gameObject); }
            _accountKingdomPanel = null;
            AL.Core.Accounts.IEmailCodeLoginProvider loginProvider = null;
            System.Threading.Tasks.Task<AL.Core.Accounts.AccountSignOutResult> signout = null;
            try
            {
                if (ServiceLocator.TryGet(out loginProvider) && loginProvider is AL.Core.Accounts.IAccountSignOutProvider logout)
                    signout = logout.SignOutAsync(CancellationToken.None);
            }
            catch (Exception)
            {
                // A future capability may throw before returning a Task. Preserve local recovery.
                // The current HTTP adapter's local invalidation does not delete saves or journals.
                if (loginProvider is AL.Core.Accounts.HttpAccountProvider http) http.ClearSession();
            }
            CancelKingdomProgress(); _kingdomAccountSession = null;
            if (_kingdomOnboardingPanel != null) Destroy(_kingdomOnboardingPanel.gameObject);
            _kingdomOnboardingPanel = null;
            _accountPresentationData?.Dispose(); _accountPresentationData = null;
            if (_emailLoginPanel != null)
            {
                _emailLoginPanel.ResetForSignIn();
                _emailLoginPanel.gameObject.SetActive(true);
            }
            // All local credentials, gameplay references and login presentation were cleared
            // before waiting. Completion never mutates a newly signed-in session.
            if (signout != null)
            {
                try { await signout; }
                catch (Exception) { /* Local signout stands; revocation was not confirmed. */ }
            }
        }

        private async void OnAccountKingdomReady(AL.Core.Accounts.AccountLoginSession session,
            AL.Core.Accounts.AccountKingdomState kingdom)
        {
            var panel = _kingdomOnboardingPanel;
            if (panel == null || kingdom == null || kingdom.Kingdom == null || !ReferenceEquals(session, _kingdomAccountSession)) return;
            CancelKingdomProgress();
            var ownedPresentation = panel.TakePresentationDataOwnership();
            if (ownedPresentation != null) _accountPresentationData = ownedPresentation;
            AL.Core.Accounts.IAccountKingdomProgressProvider provider;
            if (!ServiceLocator.TryGet(out provider) || provider == null) { panel.ShowEntryUnavailable(); return; }
            var request = new CancellationTokenSource(); _kingdomProgressRequest = request;
            panel.ShowProgressLoading(() => OnAccountKingdomReady(session, kingdom));
            try
            {
                var progress = await provider.ReadProgressAsync(session, kingdom.Kingdom, request.Token);
                if (this == null || !isActiveAndEnabled || !ReferenceEquals(_kingdomProgressRequest, request) || panel != _kingdomOnboardingPanel || panel == null) return;
                var presentation = await AccountBuildingPresentationCatalog.LoadAsync(request.Token);
                if (this == null || !isActiveAndEnabled || !ReferenceEquals(_kingdomProgressRequest, request) || panel != _kingdomOnboardingPanel || panel == null) return;
                _accountProgress = progress;
                if (_accountKingdomPanel != null) { _accountKingdomPanel.RetireMutationOwner("logout-replacement-or-destroy");Destroy(_accountKingdomPanel.gameObject); }
                AccountKingdomManagementPanel created = null;
                AccountKingdomMobileShell createdShell = null;
                Action returnToLogin = () => {
                    if (ReferenceEquals(_accountKingdomPanel, created) && ReferenceEquals(_kingdomAccountSession, session)) ReturnToKingdomLogin();
                };
#if UNITY_INCLUDE_TESTS
                if (_accountPanelFactoryForTests != null)
                    created = _accountPanelFactoryForTests(_safeAreaRoot, session, progress, returnToLogin, panel.PresentationData, presentation);
                else
#endif
                    created = AccountKingdomManagementPanel.CreateGameplay(_safeAreaRoot, session, progress, returnToLogin,
                        data: panel.PresentationData, buildingPresentation: presentation,
                        initializeShellBeforeFirstRender: shell => createdShell = shell);
                _accountKingdomPanel = created;
                _accountKingdomShell = createdShell;
                BindStoryRoute(session, progress.Kingdom, created, createdShell);
                panel.gameObject.SetActive(false);
            }
            catch (Exception error)
            {
                if (this != null && isActiveAndEnabled && ReferenceEquals(_kingdomProgressRequest, request) && panel != null && panel == _kingdomOnboardingPanel)
                    panel.ShowProgressFailure(error is AL.Core.Accounts.AccountKingdomProgressMigrationException,
                        error is AL.Core.Accounts.AccountSessionExpiredException);
            }
            finally
            {
                if (ReferenceEquals(_kingdomProgressRequest, request)) _kingdomProgressRequest = null;
                request.Dispose();
            }
        }

        // Called only with an explicitly admitted existing F directory. No default or mkdir.
        public void ConfigureStoryStorage(string absoluteExistingFDirectory)
        {
            RetireStoryRoute("story-storage-replaced");_storyIntentStore=null;
            _storyIntentStore=new AL.Core.Accounts.StoryPendingIntentStore(absoluteExistingFDirectory);
            if(_accountKingdomPanel!=null&&_accountKingdomShell!=null&&_accountProgress!=null)
                BindStoryRoute(_kingdomAccountSession,_accountProgress.Kingdom,_accountKingdomPanel,_accountKingdomShell);
        }
        private void BindStoryRoute(AL.Core.Accounts.AccountLoginSession session,
            AL.Core.Accounts.AccountKingdom kingdom, AccountKingdomManagementPanel panel,
            AccountKingdomMobileShell shell)
        {
            RetireStoryRoute("replacement");
            var component=_storyRouteHost;var route=component as IAccountStoryRouteHost;
            var compositionComponent=_storyComposition;var composition=compositionComponent as IAccountStoryComposition;
            var accountHost=_accountHost;var provider=accountHost!=null?accountHost.StoryProvider:null;var store=_storyIntentStore;
            var safeArea=_safeAreaRoot;var input=EventSystem.current;
            if(component==null||!component.isActiveAndEnabled||route==null||shell==null||
                compositionComponent==null||!compositionComponent.isActiveAndEnabled||composition==null||provider==null||store==null||
                panel==null||session?.Account==null||kingdom==null||
                session.Account.AccountId!=kingdom.AccountId||session.Account.ProfileId!=kingdom.ProfileId||safeArea==null||
                !safeArea.gameObject.activeInHierarchy||input==null||!input.isActiveAndEnabled)return;
            var generation=new object();_storyRouteGeneration=generation;
            _boundStoryRoute=route;_storyRouteShell=shell;
            Func<bool> current=()=>this!=null&&isActiveAndEnabled&&component!=null&&component.isActiveAndEnabled&&
                ReferenceEquals(component,_storyRouteHost)&&ReferenceEquals(generation,_storyRouteGeneration)&&
                ReferenceEquals(route,_boundStoryRoute)&&ReferenceEquals(session,_kingdomAccountSession)&&
                compositionComponent!=null&&compositionComponent.isActiveAndEnabled&&ReferenceEquals(compositionComponent,_storyComposition)&&
                accountHost!=null&&ReferenceEquals(accountHost,_accountHost)&&ReferenceEquals(provider,accountHost.StoryProvider)&&
                ReferenceEquals(store,_storyIntentStore)&&session.ExpiresAt>DateTimeOffset.UtcNow.ToUnixTimeSeconds()&&
                panel!=null&&ReferenceEquals(panel,_accountKingdomPanel)&&!panel.MutationOwnerRetired&&panel.GameplayStateVisible&&
                ReferenceEquals(session,panel.HudSession)&&ReferenceEquals(provider,panel.StoryProvider)&&
                AL.UI.AccountHeroRosterReadState.SameOwner(kingdom,panel.StoryKingdom)&&
                shell!=null&&shell.isActiveAndEnabled&&ReferenceEquals(shell,_accountKingdomShell)&&
                AL.UI.AccountHeroRosterReadState.SameOwner(kingdom,_accountProgress?.Kingdom)&&
                safeArea!=null&&ReferenceEquals(safeArea,_safeAreaRoot)&&safeArea.gameObject.activeInHierarchy&&
                input!=null&&input.isActiveAndEnabled&&ReferenceEquals(input,EventSystem.current);
            _storyRouteCurrent=current;
            async Task RefreshCity(CancellationToken cancellation)
            {
                cancellation.ThrowIfCancellationRequested();if(!current())throw new OperationCanceledException();
                if(!await panel.RefreshAfterStoryAsync(cancellation,current))throw new InvalidOperationException("AL-STORY-CITY-REFRESH-UNAVAILABLE");
                cancellation.ThrowIfCancellationRequested();if(!current())throw new OperationCanceledException();
                // Closes the underlying menu only; route/FlowOwner stays live through ReturnCity.
                shell.Navigate("City");
            }
            void BindPreparedRoute()
            {
                try
                {
                    if(!current()||!composition.TryConfigure(route,()=>current()?provider:null,
                        owner=>{if(!current()||!AL.UI.AccountHeroRosterReadState.SameOwner(kingdom,owner))throw new OperationCanceledException();return store;},
                        ()=>panel.PresentationLocale,RefreshCity)||!current()||
                        !route.TryBind(session,kingdom,safeArea,input,current)||!current())
                    {if(ReferenceEquals(generation,_storyRouteGeneration))RetireStoryRoute("bind-unavailable");return;}
                    shell.SetStoryRoute(route,session);
                }
                catch(Exception){if(ReferenceEquals(generation,_storyRouteGeneration))RetireStoryRoute("bind-failed");}
            }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            try
            {
                if(composition is IAccountStoryPreparation preparation && preparation.RequiresPreparation)
                {
                    var cancellation=new CancellationTokenSource();
                    _storyPreparation=preparation;_storyPreparationCancellation=cancellation;
                    _storyPreparationTask=PrepareStoryRouteAsync(preparation,generation,provider,session,kingdom,
                        ()=>current()?provider:null,current,BindPreparedRoute,cancellation);
                    return;
                }
            }
            catch(Exception)
            {
                if(ReferenceEquals(generation,_storyRouteGeneration))RetireStoryRoute("preparation-start-failed");
                return;
            }
#endif
            BindPreparedRoute();
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // All errors are observed here; retirement invalidates the generation before cancellation.
        private async Task PrepareStoryRouteAsync(IAccountStoryPreparation preparation,object generation,
            AL.Core.Accounts.IAccountStoryProvider provider,AL.Core.Accounts.AccountLoginSession session,
            AL.Core.Accounts.AccountKingdom kingdom,Func<AL.Core.Accounts.IAccountStoryProvider> readProvider,
            Func<bool> current,Action bind,CancellationTokenSource cancellation)
        {
            try
            {
                bool ready=await preparation.PrepareAsync(provider,session,kingdom,readProvider,current,cancellation.Token);
                if(!ReferenceEquals(generation,_storyRouteGeneration))return;
                if(!ready||cancellation.IsCancellationRequested||!current())
                {RetireStoryRoute("preparation-unavailable");return;}
                bind();
            }
            catch(Exception)
            {
                if(ReferenceEquals(generation,_storyRouteGeneration))RetireStoryRoute("preparation-failed");
            }
            finally
            {
                if(ReferenceEquals(cancellation,_storyPreparationCancellation))_storyPreparationCancellation=null;
                cancellation.Dispose();
            }
        }
#endif
        private void RetireStoryRoute(string reason)
        {
            var route = _boundStoryRoute; var shell = _storyRouteShell;
            _storyRouteGeneration = null; _boundStoryRoute = null; _storyRouteShell = null; _storyRouteCurrent = null;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            var preparation=_storyPreparation;var cancellation=_storyPreparationCancellation;
            _storyPreparation=null;_storyPreparationCancellation=null;
            try { cancellation?.Cancel(); }
            catch(Exception) { /* A cancellation callback cannot prevent route retirement. */ }
            try { preparation?.RetirePreparation(reason); }
            catch(Exception) { /* The Boot generation is already invalidated. */ }
#endif
            if (shell != null) shell.SetStoryRoute(null, null);
            try { route?.Retire(reason); }
            catch (Exception) { /* Binding already invalidated; retirement cannot re-enable entry. */ }
        }
        private void CancelKingdomProgress()
        {
            RetireStoryRoute("progress-owner-retired");
            var request = _kingdomProgressRequest; _kingdomProgressRequest = null; _accountProgress = null;
            if (request == null) return;
            try { request.Cancel(); } catch (Exception) { /* Private callback text is never surfaced. */ }
        }

        private void OnRetryRequested()
        {
            if (_readiness == null || Time.frameCount <= _readyFrame)
            {
                return;
            }

            LaunchReadinessFailure previousFailure = _readiness.Snapshot.Failure;
            if (!_readiness.TryBeginRetry())
            {
                RefreshPresentation(force: true);
                return;
            }

            _bootReceipt = null;
            _catalogReceipt = null;
            _focusedGeneration = 0;
            _focusedAction = null;
            _launchLifecycle = new LaunchCinematicLifecycle();
            _launchLifecycle.MarkPreparing();
            _launchLifecycle.FailToFallback("approved-media-unavailable");
            _readiness.TryEstablishMedia(
                _readiness.AttemptGeneration,
                LaunchMediaPresentation.StaticFallbackEstablished);

            if (previousFailure == LaunchReadinessFailure.RequiredCatalogUnavailable ||
                previousFailure == LaunchReadinessFailure.EvidenceStale)
            {
                RealmCatalogRuntime.TryRetry();
            }

            RefreshPresentation(force: true);
        }

        private void BuildRuntimeSplash()
        {
            var canvasObject = new GameObject("LaunchReadinessCanvas");
            canvasObject.transform.SetParent(transform, false);
            var canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;

            var scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            // Treat layout units as mobile-density-independent planning units so the 64-unit
            // action floor remains comfortably above the 48 dp interaction target on narrow screens.
            scaler.referenceResolution = new Vector2(390f, 844f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            canvasObject.AddComponent<GraphicRaycaster>();

            CreatePanel(
                canvasObject.transform,
                "StaticFallbackBackground",
                new Color(0.006f, 0.008f, 0.014f, 1f),
                Vector2.zero,
                Vector2.one);

            var safeAreaObject = new GameObject("SafeArea");
            safeAreaObject.transform.SetParent(canvasObject.transform, false);
            _safeAreaRoot = safeAreaObject.AddComponent<RectTransform>();

            var contentObject = new GameObject("LaunchContent");
            contentObject.transform.SetParent(_safeAreaRoot, false);
            _splashContent = contentObject;
            var contentRect = contentObject.AddComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0.08f, 0.14f);
            contentRect.anchorMax = new Vector2(0.92f, 0.86f);
            contentRect.offsetMin = Vector2.zero;
            contentRect.offsetMax = Vector2.zero;

            var layout = contentObject.AddComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(20, 20, 20, 20);
            layout.spacing = 20f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;

            Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf") ??
                Resources.GetBuiltinResource<Font>("Arial.ttf");

            Text title = CreateText(
                contentObject.transform,
                "Title",
                font,
                "ANOTHER LIFE",
                52,
                84f);
            title.color = new Color(0.92f, 0.92f, 0.88f, 1f);

            Text build = CreateText(
                contentObject.transform,
                "BuildLabel",
                font,
                _buildLabel,
                16,
                36f);
            build.color = new Color(0.66f, 0.69f, 0.72f, 0.9f);

            _statusText = CreateText(
                contentObject.transform,
                "ReadinessStatus",
                font,
                "Loading saved journey",
                30,
                72f);
            _statusText.color = new Color(0.86f, 0.90f, 0.95f, 1f);

            _detailText = CreateText(
                contentObject.transform,
                "ReadinessDetail",
                font,
                "Required game data is still being verified.",
                20,
                76f);
            _detailText.color = new Color(0.70f, 0.76f, 0.82f, 1f);

            _continueButton = CreateButton(
                contentObject.transform,
                "FinishedLoadingAction",
                font,
                MvpApprovalSlotRuntime.IsApprovalFlavor ? "Continue MVP Journey" : "Continue");
            _continueButton.onClick.AddListener(OnContinueRequested);
            _continueButton.gameObject.SetActive(false);

            if (MvpApprovalSlotRuntime.IsApprovalFlavor)
            {
                _startNewMvpButton = CreateButton(
                    contentObject.transform,
                    "StartNewMvpJourneyAction",
                    font,
                    "Start New MVP Journey");
                _startNewMvpButton.onClick.AddListener(OnStartNewMvpRequested);
                _startNewMvpButton.gameObject.SetActive(false);

                _continueButton.navigation = new Navigation
                {
                    mode = Navigation.Mode.Explicit,
                    selectOnDown = _startNewMvpButton,
                    selectOnUp = _startNewMvpButton
                };
                _startNewMvpButton.navigation = new Navigation
                {
                    mode = Navigation.Mode.Explicit,
                    selectOnDown = _continueButton,
                    selectOnUp = _continueButton
                };
            }

            _retryButton = CreateButton(
                contentObject.transform,
                "RetryReadinessAction",
                font,
                "Retry");
            _retryButton.onClick.AddListener(OnRetryRequested);
            _retryButton.gameObject.SetActive(false);

            UpdateSafeAreaIfNeeded();
        }

        private void UpdateSafeAreaIfNeeded()
        {
            if (_safeAreaRoot == null ||
                Screen.width <= 0 ||
                Screen.height <= 0)
            {
                return;
            }

            Rect safeArea = Screen.safeArea;
            if (_lastScreenWidth == Screen.width &&
                _lastScreenHeight == Screen.height &&
                _lastSafeArea == safeArea)
            {
                return;
            }

            _lastScreenWidth = Screen.width;
            _lastScreenHeight = Screen.height;
            _lastSafeArea = safeArea;
            _safeAreaRoot.anchorMin = new Vector2(
                safeArea.xMin / Screen.width,
                safeArea.yMin / Screen.height);
            _safeAreaRoot.anchorMax = new Vector2(
                safeArea.xMax / Screen.width,
                safeArea.yMax / Screen.height);
            _safeAreaRoot.offsetMin = Vector2.zero;
            _safeAreaRoot.offsetMax = Vector2.zero;
        }

        private static string StatusFor(LaunchReadinessSnapshot snapshot)
        {
            switch (snapshot.State)
            {
                case LaunchReadinessState.WaitingForBootLoad:
                    return "Loading saved journey";
                case LaunchReadinessState.WaitingForRequiredCatalogs:
                    return "Loading realm choices";
                case LaunchReadinessState.WaitingForMediaPresentation:
                    return "Preparing launch presentation";
                case LaunchReadinessState.WaitingForDestination:
                    return "Preparing character setup";
                case LaunchReadinessState.AwaitingExplicitContinue:
                    return "Finished Loading";
                case LaunchReadinessState.Transitioning:
                    return "Opening character setup";
                case LaunchReadinessState.Failed:
                    return "Launch needs attention";
                default:
                    return "Preparing launch";
            }
        }

        private static string DetailFor(LaunchReadinessSnapshot snapshot)
        {
            if (snapshot.State != LaunchReadinessState.Failed)
            {
                return snapshot.CanContinue
                    ? "Press Continue, Enter, Space, or your controller Submit button."
                    : "Required game data is still being verified.";
            }

            switch (snapshot.Failure)
            {
                case LaunchReadinessFailure.RequiredCatalogUnavailable:
                    return snapshot.RetryAllowed
                        ? "Realm choices could not be loaded. Retry this launch check."
                        : "Realm choices could not be loaded. Restart the game.";
                case LaunchReadinessFailure.DestinationUnavailable:
                    return snapshot.RetryAllowed
                        ? "Character setup is unavailable. Retry this launch check."
                        : "Character setup is unavailable. Restart the game.";
                case LaunchReadinessFailure.RetryLimitReached:
                    return "Launch could not recover after several attempts. Restart the game.";
                case LaunchReadinessFailure.EvidenceStale:
                    return snapshot.RetryAllowed
                        ? "Launch data changed while loading. Retry this launch check."
                        : "Launch data changed unexpectedly. Restart the game.";
                default:
                    return "Your saved journey could not be verified. Restart the game.";
            }
        }

        private static Image CreatePanel(
            Transform parent,
            string name,
            Color color,
            Vector2 anchorMin,
            Vector2 anchorMax)
        {
            var panelObject = new GameObject(name);
            panelObject.transform.SetParent(parent, false);
            var image = panelObject.AddComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            RectTransform rect = image.rectTransform;
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            return image;
        }

        private static Text CreateText(
            Transform parent,
            string name,
            Font font,
            string value,
            int fontSize,
            float preferredHeight)
        {
            var textObject = new GameObject(name);
            textObject.transform.SetParent(parent, false);
            var text = textObject.AddComponent<Text>();
            text.font = font;
            text.text = value;
            text.fontSize = fontSize;
            text.alignment = TextAnchor.MiddleCenter;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = Math.Max(14, fontSize / 2);
            text.resizeTextMaxSize = fontSize;
            text.raycastTarget = false;
            var layout = textObject.AddComponent<LayoutElement>();
            layout.preferredHeight = preferredHeight;
            return text;
        }

        private static Button CreateButton(
            Transform parent,
            string name,
            Font font,
            string label)
        {
            var buttonObject = new GameObject(name);
            buttonObject.transform.SetParent(parent, false);
            var image = buttonObject.AddComponent<Image>();
            image.color = new Color(0.18f, 0.38f, 0.58f, 1f);
            var button = buttonObject.AddComponent<Button>();
            button.targetGraphic = image;
            button.navigation = new Navigation { mode = Navigation.Mode.None };
            var layout = buttonObject.AddComponent<LayoutElement>();
            layout.preferredHeight = 72f;
            layout.minHeight = 64f;

            Text text = CreateText(
                buttonObject.transform,
                "Label",
                font,
                label,
                25,
                64f);
            RectTransform textRect = text.rectTransform;
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(18f, 8f);
            textRect.offsetMax = new Vector2(-18f, -8f);
            text.color = Color.white;
            return button;
        }

        private static void SetButtonLabel(Button button, string label)
        {
            if (button == null)
            {
                return;
            }

            Text text = button.GetComponentInChildren<Text>(includeInactive: true);
            if (text != null)
            {
                text.text = label ?? string.Empty;
            }
        }
    }
}

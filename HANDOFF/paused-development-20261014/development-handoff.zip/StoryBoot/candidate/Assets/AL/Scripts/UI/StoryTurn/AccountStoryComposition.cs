using System;
using System.Threading;
using System.Threading.Tasks;
using AL.Core.Accounts;
using UnityEngine;

namespace AL.UI
{
    public sealed class AccountStoryComposition : MonoBehaviour, IAccountStoryComposition
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        , IAccountStoryPreparation
#endif
    {
        [SerializeField] private AccountStoryFlowHost _flowHost;
        [SerializeField] private MonoBehaviour _approvedContent;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // Explicit opt-in only. No shipped content, authority or automatic catalog discovery.
        [SerializeField] private bool _prepareDevelopmentContent;
        [SerializeField] private TextAsset _developmentPresentation;
        [SerializeField] private string _admittedCatalogRevision;
        [SerializeField] private string _admittedContentId;
        [SerializeField] private string _admittedDefinitionRevision;
        private object _preparationGeneration;
        private DevelopmentStoryCatalogPresentation _preparedSource;
        public bool RequiresPreparation => _prepareDevelopmentContent;

        public async Task<bool> PrepareAsync(IAccountStoryProvider provider, AccountLoginSession session,
            AccountKingdom kingdom, Func<IAccountStoryProvider> readProvider,
            Func<bool> stillCurrent, CancellationToken cancellation)
        {
            RetirePreparation("development-content-replaced");
            if(!RequiresPreparation || !isActiveAndEnabled || cancellation.IsCancellationRequested)return false;
            var source=_approvedContent as DevelopmentStoryCatalogPresentation;
            var asset=_developmentPresentation;
            string catalog=_admittedCatalogRevision,content=_admittedContentId,definition=_admittedDefinitionRevision;
            if(source==null || !source.isActiveAndEnabled || asset==null ||
                string.IsNullOrWhiteSpace(catalog)||string.IsNullOrWhiteSpace(content)||
                string.IsNullOrWhiteSpace(definition)||readProvider==null||stillCurrent==null)return false;
            var generation=new object();_preparationGeneration=generation;_preparedSource=source;
            bool Live()=>this!=null&&isActiveAndEnabled&&_prepareDevelopmentContent&&
                ReferenceEquals(generation,_preparationGeneration)&&ReferenceEquals(source,_approvedContent)&&
                ReferenceEquals(source,_preparedSource)&&ReferenceEquals(asset,_developmentPresentation)&&
                catalog==_admittedCatalogRevision&&content==_admittedContentId&&definition==_admittedDefinitionRevision&&
                !cancellation.IsCancellationRequested&&stillCurrent();
            try
            {
                using(cancellation.Register(()=>{
                    if(ReferenceEquals(generation,_preparationGeneration)&&source!=null)
                        source.Revoke("development-content-cancelled");
                }))
                {
                    if(!Live())throw new OperationCanceledException();
                    bool ready=await source.BindAsync(asset.text,catalog,content,definition,provider,session,
                        kingdom,readProvider,Live);
                    if(ready&&Live()&&source.IsAvailable)return true;
                }
            }
            catch(Exception) { /* Failure stays unavailable; the owning Boot observes false. */ }
            if(ReferenceEquals(generation,_preparationGeneration))RetirePreparation("development-content-unavailable");
            return false;
        }

        public void RetirePreparation(string reason)
        {
            var source=_preparedSource;
            _preparationGeneration=null;_preparedSource=null;
            if(source!=null)source.Revoke(reason);
        }
        private void OnDisable(){RetirePreparation("composition-disabled");}
        private void OnDestroy(){RetirePreparation("composition-destroyed");}
#endif
        public bool TryConfigure(IAccountStoryRouteHost expectedRoute,
            Func<IAccountStoryProvider> readProvider, Func<AccountKingdom,IStoryPendingIntentStore> stores,
            Func<string> locale, Func<CancellationToken,Task> refreshCity)
        {
            // Never retire a different serialized host because of a miswired reference.
            if(!isActiveAndEnabled || _flowHost==null || !ReferenceEquals(expectedRoute,_flowHost))return false;
            _flowHost.Retire("composition-replaced");
            var component=_approvedContent;var source=component as IAccountStoryApprovedContentSource;
            bool ContentLive()=>this!=null&&isActiveAndEnabled&&component!=null&&component.isActiveAndEnabled&&
                ReferenceEquals(component,_approvedContent)&&source!=null&&source.IsAvailable
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                &&(!_prepareDevelopmentContent||(ReferenceEquals(component,_preparedSource)&&_preparationGeneration!=null))
#endif
                ;
            try
            {
                if(!ContentLive()||readProvider==null||stores==null||locale==null||refreshCity==null)return false;
                // Content loss also invalidates the provider identity observed by the owner.
                _flowHost.Configure(()=>ContentLive()?readProvider():null,stores,
                    (kind,id,language)=>ContentLive()?source.Resolve(kind,id,language):null,locale,refreshCity,
                    (id,language)=>ContentLive()?source.RewardLabel(id,language):null);
                return true;
            }
            catch(Exception){_flowHost.Retire("composition-unavailable");return false;}
        }
    }
}

using System;
using System.Threading;
using System.Threading.Tasks;
using AL.Core.Accounts;

namespace AL.UI
{
    // Optional bootstrap boundary; AL.Runtime never depends on AL.StoryPresentation.
    public interface IAccountStoryPreparation
    {
        bool RequiresPreparation { get; }
        Task<bool> PrepareAsync(IAccountStoryProvider provider, AccountLoginSession session,
            AccountKingdom kingdom, Func<IAccountStoryProvider> readProvider,
            Func<bool> stillCurrent, CancellationToken cancellation);
        void RetirePreparation(string reason);
    }
}

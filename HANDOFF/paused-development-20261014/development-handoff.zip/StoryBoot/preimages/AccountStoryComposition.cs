using System;
using System.Threading;
using System.Threading.Tasks;
using AL.Core.Accounts;
using UnityEngine;

namespace AL.UI
{
    public sealed class AccountStoryComposition : MonoBehaviour, IAccountStoryComposition
    {
        [SerializeField] private AccountStoryFlowHost _flowHost;
        [SerializeField] private MonoBehaviour _approvedContent;
        public bool TryConfigure(IAccountStoryRouteHost expectedRoute,
            Func<IAccountStoryProvider> readProvider, Func<AccountKingdom,IStoryPendingIntentStore> stores,
            Func<string> locale, Func<CancellationToken,Task> refreshCity)
        {
            // Never retire a different serialized host because of a miswired reference.
            if(!isActiveAndEnabled || _flowHost==null || !ReferenceEquals(expectedRoute,_flowHost))return false;
            _flowHost.Retire("composition-replaced");
            var component=_approvedContent;var source=component as IAccountStoryApprovedContentSource;
            bool ContentLive()=>this!=null&&isActiveAndEnabled&&component!=null&&component.isActiveAndEnabled&&
                ReferenceEquals(component,_approvedContent)&&source!=null&&source.IsAvailable;
            try
            {
                if(!ContentLive()||readProvider==null||stores==null||locale==null||refreshCity==null)return false;
                // Content loss also invalidates the provider identity observed by the owner.
                _flowHost.Configure(()=>ContentLive()?readProvider():null,stores,
                    (kind,id,language)=>ContentLive()?source.Resolve(kind,id,language):null,locale,refreshCity,
                    (id,language)=>ContentLive()?source.RewardLabel(id,language):null);
                return true;
            }
            catch(Exception){_flowHost.Retire("composition-unavailable");return false;}
        }
    }
}
# Owned Story Boot preparation hook — output-only r001

Six candidate files are ready for independent source review. No canonical source, scene, catalog, assembly definition, Git state or sealed presentation r002 file was edited. This packet is not promoted or runtime-qualified.

## Behavior

Boot uses the optional IAccountStoryPreparation interface from AL.Runtime. Only Editor/development AccountStoryComposition implements it. Its opt-in flag defaults false; JSON asset and admitted catalog/content/definition fields are unset. When opted in, composition prepares the exact _approvedContent instance it later consumes, using the existing AccountServiceHost provider, session, kingdom and Boot ownership callback.

Boot stores an observed Task with handled failure, waits for preparation and checks its captured generation/current owner before the existing TryConfigure -> TryBind -> SetStoryRoute sequence. Retirement invalidates Boot first, cancels a pending adapter read and revokes composition preparation. Old completions do not retire or revoke a replacement generation. Composition also captures source, asset and revision identities and retires its source on disable/destroy.

No runtime reflection, new provider, account authority, TestOnly conversion, numeric tuning or additional async void was introduced. Existing unrelated Boot async void methods remain unchanged. The adapter is referenced only inside AL.StoryPresentation; AL.Runtime gains no reverse reference. With development blocks removed, composition tokens match the canonical preimage.

## Exact proposed promotion footprint

Modified:
- Assets/AL/Scripts/UI/BootController.cs
- Assets/AL/Scripts/UI/StoryTurn/AccountStoryComposition.cs

New:
- Assets/AL/Scripts/UI/IAccountStoryPreparation.cs and .meta
- Assets/AL/Tests/PlayMode/StoryTurn/AccountStoryPreparationTests.cs and .meta

Existing modified-file metas stay unchanged. New tests use AL.StoryPresentation.PlayMode.Tests with its existing AL.StoryPresentation, AL.Runtime, AL.Accounts and UnityEngine.UI references plus StoryCombat.Core.dll and StoryJournal.Core.dll. No asmdef changes. Synthetic test strings and in-memory HTTP transport are confined to the existing test assembly; they are not shipping admission data.

## Dependencies and sequencing

The sealed six-file presentation r002 packet (PACKET SHA256 3DEAA36D819A8463C755300F8DE9E1F5A9E94DBE826D124B074A436853BD35C7) is required in a qualification overlay. Its adapter/DTO/parser/tests/metas remain immutable. The new candidates alone are not a complete compile overlay until that dependency is present. Use Root's coherent source backup and native operator protocol before compiling either set.

The normal backend factory/read projection and actual admitted content mapping remain independent dependencies for playing the owned route. No real presentation JSON/meta or Boot scene wiring is included. A ready-state stage-only test map exercises lifecycle only and does not establish complete hero, skill, enemy or reward coverage. Real mapping and runtime qualification must precede scene activation.

## Validation

VERIFY_SOURCE.ps1 passed: exact six-file candidate footprint, 23 source/dependency hash pins, unchanged assembly dependency direction, unchanged production composition tokens, no additional async void. This is source inspection, not a compiler/parser or gameplay test.

26 new test cases across 10 methods are authored, zero executed:
- Assembly direction and interface location.
- Default opt-out/unset admission and existing synchronous path.
- Pending read with publication only after the same source is ready.
- Eleven lifetime changes: retirement, logout, disable, expiry, provider replacement, source replacement, configuration change, composition disable, EventSystem loss, owner replacement and opt-out.
- Reverse completion with late 200/401 cannot revoke the newer binding.
- Source replacement prepares only the composition's new source.
- Missing asset/admission values/wrong source/missing art fail closed.
- Retirement after successful preparation revokes content.
- Provider exception is observed without publication.

Run these alongside the 30 authored presentation r002 tests, existing AccountStoryCompositionTests and route handoff coverage after native admission. Record actual compiler/test/runtime results separately. No native lease, compiler, Unity, backend or gameplay run occurred here.

## Review notes and limits

Cancellation is owned by Boot and invoked on its existing Unity lifecycle path. Composition forwards it to the sealed adapter's revocation; no worker-thread/native launch is introduced. The captured token remains a validity guard after preparation completes, while explicit composition retirement revokes the already-prepared source.

The production Boot bind body was moved into a local function so both ordinary and prepared routes use the same sequence. No production settings or scene references were added. Interface methods define only bootstrap preparation/retirement, never entry, action, recovery, settlement or provider replacement.

Root must review and release the canonical write pause before any promotion. No user permission wait is needed for the scoped output-only source work already completed.

param([Parameter(Mandatory)][ValidateSet('manual11','story40','tower7')][string]$Selection)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
# Source-only projection. No trial reads, writes, process census or launches.
function ReadPinnedJson($Pin) {
 if($Pin.sha256 -notmatch '^[A-Fa-f0-9]{64}$'){throw 'Missing source evidence hash'}
 $path=[IO.Path]::GetFullPath([string]$Pin.path)
 if(-not $path.StartsWith('F:\AnotherLife\outputs\',[StringComparison]::OrdinalIgnoreCase)){throw 'Evidence outside F output boundary'}
 $cursor=$path
 while($cursor){$item=Get-Item -LiteralPath $cursor -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Evidence reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
 if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $Pin.sha256){throw 'Source evidence hash mismatch'}
 Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
}
$packet=Split-Path -Parent $PSScriptRoot
$binding=Get-Content -LiteralPath "$PSScriptRoot\BINDING.json" -Raw|ConvertFrom-Json
$entry=Get-Content -LiteralPath "$packet\selections\$Selection.json" -Raw|ConvertFrom-Json
$map=ReadPinnedJson $binding.reuseMap
$source=@($map.selections|Where-Object {$_.id -ceq $Selection})
if($source.Count -ne 1){throw 'Selection absent or duplicated'}
$source=$source[0]
if($entry.id -cne $Selection -or $entry.filter -cne $source.unchangedFilter -or $entry.assembly -cne $source.assembly -or $entry.count -ne $source.count -or $entry.methodCount -ne $source.methodCount){throw 'Selection contract changed'}
if($entry.roster.path -cne $source.rosterPath -or $entry.roster.sha256 -ne $source.rosterSHA256 -or $entry.inventory.path -cne $source.sourceInventoryPath -or $entry.inventory.sha256 -ne $source.sourceInventorySHA256){throw 'Source identity changed'}
$roster=ReadPinnedJson $entry.roster
$inventory=ReadPinnedJson $entry.inventory
if($roster.count -ne $entry.count -or @($roster.cases).Count -ne $entry.count -or $inventory.caseCount -ne $entry.count -or $inventory.methodCount -ne $entry.methodCount -or $roster.filter -cne $entry.filter -or $roster.assembly -cne $entry.assembly){throw 'Source roster contract mismatch'}
$semantic=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($case in $inventory.cases){$key=$case.classname+'.'+$case.method+'|'+(ConvertTo-Json -InputObject $case.arguments -Compress);if(-not $semantic.Add($key)){throw 'Duplicate source semantics'}}
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$names=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($case in $roster.cases){if(-not $seen.Add($case.semanticKey) -or -not $semantic.Contains($case.semanticKey) -or -not $names.Add($case.fullname) -or $case.assembly -cne $entry.assembly -or $case.fullname -cne ($case.classname+'.'+$case.name)){throw 'Semantic/name identity mismatch'}}
if(-not $seen.SetEquals($semantic) -or -not $names.SetEquals([string[]]$roster.expectedFullNames)){throw 'Exact case-set mismatch'}
$classes=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($fixture in $roster.fixtures){if(-not $classes.Add($fixture.className)){throw 'Duplicate fixture'}}
if(-not $classes.SetEquals([string[]]$entry.fixtures) -or -not $classes.SetEquals([string[]]$source.classes)){throw 'Fixture set changed'}
if($binding.trialRepo -cne 'F:\AnotherLife\.codex-worktrees\unity-search-qualification' -or $binding.unityProject -cne ($binding.trialRepo+'\unity')){throw 'Trial binding changed'}
if($binding.editor.path -cne 'F:\Unity\6000.6.5f1\Editor\Unity.exe' -or $binding.editor.sha256 -cne '35DE3C28BD96C521C396251D18ACFD2B67EB1B1C68711023232955ABB4B705AF'){throw 'Editor binding changed'}
if($binding.limits.nativeSeconds -ne 300 -or $binding.limits.cleanupSeconds -ne 90 -or $binding.limits.maxInvocationsPerSelection -ne 1 -or $binding.automaticChaining -ne $false){throw 'Trial stop contract changed'}
# Projection changes only operative fixture paths. Original roster stays pinned.
foreach($fixture in $roster.fixtures){$prefix='F:\AnotherLife\';if(-not $fixture.fixturePath.StartsWith($prefix,[StringComparison]::Ordinal)){throw 'Unexpected fixture prefix'};$fixture.fixturePath=Join-Path $binding.trialRepo $fixture.fixturePath.Substring($prefix.Length)}
$roster.nunitAssembly=$null
$roster.nunitSha256=$null
$roster.status='PROJECTED_SOURCE_IDENTITIES_NOT_RUNTIME_QUALIFIED'
$arguments=@('-batchmode','-projectPath',$binding.unityProject,'-runTests','-testPlatform','PlayMode','-assemblyNames',$entry.assembly,'-testFilter',$entry.filter,'-testResults',($entry.output+'\TEST_RESULTS.xml'),'-logFile',($entry.output+'\Editor.log'),'-job-worker-count','2')
[pscustomobject]@{
 status='HELD_SOURCE_ONLY';selection=$Selection;binding=$binding;config=$entry;roster=$roster
 expectedAssemblyFullname=($binding.unityProject.Replace('\','/')+'/Library/ScriptAssemblies/'+$entry.assembly+'.dll')
 proposedLaunch=[pscustomobject]@{image=$binding.editor.path;workingDirectory=$binding.unityProject;argumentList=$arguments;useShellExecute=$false;windowStyle='Hidden'}
 blockers=@($binding.unresolved.id)+@('Native executor deliberately unavailable pending independent final wrapper review','Per-selection fresh admission required')
 canLaunch=$false;sourceIdentityProjectionPassed=$true;runtimeValidated=$false
}

# Read-only XML checker derived from r003. Independent source review required.
# Only evaluates supplied XML under the fixed selection output. No launch/admission.
param([Parameter(Mandatory)][ValidateSet('manual11','story40','tower7')][string]$Selection)
$ErrorActionPreference='Stop'
$plan=& (Join-Path $PSScriptRoot 'prepare-selection.ps1') -Selection $Selection
$out=$plan.config.output
$script:TestConfig=$plan.config
$script:TrialAssemblyFullname=$plan.expectedAssemblyFullname
$script:ExpectedClasses=[Collections.Generic.HashSet[string]]::new([string[]]$plan.config.fixtures,[StringComparer]::Ordinal)
$script:ExpectedCases=[Collections.Generic.HashSet[string]]::new([string[]]$plan.roster.expectedFullNames,[StringComparer]::Ordinal)
$script:ExpectedOwners=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
$script:ExpectedNames=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
$script:ExpectedMethods=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
foreach($case in $plan.roster.cases){$script:ExpectedOwners.Add($case.fullname,$case.classname);$script:ExpectedNames.Add($case.fullname,$case.name);$script:ExpectedMethods.Add($case.fullname,$case.method)}
function Boundary($Path){
 $full=[IO.Path]::GetFullPath($Path)
 if($full -cne ($out+'\TEST_RESULTS.xml')){throw 'Unexpected XML path'}
 $cursor=$full
 while($cursor){$i=Get-Item -LiteralPath $cursor -ErrorAction Stop;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'XML reparse'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
}
function AssertSelectedTestXml {
 $path="$out\TEST_RESULTS.xml";Boundary $path
 if(-not(Test-Path $path)-or(Get-Item $path).Length-gt8MB){throw 'Missing/oversized test XML'}
 $settings=[Xml.XmlReaderSettings]::new();$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=8MB
 $reader=[Xml.XmlReader]::Create($path,$settings)
 try{$xml=[Xml.XmlDocument]::new();$xml.XmlResolver=$null;$xml.Load($reader)}finally{$reader.Dispose()}
 $config=$script:TestConfig;$cases=@($xml.SelectNodes('//test-case'));$run=$xml.DocumentElement
 if($run.Name-cne'test-run'-or$run.result-cne'Passed'-or$run.total-cne[string]$config.count-or$run.passed-cne[string]$config.count-or$run.failed-cne'0'-or$run.skipped-cne'0'-or$run.inconclusive-cne'0'-or$cases.Count-ne$config.count){throw 'Selected test result/count mismatch'}
 $assemblies=@($xml.SelectNodes('//test-suite[@type="Assembly"]'))
 $assemblyFullname=$script:TrialAssemblyFullname
 if($assemblies.Count-ne1-or$assemblies[0].name-cne($config.assembly+'.dll')-or$assemblies[0].fullname.Replace('\','/')-cne$assemblyFullname-or$assemblies[0].result-cne'Passed'){throw 'Selected test assembly mismatch'}
 $fixtureSuites=@($xml.SelectNodes('//test-suite[@type="TestFixture"]'))
 $seenClasses=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($suite in $fixtureSuites){if(-not$seenClasses.Add([string]$suite.fullname)-or$suite.result-cne'Passed'){throw 'Fixture suite duplicate/failure'}}
 if($fixtureSuites.Count-ne$config.fixtures.Count-or-not$script:ExpectedClasses.SetEquals($seenClasses)){throw 'Fixture suite set mismatch'}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($case in $cases){
  $containers=@($case.SelectNodes('ancestor::test-suite'));$owner=$null
  if(-not$script:ExpectedOwners.TryGetValue([string]$case.fullname,[ref]$owner)-or$case.methodname-cne$script:ExpectedMethods[[string]$case.fullname]-or$case.result-cne'Passed'-or$case.classname-cne$owner-or$case.name-cne$script:ExpectedNames[[string]$case.fullname]-or-not$seen.Add([string]$case.fullname)-or-not$script:ExpectedCases.Contains([string]$case.fullname)-or
   $containers.Count-eq0-or@($containers|Where-Object {$_.result-cne'Passed'}).Count-ne0-or@($containers|Where-Object {$_.type-ceq'TestFixture'-and$_.fullname-ceq$owner}).Count-ne1-or@($containers|Where-Object {$_.type-ceq'Assembly'-and$_.name-ceq($config.assembly+'.dll')}).Count-ne1){throw 'Selected test identity/ancestry/result mismatch'}
 }
 if(-not$script:ExpectedCases.SetEquals($seen)){throw 'Selected test exact set mismatch'}
 [pscustomobject]@{exactXmlPassed=$true;nativeAccepted=$false;runtimeFreshnessAccepted=$false;count=$cases.Count;selection=$Selection;xmlSHA256=(Get-FileHash -LiteralPath $path).Hash;scope='XML identities only; fresh runtime/source/cleanup receipts independently required'}
}
AssertSelectedTestXml

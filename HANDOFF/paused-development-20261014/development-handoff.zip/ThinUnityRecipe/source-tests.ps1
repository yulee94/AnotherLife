$ErrorActionPreference='Stop'
# Pure source-recipe tests; fixtures confined to this F-only packet.
$fixture=Join-Path $PSScriptRoot 'source-test-fixture'
if(Test-Path -LiteralPath $fixture){throw 'Existing test evidence; no rerun overwrite'}
[void][IO.Directory]::CreateDirectory("$fixture\common")
[void][IO.Directory]::CreateDirectory("$fixture\selections")
Copy-Item -LiteralPath "$PSScriptRoot\common\prepare-selection.ps1" -Destination "$fixture\common\prepare-selection.ps1"
$bindingText=[IO.File]::ReadAllText("$PSScriptRoot\common\BINDING.json")
$entryText=[IO.File]::ReadAllText("$PSScriptRoot\selections\manual11.json")
$results=[Collections.Generic.List[object]]::new()
foreach($id in @('manual11','story40','tower7')){
 $p=& "$PSScriptRoot\selections\$id.ps1"
 if($p.canLaunch -ne $false -or $p.runtimeValidated -ne $false -or -not $p.sourceIdentityProjectionPassed -or $null -ne $p.roster.nunitAssembly -or $null -ne $p.roster.nunitSha256){throw 'Held projection failed'}
 $results.Add([ordered]@{case="unchanged-$id";passed=$true;count=$p.config.count;nativeLaunched=$false})
}
$cases=@(
 @{name='broad-filter';change={param($b,$e) $e.filter='AL.Tests.PlayMode'}},
 @{name='wrong-assembly';change={param($b,$e) $e.assembly='AL.Runtime'}},
 @{name='wrong-count';change={param($b,$e) $e.count=12}},
 @{name='roster-hash';change={param($b,$e) $e.roster.sha256=('0'*64)}},
 @{name='canonical-trial';change={param($b,$e) $b.trialRepo='F:\AnotherLife'}},
 @{name='old-editor';change={param($b,$e) $b.editor.path='F:\Unity\6000.5.3f1\Editor\Unity.exe'}},
 @{name='extended-timeout';change={param($b,$e) $b.limits.nativeSeconds=301}},
 @{name='auto-chain';change={param($b,$e) $b.automaticChaining=$true}}
)
foreach($case in $cases){
 $b=$bindingText|ConvertFrom-Json;$e=$entryText|ConvertFrom-Json
 & $case.change $b $e
 $b|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$fixture\common\BINDING.json" -Encoding utf8
 $e|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$fixture\selections\manual11.json" -Encoding utf8
 $rejected=$false;$message=$null
 try{$null=& "$fixture\common\prepare-selection.ps1" -Selection manual11}catch{$rejected=$true;$message=$_.Exception.Message}
 if(-not $rejected){throw "Mutation accepted: $($case.name)"}
 $results.Add([ordered]@{case=$case.name;passed=$true;rejected=$true;message=$message;nativeLaunched=$false})
}
# Even booleans cannot turn this source-only implementation into a launcher.
$b=$bindingText|ConvertFrom-Json;$e=$entryText|ConvertFrom-Json
$b.nativeAdmitted=$true;$b.sourceSealed=$true;$b.independentReviewAccepted=$true;$e.admission.coordinatorAdmitted=$true
$b|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$fixture\common\BINDING.json" -Encoding utf8
$e|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$fixture\selections\manual11.json" -Encoding utf8
$p=& "$fixture\common\prepare-selection.ps1" -Selection manual11
if($p.canLaunch -ne $false){throw 'Boolean admitted native execution'}
$results.Add([ordered]@{case='booleans-cannot-enable-launch';passed=$true;nativeLaunched=$false})
# Restore fixture to closed source inputs, preserving test results separately.
[IO.File]::WriteAllText("$fixture\common\BINDING.json",$bindingText)
[IO.File]::WriteAllText("$fixture\selections\manual11.json",$entryText)
[pscustomobject]@{scope='Source projection and rejection tests only';passed=$results.Count;failed=0;nativeTestsRun=0;results=$results}

# Source-only recipe entry; returns a held plan and never launches Unity.
& (Join-Path $PSScriptRoot '..\common\prepare-selection.ps1') -Selection 'tower7'

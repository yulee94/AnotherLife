param([Parameter(Mandatory)][ValidateSet('Build','Test')][string]$Phase)
$ErrorActionPreference='Stop'
$prep=$PSScriptRoot
$run='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r002'
$cwd='F:\AnotherLife';$sdk='F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk';$dotnet="$sdk\dotnet.exe"
$project='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-candidates-20261014-r001\tests\StoryCombat.V2.Candidate.Tests.csproj'
function Read($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json}
function Save($name,$v){$v|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$run\$name"}
function Pin($p){if((Get-FileHash -LiteralPath $p.path).Hash-ne$p.sha256){throw "Pin drift: $($p.path)"}}
function FPath($path){$path=[IO.Path]::GetFullPath($path);if(-not$path.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)){throw 'Non-F path'};for($p=$path;$p;$p=[IO.Path]::GetDirectoryName($p)){if((Test-Path -LiteralPath $p)-and((Get-Item -LiteralPath $p).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse'}}}
function Deadline {if(-not(Test-Path "$run\CLOCK.json")){throw 'Clock missing'};$c=Read "$run\CLOCK.json";if([DateTime]::UtcNow.Ticks-ge[long]$c.deadlineUtcTicks){throw 'Original300 deadline expired'}}
function Admission {
 $a=Read "$run\ROOT_ADMISSION.json";$lease=Read "$cwd\.agent\NATIVE_SLOT_RESERVATION.json"
 if($a.candidatePacketSHA256-cne'AC10C226C897DC7AED7E36D28A2EA0ACE45336C3F5EE5E808272F5ABDDCA8378'-or$a.sourceReview.path-cne'F:\AnotherLife\outputs\LOCAL-COORD\combat-d3-source-review-20261014-r001\REVIEW.md'-or$a.sourceReview.sha256-cne'ECE5123A37EF9CF51E9230C6A58409956695B50A5A8235D49884EC674CFB9324'){throw 'D3 source review binding missing'}
 if($a.status-ne'ADMITTED'-or$a.run-ne$run-or$a.nativeExecutionAuthorized-ne$true-or$a.expectedCases-ne252-or$a.deadlineSeconds-ne300-or$a.maxSdkCalls-ne9-or$a.sourceQaAccepted-ne$true){throw 'Admission absent'}
 if($lease.leaseId-ne$a.leaseId-or[string]::IsNullOrWhiteSpace($a.leaseId)-or$lease.nativeExecutionAuthorized-ne$true-or$lease.nativeHeavySlotsReserved-ne1-or$lease.exclusiveNativeWindow-ne$true-or$lease.canonicalWritesPermitted-ne$false-or$lease.admissionPath-ne"$run\ROOT_ADMISSION.json"-or$lease.admissionSha256-ne(Get-FileHash "$run\ROOT_ADMISSION.json").Hash){throw 'Exact sole lease absent'}
 Pin @{path="$prep\PACKET_PINS.json";sha256=$a.recipePacketSHA256}
 foreach($review in @($a.sourceReview,$a.recipeReview)){if(-not$review.path-or$review.sha256-notmatch'^[A-Fa-f0-9]{64}$'){throw 'Required review unbound'};FPath $review.path;Pin $review}
 foreach($p in (Read "$prep\PACKET_PINS.json")){FPath $p.path;Pin $p}
 foreach($p in (Read "$prep\SOURCE_PINS.json")){FPath $p.path;Pin $p}
 foreach($p in (Read "$prep\ANCESTOR_PINS.json")){FPath $p.path;if((Test-Path $p.path)-ne$p.exists){throw 'Ancestor configuration drift'};if($p.exists){Pin $p}}
 if(Test-Path "$run\FAILED.json"){throw 'Failure is terminal; no retry'}
}
function MemorySample($samples){
 $samples=@($samples)
 if($samples.Count-ne1-or$null-eq$samples[0]){throw 'Memory sample cardinality'}
 $m=$samples[0];$values=@{}
 foreach($field in 'AvailableBytes','CommitLimit','CommittedBytes','PercentCommittedBytesInUse'){
  $property=$m.PSObject.Properties[$field]
  if($null-eq$property-or$null-eq$property.Value){throw "Memory field missing: $field"}
  $v=$property.Value
  if($v-isnot[byte]-and$v-isnot[sbyte]-and$v-isnot[int16]-and$v-isnot[uint16]-and$v-isnot[int32]-and$v-isnot[uint32]-and$v-isnot[int64]-and$v-isnot[uint64]-and$v-isnot[single]-and$v-isnot[double]-and$v-isnot[decimal]){throw "Memory field not numeric: $field"}
  $d=[double]$v
  if([double]::IsNaN($d)-or[double]::IsInfinity($d)-or$d-lt0){throw "Memory field invalid: $field"}
  if($field-ne'PercentCommittedBytesInUse'){
   if([decimal]$v-gt[long]::MaxValue-or[decimal]$v-ne[decimal]::Truncate([decimal]$v)){throw "Memory byte field out of range: $field"}
   $values[$field]=[long]$v
  }else{if($d-gt100){throw 'Memory percentage out of range'};$values[$field]=$d}
 }
 if($values.CommitLimit-le0-or$values.CommittedBytes-gt$values.CommitLimit){throw 'Memory commit relationship invalid'}
 $derived=100.0*$values.CommittedBytes/$values.CommitLimit
 if([Math]::Abs($values.PercentCommittedBytesInUse-$derived)-gt1.0){throw 'Memory percentage inconsistent with byte sample'}
 return @{ram=$values.AvailableBytes;headroom=$values.CommitLimit-$values.CommittedBytes;commit=$values.PercentCommittedBytesInUse}
}
function Gates($label){
 Admission
 if((@(Get-ChildItem -LiteralPath "$sdk\sdk" -Directory).Name -join ';')-cne'8.0.318'-or(@(Get-ChildItem -LiteralPath "$sdk\shared\Microsoft.NETCore.App" -Directory).Name -join ';')-cne'8.0.21'){throw 'SDK/runtime selection drift'}
 $m=MemorySample @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop)
 $r=@{C=(Get-PSDrive C).Free;F=(Get-PSDrive F).Free;ram=$m.ram;headroom=$m.headroom;commit=$m.commit}
 Save "$label-resources.json" $r
 if($r.C-lt40GB-or$r.F-lt20GB-or$r.ram-lt8GB-or$r.headroom-lt15GB-or$r.commit-ge80){throw 'Resources'}
 $rows=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object{$_.Name-match'^(Unity.*|blender|dotnet|MSBuild|csc|VBCSCompiler|python.*|mono|mcs|bee_backend|cl|link|java|adb|il2cpp)(\.exe)?$'}|Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
 Save "$label-census.json" $rows;if($rows.Count){throw 'Native workers present; Root disposition required'}
}
function Native($label,[string[]]$arguments){
 if(Test-Path "$run\$label-START.json"){throw 'Invocation already attempted'};Gates $label;Deadline
 if((Get-Location).Path-ne$cwd-or[Environment]::CurrentDirectory-ne$cwd-or$env:DOTNET_NOLOGO-ne'true'){throw 'CWD/environment drift'}
 Save "$label-START.json" @{utc=[DateTime]::UtcNow.ToString('o');arguments=$arguments;cwd=$cwd}
 Deadline
 & $dotnet @arguments > "$run\$label.log" 2>&1
 $code=$LASTEXITCODE;Save "$label-EXIT.json" @{exit=$code;utc=[DateTime]::UtcNow.ToString('o')}
 if($code-ne0){throw "SDK phase $label failed exit $code"};Deadline
}
FPath $prep;FPath $run;if(-not(Test-Path "$run\ROOT_ADMISSION.json")){throw 'Root must first prepare exact fresh runtime and admission'}
Admission
$saved=@{};$oldLocation=(Get-Location).Path;$oldCurrent=[Environment]::CurrentDirectory
try {
 foreach($name in @('DOTNET_STARTUP_HOOKS','DOTNET_ADDITIONAL_DEPS','DOTNET_SHARED_STORE','DOTNET_DiagnosticPorts','CORECLR_ENABLE_PROFILING','CORECLR_PROFILER','CORECLR_PROFILER_PATH','COR_ENABLE_PROFILING','COR_PROFILER','COR_PROFILER_PATH','NUGET_PLUGIN_PATHS','MSBuildSDKsPath','MSBUILD_EXE_PATH','MSBuildExtensionsPath','MSBuildExtensionsPath32','MSBuildExtensionsPath64','CustomBeforeMicrosoftCommonTargets','CustomAfterMicrosoftCommonTargets','DirectoryBuildPropsPath','DirectoryBuildTargetsPath','DirectoryPackagesPropsPath','DOTNET_MSBUILD_SDK_RESOLVER_SDKS_DIR','DOTNET_MSBUILD_SDK_RESOLVER_SDKS_VER','DOTNET_MSBUILD_SDK_RESOLVER_CLI_DIR')){if([Environment]::GetEnvironmentVariable($name,'Process')){throw "Inherited hook rejected: $name"}}
 $environment=@{DOTNET_ROOT=$sdk;DOTNET_ROOT_X64=$sdk;DOTNET_NOLOGO='true';DOTNET_MULTILEVEL_LOOKUP='0';DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1';DOTNET_CLI_TELEMETRY_OPTOUT='1';DOTNET_GENERATE_ASPNET_CERTIFICATE='false';DOTNET_ADD_GLOBAL_TOOLS_TO_PATH='false';DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE='true';MSBuildEnableWorkloadResolver='false';MSBUILDDISABLENODEREUSE='1'}
 foreach($name in 'TEMP','TMP','DOTNET_CLI_HOME','NUGET_PACKAGES','NUGET_HTTP_CACHE_PATH','NUGET_PLUGINS_CACHE_PATH','NUGET_SCRATCH','DOTNET_BUNDLE_EXTRACT_BASE_DIR','MSBUILDDEBUGPATH','SQLITE_TMPDIR','USERPROFILE','APPDATA','LOCALAPPDATA'){$environment[$name]=if($name-eq'TMP'){"$run\TEMP"}else{"$run\$name"};FPath $environment[$name];[IO.Directory]::CreateDirectory($environment[$name])|Out-Null}
 foreach($name in $environment.Keys){$saved[$name]=[Environment]::GetEnvironmentVariable($name,'Process');[Environment]::SetEnvironmentVariable($name,$environment[$name],'Process')}
 Set-Location $cwd;[Environment]::CurrentDirectory=$cwd
 if([IO.Path]::GetTempPath().TrimEnd('\')-ne$environment.TEMP){throw 'Managed temporary path mismatch'}
 foreach($directory in @($run)+@($environment.Values|Where-Object{$_-like "$run\*"}|Sort-Object -Unique)){
  $probe="$directory\access-$Phase";if((Test-Path $probe)-or(Test-Path "$probe.verified")){throw 'Existing phase probe'};[IO.File]::WriteAllText($probe,'verified');if([IO.File]::ReadAllText($probe)-ne'verified'){throw 'Read denied'};Move-Item $probe "$probe.verified"
 }
 $common=@("-p:ArtifactsPath=$run\artifacts",'-p:UseArtifactsOutput=true','-p:UseAppHost=false','-p:UseSharedCompilation=false','-p:NuGetAudit=false','-p:MSBuildEnableWorkloadResolver=false','-p:Configuration=Debug','-m:1','-nr:false',"-p:CustomAfterMicrosoftCommonTargets=$prep\CompileEvidence.targets")
 $graph=Read "$prep\EXPECTED_GRAPH.json"
 if($Phase-eq'Build'){
  if(Test-Path "$run\CLOCK.json"){throw 'Original job already started; no rebuild'}
  Gates 'initial'
  & "$prep\Review-Compiler.ps1" -Stage preflight > "$run\COMPILER_PREFLIGHT.json"
  if((Read "$run\COMPILER_PREFLIGHT.json").accepted-ne$true){throw 'Compiler observer preflight rejected'}
  Save 'COMPILER_PREFLIGHT.observer.json' @{exit=0;sdkCalls=0;reportSHA256=(Get-FileHash "$run\COMPILER_PREFLIGHT.json").Hash}
  foreach($p in (Read 'F:\AnotherLife\outputs\LOCAL-WEB\mode-progression-sdk-preparation-20261014-r002\SDK_REFERENCE_PINS.json').files){FPath $p.path;Pin $p}
  [IO.Directory]::CreateDirectory("$run\empty-feed")|Out-Null;if(@(Get-ChildItem "$run\empty-feed" -Force).Count){throw 'Offline feed not empty'}
  $now=[DateTime]::UtcNow;Save 'CLOCK.json' @{startUtcTicks=$now.Ticks;deadlineUtcTicks=$now.AddSeconds(300).Ticks;seconds=300}
  Native 'restore' (@('restore',$project,'--disable-parallel','--source',"$run\empty-feed",'--packages',"$run\NUGET_PACKAGES")+$common)
  foreach($stage in 'pre','post'){
   if($stage-eq'post'){Native 'build' (@('build',$project,'--no-restore','-v:diag',"-bl:$run\build.binlog")+$common)}
   foreach($row in $graph){Native "$stage-$($row.name)" (@('msbuild',$row.project,'-getItem:Compile,ProjectReference,PackageReference,FrameworkReference','-getProperty:TargetFramework,LangVersion,DefineConstants,TargetPath,BaseIntermediateOutputPath,MSBuildProjectExtensionsPath,MSBuildAllProjects')+$common)}
   & "$prep\Verify-Graph.ps1" -Stage $stage;Deadline
  }
  & "$prep\Review-Compiler.ps1" -Stage compiled > "$run\ROOT_COMPILER_REVIEW.json"
  if((Read "$run\ROOT_COMPILER_REVIEW.json").accepted-ne$true){throw 'Compiler review rejected'}
  Gates 'build-closeout';Deadline;Save 'BUILD_READY.json' @{sdkCalls=8;accepted=$false;reason='Prepared read-only compiler helper accepted; original clock continues'}
 }else{
  Deadline;if(-not(Test-Path "$run\BUILD_READY.json")){throw 'Build incomplete'}
  foreach($label in @('restore','build')+@($graph|ForEach-Object{"pre-$($_.name)";"post-$($_.name)"})){if((Read "$run\$label-EXIT.json").exit-ne0){throw 'Prior SDK exit missing/nonzero'}}
  $review=Read "$run\ROOT_COMPILER_REVIEW.json"
  foreach($field in 'accepted','cscOperandsVerified','importsVerified','depsAssetsVerified','pePdbLinksVerified','sourceDocumentsVerified','sdkReferenceBaselineVerified'){if($review.$field-ne$true){throw "Compiler review incomplete: $field"}}
  if($review.recipePacketSHA256-ne(Get-FileHash "$prep\PACKET_PINS.json").Hash-or@($review.files).Count-lt6){throw 'Compiler review binding incomplete'}
  foreach($p in $review.files){FPath $p.path;Pin $p}
  foreach($row in $graph){foreach($ext in 'dll','pdb'){$path="$run\artifacts\bin\$($row.name)\debug\$($row.name).$ext";if(@($review.files|Where-Object{$_.path-eq$path}).Count-ne1){throw 'Missing exact DLL/PDB pair'}}}
  & "$prep\Verify-Graph.ps1" -Stage post;Deadline
  Native 'test' @('--fx-version','8.0.21',"$run\artifacts\bin\StoryCombat.V2.Candidate.Tests\debug\StoryCombat.V2.Candidate.Tests.dll")
  . "$prep\Test-RosterRule.ps1"
  Assert-TestRoster @(Get-Content "$run\test.log") @(Read "$prep\EXPECTED_TESTS.json")
  Gates 'final';Deadline;Save 'RESULT.json' @{passed=252;failed=0;sdkCalls=9;testLogSHA256=(Get-FileHash "$run\test.log").Hash;accepted=$true;scope='Candidate unit/golden validation only; no shipping/gameplay acceptance'}
 }
}catch{Save 'FAILED.json' @{phase=$Phase;error=$_.Exception.Message;utc=[DateTime]::UtcNow.ToString('o');retryAllowed=$false};throw}
finally{
 try{foreach($name in $saved.Keys){if($null-eq$saved[$name]){[Environment]::SetEnvironmentVariable($name,[NullString]::Value,'Process')}else{[Environment]::SetEnvironmentVariable($name,$saved[$name],'Process')}}}
 finally{try{Set-Location $oldLocation}finally{[Environment]::CurrentDirectory=$oldCurrent}}
}

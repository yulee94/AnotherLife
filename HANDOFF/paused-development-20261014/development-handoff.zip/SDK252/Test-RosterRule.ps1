function Assert-TestRoster($Lines,$Expected) {
 $lines=@($Lines);$expected=@($Expected)
 if($expected.Count-ne252-or@($expected|Sort-Object -Unique).Count-ne252){throw 'Expected roster invalid'}
 $actual=@($lines|Where-Object{$_-cmatch'^PASS '}|ForEach-Object{$_.Substring(5)})
 if($actual.Count-ne252-or@($actual|Sort-Object -Unique).Count-ne252-or(($actual|Sort-Object)-join"`n")-cne(($expected|Sort-Object)-join"`n")-or@($lines|Where-Object{$_-ceq'RESULT passed=252 failed=0'}).Count-ne1-or@($lines|Where-Object{$_-cmatch'^FAIL '}).Count-or$lines.Count-ne253){throw 'Exact stdout roster/count mismatch'}
}

Set-StrictMode -Version Latest
function ReadPdbBinding([string]$Dll,$ExpectedDocuments) {
 $Pdb=[IO.Path]::ChangeExtension($Dll,'.pdb')
 $ds=[IO.File]::OpenRead($Dll);$ps=[IO.File]::OpenRead($Pdb);$pe=$null;$provider=$null
 try {
  $pe=[Reflection.PortableExecutable.PEReader]::new($ds)
  $provider=[Reflection.Metadata.MetadataReaderProvider]::FromPortablePdbStream($ps)
  $mr=$provider.GetMetadataReader();$id=[byte[]]$mr.DebugMetadataHeader.Id
  if($id.Length-ne20){throw 'Unexpected portable PDB id'}
  $guid=[Guid]::new([byte[]]$id[0..15]);$stamp=[BitConverter]::ToUInt32($id,16)
  $entries=@($pe.ReadDebugDirectory()|Where-Object {$_.Type-eq'CodeView'})
  if($entries.Count-ne1){throw 'CodeView count'}
  $cv=$pe.ReadCodeViewDebugDirectoryData($entries[0])
  if($cv.Guid-ne$guid-or$cv.Age-ne1-or$entries[0].Stamp-ne$stamp){throw 'DLL/PDB identity mismatch'}
  $docs=@()
  foreach($handle in $mr.Documents){
   $d=$mr.GetDocument($handle);$path=FullPath ($mr.GetString($d.Name)) 'F:\AnotherLife'
   AssertPlain $path
   if($mr.GetGuid($d.HashAlgorithm)-ne[Guid]'8829d00f-11b8-4213-878b-770e8597ac16'){throw 'Unexpected document hash algorithm'}
   $hash=[Convert]::ToHexString($mr.GetBlobBytes($d.Hash))
   if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw "PDB document mismatch: $path"}
   $docs+=@{path=$path;sha256=$hash}
  }
  SameSet @($docs.path) @($ExpectedDocuments) 'PDB documents'
  return @{codeViewGuid=$guid.ToString();stamp=$stamp;pdbId=[Convert]::ToHexString($id);documents=$docs.Count}
 }finally{if($provider){$provider.Dispose()};if($pe){$pe.Dispose()};$ps.Dispose();$ds.Dispose()}
}
function FullPath([string]$Path,[string]$Base) {
 if(-not [IO.Path]::IsPathRooted($Path)){$Path=Join-Path $Base $Path}
 $p=[IO.Path]::GetFullPath($Path)
 if(-not $p.StartsWith('F:\',[StringComparison]::OrdinalIgnoreCase)){throw "Non-F input: $p"}
 return $p
}
function AssertPlain([string]$Path) {
 $p=$Path
 while($p){if((Test-Path -LiteralPath $p)-and((Get-Item -LiteralPath $p).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw "Reparse: $p"};$p=[IO.Path]::GetDirectoryName($p)}
}
function TextHash([string]$Text) {return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Text)))}
function Template([string]$Text,[string]$Run,[string]$Prep) {
 return $Text.Replace($Run.Replace('\','\\'),'{RUN-JSON}').Replace($Prep.Replace('\','\\'),'{PREP-JSON}').Replace($Run,'{RUN}').Replace($Prep,'{PREP}').Replace($Run.Replace('\','/'),'{RUN-SLASH}').Replace($Prep.Replace('\','/'),'{PREP-SLASH}')
}
function SameSet($A,$B,[string]$Label) {
 $a1=@($A|Sort-Object);$b1=@($B|Sort-Object)
 if(($a1-join "\n")-cne($b1-join "\n")){throw "Set mismatch: $Label"}
}
function ReadCommands([string]$Run,[string]$Prep,$Graph) {
 $lines=@(Select-String -LiteralPath "$Run\build.log" -Pattern 'dotnet\.exe exec .*Roslyn.*csc\.dll'|ForEach-Object Line)
 if($lines.Count-ne 3){throw 'Expected exactly three compiler commands'}
 $seen=@{}
 foreach($raw in $lines){
  $line=[regex]::Replace($raw,'\((?:TaskId:|작업 ID:)\d+\)\s*$','').Trim()
  $tokens=@([regex]::Matches($line,'(?:[^\s"]+|"[^"]*")+')|ForEach-Object {$_.Value.Replace('"','')})
  if(@($tokens|Where-Object {$_-like '@*'}).Count){throw 'Unreviewed response file'}
  $outs=@($tokens|Where-Object {$_-like '/out:*'});if($outs.Count-ne 1){throw 'Output ambiguity'}
  $output=FullPath $outs[0].Substring(5) 'F:\AnotherLife'
  $projects=@($Graph.projects|Where-Object {$output-eq"$Run\artifacts\obj\$($_.project)\debug\$($_.project).dll"})
  if($projects.Count-ne 1){throw "Unknown compiler output: $output"}
  $project=$projects[0];$name=$project.project
  if($seen.ContainsKey($name)){throw 'Duplicate project compilation'};$seen[$name]=$true
  $base=[IO.Path]::GetDirectoryName($project.projectPath)
  $normalized=@();$inputs=@();$sources=@()
  for($i=0;$i-lt$tokens.Count;$i++){
   $t=$tokens[$i]
   if($i-eq 0-or$i-eq 2){$p=FullPath $t $base;$inputs+=[pscustomobject]@{kind='compiler';path=$p};$normalized+=Template $p $Run $Prep;continue}
   if($t-match '^/(reference|analyzer|analyzerconfig|sourcelink|additionalfile|ruleset|keyfile|resource|linkresource|win32res|win32icon|win32manifest|out|refout|doc|errorlog):(.+)$'){
    $kind=$Matches[1];$value=$Matches[2]
    if($value.Contains(',')-or$value.Contains('=')){throw "Unsupported compound path argument: $t"}
    $p=FullPath $value $base;$normalized+=('/'+$kind+':'+(Template $p $Run $Prep))
    if($kind-notin@('out','refout','doc','errorlog')){$inputs+=[pscustomobject]@{kind=$kind;path=$p}}
   }elseif($t-match '\.cs$'-and-not$t.StartsWith('/')){$p=FullPath $t $base;$sources+=$p;$normalized+=Template $p $Run $Prep}
   else{$normalized+=$t}
  }
  $expected=@($project.compile);$product=@($sources|Where-Object {$expected-contains$_})
  SameSet $product $expected "$name product sources"
  if($sources.Count-ne@($sources|Sort-Object -Unique).Count){throw 'Duplicate source'}
  $generated=@($sources|Where-Object {$expected-notcontains$_})
  $expectedGenerated=@("$Run\artifacts\obj\$name\debug\$name.AssemblyInfo.cs")
  if($project.targetFramework-eq'net8.0'){$expectedGenerated+="$Run\artifacts\obj\$name\debug\$name.GlobalUsings.g.cs";$expectedGenerated+="$Run\artifacts\obj\$name\debug\.NETCoreApp,Version=v8.0.AssemblyAttributes.cs"}
  elseif($project.targetFramework-eq'netstandard2.1'){$expectedGenerated+="$Run\artifacts\obj\$name\debug\.NETStandard,Version=v2.1.AssemblyAttributes.cs"}
  else{throw 'Unknown framework'}
  SameSet $generated $expectedGenerated "$name generated sources"
  [pscustomobject]@{project=$name;rawCommandSHA256=(TextHash $raw);normalizedTokens=$normalized;inputs=$inputs;product=$product;generated=$generated;output=$output}
 }
}


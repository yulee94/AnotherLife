Read CORRECTION.md first for the three reviewed r002 launcher fixes and45 actual pure/mock checks. This is a held source-only successor; no runtime admission.

# D3 SDK252 source-only validation successor

Status: HELD for independent recipe review and fresh Root admission. D3 source review ECE5123A37EF9CF51E9230C6A58409956695B50A5A8235D49884EC674CFB9324 accepts candidate AC10C226C897DC7AED7E36D28A2EA0ACE45336C3F5EE5E808272F5ABDDCA8378 at source level only. All 252 combat cases are UNRUN. The admission template, recipe acceptance and native authorization remain false. No runtime directory, admission, lease or clock was created.

## Exact graph and scope

EXPECTED_GRAPH.json fixes three projects: D3 StoryCombat.V2.Candidate (nine authored C# files, netstandard2.1/C#8), StoryCombat.V2.Candidate.Tests (seven authored files, net8.0/C#12), and the actual canonical StoryCombat.Core (three sources plus its project, netstandard2.1/C#8). SOURCE_GRAPH_PINS.json pins all 22 project/source files. The v1 golden fixture and original golden-source evidence are separately pinned in SOURCE_PINS.json. No alternate v1 copy is substituted. The 252 unique names are in EXPECTED_TESTS.json; TEST_ROSTER_PROVENANCE.json preserves their originating files and UNRUN status.

The v1 golden checks original snapshot/input hash, codec roundtrip, terminal Victory, version13, HP56,80,80,80,80,0,0,0 and original terminal state hash against the canonical fixture. The candidate test process reads this exact F fixture. It does not authorize Unity, host integration, live catalog values, all eight kits or Phase1 acceptance.

## Preserved predecessor and bounded changes

The prior SDK31 r003 packet, source/compiler readers, inventory manifest, reviewed r003 framework correction, r002 framework failure and r003 resource failure are pinned unchanged. Original r003 Root release is 9E4C60A8E0DA2629D151B903234CC984625FECBBC75B6929C4E7290606245BC2: commit headroom fell below15 GiB before restore; zero SDK calls and tests. Its original clock/failure/native-release evidence is preserved. Nothing here retries, extends or reopens either old run.

Changes from SDK31 r003: rebind candidate/preparation/future-runtime paths; enumerate nine engine/seven test sources in graph and compiler operand expectations; bind accepted D3 review and exact packet; update roster gate to252/253 lines; factor only that pure stdout gate into Test-RosterRule.ps1; check exact installed SDK/runtime version directory selection and use explicit --fx-version8.0.21 for the test call. The PE/PDB reader and all other compiler/closure checks retain predecessor logic. Authoring scripts are retained as preparation provenance, not executable run entrypoints; do not rerun Prepare-Packet.ps1 against a sealed packet.

The corrected framework distinction remains exact: implicit FrameworkReference is NETStandard.Library for netstandard2.1 and Microsoft.NETCore.App for net8.0, with the complete expected metadata object. The compiler reference pack path is NETStandard.Library.Ref/2.1.0/ref/netstandard2.1. These are different identities; do not rename either to the other. Package references remain forbidden. Reuse qualified SDK_REFERENCE_PINS.json hash97AC27FD42FDACE19A75A356793D5153696BC02BBF4D125C1DEE60DDBCFA88B5; preparation checks referenced operand membership without recollecting/rehashing the full vendor tree. The separately admitted runtime still rechecks the original inventory as before.

## Future Root calls and nine SDK invocations

Only after independent recipe acceptance, Root's exact admission and exclusive native lease:

```powershell
& 'F:\AnotherLife\outputs\LOCAL-COORD\combat-d3-sdk252-preparation-20261014-r002\Root-Launcher.ps1' -Phase Build
& 'F:\AnotherLife\outputs\LOCAL-COORD\combat-d3-sdk252-preparation-20261014-r002\Root-Launcher.ps1' -Phase Test
```

Future run: F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r002. Vendor executable: F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk\dotnet.exe, SDK8.0.318, runtime8.0.21. SDK_CALLS.json contains the literal argument arrays. Calls in order: offline restore, three pre-build project evaluations, one diagnostic build, three post-build evaluations, one test DLL execution. Preflight/compiler observers are in-process source readers, not SDK calls. No process launch is authorized by this document alone.

One original300-second tick clock starts after preflight/baseline verification and before restore. Build and Test share it, with no reset. Exact eight SDK exit receipts are required before test. Test requires exit0, each252 expected PASS name exactly once, exactly one RESULT passed=252 failed=0, no FAIL and exactly253 stdout lines. Order is irrelevant; case/name/multiplicity are exact. No rerun on failure or partial results.

## Storage, resources and stop rules

Canonical cwd is F:\AnotherLife. Explicit F paths cover TEMP/TMP, CLI/profile/cache/NuGet, source inputs, generated artifacts, logs/binlog, DLL/PDB, deps/runtimeconfig and observer reports. Empty F feed/fresh package cache, no package download/install permission. Ancestor checks inspect only five exact config filenames through project chains and drive root, recording existence/hashes; they do not expand the write boundary or permit arbitrary drive configuration. Reparse checks and access probes precede runtime writes. Existing vendor installation/global credentials are untouched. Source routing checks are not proof of zero application-managed C writes.

Unchanged floors: C40GiB, F20GiB, available RAM8GiB, commit headroom15GiB, commit below80%, one exclusive native slot. Latest reported14.646GiB headroom remains a hold; rounding or proximity is not a waiver. Any active source capture/native lease must be resolved by Root before this unrelated native admission. No current lease/source pause is changed here.

Every SDK call checks fresh resources/census, exact admission/pins and original deadline. The synchronous launcher cannot preempt a hung child. Root must retain the original execution session, monitor at intervals no longer than50 seconds, stop dispatching on failure/deadline/resource/census mismatch and own unresolved child disposition. No force-kill, cleanup, deletion, retry or clock extension is authorized. Preserve all failed logs/receipts. Environment restoration in finally is process-local; it does not clean artifacts or release Root's lease. Root must establish child exit/census and separately record release; never claim cleanup from a helper return alone.

## Compiler and artifact evidence

Prepared compiler operands are prospective adaptations, not an observed D3 build. Token comparison preserves multiplicity and refuses unknown inputs, response files and unpinned references/analyzers. Authored sources9+7+3 and generated sources2+3+2 are exact:26 PDB source documents across three DLL/PDB pairs. Verify source checksums, CodeView/PDB identity, bin/obj copies, sibling references, package-free assets/deps and test runtimeconfig. Unknown dependency/native assets/imports fail closed.

Reported MSBuildAllProjects is not a complete transitive import trace. Generated source paths/counts/checksums are checked, but generated semantics are not preapproved by content hashes. Retain these predecessor limitations. F routing and compiler qualification require actual future evidence; static acceptance does not establish runtime routing or passing tests.

## Preparation evidence

Actual checks: exact candidate/predecessor seals, source hashes, XML compile/reference closure, authored252-name extraction, compiler operand source membership, vendor reference membership, PowerShell AST parse and12 pure stdout-rule cases. No launcher, graph verifier, compiler-evidence reader, SDK, compiler, candidate DLL, native census or Unity execution occurred. The initial preparation checker had two source-only authoring defects (join comparison parentheses, rooted XML reference resolution); both were corrected before final checks, with no SDK effect. PREPARATION_HISTORY.json preserves those failures.

Independent review must inspect the sealed packet and exact deltas before Root creates any admission. A future252-pass result would be scoped candidate unit/golden validation only.

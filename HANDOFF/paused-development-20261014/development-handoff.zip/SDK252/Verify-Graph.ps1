param([Parameter(Mandatory)][ValidateSet('pre','post')][string]$Stage)
$ErrorActionPreference='Stop'
$prep=$PSScriptRoot
$run='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r002'
$sdk=Get-Content -Raw 'F:\AnotherLife\outputs\LOCAL-WEB\mode-progression-sdk-preparation-20261014-r002\SDK_REFERENCE_PINS.json'|ConvertFrom-Json
$allowed=@{};foreach($pin in $sdk.files){$allowed[$pin.path]=$pin.sha256}
function Same($a,$b){$a=@($a);$b=@($b);if($a.Count-ne$b.Count-or(@($a|Sort-Object -Unique).Count-ne$a.Count)-or(($a|Sort-Object)-join"`n")-cne(($b|Sort-Object)-join"`n")){throw 'Exact graph mismatch'}}
function InRun($p){$full=[IO.Path]::GetFullPath($p);if(-not$full.StartsWith($run+'\',[StringComparison]::OrdinalIgnoreCase)){throw "Output outside run: $p"}}
$reports=@()
foreach($row in (Get-Content -Raw "$prep\EXPECTED_GRAPH.json"|ConvertFrom-Json)){
 $e=Get-Content -Raw "$run\$Stage-$($row.name).log"|ConvertFrom-Json
 Same @($e.Items.Compile|ForEach-Object{$_.FullPath}) $row.sources
 Same @($e.Items.ProjectReference|ForEach-Object{$_.FullPath}) $row.references
 if(@($e.Items.PackageReference).Count-ne0){throw 'Unexpected package reference'}
 $frameworks=@($e.Items.FrameworkReference);$expectedFrameworks=@($row.frameworkReferences)
 if($frameworks.Count-ne1-or$expectedFrameworks.Count-ne1){throw 'Framework reference cardinality drift'}
 $identity=if($row.framework-eq'netstandard2.1'){'NETStandard.Library'}elseif($row.framework-eq'net8.0'){'Microsoft.NETCore.App'}else{throw 'Unapproved target framework'}
 if($expectedFrameworks[0].Identity-cne$identity){throw 'Framework expectation inconsistent with TFM'}
 Same @($frameworks[0].PSObject.Properties|ForEach-Object{$_.Name}) @($expectedFrameworks[0].PSObject.Properties|ForEach-Object{$_.Name})
 foreach($property in $expectedFrameworks[0].PSObject.Properties){if([string]$frameworks[0].($property.Name)-cne[string]$property.Value){throw "Framework metadata drift: $($property.Name)"}}
 if($e.Properties.TargetFramework-ne$row.framework-or$e.Properties.LangVersion-ne$row.language){throw 'Framework/language drift'}
 InRun $e.Properties.TargetPath;InRun $e.Properties.BaseIntermediateOutputPath;InRun $e.Properties.MSBuildProjectExtensionsPath
 $expected="$run\artifacts\bin\$($row.name)\debug\$($row.name).dll"
 if([IO.Path]::GetFullPath($e.Properties.TargetPath)-ne$expected){throw 'Target routing drift'}
 if($Stage-eq'post'){
  $before=Get-Content -Raw "$run\pre-$($row.name).log"|ConvertFrom-Json
  Same @($before.Properties.DefineConstants.Split(';')|Sort-Object -Unique) @($e.Properties.DefineConstants.Split(';')|Sort-Object -Unique)
  Same @($before.Properties.MSBuildAllProjects.Split(';')|Sort-Object -Unique) @($e.Properties.MSBuildAllProjects.Split(';')|Sort-Object -Unique)
  $actual=@(Get-Content "$run\artifacts\$($row.name).sources.txt"|Where-Object{$_})
  foreach($source in $row.sources){if(@($actual|Where-Object{$_-eq$source}).Count-ne1){throw 'Compiler missing/duplicate product source'}}
  foreach($source in $actual){if($row.sources-notcontains$source){InRun $source;if($source-notlike '*.AssemblyInfo.cs'-and$source-notlike '*.AssemblyAttributes.cs'-and$source-notlike '*.GlobalUsings.g.cs'){throw 'Unexpected generated source'}}}
  foreach($kind in 'references','analyzers'){
   foreach($path in (Get-Content "$run\artifacts\$($row.name).$kind.txt"|Where-Object{$_})){
    $path=[IO.Path]::GetFullPath($path)
    if($allowed.ContainsKey($path)){if((Get-FileHash $path).Hash-ne$allowed[$path]){throw 'SDK reference drift'}}
    else{InRun $path;if($kind-eq'analyzers'-or$path-notmatch '\\(ref|refint|debug)\\StoryCombat\.(Core|V2\.Candidate)\.dll$'){throw 'Unqualified compiler reference'}}
   }
  }
 }
 $reports+=@{project=$row.project;target=$expected;sourceCount=$row.sources.Count;stage=$Stage}
}
$reports|ConvertTo-Json -Depth 5|Set-Content "$run\GRAPH-$Stage.json"

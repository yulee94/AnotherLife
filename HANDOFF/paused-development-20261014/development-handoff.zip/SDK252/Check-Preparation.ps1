# Source/manifest checks and the side-effect-free stdout rule only. No SDK or validation launcher.
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
function ReadJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json}
$parsed=@();foreach($p in (Get-ChildItem -LiteralPath $out -Filter '*.ps1')){$tokens=$null;$errors=$null;[Management.Automation.Language.Parser]::ParseFile($p.FullName,[ref]$tokens,[ref]$errors)|Out-Null;if($errors.Count){throw ($errors|Out-String)};$parsed+=$p.Name}
$graph=@(ReadJson "$out\EXPECTED_GRAPH.json");$commands=@((ReadJson "$out\COMPILER_EXPECTATIONS.json").commands)
$closure=@();foreach($row in $graph){
 [xml]$xml=Get-Content -LiteralPath $row.project -Raw
 $dir=[IO.Path]::GetDirectoryName($row.project)
 $actual=@($xml.Project.ItemGroup.Compile|ForEach-Object{$(if([IO.Path]::IsPathRooted($_.Include)){[IO.Path]::GetFullPath($_.Include)}else{[IO.Path]::GetFullPath((Join-Path $dir $_.Include))})})
 if((($actual|Sort-Object)-join'|') -cne (($row.sources|Sort-Object)-join'|')){throw 'XML source mismatch'}
 $refs=@($xml.SelectNodes('//ProjectReference')|ForEach-Object{$(if([IO.Path]::IsPathRooted($_.Include)){[IO.Path]::GetFullPath($_.Include)}else{[IO.Path]::GetFullPath((Join-Path $dir $_.Include))})})
 if((($refs|Sort-Object)-join'|') -cne (($row.references|Sort-Object)-join'|')){throw 'XML references mismatch'}
 $command=@($commands|Where-Object project -eq $row.name)[0]
 $sourceOperands=@($command.normalizedTokens|Where-Object{$_-like'*.cs'})
 if((($sourceOperands|Sort-Object)-join'|') -cne ((@($row.sources)+@($command.generated)|Sort-Object)-join'|')){throw 'Compiler source operands'}
 foreach($path in @($row.project)+@($row.sources)){$closure+=@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash;role=$row.name}}
}
if($graph[0].sources.Count-ne9-or$graph[1].sources.Count-ne7-or$graph[2].sources.Count-ne3-or$closure.Count-ne22){throw 'Source closure count'}
$closure|ConvertTo-Json -Depth 8|Set-Content "$out\SOURCE_GRAPH_PINS.json" -Encoding utf8
$pins=@(ReadJson "$out\SOURCE_PINS.json");foreach($p in $pins){if((Get-FileHash -LiteralPath $p.path).Hash-ne$p.sha256){throw "Source drift: $($p.path)"}}
$roster=@(ReadJson "$out\EXPECTED_TESTS.json")
$authored=@();foreach($p in $graph[1].sources){$authored+=@([regex]::Matches((Get-Content $p -Raw),'Test\("([^"]+)"')|ForEach-Object{$_.Groups[1].Value})}
if($authored.Count-ne252-or(($authored|Sort-Object)-join'|')-cne(($roster|Sort-Object)-join'|')){throw 'Authored roster mismatch'}
. "$out\Test-RosterRule.ps1"
$valid=@($roster|ForEach-Object{"PASS $_"})+@('RESULT passed=252 failed=0')
$tests=@()
function Case($name,$lines,$expected,$accept){$didAccept=$true;try{Assert-TestRoster $lines $expected}catch{$didAccept=$false};if($didAccept-ne$accept){throw "Pure rule case failed: $name"};$script:tests+=@{name=$name;expectedAccept=$accept;passed=$true}}
Case 'exact252' $valid $roster $true
Case 'differentOrderSameExactNames' (@($valid[0..251]|Sort-Object -Descending)+@($valid[252])) $roster $true
Case 'missingCase' @($valid[1..252]) $roster $false
$v=$valid.Clone();$v[0]=$v[1];Case 'duplicateReplacingCase' $v $roster $false
$v=$valid.Clone();$v[0]='PASS unknown';Case 'unknownCase' $v $roster $false
$v=$valid.Clone();$v[0]=$v[0].Replace('PASS ','pass ');Case 'caseSensitivePrefix' $v $roster $false
Case 'extraLine' (@($valid)+@('noise')) $roster $false
$v=$valid.Clone();$v[252]='RESULT passed=31 failed=0';Case 'stale31Summary' $v $roster $false
$v=$valid.Clone();$v[252]='RESULT passed=252 failed=1';Case 'nonzeroFailureSummary' $v $roster $false
$v=$valid.Clone();$v[0]='FAIL broken';Case 'failedCase' $v $roster $false
Case 'duplicateResult' (@($valid)+@($valid[252])) $roster $false
Case 'invalidExpectedRoster' $valid @($roster[1..251]) $false
$sdk=ReadJson 'F:\AnotherLife\outputs\LOCAL-WEB\mode-progression-sdk-preparation-20261014-r002\SDK_REFERENCE_PINS.json'
$known=@{};foreach($pin in $sdk.files){$known[$pin.path]=$pin.sha256}
$external=@($commands.normalizedTokens|ForEach-Object{$_}|Where-Object{$_-match'^/(reference|analyzer):F:'}|ForEach-Object{$_ -replace '^/[^:]+:',''}|Sort-Object -Unique)
foreach($p in $external){if(!$known.ContainsKey($p)){throw "Unpinned external operand $p"}}
$ns=@($external|Where-Object{$_-match'\\packs\\NETStandard.Library.Ref\\2.1.0\\ref\\netstandard2.1\\'}).Count
if($ns-eq0){throw 'Corrected NETStandard ref pack missing'}
$run='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r001';if(Test-Path $run){throw 'Unexpected runtime exists'}
@{status='STATIC_PREPARATION_CHECKS_ONLY';scriptParseErrors=0;parsedScripts=$parsed;projectCount=3;engineSources=9;testSources=7;canonicalV1ClosureFiles=4;sourceGraphFiles=$closure.Count;sourceEvidencePins=$pins.Count;authoredTestCases=252;candidateTestsRun=0;sdkCalls=0;pureWrapperCases=$tests;externalOperandPaths=$external.Count;netstandardRefOperands=$ns;vendorInventoryReusedByHash=$true;vendorFilesRehashedHere=$false;runtimeDirectoryExists=$false;nativeExecutionAuthorized=$false;recipeAccepted=$false}|ConvertTo-Json -Depth 10|Set-Content "$out\STATIC_VALIDATION.json" -Encoding utf8
Write-Output "Static checks passed; 12 pure stdout-rule cases; 252 candidate tests remain UNRUN."

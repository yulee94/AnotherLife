# Runs only selected function/finally AST bodies with in-process mocks. No launcher/SDK execution.
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile("$out\Root-Launcher.ps1",[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Launcher AST errors'}
$functions=@{}
foreach($name in 'MemorySample','Gates','Deadline','Native'){
 $node=@($ast.FindAll({param($n)$n-is[Management.Automation.Language.FunctionDefinitionAst]},$false)|Where-Object Name -eq $name)
 if($node.Count-ne1){throw "Function absent $name"}
 $functions[$name]=$node[0].Extent.Text
 . ([scriptblock]::Create($node[0].Extent.Text))
}
$results=@()
function Case($name,[scriptblock]$action,$shouldPass){
 $passed=$true;$message=$null
 try{& $action}catch{$passed=$false;$message=$_.Exception.Message}
 if($passed-ne$shouldPass){throw "Unexpected pure/mock result: $name; $message"}
 $script:results+=@{name=$name;expectedSuccess=$shouldPass;observedSuccess=$passed;passed=$true;diagnostic=$message}
}
function ValidMemory {return [pscustomobject]@{AvailableBytes=[long]16GB;CommitLimit=[long]100GB;CommittedBytes=[long]40GB;PercentCommittedBytesInUse=[uint64]40}}
Case 'valid numeric sample' {MemorySample @((ValidMemory))|Out-Null} $true
foreach($field in 'AvailableBytes','CommitLimit','CommittedBytes','PercentCommittedBytesInUse'){
 $script:field=$field
 Case "missing $field" {$m=ValidMemory;$m.PSObject.Properties.Remove($script:field);MemorySample @($m)|Out-Null} $false
 Case "null $field" {$m=ValidMemory;$m.($script:field)=$null;MemorySample @($m)|Out-Null} $false
 Case "negative $field" {$m=ValidMemory;$m.($script:field)=-1;MemorySample @($m)|Out-Null} $false
 Case "NaN $field" {$m=ValidMemory;$m.($script:field)=[double]::NaN;MemorySample @($m)|Out-Null} $false
 Case "infinite $field" {$m=ValidMemory;$m.($script:field)=[double]::PositiveInfinity;MemorySample @($m)|Out-Null} $false
}
Case 'no sample' {MemorySample @()|Out-Null} $false
Case 'null sample' {MemorySample @($null)|Out-Null} $false
Case 'multiple samples' {MemorySample @((ValidMemory),(ValidMemory))|Out-Null} $false
Case 'string numeric refused' {$m=ValidMemory;$m.CommittedBytes='0';MemorySample @($m)|Out-Null} $false
Case 'boolean refused' {$m=ValidMemory;$m.CommittedBytes=$false;MemorySample @($m)|Out-Null} $false
Case 'zero limit' {$m=ValidMemory;$m.CommitLimit=0;MemorySample @($m)|Out-Null} $false
Case 'committed exceeds limit' {$m=ValidMemory;$m.CommittedBytes=101GB;MemorySample @($m)|Out-Null} $false
Case 'fractional byte count' {$m=ValidMemory;$m.AvailableBytes=1.25;MemorySample @($m)|Out-Null} $false
Case 'uint64 beyond signed range' {$m=ValidMemory;$m.CommitLimit=[uint64]::MaxValue;MemorySample @($m)|Out-Null} $false
Case 'percentage beyond100' {$m=ValidMemory;$m.PercentCommittedBytesInUse=101;MemorySample @($m)|Out-Null} $false
Case 'percentage inconsistent with bytes' {$m=ValidMemory;$m.PercentCommittedBytesInUse=0;MemorySample @($m)|Out-Null} $false
Case 'rounded percentage within1' {$m=ValidMemory;$m.PercentCommittedBytesInUse=39;MemorySample @($m)|Out-Null} $true

# Mock only the external boundaries. Execute actual extracted Gates/Native/Deadline unchanged.
$script:memory=ValidMemory;$script:expireAt='';$script:invocations=0;$script:startRecorded=$false
$script:clock=[pscustomobject]@{startUtcTicks=[DateTime]::UtcNow.Ticks;deadlineUtcTicks=[DateTime]::UtcNow.AddSeconds(300).Ticks;seconds=300}
function Read($p){return $script:clock}
function Test-Path($Path){return $Path-like'*CLOCK.json'}
function Admission {if($script:expireAt-eq'pin'){$script:clock.deadlineUtcTicks=[DateTime]::UtcNow.AddTicks(-1).Ticks}}
function Get-ChildItem {param($LiteralPath,[switch]$Directory) if($LiteralPath.EndsWith('\sdk')){[pscustomobject]@{Name='8.0.318'}}else{[pscustomobject]@{Name='8.0.21'}}}
function Get-CimInstance {param($ClassName,$ErrorAction) if($ClassName-eq'Win32_PerfFormattedData_PerfOS_Memory'){return $script:memory}else{return @()}}
function Get-PSDrive($Name){return [pscustomobject]@{Free=[long]100GB}}
function Save($name,$v){if($name-like'*-START.json'){$script:startRecorded=$true;if($script:expireAt-eq'START'){$script:clock.deadlineUtcTicks=[DateTime]::UtcNow.AddTicks(-1).Ticks}};if($name-like'*-resources.json'-and$script:expireAt-eq'gate'){$script:clock.deadlineUtcTicks=[DateTime]::UtcNow.AddTicks(-1).Ticks}}
$sdk='F:\Unity\6000.5.3f1\Editor\Data\DotNetSdk';$cwd='F:\AnotherLife'
$run="$out\pure-mock-evidence"
[IO.Directory]::CreateDirectory($run)|Out-Null
$dotnet={param([Parameter(ValueFromRemainingArguments)]$Values)$script:invocations++;$global:LASTEXITCODE=0}
$oldCurrent=[Environment]::CurrentDirectory;$oldLocation=(Get-Location).Path;$oldLogo=[Environment]::GetEnvironmentVariable('DOTNET_NOLOGO','Process')
try{
 Set-Location $cwd;[Environment]::CurrentDirectory=$cwd;[Environment]::SetEnvironmentVariable('DOTNET_NOLOGO','true','Process')
 Case 'actual Gates complete sample passes' {Gates 'valid'} $true
 Case 'actual Gates missing committed refuses before census' {$script:memory=ValidMemory;$script:memory.PSObject.Properties.Remove('CommittedBytes');Gates 'missing'} $false
 $script:memory=ValidMemory
 Case 'actual Gates 14GiB headroom refuses' {$script:memory=[pscustomobject]@{AvailableBytes=16GB;CommitLimit=64GB;CommittedBytes=50GB;PercentCommittedBytesInUse=78.125};Gates 'belowFloor'} $false
 Case 'actual Gates exactly80percent refuses' {$script:memory=[pscustomobject]@{AvailableBytes=16GB;CommitLimit=100GB;CommittedBytes=80GB;PercentCommittedBytesInUse=80};Gates 'at80'} $false
 $script:memory=ValidMemory
 foreach($stage in 'pin','gate','START'){
  $script:expireAt=$stage;$script:invocations=0;$script:startRecorded=$false;$script:clock.deadlineUtcTicks=[DateTime]::UtcNow.AddSeconds(300).Ticks
  Case "expiry during $stage refuses invocation" {Native 'mock' @('never-native')} $false
  if($script:invocations-ne0){throw 'Unexpected mocked dispatch after expiry'}
  if(($stage-eq'START')-ne$script:startRecorded){throw 'START boundary evidence incorrect'}
 }
 $script:expireAt='';$script:clock.deadlineUtcTicks=[DateTime]::UtcNow.AddSeconds(300).Ticks;$script:invocations=0
 Case 'unexpired actual Native reaches only mock once' {Native 'mock-positive' @('never-native')} $true
 if($script:invocations-ne1){throw 'Mock invocation count'}
}finally{
 if($null-eq$oldLogo){[Environment]::SetEnvironmentVariable('DOTNET_NOLOGO',[NullString]::Value,'Process')}else{[Environment]::SetEnvironmentVariable('DOTNET_NOLOGO',$oldLogo,'Process')}
 Set-Location $oldLocation;[Environment]::CurrentDirectory=$oldCurrent
}

# Execute the actual top-level finally AST after a forced throw using unique test-only keys.
$tryNode=@($ast.EndBlock.Statements|Where-Object{$_-is[Management.Automation.Language.TryStatementAst]})
if($tryNode.Count-ne1-or$null-eq$tryNode[0].Finally){throw 'Finally AST absent'}
$finallyText=$tryNode[0].Finally.Extent.Text
$cleanup=[scriptblock]::Create('try { throw "sentinel-test" } finally '+$finallyText)
$names=@('AL_SDK252_R002_TEST_ABSENT','AL_SDK252_R002_TEST_EMPTY','AL_SDK252_R002_TEST_VALUE')
$original=@{};foreach($n in $names){$original[$n]=[Environment]::GetEnvironmentVariable($n,'Process')}
try{
 [Environment]::SetEnvironmentVariable($names[0],[NullString]::Value,'Process');[Environment]::SetEnvironmentVariable($names[1],'','Process');[Environment]::SetEnvironmentVariable($names[2],'exact old value','Process')
 $saved=@{};foreach($n in $names){$saved[$n]=[Environment]::GetEnvironmentVariable($n,'Process');[Environment]::SetEnvironmentVariable($n,'changed','Process')}
 $oldLocation=(Get-Location).Path;$oldCurrent=[Environment]::CurrentDirectory
 Set-Location $out;[Environment]::CurrentDirectory=$out
 try{& $cleanup}catch{if($_.Exception.Message-ne'sentinel-test'){throw}}
 Case 'throw-finally restores absent value as absent' {if($null-ne[Environment]::GetEnvironmentVariable($names[0],'Process')){throw 'not absent'}} $true
 Case 'throw-finally restores empty value exactly' {if([Environment]::GetEnvironmentVariable($names[1],'Process')-cne$saved[$names[1]]){throw 'empty mismatch'}} $true
 Case 'throw-finally restores existing value exactly' {if([Environment]::GetEnvironmentVariable($names[2],'Process')-cne'exact old value'){throw 'value mismatch'}} $true
 Case 'throw-finally restores both locations' {if((Get-Location).Path-ne$oldLocation-or[Environment]::CurrentDirectory-ne$oldCurrent){throw 'location mismatch'}} $true
}finally{foreach($n in $names){if($null-eq$original[$n]){[Environment]::SetEnvironmentVariable($n,[NullString]::Value,'Process')}else{[Environment]::SetEnvironmentVariable($n,$original[$n],'Process')}}}
@{status='PURE_AND_MOCK_WRAPPER_CHECKS_ONLY';cases=$results;count=$results.Count;launcherSHA256=(Get-FileHash "$out\Root-Launcher.ps1").Hash;extractedFunctions=@($functions.Keys);finallyAstExtracted=$true;sdkCalls=0;nativeProcesses=0;candidateCasesRun=0;mockDispatches=1;realCimQueries=0;deadlineMutation='In-memory mock clock only; no runtime CLOCK created or changed'}|ConvertTo-Json -Depth 10|Set-Content "$out\WRAPPER_PURE_TESTS.json" -Encoding utf8
Write-Output "$($results.Count) wrapper pure/mock cases passed; zero SDK/native calls."

$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$old='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-v2-sdk31-preparation-20261014-r003'
$oldCandidate='F:\AnotherLife\outputs\LOCAL-DEV-01\celestial-combat-v2-candidates-20261014-r002'
$candidate='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-candidates-20261014-r001'
$oldRun='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-v2-sdk31-run-20261014-r003'
$run='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r001'
function ReadJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json}
function Json($n,$v){$v|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$out\$n" -Encoding utf8}
function Hash($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash}
function Rebind($s){$s.Replace($oldRun,$run).Replace($old,$out).Replace($oldCandidate,$candidate).Replace($oldCandidate.Replace('\','\\'),$candidate.Replace('\','\\'))}
if((Hash "$candidate\PACKET_PINS.json")-ne'AC10C226C897DC7AED7E36D28A2EA0ACE45336C3F5EE5E808272F5ABDDCA8378'){throw 'D3 seal drift'}
foreach($packet in @("$candidate\PACKET_PINS.json","$old\PACKET_PINS.json")){foreach($pin in (ReadJson $packet)){if((Hash $pin.path)-ne$pin.sha256){throw "Pinned member drift: $($pin.path)"}}}
if(Test-Path -LiteralPath $run){throw 'Fresh future runtime already exists'}
foreach($name in 'Root-Launcher.ps1','Review-Compiler.ps1','Compiler-Paths.ps1','Verify-Graph.ps1','CompileEvidence.targets'){
 $s=Rebind (Get-Content -LiteralPath "$old\$name" -Raw)
 if($name-eq'Root-Launcher.ps1'){
  $s=$s.Replace('expectedCases-ne31','expectedCases-ne252').Replace('Count-ne31','Count-ne252').Replace('passed=31 failed=0','passed=252 failed=0').Replace('Count-ne32','Count-ne253').Replace('passed=31;','passed=252;')
  $s=$s.Replace('$a.sourceReview,$a.fixtureDeltaReview,$a.recipeReview','$a.sourceReview,$a.recipeReview')
  $s=$s.Replace("function Read(`$p){Get-Content -LiteralPath `$p -Raw|ConvertFrom-Json}","function Read(`$p){Get-Content -LiteralPath `$p -Raw|ConvertFrom-Json}")
 }
 [IO.File]::WriteAllText("$out\$name",$s)
}
$graph=ReadJson "$old\EXPECTED_GRAPH.json"
$exact=@(ReadJson "$candidate\EXACT_CANDIDATE_FILES.json")
foreach($row in $graph){
 $row.project=Rebind $row.project
 $row.references=@($row.references|ForEach-Object{Rebind $_})
 if($row.name-ne'StoryCombat.Core'){$row.sources=@($exact|Where-Object project -eq $row.project|ForEach-Object source)}
 foreach($f in $row.frameworkReferences){foreach($property in @($f.PSObject.Properties)){$f.($property.Name)=Rebind ([string]$property.Value)}}
}
Json 'EXPECTED_GRAPH.json' $graph
$expect=ReadJson "$old\COMPILER_EXPECTATIONS.json"
$expect.origin='Prospective D3 adaptation of pinned SDK31 r003 compiler operands: candidate paths and exact nine-engine/seven-test source operands only. Same three projects/frameworks/compiler options. Unrun; no observed D3 build claimed.'
foreach($command in $expect.commands){
 $oldRow=@(ReadJson "$old\EXPECTED_GRAPH.json"|Where-Object name -eq $command.project)[0]
 $newRow=@($graph|Where-Object name -eq $command.project)[0]
 $command.normalizedTokens=@($command.normalizedTokens|Where-Object{$oldRow.sources-notcontains$_}|ForEach-Object{Rebind $_})+@($newRow.sources)
}
Json 'COMPILER_EXPECTATIONS.json' $expect
$roster=@(ReadJson "$candidate\EXPECTED_TESTS.json")
if($roster.Count-ne252-or@($roster.name|Sort-Object -Unique).Count-ne252-or@($roster|Where-Object status -ne 'UNRUN').Count){throw 'Roster'}
Json 'EXPECTED_TESTS.json' @($roster.name)
Json 'TEST_ROSTER_PROVENANCE.json' $roster
# Reuse the qualified vendor inventory by its sealed manifest, never regenerate it.
$pins=@(ReadJson "$old\SOURCE_PINS.json")
$pins+=@(Get-ChildItem -LiteralPath $oldRun -File|ForEach-Object{@{path=$_.FullName;sha256=(Hash $_.FullName)}})
$pins+=@(@("$old\PACKET_PINS.json","$old\Root-Launcher.ps1","$old\Review-Compiler.ps1","$old\Compiler-Paths.ps1","$old\Verify-Graph.ps1","$old\EXPECTED_GRAPH.json","$old\COMPILER_EXPECTATIONS.json","$candidate\PACKET_PINS.json","$candidate\EXACT_CANDIDATE_FILES.json","$candidate\EXPECTED_TESTS.json","$candidate\HANDOFF.md",'F:\AnotherLife\outputs\LOCAL-COORD\combat-v2-framework-delta-review-20261014-r001\REVIEW.md','F:\AnotherLife\outputs\LOCAL-COORD\combat-v2-sdk31-recipe-review-20261014-r001\REVIEW.md')|ForEach-Object{@{path=$_;sha256=(Hash $_)}})
$pins+=@($exact|ForEach-Object{@{path=$_.source;sha256=$_.sha256}})
$pins+=@($graph.project|ForEach-Object{@{path=$_;sha256=(Hash $_)}})
$unique=@{};foreach($p in $pins){if((Hash $p.path)-ne$p.sha256){throw "Evidence drift: $($p.path)"};$unique[$p.path]=$p}
Json 'SOURCE_PINS.json' @($unique.Values|Sort-Object path)
# Exact configuration names only, ancestor chains including drive root. No arbitrary drive config reads.
$ancestors=@{};foreach($start in @($graph.project|ForEach-Object{[IO.Path]::GetDirectoryName($_)})+@('F:\AnotherLife')){
 for($dir=$start;$dir;$dir=[IO.Path]::GetDirectoryName($dir)){
  foreach($name in 'Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config'){
   $p=Join-Path $dir $name;$exists=Test-Path -LiteralPath $p
   $ancestors[$p]=@{path=$p;exists=$exists;sha256=$(if($exists){Hash $p}else{$null})}
  }
 }
}
Json 'ANCESTOR_PINS.json' @($ancestors.Values|Sort-Object path)
# This is an inert template, never a Root admission or lease.
Json 'ROOT_ADMISSION.template.json' @{status='HELD';nativeExecutionAuthorized=$false;sourceQaAccepted=$false;sourceReview=@{path=$null;sha256=$null};recipeReview=@{path=$null;sha256=$null};recipePacketSHA256=$null;leaseId=$null;expectedCases=252;maxSdkCalls=9;deadlineSeconds=300;run=$run;candidatePacketSHA256=(Hash "$candidate\PACKET_PINS.json")}
Json 'FOUNDATION_RECEIPT.json' @{scope='Source-only SDK recipe preparation; no gameplay/art production';foundation=@{path='F:\AnotherLife\.agent\WORLD_FOUNDATION.md';sha256=(Hash 'F:\AnotherLife\.agent\WORLD_FOUNDATION.md')};reads=@('Current AGENTS agreement','Relevant shared Foundation Phase1/save/provenance/owner requirements from preceding source specification','D3 HANDOFF and exact source/roster manifests','SDK31 r003 recipe/correction and prior reviews/failure receipts','unity-build-validation SKILL and four mandatory foundation references');nativeExecutionAuthorized=$false;sourceQaAccepted=$false;testsRun=0}
Json 'PREPARATION_STATUS.json' @{status='HELD_FOR_INDEPENDENT_RECIPE_REVIEW_AND_D3_SOURCE_QA';sourceQaAccepted=$false;recipeAccepted=$false;nativeExecutionAuthorized=$false;sdkCalls=0;testsRun=0;expectedCases=252;candidatePacketSHA256=(Hash "$candidate\PACKET_PINS.json");previousReleaseSHA256=(Hash "$oldRun\ROOT_RELEASE.json");runtimeDirectoryExists=(Test-Path -LiteralPath $run)}
Write-Output 'Prepared source-only files; no validation wrapper or SDK invoked.'

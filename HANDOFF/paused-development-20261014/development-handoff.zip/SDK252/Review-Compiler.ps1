param([ValidateSet('preflight','compiled')][string]$Stage='compiled')
$ErrorActionPreference='Stop'
$prep=$PSScriptRoot
$run='F:\AnotherLife\outputs\LOCAL-DEV-01\combat-d3-sdk252-run-20261014-r002'
. "$prep\Compiler-Paths.ps1"
function ReadJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json}
function CheckPin($pin){AssertPlain (FullPath $pin.path 'F:\AnotherLife');if((Get-FileHash -LiteralPath $pin.path).Hash-ne$pin.sha256){throw "Pin drift: $($pin.path)"}}
function Deadline {if($Stage-eq'compiled'){$c=ReadJson "$run\CLOCK.json";if(([long]$c.deadlineUtcTicks-[long]$c.startUtcTicks)-ne[TimeSpan]::FromSeconds(300).Ticks-or[DateTime]::UtcNow.Ticks-ge[long]$c.deadlineUtcTicks){throw 'Original300 deadline'}}}
$files=@{}
function Evidence($path){$path=FullPath $path 'F:\AnotherLife';AssertPlain $path;$files[$path]=(Get-FileHash -LiteralPath $path).Hash}
foreach($pin in (ReadJson "$prep\SOURCE_PINS.json")){CheckPin $pin}
foreach($pin in (ReadJson "$prep\PACKET_PINS.json")){CheckPin $pin}
# Resolve existing runtime metadata types only. Never Add-Type or load the candidate assemblies.
if($null-eq('System.Reflection.PortableExecutable.PEReader' -as[type])-or$null-eq('System.Reflection.Metadata.MetadataReaderProvider' -as[type])){throw 'Existing metadata reader unavailable'}
$inventory=ReadJson 'F:\AnotherLife\outputs\LOCAL-WEB\mode-progression-sdk-preparation-20261014-r002\SDK_REFERENCE_PINS.json'
$known=@{};foreach($pin in $inventory.files){$known[$pin.path]=$pin.sha256}
if($Stage-eq'preflight'){@{accepted=$true;scope='PIN_AND_EXISTING_METADATA_TYPE_PREFLIGHT_ONLY';sdkCalls=0}|ConvertTo-Json;return}
Deadline
$rows=@(ReadJson "$prep\EXPECTED_GRAPH.json")
$graph=[pscustomobject]@{projects=@($rows|ForEach-Object{[pscustomobject]@{project=$_.name;projectPath=$_.project;compile=$_.sources;targetFramework=$_.framework}})}
$expectedSdk=@('restore','build');foreach($row in $rows){$expectedSdk+="pre-$($row.name)";$expectedSdk+="post-$($row.name)"}
# Explicit eight SDK receipts; the separately named observer receipt never enters this set.
$receiptNames=@(Get-ChildItem $run -Filter '*-EXIT.json'|ForEach-Object{$_.BaseName.Replace('-EXIT','')})
SameSet $receiptNames $expectedSdk 'eight SDK receipts'
foreach($phase in $expectedSdk){$f="$run\$phase-EXIT.json";if((ReadJson $f).exit-ne0){throw 'SDK failure'};Evidence $f}
if((ReadJson "$run\COMPILER_PREFLIGHT.observer.json").exit-ne0){throw 'Preflight observer failure'}
Evidence "$run\COMPILER_PREFLIGHT.observer.json"
$expect=ReadJson "$prep\COMPILER_EXPECTATIONS.json"
$commands=@(ReadCommands $run $prep $graph);$results=@()
foreach($command in $commands){
 Deadline
 $row=$rows|Where-Object name -eq $command.project;$n=$row.name
 $wanted=@($expect.commands|Where-Object project -eq $n);if($wanted.Count-ne1){throw 'Missing operand expectation'}
 SameSet $command.normalizedTokens $wanted[0].normalizedTokens "$n exact compiler operands"
 foreach($input in $command.inputs){
  $path=$input.path;AssertPlain $path
  if($known.ContainsKey($path)){CheckPin @{path=$path;sha256=$known[$path]}}
  elseif($path.StartsWith($run+'\',[StringComparison]::OrdinalIgnoreCase)){
   if($input.kind-eq'reference'){
    $producer=@($rows|Where-Object{$path-eq"$run\artifacts\bin\$($_.name)\debug\$($_.name).dll"})
    if($producer.Count-ne1-or$row.references-notcontains$producer[0].project){throw 'Unexpected sibling reference'}
    $other="$run\artifacts\obj\$($producer[0].name)\debug\$($producer[0].name).dll"
    if((Get-FileHash $path).Hash-ne(Get-FileHash $other).Hash){throw 'Reference copy mismatch'};Evidence $other
   }elseif($input.kind-notin@('sourcelink','analyzerconfig')){throw 'Unexpected generated compiler input'}
  }else{throw "Unpinned compiler input: $path"}
  Evidence $path
 }
 foreach($stageName in 'pre','post'){
  $ef="$run\$stageName-$n.log";$eval=ReadJson $ef;Evidence $ef
  SameSet @($eval.Items.Compile.FullPath) $row.sources "$n evaluated sources"
  foreach($import in @($eval.Properties.MSBuildAllProjects.Split(';')|Where-Object{$_}|Sort-Object -Unique)){
   $import=FullPath $import 'F:\AnotherLife';AssertPlain $import
   if($known.ContainsKey($import)){CheckPin @{path=$import;sha256=$known[$import]}}
   elseif($import-eq"$prep\CompileEvidence.targets"-or$import-eq$row.project){}
   elseif($import-eq"$run\artifacts\obj\$n\$n.csproj.nuget.g.targets"-or$import-eq"$run\artifacts\obj\$n\$n.csproj.nuget.g.props"){
    [xml]$nx=Get-Content $import -Raw;if(@($nx.SelectNodes('//*[local-name()="Import"]')).Count){throw 'Unexpected package import'}
   }else{throw "Unqualified reported import: $import"};Evidence $import
  }
 }
 foreach($f in @($command.output,$command.output.Replace('.dll','.pdb'),"$run\artifacts\bin\$n\debug\$n.dll","$run\artifacts\bin\$n\debug\$n.pdb")){Evidence $f}
 foreach($ext in 'dll','pdb'){if($files["$run\artifacts\obj\$n\debug\$n.$ext"]-ne$files["$run\artifacts\bin\$n\debug\$n.$ext"]){throw 'Bin/obj mismatch'}}
 foreach($source in @($command.product)+@($command.generated)){Evidence $source}
 $binding=ReadPdbBinding $command.output @($command.product+$command.generated)
 $af="$run\artifacts\obj\$n\project.assets.json";$assets=ReadJson $af;Evidence $af
 $expectedLibraries=@($row.references|ForEach-Object{[IO.Path]::GetFileNameWithoutExtension($_)+'/1.0.0'})
 SameSet @($assets.libraries.PSObject.Properties|ForEach-Object{$_.Name}) $expectedLibraries "$n assets project libraries"
 foreach($lib in $assets.libraries.PSObject.Properties){if($lib.Value.type-ne'project'){throw 'Package in assets'}}
 foreach($tf in $assets.targets.PSObject.Properties){SameSet @($tf.Value.PSObject.Properties|ForEach-Object{$_.Name}) $expectedLibraries "$n assets target closure"}
 SameSet @($assets.packageFolders.PSObject.Properties|ForEach-Object{$_.Name}|ForEach-Object{$_.TrimEnd('\')}) @("$run\NUGET_PACKAGES") "$n package cache"
 $df="$run\artifacts\bin\$n\debug\$n.deps.json";$deps=ReadJson $df;Evidence $df
 $depsLibraries=@("$n/1.0.0")+$expectedLibraries
 SameSet @($deps.libraries.PSObject.Properties|ForEach-Object{$_.Name}) $depsLibraries "$n deps libraries"
 foreach($lib in $deps.libraries.PSObject.Properties){if($lib.Value.type-ne'project'){throw 'Package in deps'}}
 $baseTarget=if($row.framework-eq'net8.0'){'.NETCoreApp,Version=v8.0'}else{'.NETStandard,Version=v2.1'}
 if($deps.runtimeTarget.name-notin@($baseTarget,$baseTarget+'/')){throw 'Unexpected deps runtime target'}
 foreach($tf in $deps.targets.PSObject.Properties){
  $names=@($tf.Value.PSObject.Properties|ForEach-Object{$_.Name})
  if($tf.Name-eq$deps.runtimeTarget.name){SameSet $names $depsLibraries "$n deps runtime closure"}
  elseif($tf.Name-ne$baseTarget-or$names.Count){throw 'Unexpected extra deps target'}
  foreach($lib in $tf.Value.PSObject.Properties){
   $assembly=$lib.Name.Split('/')[0]+'.dll'
   $runtime=$lib.Value.PSObject.Properties['runtime'];if($null-eq$runtime){throw 'Runtime entry absent'}
   SameSet @($runtime.Value.PSObject.Properties|ForEach-Object{$_.Name}) @($assembly) "$n deps assembly"
   if($null-ne$lib.Value.PSObject.Properties['native']-or$null-ne$lib.Value.PSObject.Properties['runtimeTargets']){throw 'Unexpected native/runtime assets'}
  }
 }
 if($row.framework-eq'net8.0'){
  $rf="$run\artifacts\bin\$n\debug\$n.runtimeconfig.json";$rc=ReadJson $rf;Evidence $rf
  if($rc.runtimeOptions.tfm-ne'net8.0'-or$rc.runtimeOptions.framework.name-ne'Microsoft.NETCore.App'-or$rc.runtimeOptions.framework.version-ne'8.0.0'){throw 'Unexpected runtime framework'}
 }
 $results+=@{project=$n;authoredSources=$command.product.Count;generatedSources=$command.generated.Count;rawCommandSHA256=$command.rawCommandSHA256;pdbBinding=$binding}
}
Evidence "$run\build.log";Evidence "$run\build.binlog";Evidence "$run\CLOCK.json"
Deadline
@{accepted=$true;recipePacketSHA256=(Get-FileHash "$prep\PACKET_PINS.json").Hash;cscOperandsVerified=$true;importsVerified=$true;depsAssetsVerified=$true;pePdbLinksVerified=$true;sourceDocumentsVerified=$true;sdkReferenceBaselineVerified=$true;sdkCalls=8;observerCount=1;projects=$results;files=@($files.Keys|Sort-Object|ForEach-Object{@{path=$_;sha256=$files[$_]}});limits='Imports verified against reported MSBuildAllProjects and pinned SDK; this is not a complete transitive import trace. Generated source paths/counts and PDB checksums are exact; generated semantics are not preapproved. No assembly loading, SDK call, child process, or artifact mutation by this helper.'}|ConvertTo-Json -Depth 12
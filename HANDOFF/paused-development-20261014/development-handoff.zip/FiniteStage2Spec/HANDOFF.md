# Stage 2 specification handoff

Deliverable is SPEC.md and the exact 46-path proposed maximum footprint. No Stage 2 code or runtime test was authored. Stage 1 remains sealed and source accepted,16 unrun. Fourteen source/closure/security references are pinned. Account XML25 and transfer4 are proposals only; canonical ledger unchanged. Training22 defaults false. Root must approve footprint and reserve formats after source-capture pause release and pin recheck.

Reuse the accepted joint Story23/Tower24 writer closure with current canonical App security postimages. The ordinary catalog-owned public Create/read projection and all-writer finite completion admission are one bounded integration. Keep unsupported card rewards and missing enrollment/content unavailable. Include separately qualified client plugin successors with source provenance/freshness and counter/reason readback; old DLLs do not establish finite support. Manual effectsV2 is separate and finite Damage/Heal is not all120 kits.

Storage reservation does not solve global16MiB/10000-node lifetime capacity or20k-account scaling. Active-v1 continuation remains Stage3. Starter owned-five development qualification is first; full Phase1 requirements remain.

Validation performed here: F path/ancestor reparse/capacity/write/read/rename checks, JSON parse, exact footprint uniqueness, source-pin/preimage recheck and packet hashes. No compiler, SDK, runtime, Unity or device test. No canonical mutation or format allocation. Outputs are for Root review; no implementation/native admission inferred.
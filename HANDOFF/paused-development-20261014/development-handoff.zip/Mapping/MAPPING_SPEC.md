# Owned Story mapping completeness — scoped Stage 2 handoff

This packet defines mapping checks against IMPLEMENTATION_SPEC.json.normalComposition.inputContract and current Unity consumers. The inspected backend contract is still a proposal; no KingdomStoryCatalog implementation/runtime schema or admitted response values were found in the scoped backend Story packets. Do not mistake proposed field semantics below for final JSON property names. No display catalog is authored here.

## Exact joins

| Display role | Authoritative identity | Required coverage |
|---|---|---|
| Stage | AccountStoryState.Stages[].StageId; active Entry.Command.StageId == Journal.Input.ContentId | Selected catalog stage, exact DefinitionRevision == frozen ContentVersion |
| Hero | Journal.Input.Heroes[].DefinitionId | All eligible hero definitions for the admitted stage, then every frozen party member; NOT InstanceId/acquisition ID |
| Skill | Each admitted hero definition's Skills[].Id; frozen Hero.Skills[].Id | Union across eligible definitions and all turns, not only the currently selected actor |
| Enemy | Selected encounter enemies' DefinitionId; frozen Input.Enemies[].DefinitionId | Every encounter variant; target index identifies an instance, not its art |
| Reward | AccountStoryTerminal.Grants[].Items[].DefinitionId | Union of actual supported first-clear/repeat/terminal terms; quantity remains server-supplied |

Top-level display catalogRevision/contentId/definitionRevision must equal the server-pinned catalog revision/selected stage ID/definition revision. Separately pin hero DefinitionVersion, engine version, runtime catalog source hash, visual source/hash and approval provenance in the mapping receipt; the sealed display schema has no slots for these extra provenance fields. Never add unknown fields to its strict JSON.

Coverage rule: required keys minus mapped keys must be empty. Required keys come from the validated server catalog, including every eligible owned definition and reachable skill for that bounded stage. A five-starter inventory alone is insufficient if the server admits other owned definitions. Repeated hero/enemy definitions share a display key while retaining distinct instance/target identities. One kind/id mapping cannot represent conflicting version-dependent art or labels; diagnose conflicts instead of last-write-wins.

## Current compatibility edges

- Ready BindAsync checks the stage and rows supplied, but cannot verify all future combat IDs. A stage-only catalog can bind and still be incomplete. Enforce the complete source join before route activation, then cross-check the frozen attempt.
- Active BindAsync checks all frozen heroes/skills/enemies, but reward rows are not checked against all possible terminal rewards. AccountStoryFlowHost falls back to rewardUnknown when a label is absent; that fallback is not completeness acceptance.
- The adapter permits one configured stage and rejects another unlocked stage on a ready read. Backend Stage 2 proposes up to600 views. Do not truncate/filter server rows to force compatibility. Multiple unlocked stages need a separately bounded adapter successor, or a genuinely one-stage server qualification scope.
- Backend continuation may retain an older frozen attempt after new-entry catalog replacement/removal. The current adapter demands the read state's catalog/stage/definition match its configured triple. A differing current read catalog must remain unavailable until a frozen-version mapping selection successor is reviewed. Do not rewrite old attempt IDs/revisions.
- entries <=256, rewards <=64 and UTF-8 JSON <=131072 bytes are adapter limits, not evidence of whole-game fit. Partitioning/selection is future work if the actual bounded map exceeds them.
- Combat view labels must remain nonblank and <=160 characters after the adapter adds the Stage prefix ("PROVISIONAL · " / "임시 콘텐츠 · "). Check both locales. Structural JSON acceptance alone does not enforce the view limit.
- Unknown skill effects, engines and reward kinds are backend capability failures. Presentation must not conceal them by relabeling a generic attack or a resource as a card.

## Five inspected provisional portrait sources

All five PNGs under Resources/DevelopmentGacha/Heroes were visually inspected. They show adult full-body figures, grounded cloth/leather equipment, distinct weapons and no conspicuous high-rarity emission. This is a provisional source observation, not final art or device acceptance.

| Definition ID | Observed visual cues | Readability check to retain |
|---|---|---|
| normal_vanguard_01 | Blue/cream padded equipment, sword and large shield | Shield silhouette and sword at small card scale |
| normal_sharpshooter_01 | Blue/cream tunic, bow and quiver | Bow/quiver remain distinguishable from vanguard |
| normal_archmage_01 | Green/cream robes, leaf staff, book | Book/staff differentiate it from lifewarden |
| normal_lifewarden_01 | Green/cream robes, vine staff, belt bottles and pouch | Similar palette/staff silhouette requires actual small-card comparison |
| normal_shadowblade_01 | Dark violet gear, two daggers, violet skin | Dark silhouette and daggers remain readable against battle background |

Each proposed resource key is DevelopmentGacha/Heroes/<definitionId>, without extension, conditional on the actual runtime definition join. Every inspected meta has textureType:0 and spriteMode:1. Existing DevelopmentGachaPanel/DevelopmentHeroCollectionView load Texture2D then Sprite.Create. The sealed adapter defaults to Resources.Load<Sprite>, so these paths are NOT load-qualified. A native read must prove sprite loading; if it fails, allocate exact importer changes or a bounded owned texture-to-sprite lifecycle separately. This packet changes neither and supplies no loader override. Sprite-mode metadata alone is insufficient.

No actual server-selected enemy/skill/reward visual IDs exist in this inspected handoff. Do not reuse these hero portraits as enemy/skill placeholders or invent those rows.

## Required next data handoff

Backend supplies the exact admitted runtime source/hash and normal-factory read values; selected stage and definition; supported engine; eligible hero definition versions and skill IDs; enemy variants; supported reward DefinitionIds; and catalog-bound visual IDs/provenance. Record actual values only then. TEST_MATRIX.json is the bounded acceptance matrix to apply to that handoff, not an executed test suite.

Both accepted source packets remain immutable: adapter30 tests and Boot26 tests are still unrun. No canonical writes, compiler/native execution or content activation occurred.
